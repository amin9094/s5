#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.backup_service import (  # noqa: E402
    create_operational_backup,
    create_payload_backup,
    prune_operational_backups,
    upload_external_backup,
)
from core.db import load_db  # noqa: E402


async def _run() -> Path:
    if SETTINGS.database_url:
        target = create_payload_backup(
            load_db(),
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
        )
    else:
        if not SETTINGS.db_file.is_file():
            # SQLite is initialized lazily by core.db; force initialization once.
            load_db()
        target = create_operational_backup(
            SETTINGS.db_file,
            SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
        )
    prune_operational_backups(SETTINGS.backup_dir, keep=30)
    if SETTINGS.external_backup_url:
        await upload_external_backup(target, SETTINGS.external_backup_url)
    return target


def main() -> int:
    target = asyncio.run(_run())
    print(f"Backup created: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
