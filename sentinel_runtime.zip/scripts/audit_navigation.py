"""Offline audit of literal buttons and Back targets against actual handlers.

Dynamic IDs, permission combinations and Telegram behavior need integration
tests; this report deliberately does not claim those are proven by AST checks.
"""
from __future__ import annotations
import ast
import json
import os
from pathlib import Path
import re
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    with tempfile.TemporaryDirectory(prefix='sentinel-nav-') as folder:
        os.environ.update(BOT_TOKEN='123456789:'+'A'*32,DATABASE_URL='',POSTGRES_URL='',REDIS_URL='',
                          DB_FILE=f'{folder}/db.sqlite3',PERSISTENT_DATA_DIR=folder,LOG_DIR=f'{folder}/logs')
        from telegram.ext import CallbackQueryHandler, ConversationHandler
        import bot
        from handlers.callback_routes import callback_routes
        app=bot.build_application(); patterns=[]
        def scan(handler):
            if isinstance(handler,CallbackQueryHandler) and handler.pattern:patterns.append(handler.pattern)
            if isinstance(handler,ConversationHandler):
                for child in handler.entry_points+handler.fallbacks+[h for rows in handler.states.values() for h in rows]:scan(child)
        for rows in app.handlers.values():
            for handler in rows:scan(handler)
        global_patterns=[re.compile(pattern) for pattern,fn in callback_routes(vars(bot)) if fn.__name__!='navigation_back']
        buttons=0; backs=0; dynamic=0; missing={}; oversized={}; back_missing={}
        for root in ('bot_runtime','ui'):
            for path in (ROOT/root).rglob('*.py'):
                tree=ast.parse(path.read_text())
                for node in ast.walk(tree):
                    if isinstance(node,ast.keyword) and node.arg=='callback_data':
                        if isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):
                            value=node.value.value;buttons+=1;location=f'{path.relative_to(ROOT)}:{node.value.lineno}'
                            if not any(p.match(value) for p in patterns):missing.setdefault(value,[]).append(location)
                            if len(value.encode())>64:oversized.setdefault(value,[]).append(location)
                        else:dynamic+=1
                    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='back' and node.args and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):
                        target=node.args[0].value;backs+=1
                        if not any(p.match(target) for p in global_patterns) and not target.startswith('sig_back:'):
                            back_missing.setdefault(target,[]).append(f'{path.relative_to(ROOT)}:{node.lineno}')
        result={'literal_buttons_checked':buttons,'literal_back_targets_checked':backs,
                'distinct_handler_patterns':len(set(p.pattern for p in patterns)),
                'dynamic_button_expressions_requiring_runtime_tests':dynamic,
                'unmatched_buttons':missing,'unmatched_back_targets':back_missing,'oversized_callbacks':oversized}
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        return int(bool(missing or back_missing or oversized))


if __name__=='__main__':raise SystemExit(main())
