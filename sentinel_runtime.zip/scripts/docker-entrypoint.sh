#!/bin/sh
set -eu

cd /app

PERSISTENT_DATA_DIR_VALUE="${PERSISTENT_DATA_DIR:-${RAILWAY_VOLUME_MOUNT_PATH:-${VOLUME_MOUNT_PATH:-}}}"
if [ -z "$PERSISTENT_DATA_DIR_VALUE" ] && [ -n "${RAILWAY_ENVIRONMENT:-}" ] && [ -d /data ]; then
    PERSISTENT_DATA_DIR_VALUE=/data
fi
DATA_ROOT_VALUE="${PERSISTENT_DATA_DIR_VALUE:-data}"
DB_FILE_VALUE="${DB_FILE:-$DATA_ROOT_VALUE/sentinel.sqlite3}"
LOG_DIR_VALUE="${LOG_DIR:-logs}"
BACKUP_DIR_VALUE="${BACKUP_DIR:-$DATA_ROOT_VALUE/backups}"
HEARTBEAT_FILE_VALUE="${HEARTBEAT_FILE:-$DATA_ROOT_VALUE/heartbeat.json}"
PERSISTENCE_FILE_VALUE="${PERSISTENCE_FILE:-$DATA_ROOT_VALUE/telegram-state.sqlite3}"
METRICS_FILE_VALUE="${METRICS_FILE:-$DATA_ROOT_VALUE/metrics.json}"
SUPPORT_ATTACHMENT_DIR_VALUE="${SUPPORT_ATTACHMENT_STORAGE_DIR:-${PERSISTENT_DATA_DIR_VALUE:+$PERSISTENT_DATA_DIR_VALUE/support_attachments}}"
SIGNAL_TEMPLATE_DIR_VALUE="${SIGNAL_TEMPLATE_STORAGE_DIR:-${PERSISTENT_DATA_DIR_VALUE:+$PERSISTENT_DATA_DIR_VALUE/signal_templates}}"
if [ -n "${RECEIPT_STORAGE_DIR:-}" ]; then
    RECEIPT_DIR_VALUE="$RECEIPT_STORAGE_DIR"
elif [ -n "$PERSISTENT_DATA_DIR_VALUE" ]; then
    RECEIPT_DIR_VALUE="$PERSISTENT_DATA_DIR_VALUE/payment_receipts"
else
    RECEIPT_DIR_VALUE="$(dirname "$DB_FILE_VALUE")/payment_receipts"
fi

absolute_path() {
    case "$1" in /*) printf '%s\n' "$1" ;; *) printf '/app/%s\n' "$1" ;; esac
}
canonical_path() {
    readlink -m "$1"
}

DB_PATH="$(canonical_path "$(absolute_path "$DB_FILE_VALUE")")"
LOG_PATH="$(canonical_path "$(absolute_path "$LOG_DIR_VALUE")")"
BACKUP_PATH="$(canonical_path "$(absolute_path "$BACKUP_DIR_VALUE")")"
HEARTBEAT_PATH="$(canonical_path "$(absolute_path "$HEARTBEAT_FILE_VALUE")")"
PERSISTENCE_PATH="$(canonical_path "$(absolute_path "$PERSISTENCE_FILE_VALUE")")"
METRICS_PATH="$(canonical_path "$(absolute_path "$METRICS_FILE_VALUE")")"
RECEIPT_PATH="$(canonical_path "$(absolute_path "$RECEIPT_DIR_VALUE")")"
SUPPORT_ATTACHMENT_PATH="$(canonical_path "$(absolute_path "${SUPPORT_ATTACHMENT_DIR_VALUE:-$(dirname "$DB_FILE_VALUE")/support_attachments}")")"
SIGNAL_TEMPLATE_PATH="$(canonical_path "$(absolute_path "${SIGNAL_TEMPLATE_DIR_VALUE:-$(dirname "$DB_FILE_VALUE")/signal_templates}")")"

# Never recursively change ownership outside explicitly approved runtime roots.
# Operators may extend this list for a mounted volume, but cannot use / or /app.
ALLOWED_ROOTS="${SENTINEL_ALLOWED_STORAGE_ROOTS:-/app/data:/app/logs:/mnt/data:/data:/var/lib/sentinel}"
validate_directory() {
    candidate="$(canonical_path "$1")"
    case "$candidate" in /|/app|/usr|/etc|/var|/home|/root) echo "Unsafe storage directory: $candidate" >&2; exit 78 ;; esac
    old_ifs="$IFS"
    IFS=':'
    allowed=0
    for raw_root in $ALLOWED_ROOTS; do
        root="$(canonical_path "$raw_root")"
        case "$root" in /|/app|/usr|/etc|/var|/home|/root|'') continue ;; esac
        case "$candidate/" in "$root/"*) allowed=1; break ;; esac
    done
    IFS="$old_ifs"
    if [ "$allowed" -ne 1 ]; then
        echo "Storage directory is outside SENTINEL_ALLOWED_STORAGE_ROOTS: $candidate" >&2
        exit 78
    fi
}

DB_DIR="$(dirname "$DB_PATH")"
HEARTBEAT_DIR="$(dirname "$HEARTBEAT_PATH")"
PERSISTENCE_DIR="$(dirname "$PERSISTENCE_PATH")"
METRICS_DIR="$(dirname "$METRICS_PATH")"
for directory in "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"; do
    validate_directory "$directory"
done

mkdir -p "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"
if [ "$(id -u)" -eq 0 ]; then
    for directory in "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"; do
        chown sentinel:sentinel "$directory"
        chmod 0700 "$directory"
    done
    # Repair only managed state files, without following symlinks or changing
    # ownership of unrelated files elsewhere on a mounted volume.
    for state_file in "$DB_PATH" "$DB_PATH-wal" "$DB_PATH-shm" "$PERSISTENCE_PATH" "$PERSISTENCE_PATH-wal" "$PERSISTENCE_PATH-shm" "$HEARTBEAT_PATH" "$METRICS_PATH"; do
        if [ -L "$state_file" ]; then
            echo "Refusing symbolic-link state file: $state_file" >&2
            exit 78
        fi
        if [ -f "$state_file" ]; then
            chown sentinel:sentinel "$state_file"
            chmod 0600 "$state_file"
        fi
    done
fi

umask 077
if [ "$#" -eq 0 ]; then set -- python main.py; fi
if [ "$(id -u)" -eq 0 ]; then exec gosu sentinel "$@"; fi
exec "$@"
