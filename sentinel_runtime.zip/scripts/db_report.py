from __future__ import annotations

import argparse
import json
from collections import defaultdict

from core.db import database_catalog


def main() -> int:
    parser = argparse.ArgumentParser(description="SENTINEL categorized database report")
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON")
    args = parser.parse_args()
    report = database_catalog()
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print(f"Backend: {report['backend']}")
    print(f"Schema: {report['schema_version']} / categorized storage: {report['relational_storage_version']}")
    print(f"State version: {report['state_version']}")
    print(f"Users: {report['users']} | Profiles: {report['user_profiles']} | Memberships: {report['active_or_historical_memberships']}")
    print(f"Logical sections: {report['section_count']}")
    grouped: dict[str, list[dict]] = defaultdict(list)
    for item in report["sections"]:
        grouped[str(item["domain"])].append(item)
    for domain in sorted(grouped):
        print(f"\n[{domain}] ({report['domain_totals'].get(domain, 0)} records)")
        for item in grouped[domain]:
            print(f"  - {item['section']}: {item['records']} ({item['container']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
