#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.async_db import async_snapshot, async_with_db  # noqa: E402
from core.db import SCHEMA_VERSION  # noqa: E402
from core.shared_cache import shared_cache_healthcheck  # noqa: E402
from modules.crypto_prices import fetch_crypto_quote  # noqa: E402
from modules.signal_image import create_signal_image  # noqa: E402


def offline_contract() -> dict[str, Any]:
    seed = json.loads((ROOT / "data" / "database.json").read_text(encoding="utf-8"))
    if int(seed.get("schema_version", 0) or 0) != SCHEMA_VERSION:
        raise RuntimeError("seed database schema does not match the application schema")
    return {
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "storage": "postgres" if SETTINGS.database_url else "sqlite",
        "schema_version": SCHEMA_VERSION,
        "staging_public_configured": bool(SETTINGS.staging_public_channel_id),
        "staging_private_configured": bool(SETTINGS.staging_private_channel_id),
        "live_ready": bool(
            SETTINGS.bot_token
            and SETTINGS.staging_public_channel_id
            and SETTINGS.staging_private_channel_id
        ),
    }


async def check_channel(bot: Any, chat_id: int, label: str, *, invite_test: bool) -> dict[str, Any]:
    me = await bot.get_me()
    membership = await bot.get_chat_member(chat_id, me.id)
    status = str(getattr(membership, "status", ""))
    if status not in {"administrator", "creator"}:
        raise RuntimeError(f"{label}: bot is not an administrator")
    message = await bot.send_message(
        chat_id=chat_id,
        text=(
            "🧪 SENTINEL STAGING SMOKE\n"
            f"{datetime.now(UTC).isoformat()}\n"
            "This message will be removed automatically."
        ),
        disable_notification=True,
    )
    await bot.delete_message(chat_id=chat_id, message_id=message.message_id)
    preview_path = Path(
        create_signal_image(
            "BTCUSDT",
            "70000 - 70200",
            ["71000", "72000", "73500"],
            "69000",
            "BUY",
            "1",
        )
    )
    try:
        with preview_path.open("rb") as preview:
            signal_message = await bot.send_photo(
                chat_id=chat_id,
                photo=preview,
                caption="SENTINEL staging signal render smoke",
                disable_notification=True,
            )
        await bot.delete_message(chat_id=chat_id, message_id=signal_message.message_id)
    finally:
        preview_path.unlink(missing_ok=True)
    invite_result = "skipped"
    if invite_test:
        invite = await bot.create_chat_invite_link(
            chat_id=chat_id,
            name="SENTINEL staging smoke",
            member_limit=1,
        )
        await bot.revoke_chat_invite_link(chat_id=chat_id, invite_link=invite.invite_link)
        invite_result = "created_and_revoked"
    return {
        "label": label,
        "chat_id": chat_id,
        "bot_status": status,
        "message_roundtrip": "ok",
        "signal_image_roundtrip": "ok",
        "invite_roundtrip": invite_result,
    }


async def _database_roundtrip() -> str:
    nonce = uuid.uuid4().hex
    await async_with_db(
        lambda db: db.setdefault("staging_smoke_checks", {}).update(
            {nonce: {"created_at": datetime.now(UTC).isoformat()}}
        )
    )
    stored = (await async_snapshot()).get("staging_smoke_checks", {}).get(nonce)
    if not isinstance(stored, dict):
        raise RuntimeError("database staging roundtrip failed")
    await async_with_db(lambda db: db.setdefault("staging_smoke_checks", {}).pop(nonce, None))
    return "write_read_delete"


async def live_smoke(*, provider_checks: bool = False) -> None:
    from telegram import Bot
    SETTINGS.validate()
    if not SETTINGS.staging_public_channel_id or not SETTINGS.staging_private_channel_id:
        raise RuntimeError(
            "STAGING_PUBLIC_CHANNEL_ID and STAGING_PRIVATE_CHANNEL_ID are required for live smoke"
        )
    async with Bot(SETTINGS.bot_token) as bot:
        me = await bot.get_me()
        public = await check_channel(
            bot,
            SETTINGS.staging_public_channel_id,
            "public",
            invite_test=True,
        )
        private = await check_channel(
            bot,
            SETTINGS.staging_private_channel_id,
            "private",
            invite_test=False,
        )
    database = await _database_roundtrip()
    cache = await shared_cache_healthcheck(require_redis=bool(SETTINGS.redis_url))
    provider = "skipped"
    if provider_checks:
        quote = await fetch_crypto_quote("bitcoin", force=True)
        if quote.price_usd <= 0 or not quote.identity_verified:
            raise RuntimeError("identity-verified crypto provider smoke failed")
        provider = f"{quote.source}:{quote.provider_asset_id or quote.coin_id}"
    print(
        f"LIVE STAGING SMOKE OK: @{me.username}; "
        f"public={public['message_roundtrip']}/{public['signal_image_roundtrip']}/{public['invite_roundtrip']}; "
        f"private={private['message_roundtrip']}/{private['signal_image_roundtrip']}; "
        f"database={database}; cache={cache['backend']}; provider={provider}"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--offline", action="store_true")
    mode.add_argument("--live", action="store_true")
    parser.add_argument(
        "--provider-checks",
        action="store_true",
        help="also verify an identity-safe live crypto quote",
    )
    args = parser.parse_args()
    if args.offline:
        result = offline_contract()
        print(
            "OFFLINE STAGING CONTRACT OK: "
            f"version={result['version']}; storage={result['storage']}; "
            f"schema={result['schema_version']}; live_ready={result['live_ready']}"
        )
        return 0
    asyncio.run(live_smoke(provider_checks=args.provider_checks))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
