from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from core.db import with_db
from repositories.v2.commerce import CommerceRepository

logger = logging.getLogger(__name__)


def _parse(value: Any) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except (TypeError, ValueError):
        return None


def merge_entitlement_rows(
    db: dict[str, Any],
    rows: list[dict[str, Any]],
    *,
    now: datetime | None = None,
) -> int:
    """Project normalized memberships into the Telegram compatibility section.

    The normalized entitlement table remains the source of truth.  This
    projection is idempotent and preserves channel-removal retry metadata so a
    reconciliation pass cannot accidentally lose Telegram access-control state.
    """
    current_time = now or datetime.now(UTC)
    memberships = db.setdefault("vip_users", {})
    changed = 0
    for row in rows:
        uid = str(row.get("user_id") or "").strip()
        expires = _parse(row.get("expires_at"))
        if not uid or expires is None:
            continue
        previous = memberships.get(uid) if isinstance(memberships.get(uid), dict) else {}
        status = "active" if str(row.get("status") or "active") == "active" and expires > current_time else "expired"
        projected = {
            **previous,
            "status": status,
            "expires_at": expires.astimezone(UTC).isoformat(),
            "source_order_id": str(row.get("order_id") or previous.get("source_order_id") or "") or None,
            "normalized_entitlement": True,
            "normalized_updated_at": str(row.get("updated_at") or ""),
            "invite_link": str(row.get("invite_link") or previous.get("invite_link") or "") or None,
        }
        if status == "active":
            projected.update({
                "channel_removed_at": None,
                "channel_removal_status": None,
                "channel_removal_phase": None,
                "channel_removal_next_retry_at": None,
            })
        elif not projected.get("channel_removed_at"):
            projected.update({
                "channel_removal_status": projected.get("channel_removal_status") or "pending",
                "channel_removal_phase": projected.get("channel_removal_phase") or "ban",
            })
        if projected != previous:
            memberships[uid] = projected
            changed += 1
    return changed


def project_normalized_entitlements_to_legacy(user_id: int | str | None = None) -> int:
    """Disabled in v8.15.0: normalized entitlements are authoritative."""
    return 0
