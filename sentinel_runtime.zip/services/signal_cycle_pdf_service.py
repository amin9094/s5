from __future__ import annotations

import os
from io import BytesIO
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from core.rtl_text import visual_rtl
from modules.signal_portal import signal_cycle_rows, signal_cycle_summary, signal_display_number

FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
_FONT_READY = False


def _font_candidates() -> list[tuple[Path, Path]]:
    """Return Unicode font pairs in deployment-preference order.

    Railway installs DejaVu at the first pair below.  The additional pairs
    keep local quality gates and disaster-recovery builds portable instead of
    failing merely because the host is Windows or macOS.  Operators can
    override every platform default with the two SENTINEL_PDF_FONT variables.
    """
    candidates: list[tuple[Path, Path]] = []
    configured_regular = os.getenv("SENTINEL_PDF_FONT_REGULAR", "").strip()
    configured_bold = os.getenv("SENTINEL_PDF_FONT_BOLD", "").strip()
    if configured_regular or configured_bold:
        if not configured_regular or not configured_bold:
            raise RuntimeError("SIGNAL_CYCLE_PDF_FONT_OVERRIDE_INCOMPLETE")
        candidates.append((Path(configured_regular), Path(configured_bold)))

    windows_root = Path(os.getenv("WINDIR", "C:/Windows"))
    candidates.extend(
        [
            (
                Path("/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf"),
                Path("/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf"),
            ),
            (windows_root / "Fonts" / "tahoma.ttf", windows_root / "Fonts" / "tahomabd.ttf"),
            (windows_root / "Fonts" / "arial.ttf", windows_root / "Fonts" / "arialbd.ttf"),
            (
                Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
                Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf"),
            ),
        ]
    )
    candidates.append((FONT_REGULAR, FONT_BOLD))

    # ReportLab ships Bitstream Vera.  It is a final availability fallback for
    # non-Persian reports; production keeps using DejaVu for full Persian glyph
    # coverage.
    import reportlab

    reportlab_fonts = Path(reportlab.__file__).resolve().parent / "fonts"
    candidates.append((reportlab_fonts / "Vera.ttf", reportlab_fonts / "VeraBd.ttf"))
    return candidates


def _resolve_fonts() -> tuple[Path, Path]:
    checked: list[str] = []
    for regular, bold in _font_candidates():
        checked.append(f"{regular}|{bold}")
        if regular.is_file() and bold.is_file():
            return regular, bold
    raise RuntimeError("SIGNAL_CYCLE_PDF_FONT_MISSING: " + "; ".join(checked))


def _register_fonts() -> None:
    global _FONT_READY
    if _FONT_READY:
        return
    regular, bold = _resolve_fonts()
    pdfmetrics.registerFont(TTFont("SentinelCycleSans", str(regular)))
    pdfmetrics.registerFont(TTFont("SentinelCycleSansBold", str(bold)))
    _FONT_READY = True


def _clean(value: Any, limit: int = 800) -> str:
    return " ".join(str(value if value not in {None, ""} else "-").replace("\r", " ").replace("\n", " ").split())[:limit]


def _paragraph(value: Any, style: ParagraphStyle) -> Paragraph:
    text = _clean(value)
    if style.wordWrap == "RTL":
        text = visual_rtl(text)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(text, style)


def _entry(row: dict[str, Any]) -> str:
    values = row.get("entries")
    if isinstance(values, list) and values:
        return " / ".join(_clean(item, 40) for item in values[:3])
    return _clean(row.get("entry"), 80)


def _targets(row: dict[str, Any]) -> str:
    values = row.get("targets")
    if isinstance(values, list) and values:
        return " / ".join(f"TP{index}: {_clean(item, 30)}" for index, item in enumerate(values[:5], start=1))
    return "-"


def _short_date(value: Any) -> str:
    clean = str(value or "-").replace("T", " ")
    return clean[:16] if clean != "-" else clean


def _localized_status(value: Any, *, fa: bool) -> str:
    clean = str(value or "open").strip().lower()
    if not fa:
        return clean
    return {
        "open": "باز", "entry_hit": "ورود فعال", "tp1": "هدف ۱", "tp2": "هدف ۲", "tp3": "هدف ۳",
        "target_complete": "تمام اهداف", "win": "برد", "stop": "حد ضرر", "stopped": "حد ضرر",
        "loss": "باخت", "manual_close": "بسته دستی", "cancelled": "لغوشده", "expired": "منقضی",
        "no_entry": "بدون ورود", "closed": "بسته",
    }.get(clean, clean.replace("_", " "))


def _page(canvas, doc, *, fa: bool, cycle_name: str) -> None:
    canvas.saveState()
    width, _height = A4
    canvas.setFont("SentinelCycleSans", 8.5)
    canvas.setFillColor(colors.HexColor("#64748B"))
    page_number = canvas.getPageNumber()
    page_label = visual_rtl(f"صفحه {page_number}") if fa else f"Page {page_number}"
    canvas.drawRightString(width - 14 * mm, 8 * mm, page_label)
    canvas.drawString(14 * mm, 8 * mm, f"SENTINEL · {_clean(cycle_name, 80)}")
    canvas.setStrokeColor(colors.HexColor("#CBD5E1"))
    canvas.line(14 * mm, 12 * mm, width - 14 * mm, 12 * mm)
    canvas.restoreState()


def build_signal_cycle_pdf(db: dict[str, Any], cycle_id: int | str, *, language: str = "fa") -> bytes:
    """Create a searchable performance PDF for one active or closed signal period."""
    _register_fonts()
    fa = str(language or "fa").lower().startswith("fa")
    summary = signal_cycle_summary(db, cycle_id)
    rows = signal_cycle_rows(db, cycle_id)
    stats = summary.get("stats") if isinstance(summary.get("stats"), dict) else {}

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=14 * mm,
        leftMargin=14 * mm,
        topMargin=14 * mm,
        bottomMargin=17 * mm,
        title=f"SENTINEL Signal Period {summary.get('name')}",
        author="SENTINEL",
        subject="Signal period performance report",
    )
    styles = getSampleStyleSheet()
    base = ParagraphStyle(
        "CycleBase",
        parent=styles["BodyText"],
        fontName="SentinelCycleSans",
        fontSize=10.5,
        leading=15,
        alignment=TA_RIGHT if fa else TA_LEFT,
        wordWrap="RTL" if fa else None,
        textColor=colors.HexColor("#0F172A"),
    )
    center = ParagraphStyle("CycleCenter", parent=base, alignment=TA_CENTER)
    small = ParagraphStyle("CycleSmall", parent=base, fontSize=8.8, leading=12)
    header = ParagraphStyle(
        "CycleHeader",
        parent=center,
        fontName="SentinelCycleSansBold",
        fontSize=9.2,
        leading=12,
        textColor=colors.white,
    )
    title = ParagraphStyle(
        "CycleTitle",
        parent=base,
        fontName="SentinelCycleSansBold",
        fontSize=19,
        leading=27,
    )
    stat_label = ParagraphStyle("CycleStatLabel", parent=center, fontSize=8.5, leading=11, textColor=colors.HexColor("#475569"))
    stat_value = ParagraphStyle("CycleStatValue", parent=center, fontName="SentinelCycleSansBold", fontSize=13, leading=16)
    card_label = ParagraphStyle("CycleCardLabel", parent=base, fontSize=8.2, leading=11, textColor=colors.HexColor("#64748B"))
    card_value = ParagraphStyle("CycleCardValue", parent=base, fontName="SentinelCycleSansBold", fontSize=10.2, leading=14)

    status = str(summary.get("status") or "active")
    status_label = ("بسته" if status == "closed" else "فعال") if fa else ("Closed" if status == "closed" else "Active")
    story: list[Any] = [
        _paragraph("گزارش عملکرد دوره سیگنال" if fa else "Signal Period Performance Report", title),
        _paragraph(f"{summary.get('name')} · #{summary.get('id')} · {status_label}", base),
        Table([[
            _paragraph((f"شروع: {_short_date(summary.get('started_at'))}" if fa else f"Started: {_short_date(summary.get('started_at'))}"), small),
            _paragraph((f"پایان: {_short_date(summary.get('closed_at'))}" if fa else f"Closed: {_short_date(summary.get('closed_at'))}"), small),
        ]], colWidths=[84 * mm, 84 * mm], hAlign="RIGHT" if fa else "LEFT"),
        Spacer(1, 4 * mm),
    ]

    labels = (["کل سیگنال", "فارکس", "کریپتو", "برد", "باخت", "نرخ برد", "سود/زیان تجمعی"] if fa else
              ["Signals", "Forex", "Crypto", "Wins", "Losses", "Win rate", "Cumulative P/L"])
    values = [
        stats.get("total", 0), stats.get("forex", 0), stats.get("crypto", 0),
        stats.get("wins", 0), stats.get("losses", 0), f"{float(stats.get('win_rate', 0) or 0):.1f}%",
        f"{float(stats.get('profit_percent_sum', 0) or 0):+.2f}%",
    ]
    stat_cells = [
        Table([[_paragraph(label, stat_label)], [_paragraph(value, stat_value)]], colWidths=[43 * mm])
        for label, value in zip(labels, values)
    ]
    stat_table = Table(
        [stat_cells[:4], stat_cells[4:] + [""]],
        colWidths=[43 * mm] * 4,
        rowHeights=[21 * mm, 21 * mm],
        hAlign="RIGHT" if fa else "LEFT",
    )
    stat_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F1F5F9")),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#CBD5E1")),
        ("INNERGRID", (0, 0), (-1, -1), 1.2, colors.white),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.extend([stat_table, Spacer(1, 5 * mm)])

    field_labels = ({
        "number": "شماره", "date": "تاریخ", "symbol": "نماد", "side": "جهت", "entry": "ورود",
        "stop": "حد ضرر", "targets": "اهداف", "risk": "ریسک", "status": "وضعیت", "profit": "سود/زیان",
    } if fa else {
        "number": "No.", "date": "Date", "symbol": "Symbol", "side": "Side", "entry": "Entry",
        "stop": "Stop", "targets": "Targets", "risk": "Risk", "status": "Status", "profit": "P/L",
    })
    if not rows:
        story.append(_paragraph("این دوره هنوز سیگنالی ندارد." if fa else "This period has no signals.", center))
    for row in rows:
        created = _short_date(row.get("created_at") or row.get("published_at"))
        profit = float(row.get("profit_percent", 0) or 0)
        values_by_key = {
            "number": f"#{signal_display_number(row)}", "date": created, "symbol": row.get("symbol") or "-",
            "side": ({"buy": "خرید", "long": "خرید", "sell": "فروش", "short": "فروش"}.get(str(row.get("side") or "").lower(), row.get("side") or "-") if fa else row.get("side") or "-"), "entry": _entry(row), "stop": row.get("stop") or row.get("stop_loss") or "-",
            "targets": _targets(row), "risk": f"{row.get('risk', row.get('risk_percent', '-'))}%",
            "status": _localized_status(row.get("status"), fa=fa), "profit": f"{profit:+.2f}%",
        }
        def cell(key: str) -> Table:
            return Table(
                [[_paragraph(field_labels[key], card_label)], [_paragraph(values_by_key[key], card_value)]],
                colWidths=[56 * mm],
            )
        top_keys = ["number", "symbol", "side"] if fa else ["symbol", "side", "number"]
        card = Table(
            [
                [_paragraph(f"{values_by_key['symbol']} · {values_by_key['number']}", header), "", ""],
                [cell(key) for key in top_keys],
                [cell(key) for key in (["date", "status", "profit"] if fa else ["date", "status", "profit"])],
                [cell(key) for key in (["entry", "stop", "risk"] if fa else ["entry", "stop", "risk"])],
                [_paragraph(field_labels["targets"], card_label), _paragraph(values_by_key["targets"], card_value), ""],
            ],
            colWidths=[56 * mm, 56 * mm, 56 * mm],
            hAlign="RIGHT" if fa else "LEFT",
        )
        card.setStyle(TableStyle([
            ("SPAN", (0, 0), (-1, 0)), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
            ("SPAN", (1, 4), (-1, 4)), ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F8FAFC")),
            ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#CBD5E1")),
            ("INNERGRID", (0, 1), (-1, -1), 0.35, colors.HexColor("#E2E8F0")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.extend([KeepTogether([card, Spacer(1, 4 * mm)])])
    doc.build(
        story,
        onFirstPage=lambda canvas, document: _page(canvas, document, fa=fa, cycle_name=str(summary.get("name") or "")),
        onLaterPages=lambda canvas, document: _page(canvas, document, fa=fa, cycle_name=str(summary.get("name") or "")),
    )
    return buffer.getvalue()
