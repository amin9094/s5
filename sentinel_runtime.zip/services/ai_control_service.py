from __future__ import annotations

import copy
import logging
import secrets
import time
from typing import Any

from config import SETTINGS, is_primary_admin
from core.db import with_db
from core.utils import parse_dt, utc_iso, utc_now
from core.webapp_auth import TelegramWebAppIdentity
from modules.ai_action_firewall import (
    HUMAN_ONLY_ACTIONS,
    backend_risk,
    build_execution_plan,
    stable_execution_key,
)
from modules.ai_undo import create_undo_snapshot, restore_undo_snapshot
from modules.gemini_admin_control import (
    ai_execution_settings,
    is_ai_operational_action_allowed,
    queue_ai_admin_commands,
    requester_may_request_action,
    sanitize_tool_calls,
)
from modules.security_audit import append_security_audit
from services.actions_v2 import action_specs
from services.miniapp_action_service_v2 import handle_miniapp_action_for_identity_v2

logger = logging.getLogger(__name__)


def _identity(actor_id: int | str, request_id: str) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(
        user_id=int(actor_id),
        username="sentinel_admin_ai",
        first_name="Sentinel",
        last_name="Admin AI",
        auth_date=int(time.time()),
        query_id=request_id,
    )


def _resolve_aliases(value: Any, *, key: str = "") -> Any:
    if isinstance(value, dict):
        return {str(k): _resolve_aliases(v, key=str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_aliases(item, key=key) for item in value]
    text = str(value or "") if isinstance(value, str) else ""
    lowered = key.casefold()
    if text.startswith("user_") and (lowered.endswith("user_id") or lowered in {"user_id", "admin_id", "to_admin_id", "trader_id", "actor_id"}):
        from modules.gemini_ai import resolve_ai_identifier
        return resolve_ai_identifier(text, "user")
    if text.startswith("ticket_") and lowered == "ticket_id":
        from modules.gemini_ai import resolve_ai_identifier
        return resolve_ai_identifier(text, "ticket")
    return value


def execute_registered_admin_action(
    actor_id: int | str,
    action_name: str,
    payload: dict[str, Any] | None = None,
    *,
    source: str = "gemini_admin_control",
    request_id: str,
    human_confirmation_source: str = "",
) -> dict[str, Any]:
    name = str(action_name or "").strip()
    if name in HUMAN_ONLY_ACTIONS:
        raise PermissionError("AI_HUMAN_ONLY_ACTION")
    if not is_ai_operational_action_allowed(name):
        raise PermissionError("AI_OPERATIONAL_ACTION_BLOCKED")
    spec = action_specs().get(name)
    if spec is None:
        raise ValueError("AI_OPERATIONAL_ACTION_UNKNOWN")
    if not spec.admin_only:
        raise PermissionError("AI_OPERATIONAL_ACTION_NOT_ADMIN_BOUND")
    if not requester_may_request_action(actor_id, name, spec.permission):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")
    clean_payload = _resolve_aliases(dict(payload or {}))
    identity = _identity(actor_id, request_id)
    result = handle_miniapp_action_for_identity_v2(
        identity,
        {"action": name, "payload": clean_payload, "request_id": request_id},
        transport_request_id=request_id,
        transport_context={
            "source": human_confirmation_source or source,
            "primary_admin_id": SETTINGS.primary_admin_id,
            "ai_origin": True,
            "human_confirmation": bool(human_confirmation_source),
            "human_confirmation_source": str(human_confirmation_source or ""),
        },
    )
    try:
        from core.miniapp_server import finalize_action_telegram_sync
        finalize_action_telegram_sync(name, result, identity)
    except Exception:
        # The action service has already completed its idempotency record. Reset
        # it only when a required external finalizer failed, so the same stable
        # Gemini execution key can be retried after the order claim is released.
        if request_id:
            try:
                from repositories.v2.idempotency import IdempotencyRepository
                IdempotencyRepository().reset_completed(identity.user_id, request_id)
            except Exception:
                logger.exception("Could not reset Gemini action idempotency after finalizer failure action=%s", name)
        raise
    if request_id and name == "payment_approve":
        from repositories.v2.idempotency import IdempotencyRepository
        IdempotencyRepository().replace_completed_response(
            identity.user_id, request_id, response=result,
        )
    return result


def _record_execution_result(
    actor_id: int | str,
    *,
    action: str,
    execution_key: str,
    status: str,
    risk: str,
    detail: dict[str, Any] | None = None,
    source: str = "gemini_admin_control",
) -> None:
    payload = {
        "action": str(action),
        "execution_key": str(execution_key),
        "status": str(status),
        "risk": str(risk),
        "detail": copy.deepcopy(detail or {}),
    }
    with_db(lambda db: append_security_audit(
        db,
        action=f"ai_action_{status}",
        actor_id=actor_id,
        details=payload,
        source=source,
    ))


def _safe_record_execution_result(
    actor_id: int | str,
    *,
    action: str,
    execution_key: str,
    status: str,
    risk: str,
    detail: dict[str, Any] | None = None,
    source: str = "gemini_admin_control",
) -> str:
    try:
        _record_execution_result(
            actor_id, action=action, execution_key=execution_key, status=status,
            risk=risk, detail=detail, source=source,
        )
        return "recorded"
    except Exception as exc:
        logger.exception("AI action audit persistence failed action=%s status=%s", action, status)
        return f"pending:{exc.__class__.__name__}"


def _record_plan(actor_id: int | str, plan: list[Any], *, conversation_id: Any, mode: str) -> None:
    def mutate(db: dict[str, Any]) -> None:
        row = {
            "id": int(db.get("next_ai_execution_plan_id", 1) or 1),
            "actor_id": str(actor_id),
            "conversation_id": str(conversation_id or ""),
            "mode": mode,
            "items": [
                {
                    "index": item.index,
                    "action": item.action,
                    "risk": item.risk,
                    "reversible": item.reversible,
                    "execution_key": item.execution_key,
                }
                for item in plan
            ],
            "created_at": utc_iso(),
        }
        db.setdefault("ai_execution_plans", []).append(row)
        db["next_ai_execution_plan_id"] = row["id"] + 1
        append_security_audit(db, action="ai_execution_plan_created", actor_id=actor_id, details={"plan_id": row["id"], "actions": [item.action for item in plan], "mode": mode}, source="ai_execution")
    with_db(mutate)


def execute_or_queue_ai_tool_calls(
    actor_id: int | str,
    raw_calls: Any,
    *,
    conversation_id: int | str = "",
    question: str = "",
    response_id: str = "",
) -> dict[str, Any]:
    calls = sanitize_tool_calls(raw_calls, admin_command=question)
    settings = ai_execution_settings()
    if not calls:
        return {"mode": "analysis_only", "executions": [], "queued": [], "tool_calls": []}
    if not settings["execution_enabled"]:
        return {
            "mode": "execution_disabled", "executions": [], "queued": [], "tool_calls": calls,
            "error": "AI_EXECUTION_KILL_SWITCH_ACTIVE",
        }

    plan = build_execution_plan(calls, conversation_id=conversation_id, response_id=response_id)
    _record_plan(actor_id, plan, conversation_id=conversation_id, mode="dry_run_validated")

    primary_direct = is_primary_admin(actor_id) and bool(settings["autonomous_primary_admin"])
    full_primary_access = primary_direct and bool(settings.get("primary_admin_full_bot_access", False))

    # Human confirmation is a backend security invariant, not a Railway feature
    # switch. Full bot access expands which registered actions the owner may ask
    # for; it never lets Gemini approve money, privileges, deletion or public
    # side effects on its own.
    protected_names = {"delegated_admin_upsert", "public_discount_create"}
    protected_calls = [call for call in calls if call.get("action") in protected_names]
    calls = [call for call in calls if call.get("action") not in protected_names]
    forced_admin_queue = queue_ai_admin_commands(
        actor_id, protected_calls, conversation_id=conversation_id, question=question,
    ) if protected_calls else []
    sensitive_risks = {"financial_mutation", "destructive", "privilege_change", "external_side_effect", "sensitive_human_confirmation"}
    if primary_direct:
        sensitive_calls = [call for call in calls if backend_risk(str(call.get("action") or "")) in sensitive_risks]
        if sensitive_calls:
            direct_calls = [call for call in calls if call not in sensitive_calls]
            queued_sensitive = queue_ai_admin_commands(
                actor_id, sensitive_calls, conversation_id=conversation_id, question=question,
            )
            # Mixed plans are not partially executed: the preview shows the complete
            # requested operation and requires one explicit human decision.
            if direct_calls:
                queued_sensitive += queue_ai_admin_commands(
                    actor_id, direct_calls, conversation_id=conversation_id, question=question,
                )
            return {
                "mode": "primary_preview_required", "executions": [],
                "queued": forced_admin_queue + queued_sensitive, "tool_calls": protected_calls + calls,
                "execution_plan": [item.__dict__ for item in plan],
            }

    if not primary_direct:
        specs = action_specs()
        permitted: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        for call in calls:
            spec = specs.get(call["action"])
            if spec and spec.admin_only and requester_may_request_action(actor_id, call["action"], spec.permission):
                permitted.append(call)
            else:
                rejected.append({**call, "error": "ADMIN_PERMISSION_REQUIRED"})
        queued = forced_admin_queue + (queue_ai_admin_commands(
            actor_id, permitted, conversation_id=conversation_id, question=question,
        ) if permitted else [])
        return {
            "mode": "primary_approval_required", "executions": [], "queued": queued,
            "rejected": rejected, "tool_calls": protected_calls + calls,
            "execution_plan": [item.__dict__ for item in plan],
        }

    # A multi-action autonomous batch containing a destructive or privilege
    # mutation cannot be made safely atomic across Telegram and database side
    # effects. Require the owner to issue those operations as individual direct
    # commands. Reversible batches receive automatic compensation on failure.
    risky = [item for item in plan if item.risk in {"destructive", "privilege_change"}]
    if len(calls) > 1 and risky:
        return {
            "mode": "primary_batch_blocked",
            "executions": [], "queued": forced_admin_queue,
            "tool_calls": protected_calls + calls,
            "error": "AI_MULTI_ACTION_NON_ATOMIC_BLOCKED",
            "execution_plan": [item.__dict__ for item in plan],
        }

    undo = create_undo_snapshot(actor_id, [call["action"] for call in calls]) if calls else None
    executions: list[dict[str, Any]] = []
    failed = False
    for index, call in enumerate(calls):
        execution_key = stable_execution_key(
            conversation_id=conversation_id,
            response_id=response_id,
            index=int(call.get("tool_call_index", index) or index),
            action=call["action"],
            payload=call.get("payload") or {},
        )
        try:
            result = execute_registered_admin_action(
                actor_id,
                call["action"],
                call.get("payload") or {},
                source="gemini_primary_autonomous",
                request_id=execution_key,
            )
            audit_status = _safe_record_execution_result(
                actor_id, action=call["action"], execution_key=execution_key,
                status="executed", risk=backend_risk(call["action"]),
                detail={"undo_token": (undo or {}).get("token")},
                source="gemini_primary_autonomous",
            )
            executions.append({
                "action": call["action"], "status": "executed", "result": result,
                "risk": backend_risk(call["action"]), "execution_key": execution_key,
                "undo_token": (undo or {}).get("token"), "audit_status": audit_status,
            })
        except Exception as exc:
            failed = True
            audit_status = _safe_record_execution_result(
                actor_id, action=call["action"], execution_key=execution_key,
                status="failed", risk=backend_risk(call["action"]),
                detail={"error": exc.__class__.__name__, "detail": str(exc)[:500]},
                source="gemini_primary_autonomous",
            )
            executions.append({
                "action": call["action"], "status": "failed",
                "error": exc.__class__.__name__, "detail": str(exc)[:1000],
                "risk": backend_risk(call["action"]), "execution_key": execution_key,
                "audit_status": audit_status,
            })
            break

    compensation: dict[str, Any] | None = None
    if failed and undo and all(item.reversible for item in plan):
        try:
            compensation = restore_undo_snapshot(str(undo["token"]), actor_id, automatic=True)
        except Exception as exc:
            compensation = {"status": "failed", "error": exc.__class__.__name__, "detail": str(exc)[:500]}

    return {
        "mode": "primary_autonomous" if not forced_admin_queue else "primary_autonomous_with_admin_approval",
        "executions": executions,
        "queued": forced_admin_queue,
        "tool_calls": protected_calls + calls,
        "execution_plan": [item.__dict__ for item in plan],
        "undo": undo,
        "compensation": compensation,
        "partial_failure": bool(failed and not compensation),
    }


def _claim_queued_ai_command(command_id: int | str, primary_admin_id: int | str, *, source: str) -> dict[str, Any]:
    if not is_primary_admin(primary_admin_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    if source not in {"telegram_callback", "miniapp_human_action"}:
        raise PermissionError("HUMAN_CONFIRMATION_REQUIRED")
    target = int(command_id)
    lease = secrets.token_urlsafe(18)
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = next((item for item in db.setdefault("ai_admin_command_queue", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == target), None)
        if not row:
            raise ValueError("AI_ADMIN_COMMAND_NOT_FOUND")
        status = str(row.get("status") or "")
        if not status.startswith("pending"):
            raise ValueError("AI_ADMIN_COMMAND_ALREADY_RESOLVED")
        row.update({
            "status": "executing", "lease_token": lease, "claimed_by": str(primary_admin_id),
            "claimed_at": utc_iso(), "human_confirmation": True, "human_confirmation_source": source,
            "updated_at": utc_iso(),
        })
        append_security_audit(db, action="ai_command_claimed", actor_id=primary_admin_id, details={"command_id": target, "lease_token": lease}, source=source)
        return copy.deepcopy(row)
    return with_db(mutate)


def _finish_claim(command_id: int | str, lease_token: str, actor_id: int | str, *, status: str, result: Any) -> dict[str, Any]:
    target = int(command_id)
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = next((item for item in db.setdefault("ai_admin_command_queue", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == target), None)
        if not row or row.get("lease_token") != lease_token or row.get("status") != "executing":
            raise ValueError("AI_COMMAND_LEASE_LOST")
        row.update({
            "status": status, "result": result, "resolved_by": str(actor_id),
            "resolved_at": utc_iso(), "updated_at": utc_iso(),
        })
        append_security_audit(db, action=f"ai_command_{status}", actor_id=actor_id, details={"command_id": target}, source="human_ai_queue")
        return copy.deepcopy(row)
    return with_db(mutate)


def approve_queued_ai_command(
    command_id: int | str,
    primary_admin_id: int | str,
    *,
    human_confirmation_source: str,
) -> dict[str, Any]:
    row = _claim_queued_ai_command(command_id, primary_admin_id, source=human_confirmation_source)
    lease = str(row.get("lease_token") or "")
    execution_key = stable_execution_key(
        conversation_id=row.get("conversation_id"), response_id=f"queue:{row.get('id')}", index=0,
        action=str(row.get("action") or ""), payload=dict(row.get("payload") or {}),
    )
    try:
        result = execute_registered_admin_action(
            primary_admin_id,
            str(row.get("action") or ""),
            dict(row.get("payload") or {}),
            source=f"human_approved_gemini_command:{row.get('requested_by')}",
            request_id=execution_key,
            human_confirmation_source=human_confirmation_source,
        )
    except Exception as exc:
        failed = _finish_claim(
            command_id, lease, primary_admin_id, status="failed",
            result={"error": exc.__class__.__name__, "detail": str(exc)[:1000]},
        )
        _record_execution_result(
            primary_admin_id, action=str(row.get("action") or ""), execution_key=execution_key,
            status="failed", risk=backend_risk(str(row.get("action") or "")),
            detail={"command_id": row.get("id"), "error": exc.__class__.__name__},
            source=human_confirmation_source,
        )
        return {"command": failed, "executed": False}
    completed = _finish_claim(command_id, lease, primary_admin_id, status="executed", result=result)
    _record_execution_result(
        primary_admin_id, action=str(row.get("action") or ""), execution_key=execution_key,
        status="executed", risk=backend_risk(str(row.get("action") or "")),
        detail={"command_id": row.get("id")}, source=human_confirmation_source,
    )
    return {"command": completed, "executed": True, "result": result}


def reject_queued_ai_command(
    command_id: int | str,
    primary_admin_id: int | str,
    *,
    reason: str = "",
    human_confirmation_source: str,
) -> dict[str, Any]:
    row = _claim_queued_ai_command(command_id, primary_admin_id, source=human_confirmation_source)
    completed = _finish_claim(
        command_id, str(row.get("lease_token") or ""), primary_admin_id,
        status="rejected", result={"reason": str(reason)[:1000]},
    )
    return completed
