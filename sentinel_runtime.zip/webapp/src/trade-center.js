function feedItem(row) {
    const labels = { signal: 'سیگنال', announcement: 'اعلان', news: 'خبر', market: 'گزارش بازار', publication: 'انتشار' };
    const signal = row.type === 'signal';
    const decision = signal && row.choice?.choice;
    const signalStatus = String(row.status || row.signal_status || '').toLowerCase();
    const signalFinal = Boolean(row.is_final || ['closed','win','loss','sl','stop','stopped','tp','tp1','tp2','tp3','be','cancelled','canceled'].includes(signalStatus));
    const decisionLabel = decision === 'taken' ? 'این سیگنال را گرفته‌اید' : decision === 'skipped' ? 'این سیگنال را رد کرده‌اید' : '';
    return `<article class="journal-card feed-item ${signal ? 'feed-signal' : ''}">
  <div class="row-between"><strong>${esc(row.title || labels[row.type] || row.type)}</strong><span class="status-badge ${row.priority === 'high' ? 'warn' : 'info'}">${esc(labels[row.type] || row.type)}</span></div>
  ${row.summary ? `<p>${esc(row.summary)}</p>` : ''}<small>${date(row.created_at)} · ${esc(row.destination || 'public')}</small>
  ${signal ? `<div class="card-actions">${signalFinal ? `<span class="status-badge warn">سیگنال بسته شده</span>` : (decision ? `<span class="status-badge ${decision === 'taken' ? 'ok' : 'muted'}">${esc(decisionLabel)}</span>` : `<button class="button small" data-signal-take="${esc(row.signal_id)}">گرفتم / ثبت ورود</button><button class="button secondary small" data-signal-skip="${esc(row.signal_id)}">نگرفتم</button>`)}<button class="button ghost small" data-signal-detail="${esc(row.signal_id)}">جزئیات</button></div>` : ''}
 </article>`;
}
function channelFeedPanel(rows = []) {
    return `<section class="panel channel-feed"><div class="panel-head"><div><small class="eyebrow">CHANNEL LIVE</small><h2>${state.lang === 'fa' ? 'آخرین محتوای کانال' : 'Channel timeline'}</h2></div><button class="button ghost small" data-open="feed">${state.lang === 'fa' ? 'مشاهده همه' : 'View all'}</button></div><div class="panel-body journal-list">${rows.slice(0, 6).map(feedItem).join('') || empty()}</div></section>`;
}
function checkFeedUpdates(rows = [], initial = false) {
    const newest = rows[0], key = 'sentinelFeedLastSeen', last = localStorage.getItem(key) || '';
    if (!newest)
        return;
    if (!initial && last && last !== String(newest.id)) {
        const message = newest.type === 'signal' ? (state.lang === 'fa' ? `سیگنال جدید ${newest.title}` : `New signal ${newest.title}`) : (newest.title || 'SENTINEL update');
        toast(message, 'info');
        tg?.HapticFeedback?.notificationOccurred?.('success');
        if (window.Notification?.permission === 'granted')
            try {
                new window.Notification('SENTINEL', { body: message, tag: String(newest.id) });
            }
            catch { }
    }
    localStorage.setItem(key, String(newest.id));
}
async function refreshFeed(notify = true) {
    const data = await loadResource('feed', true);
    if (notify)
        checkFeedUpdates(data?.items || [], false);
    return data;
}
async function feedModal() {
    const data = await refreshFeed(false);
    openModal('CHANNEL LIVE', state.lang === 'fa' ? 'مرکز اطلاع‌رسانی کانال' : 'Channel feed', `<div class="row-between"><p class="field-help">${state.lang === 'fa' ? 'سیگنال، خبر، اعلان و گزارش منتشرشده در کانال با رعایت دسترسی VIP.' : 'Signals, news, announcements and published channel reports.'}</p><button class="button secondary small" data-notification-enable>اعلان دستگاه</button></div><div class="journal-list">${(data?.items || []).map(feedItem).join('') || empty()}</div>`, []);
}
async function enableDeviceNotifications() {
    if (!('Notification' in window)) {
        toast('اعلان سیستم در این دستگاه پشتیبانی نمی‌شود', 'error');
        return;
    }
    const permission = await Notification.requestPermission();
    toast(permission === 'granted' ? 'اعلان دستگاه فعال شد' : 'مجوز اعلان داده نشد', permission === 'granted' ? 'success' : 'error');
}
function tradeActions(trade) {
    const targets = trade.targets || [trade.target].filter(Boolean), hits = new Set(trade.target_hits || []), cancelled = new Set(trade.cancelled_targets || []);
    const tp = targets.map((price, index) => { const n = index + 1; return `<button class="button small" data-paper-action="tp${n}" data-trade-id="${trade.id}" ${hits.has(n) || cancelled.has(n) ? 'disabled' : ''}>TP${n} · ${esc(price)}</button><button class="button ghost small" data-paper-cancel-target="${n}" data-trade-id="${trade.id}" ${hits.has(n) || cancelled.has(n) ? 'disabled' : ''}>لغو TP${n}</button>`; }).join('');
    return `<div class="card-actions">${tp}<button class="button secondary small" data-paper-action="breakeven" data-trade-id="${trade.id}">سر‌به‌سر</button><button class="button secondary small" data-paper-move-stop="${trade.id}">تغییر SL</button><button class="button secondary small" data-paper-action="sl" data-trade-id="${trade.id}">Stop Loss</button><button class="button ghost small" data-paper-action="cancel" data-trade-id="${trade.id}">لغو معامله</button></div>`;
}
function tradeCenterBody(data) {
    const paper = data.paper_arena || {}, accounts = paper.accounts || [], trades = (paper.trades || []).slice().reverse(), coach = data.risk_coach || {}, prop = data.prop_guardian?.accounts || [];
    return `<div class="admin-workspace">
 <section class="panel"><div class="panel-head"><div><small class="eyebrow">PAPER + PROP</small><h3>مرکز تمرین معامله و مدیریت ریسک</h3></div><button class="button small" data-paper-account-new>ساخت حساب</button></div><div class="panel-body"><div class="metric-grid">${metric('حساب', num(accounts.length, 0), '', 'info')}${metric('باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('بسته', num(paper.summary?.closed || 0, 0), '', 'good')}${metric('لغوشده', num(paper.summary?.cancelled || 0, 0), '', '')}</div>${accounts.length ? `<button class="button primary" data-paper-trade-new>ثبت معامله آزمایشی</button>` : '<p>ابتدا یک حساب آزمایشی بسازید.</p>'}</div></section>
 <section class="panel"><div class="panel-head"><h3>معاملات و تمام سناریوهای خروج</h3></div><div class="panel-body journal-list">${trades.map(trade => `<article class="journal-card"><div class="row-between"><strong>#${trade.id} · ${esc(trade.symbol)} · ${esc(String(trade.side).toUpperCase())}</strong><span class="status-badge ${trade.status === 'open' ? 'good' : trade.status === 'cancelled' ? 'warn' : 'info'}">${esc(trade.status)}</span></div><p>Entry ${esc(trade.entry)} · SL ${esc(trade.stop)} · باقی‌مانده ${pct(Number(trade.remaining_fraction ?? 1) * 100, 0)}</p><small>${date(trade.opened_at)} · ${num(trade.realized_r || trade.result_r || 0, 2)}R · ${money(trade.realized_pnl || trade.pnl_amount || 0, 'USD')}</small>${trade.status === 'open' ? tradeActions(trade) : ''}</article>`).join('') || empty()}</div></section>
 <section class="panel"><div class="panel-head"><h3>نگهبان Prop</h3></div><div class="panel-body journal-list">${prop.map(row => `<article class="journal-card"><div class="row-between"><strong>${esc(row.title || `Account ${row.account_id}`)}</strong><span class="status-badge ${row.status === 'safe' || row.status === 'passed' ? 'good' : row.status === 'blocked' ? 'bad' : 'warn'}">${esc(row.status)}</span></div>${row.status === 'unconfigured' ? `<button class="button small" data-prop-standard="${row.account_id}">فعال‌کردن قوانین استاندارد</button>` : `<p>زیان روزانه: ${pct(row.metrics?.daily_loss_percent || 0)} · افت کل: ${pct(row.metrics?.total_drawdown_percent || 0)} · پیشرفت سود: ${pct(row.metrics?.profit_progress_percent || 0)}</p><small>${(row.hard_blocks || []).join('، ') || ((row.warnings || []).join('، ') || 'بدون نقض فعال')}</small>`}</article>`).join('') || empty()}</div></section>
 <section class="panel"><div class="panel-head"><h3>مربی رفتار و ریسک متصل به سیگنال‌ها</h3><button class="button secondary small" data-risk-coach-refresh>تحلیل مجدد</button></div><div class="panel-body"><div class="metric-grid">${metric('انضباط', `${num(coach.discipline_score || 0, 1)}/100`, '', 'good')}${metric('سیگنال گرفته‌شده', num(coach.signal_risk?.taken_count || 0, 0), '', 'info')}${metric('ریسک فعال', pct(coach.signal_risk?.active_risk_percent || 0), '', 'warn')}${metric('Net R', `${num(coach.net_r || 0, 2)}R`, '', '')}</div><div class="journal-list">${(coach.findings || []).map(x => `<div class="notice ${x.severity === 'high' ? 'warning' : ''}"><strong>${esc(x.title || x.code)}</strong><br><small>${num(x.count || 0, 0)}</small></div>`).join('') || '<div class="notice">الگوی پرخطر واضحی دیده نشد.</div>'}${(coach.recommendations || []).map(x => `<p>• ${esc(x)}</p>`).join('')}</div></div></section>
 </div>`;
}
async function tradeCenterModal() {
    setBusy(true);
    try {
        const data = await loadResource('expansion', true);
        openModal('TRADING & RISK', state.lang === 'fa' ? 'مرکز تمرین معامله و مدیریت ریسک' : 'Trading practice & risk center', tradeCenterBody(data), []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function paperAccountModal() {
    openModal('PAPER ACCOUNT', 'ساخت حساب آزمایشی', `<form id="paperAccountForm"><div class="field"><label>نام حساب</label><input id="paperAccountTitle" value="حساب تمرینی" required></div><div class="field"><label>سرمایه اولیه</label><input id="paperAccountBalance" type="number" min="100" value="10000" required></div></form>`, [{ label: 'ساخت حساب', kind: 'primary', action: async () => { const f = $('#paperAccountForm'); if (!f.reportValidity())
                return; await action('paper_account_create', { title: $('#paperAccountTitle').value, starting_balance: Number($('#paperAccountBalance').value) }, false); closeModal(); invalidate('expansion'); await tradeCenterModal(); toast('حساب ساخته شد'); } }]);
}
function paperTradeModal() {
    const accounts = state.resources.expansion?.paper_arena?.accounts || [];
    openModal('PAPER TRADE', 'ثبت معامله آزمایشی', `<form id="paperTradeForm"><div class="form-grid"><div class="field"><label>حساب</label><select id="paperAccount">${accounts.map(x => `<option value="${x.id}">${esc(x.title)}</option>`).join('')}</select></div><div class="field"><label>نماد</label><input id="paperSymbol" required placeholder="XAUUSD"></div><div class="field"><label>جهت</label><select id="paperSide"><option value="buy">BUY</option><option value="sell">SELL</option></select></div><div class="field"><label>Entry</label><input id="paperEntry" type="number" step="any" required></div><div class="field"><label>SL</label><input id="paperStop" type="number" step="any" required></div><div class="field"><label>TPها (با ویرگول)</label><input id="paperTargets" required placeholder="2350,2360,2375"></div><div class="field"><label>ریسک %</label><input id="paperRisk" type="number" min=".1" max="5" step=".1" value="1" required></div></div></form>`, [{ label: 'ثبت معامله', kind: 'primary', action: async () => { const f = $('#paperTradeForm'); if (!f.reportValidity())
                return; const targets = $('#paperTargets').value.split(',').map(Number).filter(Number.isFinite); await action('paper_trade_open', { account_id: $('#paperAccount').value, symbol: $('#paperSymbol').value, side: $('#paperSide').value, entry: Number($('#paperEntry').value), stop: Number($('#paperStop').value), targets, risk_percent: Number($('#paperRisk').value) }, false); closeModal(); invalidate('expansion'); await tradeCenterModal(); toast('معامله ثبت شد'); } }]);
}
function paperMoveStopModal(id) {
    openModal('MOVE STOP', 'تغییر حد ضرر', `<form id="moveStopForm"><div class="field"><label>SL جدید</label><input id="paperNewStop" type="number" step="any" required></div><div class="field"><label>دلیل</label><input id="paperStopReason" maxlength="300"></div></form>`, [{ label: 'ذخیره', kind: 'primary', action: async () => { if (!$('#moveStopForm').reportValidity())
                return; await managePaper(id, 'move_sl', { new_stop: Number($('#paperNewStop').value), reason: $('#paperStopReason').value }); } }]);
}
async function managePaper(id, trade_action, extra = {}) {
    setBusy(true);
    try {
        await action('paper_trade_action', { trade_id: id, trade_action, ...extra }, false);
        closeModal();
        invalidate('expansion');
        await tradeCenterModal();
        toast('وضعیت معامله به‌روزرسانی شد');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
async function standardProp(accountId) {
    await action('prop_challenge_configure', { account_id: accountId, rules: { daily_loss_limit_percent: 5, total_loss_limit_percent: 10, profit_target_percent: 8, min_trading_days: 5, max_risk_per_trade_percent: 2, news_trading_allowed: true, weekend_holding_allowed: false } }, false);
    closeModal();
    invalidate('expansion');
    await tradeCenterModal();
    toast('نگهبان Prop فعال شد');
}
document.addEventListener('click', async (event) => {
    const el = event.target.closest('[data-signal-take],[data-signal-skip],[data-signal-retro],[data-notification-enable],[data-paper-account-new],[data-paper-trade-new],[data-paper-action],[data-paper-cancel-target],[data-paper-move-stop],[data-prop-standard],[data-risk-coach-refresh]');
    if (!el)
        return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.signalTake)
        return openSignal(el.dataset.signalTake);
    if (el.dataset.signalSkip)
        return setSignalChoice(el.dataset.signalSkip, 'skipped');
    if (el.dataset.signalRetro)
        return setSignalChoice(el.dataset.signalRetro, el.dataset.retroChoice, true);
    if (el.dataset.notificationEnable !== undefined)
        return enableDeviceNotifications();
    if (el.dataset.paperAccountNew !== undefined)
        return paperAccountModal();
    if (el.dataset.paperTradeNew !== undefined)
        return paperTradeModal();
    if (el.dataset.paperMoveStop)
        return paperMoveStopModal(el.dataset.paperMoveStop);
    if (el.dataset.paperAction)
        return managePaper(el.dataset.tradeId, el.dataset.paperAction);
    if (el.dataset.paperCancelTarget)
        return managePaper(el.dataset.tradeId, 'cancel_target', { target_index: Number(el.dataset.paperCancelTarget) });
    if (el.dataset.propStandard)
        return standardProp(el.dataset.propStandard);
    if (el.dataset.riskCoachRefresh !== undefined) {
        await action('risk_coach_refresh', {}, false);
        invalidate('expansion');
        closeModal();
        return tradeCenterModal();
    }
}, true);
