/* SENTINEL Sovereign Experience — server-authoritative public/VIP/admin UX. */
const sentinelLegacyOpenMore = openMore;
const sentinelLegacyRenderChrome = renderChrome;
function sentinelTier() {
    const o = state.resources.overview || {}, role = String(o.user?.role || 'user');
    if (['owner', 'admin'].includes(role))
        return { key: 'admin', label: role === 'owner' ? 'مالک سیستم' : 'مدیر', icon: 'shield' };
    if (o.account?.vip_active)
        return { key: 'vip', label: 'عضو VIP', icon: 'crown' };
    return { key: 'public', label: 'عضو عمومی', icon: 'user' };
}
function sentinelMarketLabel(value) { return String(value || 'forex').toLowerCase() === 'crypto' ? 'کریپتو' : 'فارکس'; }
function sentinelAccessLabel(value) { return String(value || 'public').toLowerCase() === 'vip' ? 'VIP' : 'عمومی'; }
function sentinelRing(value, label, tone = 'cyan') {
    const safe = Math.max(0, Math.min(100, Number(value) || 0));
    return `<div class="sentinel-ring ${tone}" style="--ring:${safe}"><div><strong>${num(safe, 0)}%</strong><span>${esc(label)}</span></div></div>`;
}
function sentinelBars(values = []) {
    const rows = values;
    const max = Math.max(1, ...rows.map(Number));
    return `<div class="micro-chart" aria-label="نمودار خلاصه">${rows.map((value, index) => `<i style="--bar:${Math.max(8, Math.round(Number(value) / max * 100))}" title="${esc(value)}"><span>${index + 1}</span></i>`).join('')}</div>`;
}
function sentinelSection(title, subtitle, body, action = '') {
    return `<section class="panel sentinel-section"><div class="panel-head"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div>${action}</div><div class="panel-body">${body}</div></section>`;
}
function sentinelService(ic, title, desc, target, badge = 0, tone = '') {
    return `<button class="service-card ${tone}" data-open="${esc(target)}">${icon(ic)}<span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span>${badge ? `<em>${num(badge, 0)}</em>` : ''}${icon('chevron')}</button>`;
}
renderChrome = function () {
    sentinelLegacyRenderChrome();
    const tier = sentinelTier(), topbar = $('.topbar'), copy = $('.topbar-copy');
    topbar?.classList.toggle('vip-shell', tier.key === 'vip');
    topbar?.classList.toggle('admin-shell', tier.key === 'admin');
    let badge = $('#accountTier');
    if (!badge && copy) {
        badge = document.createElement('button');
        badge.id = 'accountTier';
        badge.type = 'button';
        badge.dataset.open = tier.key === 'public' ? 'vip' : 'settings';
        copy.appendChild(badge);
    }
    if (badge) {
        badge.className = `account-tier ${tier.key}`;
        badge.innerHTML = `${icon(tier.icon)}<span>${esc(tier.label)}</span>`;
        badge.dataset.open = tier.key === 'public' ? 'vip' : 'settings';
    }
};
renderHome = function () {
    const o = state.resources.overview || demoOverview(), r = o.risk || {}, ex = r.account_exposure || {}, j = o.journal_stats || {}, tier = sentinelTier();
    const signals = Number(o.account?.active_signals || 0), forex = Number(o.account?.active_forex_signals || 0), crypto = Number(o.account?.active_crypto_signals || 0);
    const exposure = Math.max(0, Number(ex.open_risk_percent || 0)), remaining = Math.max(0, Number(ex.remaining_daily_risk_percent || 0));
    const journalSeries = (j.equity_curve || j.series || []).map(x => Number(x.value ?? x.pnl ?? x)).filter(Number.isFinite).slice(-12);
    $('#page-home').innerHTML = `
 <article class="sentinel-command ${tier.key}">
  <img src="./assets/brand/sentinel-miniapp-logo.2febef7c25.webp" alt="" width="82" height="82">
  <div class="command-copy"><span class="eyebrow">SENTINEL PROTECTION NETWORK</span><h1>مرکز فرمان معامله‌گری</h1><p>سیگنال، بازار، ریسک و ژورنال شما در یک نمای زنده و محافظت‌شده.</p>
   <div class="command-actions"><button class="button primary" data-page-target="signals">${icon('signal')} مشاهده سیگنال‌ها</button><button class="button secondary" data-open="tradeCenter">${icon('shield')} مرکز معامله</button></div>
  </div><div class="protection-orbit">${icon('shield')}<span>محافظ فعال</span></div>
 </article>
 <div class="market-lanes">
  <button data-signal-scope-home="public"><span>${icon('market')} سیگنال عمومی</span><strong>${num(signals, 0)}</strong><small>${num(forex, 0)} فارکس · ${num(crypto, 0)} کریپتو</small></button>
  <button class="vip-lane" data-signal-scope-home="vip"><span>${icon('crown')} اتاق VIP</span><strong>${o.account?.vip_active ? num((state.resources.feed?.groups?.vip || 0), 0) : 'قفل'}</strong><small>${o.account?.vip_active ? 'سیگنال‌های اختصاصی زنده' : 'برای دسترسی اشتراک تهیه کنید'}</small></button>
 </div>
 <section class="sentinel-dashboard">
  <div class="dashboard-chart panel"><div class="panel-head"><div><small class="eyebrow">ACCOUNT SHIELD</small><h2>وضعیت محافظت حساب</h2></div><span class="status-badge ${r.prop?.status === 'blocked' ? 'bad' : 'good'}">${esc(r.prop?.status || 'محافظت‌شده')}</span></div>
   <div class="dashboard-chart-body">${sentinelRing(Math.min(100, exposure * 20), 'ریسک باز', exposure > 3 ? 'red' : 'cyan')}<div class="chart-copy"><strong>${pct(remaining)} ظرفیت روزانه</strong>${sentinelBars(journalSeries)}<small>${num(ex.open_trades || 0, 0)} معامله باز · ${pct(j.win_rate || 0)} نرخ برد ژورنال</small></div></div>
  </div>
  <div class="quick-grid">
   <button data-open="market">${icon('market')}<strong>بازار زنده</strong><small>قیمت و واچ‌لیست</small></button>
   <button data-open="calculator">${icon('chart')}<strong>محاسبه حجم</strong><small>فارکس و کریپتو</small></button>
   <button data-page-target="journal">${icon('journal')}<strong>معاملات من</strong><small>ژورنال و نتیجه</small></button>
   <button data-open="notifications">${icon('bell')}<strong>اعلان‌ها</strong><small>کنترل بدون مزاحمت</small></button>
  </div>
 </section>
 ${sentinelSection('سیگنال‌های تازه', 'عمومی و VIP بر اساس دسترسی حساب', (o.recent_signals || []).map(signalCard).join('') || empty(), `<button class="button ghost small" data-page-target="signals">مشاهده همه</button>`)}
 ${channelFeedPanel(state.resources.feed?.items || [])}`;
};
signalCard = function (s) {
    const sell = ['sell', 'short'].includes(String(s.side).toLowerCase()), vip = String(s.access_tier || 'public') === 'vip', market = s.market_category || 'forex', choice = s.choice?.choice || '', status = String(s.status || 'open').toLowerCase(), final = Boolean(s.is_final || ['closed','win','loss','sl','stop','stopped','target_complete','manual_close','no_entry','expired','cancelled','canceled'].includes(status));
    const targets = Array.isArray(s.targets) ? s.targets : [];
    return `<article class="signal-card signal-card-v2 ${sell ? 'sell' : ''} ${vip ? 'vip' : ''}">
  <div class="signal-ribbon">${vip ? icon('crown') : icon('shield')}<span>${sentinelAccessLabel(s.access_tier)}</span><span>${sentinelMarketLabel(market)}</span></div>
  <div class="signal-top"><div class="signal-symbol"><span class="side-badge ${sell ? 'sell' : ''}">${esc(String(s.side || '').toUpperCase())}</span><div><strong>${esc(s.symbol)}</strong><small>#${num(s.display_number, 0)} · ${date(s.created_at)}</small></div></div><span class="live-dot">${esc(s.status || 'open')}</span></div>
  <div class="signal-levels"><div><span>ENTRY</span><b>${esc(s.entry)}</b></div><div><span>STOP</span><b>${esc(s.stop)}</b></div><div><span>R/R</span><b>${esc(s.risk_reward || '—')}</b></div></div>
  ${targets.length ? `<div class="target-rail">${targets.slice(0, 5).map((x, i) => `<span>TP${i + 1}<b>${esc(x)}</b></span>`).join('')}</div>` : ''}
  <div class="signal-meta"><span>${icon('market')} ${num(s.quote?.price, 6)}</span><span>${choice ? `انتخاب: ${esc(choice)}` : 'منتظر تصمیم شما'}</span></div>
  <div class="card-actions"><button class="button small" data-signal-detail="${s.id}">${icon('signal')} جزئیات</button>${!choice ? (final ? `<button class="button primary small" data-signal-retro="${s.id}" data-retro-choice="taken">گرفتم</button><button class="button ghost small" data-signal-retro="${s.id}" data-retro-choice="skipped">نگرفتم</button>` : `<button class="button primary small pulse-action" data-signal-take="${s.id}">بگیرش</button><button class="button ghost small" data-signal-skip="${s.id}">نمی‌گیرم</button>`) : ''}<button class="button secondary small" data-copy-signal="${s.id}">${icon('copy')}</button></div>
 </article>`;
};
renderSignals = async function (force = false) {
    const page = $('#page-signals');
    if (!featureEnabled('signals')) {
        page.innerHTML = pageHead('SIGNALS', t('decisionCenter'), '') + disabledPanel();
        return;
    }
    page.innerHTML = pageHead('SIGNALS', 'مرکز سیگنال SENTINEL', 'تفکیک عمومی، VIP، فارکس و کریپتو؛ هر تصمیم مستقیم به ژورنال و مربی ریسک متصل است.') + skeleton(4);
    try {
        const data = await loadResource('signals', force), rows = data?.items || [], access = data?.access || {}, groups = data?.groups || {};
        const accessFilters = `<div class="access-switch"><button class="${state.signalAccessFilter === 'all' ? 'active' : ''}" data-signal-access="all">${icon('signal')} همه <b>${num(data.total || rows.length, 0)}</b></button><button class="${state.signalAccessFilter === 'public' ? 'active' : ''}" data-signal-access="public">${icon('shield')} عمومی <b>${num(groups.public || 0, 0)}</b></button><button class="${state.signalAccessFilter === 'vip' ? 'active' : ''}" data-signal-access="vip" ${!access.vip_active ? 'data-vip-locked' : ''}>${icon('crown')} VIP <b>${access.vip_active ? num(groups.vip || 0, 0) : 'قفل'}</b></button></div>`;
        const marketFilters = `<div class="filters compact"><button class="filter-chip ${state.signalFilter === 'all' ? 'active' : ''}" data-signal-filter="all">همه بازارها</button><button class="filter-chip ${state.signalFilter === 'open' ? 'active' : ''}" data-signal-filter="open">باز</button><button class="filter-chip ${state.signalFilter === 'forex' ? 'active' : ''}" data-signal-filter="forex">فارکس · ${num(groups.forex || 0, 0)}</button><button class="filter-chip ${state.signalFilter === 'crypto' ? 'active' : ''}" data-signal-filter="crypto">کریپتو · ${num(groups.crypto || 0, 0)}</button></div>`;
        const vipNotice = state.signalAccessFilter === 'vip' && !access.vip_active ? `<section class="vip-gate">${icon('crown')}<h2>اتاق سیگنال VIP</h2><p>این بخش فقط برای اشتراک فعال باز می‌شود و سیگنال خصوصی را هم‌زمان با کانال دریافت می‌کند.</p><button class="button primary" data-open="vip">مشاهده پلن‌ها</button></section>` : '';
        page.innerHTML = pageHead('SIGNALS', 'مرکز سیگنال SENTINEL', 'عمومی و VIP، با تصمیم‌گیری مستقیم و ثبت خودکار در ژورنال.') + accessFilters + `<div class="search-box">${icon('search')}<input id="signalSearch" value="${esc(state.signalQuery)}" placeholder="نماد یا شماره سیگنال"></div>` + marketFilters + vipNotice + (!vipNotice ? `<div class="signal-list signal-catalog">${rows.map(signalCard).join('') || empty(t('noSignals'))}</div>${moreButton('signals', data)}` : '');
    }
    catch (err) {
        page.innerHTML = errorPanel(err, 'signals');
    }
};
feedItem = function (row) {
    const signal = row.type === 'signal', vip = row.access_tier === 'vip', decision = row.choice?.choice || '', status = String(row.status || row.signal_status || '').toLowerCase(), final = Boolean(row.is_final || ['closed','win','loss','sl','stop','stopped','target_complete','manual_close','no_entry','expired','cancelled','canceled'].includes(status)), labels = { signal: 'سیگنال', announcement: 'اعلان', news: 'خبر', market: 'تحلیل بازار', publication: 'انتشار' };
    return `<article class="feed-card ${signal ? 'signal' : ''} ${vip ? 'vip' : ''}">
  <div class="feed-icon">${icon(signal ? 'signal' : row.type === 'news' ? 'market' : 'bell')}</div><div class="feed-content">
   <div class="row-between"><strong>${esc(row.title || labels[row.type] || 'به‌روزرسانی')}</strong><div><span class="status-badge ${vip ? 'vip' : 'info'}">${vip ? 'VIP' : esc(labels[row.type] || row.type)}</span></div></div>
   ${row.summary ? `<p>${esc(row.summary)}</p>` : ''}<small>${date(row.created_at)} · ${sentinelMarketLabel(row.market_category)}</small>
   ${signal ? `<div class="card-actions">${decision ? `<span class="status-badge good">${decision === 'taken' ? (row.choice?.retrospective ? 'گرفتم' : 'گرفته شد و در ژورنال ثبت شد') : 'نگرفتم'}</span>` : (final ? `<button class="button primary small" data-signal-retro="${esc(row.signal_id)}" data-retro-choice="taken">گرفتم</button><button class="button ghost small" data-signal-retro="${esc(row.signal_id)}" data-retro-choice="skipped">نگرفتم</button>` : `<button class="button primary small pulse-action" data-signal-take="${esc(row.signal_id)}">بگیرش</button><button class="button ghost small" data-signal-skip="${esc(row.signal_id)}">نمی‌گیرم</button>`)}<button class="button secondary small" data-signal-detail="${esc(row.signal_id)}">بررسی</button></div>` : ''}
  </div></article>`;
};
channelFeedPanel = function (rows = []) {
    const visible = rows.slice(0, 7), vip = visible.filter(x => x.access_tier === 'vip').length;
    return sentinelSection('نبض زنده کانال', 'سیگنال، خبر و اعلان هم‌زمان با تلگرام', `<div class="feed-summary"><span>${icon('signal')} ${num(visible.filter(x => x.type === 'signal').length, 0)} سیگنال</span><span>${icon('crown')} ${num(vip, 0)} VIP</span><span class="live-pill"><i></i> زنده</span></div><div class="feed-list">${visible.map(feedItem).join('') || empty()}</div>`, `<button class="button ghost small" data-open="feed">مشاهده همه</button>`);
};
feedModal = async function () {
    const data = await refreshFeed(false), rows = data?.items || [], filters = [['all', 'همه'], ['signal', 'سیگنال'], ['news', 'خبر و بازار'], ['announcement', 'اعلان'], ['vip', 'VIP']];
    const visible = rows.filter(row => state.feedFilter === 'all' || (state.feedFilter === 'news' ? ['news', 'market'].includes(row.type) : state.feedFilter === 'vip' ? row.access_tier === 'vip' : state.feedFilter === row.type));
    openModal('CHANNEL LIVE', 'نبض زنده کانال', `<div class="feed-toolbar"><div class="filters compact">${filters.map(([key, label]) => `<button class="filter-chip ${state.feedFilter === key ? 'active' : ''}" data-feed-filter="${key}">${label}</button>`).join('')}</div><button class="button secondary small" data-notification-enable>${icon('bell')} اعلان دستگاه</button></div><div class="feed-list">${visible.map(feedItem).join('') || empty()}</div>`, []);
};
tradeCenterBody = function (data) {
    const paper = data.paper_arena || {}, accounts = paper.accounts || [], trades = (paper.trades || []).slice().reverse(), coach = data.risk_coach || {}, prop = data.prop_guardian?.accounts || [], tab = state.tradeHubTab;
    const nav = `<div class="trade-tabs"><button class="${tab === 'overview' ? 'active' : ''}" data-trade-tab="overview">نمای کلی</button><button class="${tab === 'paper' ? 'active' : ''}" data-trade-tab="paper">تمرین معامله</button><button class="${tab === 'prop' ? 'active' : ''}" data-trade-tab="prop">نگهبان Prop</button><button class="${tab === 'coach' ? 'active' : ''}" data-trade-tab="coach">مربی ریسک</button></div>`;
    const overview = `<div class="trade-overview"><div class="trade-hero">${icon('shield')}<div><small>SENTINEL TRADE SHIELD</small><h3>مرکز معامله و محافظت</h3><p>حساب آزمایشی، قوانین Prop و رفتار معاملاتی در سه بخش روشن و مستقل.</p></div></div><div class="metric-grid">${metric('حساب تمرینی', num(accounts.length, 0), '', 'info')}${metric('معامله باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('انضباط', `${num(coach.discipline_score || 0, 0)}/100`, '', 'good')}${metric('ریسک سیگنال', pct(coach.signal_risk?.active_risk_percent || 0), '', '')}</div><div class="quick-grid compact"><button data-trade-tab="paper">${icon('signal')}<strong>تمرین معامله</strong><small>ثبت و مدیریت تمام TPها</small></button><button data-trade-tab="prop">${icon('shield')}<strong>نگهبان Prop</strong><small>کنترل نقض قوانین</small></button><button data-trade-tab="coach">${icon('chart')}<strong>مربی ریسک</strong><small>تحلیل سیگنال‌های گرفته‌شده</small></button><button data-open="calculator">${icon('market')}<strong>محاسبه حجم</strong><small>قبل از ورود</small></button></div></div>`;
    const paperView = `<section class="panel flat"><div class="panel-head"><div><h3>تمرین معامله</h3><p>حساب آزمایشی و همه سناریوهای خروج در یکجا</p></div><div class="card-actions"><button class="button secondary small" data-paper-account-new>حساب جدید</button>${accounts.length ? '<button class="button primary small" data-paper-trade-new>معامله جدید</button>' : ''}</div></div><div class="panel-body"><div class="metric-grid">${metric('باز', num(paper.summary?.open || 0, 0), '', 'warn')}${metric('بسته', num(paper.summary?.closed || 0, 0), '', 'good')}${metric('لغو', num(paper.summary?.cancelled || 0, 0), '', '')}</div><div class="journal-list">${trades.map(trade => `<article class="journal-card"><div class="row-between"><strong>${esc(trade.symbol)} · ${esc(String(trade.side).toUpperCase())}</strong><span class="status-badge ${trade.status === 'open' ? 'good' : 'info'}">${esc(trade.status)}</span></div><p>Entry ${esc(trade.entry)} · SL ${esc(trade.stop)} · باقی‌مانده ${pct(Number(trade.remaining_fraction ?? 1) * 100, 0)}</p><small>${date(trade.opened_at)} · ${num(trade.realized_r || trade.result_r || 0, 2)}R</small>${trade.status === 'open' ? tradeActions(trade) : ''}</article>`).join('') || empty()}</div></div></section>`;
    const propView = `<section class="panel flat"><div class="panel-head"><div><h3>نگهبان Prop</h3><p>فاصله تا نقض قانون و آمادگی چالش</p></div></div><div class="panel-body journal-list">${prop.map(row => `<article class="prop-card"><div class="row-between"><strong>${esc(row.title || `Account ${row.account_id}`)}</strong><span class="status-badge ${['safe', 'passed'].includes(row.status) ? 'good' : row.status === 'blocked' ? 'bad' : 'warn'}">${esc(row.status)}</span></div>${row.status === 'unconfigured' ? `<p>قوانین این حساب هنوز تنظیم نشده است.</p><button class="button small" data-prop-standard="${row.account_id}">فعال‌کردن الگوی استاندارد</button>` : `<div class="prop-rings">${sentinelRing(row.metrics?.daily_loss_percent || 0, 'ضرر روزانه', Number(row.metrics?.daily_loss_percent || 0) > 4 ? 'red' : 'cyan')}${sentinelRing(row.metrics?.total_drawdown_percent || 0, 'افت کل', Number(row.metrics?.total_drawdown_percent || 0) > 8 ? 'red' : 'gold')}${sentinelRing(row.metrics?.profit_progress_percent || 0, 'هدف سود', 'green')}</div><div class="notice ${row.hard_blocks?.length ? 'danger' : ''}">${(row.hard_blocks || []).join('، ') || ((row.warnings || []).join('، ') || 'هیچ نقض فعالی ثبت نشده است.')}</div>`}</article>`).join('') || empty()}</div></section>`;
    const coachView = `<section class="panel flat"><div class="panel-head"><div><h3>مربی رفتار و ریسک</h3><p>متصل به سیگنال‌های گرفته‌شده و ژورنال واقعی شما</p></div><button class="button secondary small" data-risk-coach-refresh>تحلیل مجدد</button></div><div class="panel-body"><div class="coach-score">${sentinelRing(coach.discipline_score || 0, 'انضباط', 'green')}<div><strong>${num(coach.signal_risk?.taken_count || 0, 0)} سیگنال گرفته‌شده</strong><p>${pct(coach.signal_risk?.active_risk_percent || 0)} ریسک فعال · ${num(coach.net_r || 0, 2)}R خالص</p></div></div><div class="journal-list">${(coach.findings || []).map(x => `<div class="notice ${x.severity === 'high' ? 'danger' : x.severity === 'medium' ? 'warning' : ''}"><strong>${esc(x.title || x.code)}</strong><small>${num(x.count || 0, 0)} بار مشاهده</small></div>`).join('') || '<div class="notice good">الگوی پرخطر واضحی دیده نشد.</div>'}${(coach.recommendations || []).map(x => `<p class="coach-tip">${icon('shield')} ${esc(x)}</p>`).join('')}</div></div></section>`;
    return `<div class="trade-center-v2">${nav}${tab === 'paper' ? paperView : tab === 'prop' ? propView : tab === 'coach' ? coachView : overview}</div>`;
};
function calculatorModal() {
    const account = state.resources.overview?.risk?.default_account || {}, balance = Number(account.equity || account.balance || 10000), leverage = Number(account.leverage || 100);
    openModal('RISK CALCULATOR', 'محاسبه‌گر دقیق حجم و مارجین SENTINEL', `<form id="riskCalculatorForm"><div class="notice info"><strong>محاسبه هم‌زمان محدودیت ریسک و مارجین</strong><p>حجم نهایی از بین حجم مجاز ریسک، ظرفیت مارجین، گام حجم و حداقل سفارش انتخاب می‌شود.</p></div><div class="form-grid"><div class="field"><label>بازار</label><select id="calcMarket"><option value="forex">فارکس / CFD</option><option value="crypto">کریپتو اسپات / فیوچرز</option></select></div><div class="field"><label>نماد</label><input id="calcSymbol" value="XAUUSD" required></div><div class="field"><label>موجودی / Equity دلار</label><input id="calcBalance" type="number" min="1" step="any" value="${esc(balance)}" required></div><div class="field"><label>مارجین آزاد دلار</label><input id="calcAvailableMargin" type="number" min=".01" step="any" value="${esc(balance)}" required><small class="field-help">اگر مارجین آزاد کمتر از موجودی است، مقدار واقعی را وارد کنید.</small></div><div class="field"><label>ریسک درصدی</label><input id="calcRisk" type="number" min=".01" max="20" step=".01" value="1" required></div><div class="field"><label>قیمت ورود</label><input id="calcEntry" type="number" min=".00000001" step="any" required></div><div class="field"><label>حد ضرر</label><input id="calcStop" type="number" min=".00000001" step="any" required></div><div class="field"><label>اهرم</label><input id="calcLeverage" type="number" min="1" max="1000" value="${esc(leverage)}" required></div><div class="field"><label>کارمزد رفت‌وبرگشت %</label><input id="calcFee" type="number" min="0" max="10" step=".001" value="0"><small class="field-help">برای کریپتو؛ مجموع کارمزد ورود و خروج.</small></div><div class="field"><label>نرخ تبدیل ارز مظنه به USD</label><input id="calcCrossRate" type="number" min=".00000001" step="any" placeholder="فقط جفت‌های Cross"></div></div><details class="details-block"><summary>مشخصات پیشرفته بروکر / صرافی</summary><div class="form-grid"><div class="field"><label>Contract Size فارکس</label><input id="calcContractSize" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>حداقل لات</label><input id="calcMinLot" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>گام لات</label><input id="calcLotStep" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>حداکثر لات</label><input id="calcMaxLot" type="number" min=".00000001" step="any" placeholder="خودکار"></div><div class="field"><label>Quantity Step کریپتو</label><input id="calcQuantityStep" type="number" min=".000000000001" step="any" placeholder="0.00000001"></div><div class="field"><label>حداقل Quantity</label><input id="calcMinQuantity" type="number" min=".000000000001" step="any" placeholder="برابر گام مقدار"></div><div class="field"><label>حداقل Notional</label><input id="calcMinNotional" type="number" min="0" step="any" placeholder="مثلاً 5 USDT"></div></div></details><button class="button primary wide" type="button" data-risk-calculate>${icon('shield')} محاسبه دقیق و امن</button></form><div id="calculatorResult"></div>`, []);
}
function optionalNumber(id) { const value = $(id)?.value?.trim(); return value === '' || value == null ? null : Number(value); }
async function runRiskCalculator() {
    const form = $('#riskCalculatorForm');
    if (!form?.reportValidity()) return;
    setBusy(true);
    try {
        const payload = { market: $('#calcMarket').value, symbol: $('#calcSymbol').value, balance: Number($('#calcBalance').value), available_margin: Number($('#calcAvailableMargin').value), risk_percent: Number($('#calcRisk').value), entry: Number($('#calcEntry').value), stop: Number($('#calcStop').value), leverage: Number($('#calcLeverage').value), fee_percent: Number($('#calcFee').value), cross_rate: optionalNumber('#calcCrossRate'), contract_size: optionalNumber('#calcContractSize'), min_lot: optionalNumber('#calcMinLot'), lot_step: optionalNumber('#calcLotStep'), max_lot: optionalNumber('#calcMaxLot'), quantity_step: optionalNumber('#calcQuantityStep'), min_quantity: optionalNumber('#calcMinQuantity'), min_notional: optionalNumber('#calcMinNotional') };
        const data = await action('risk_calculate', payload, false), r = data.result || {}, forex = r.mode === 'forex', size = r.lot ?? r.quantity ?? r.units, unit = forex ? 'LOT' : 'UNIT', constraint = r.capped_by_margin ? 'ظرفیت مارجین' : 'بودجه ریسک';
        const advanced = forex ? `<div class="metric-grid">${metric('حجم خام', num(r.raw_lot, 6), 'Lot', 'info')}${metric('حد ریسک', num(r.risk_limited_lot, 6), 'Lot', '')}${metric('حد مارجین', num(r.margin_limited_lot, 6), 'Lot', r.capped_by_margin ? 'warn' : '')}${metric('فاصله استاپ', `${num(r.pip_distance, 2)} pip`, `${num(r.stop_percent, 4)}%`, '')}${metric('ارزش هر پیپ', money(r.pip_value_per_lot, 'USD'), 'برای ۱ لات', '')}${metric('Contract Size', num(r.contract_size, 4), '', '')}</div>` : `<div class="metric-grid">${metric('مقدار خام', num(r.raw_quantity, 10), '', 'info')}${metric('حد ریسک', num(r.risk_limited_quantity, 10), '', '')}${metric('حد قابل خرید', num(r.max_affordable_quantity, 10), '', r.capped_by_margin ? 'warn' : '')}${metric('فاصله استاپ', `${num(r.stop_percent, 4)}%`, '', '')}${metric('ریسک هر واحد', money(r.loss_per_unit, 'USD'), '', '')}${metric('حداقل Notional', money(r.min_notional, 'USD'), '', '')}</div>`;
        $('#calculatorResult').innerHTML = `<section class="panel calculator-audit"><div class="panel-head"><div><small class="eyebrow">POSITION AUDIT</small><h3>نتیجه محاسبه دقیق</h3></div><span class="status-badge ${r.capped_by_margin ? 'warn' : 'good'}">${esc(constraint)}</span></div><div class="panel-body"><section class="calculator-result"><div class="result-shield">${icon('shield')}</div><div><small>حجم اجرایی پیشنهادی</small><strong>${num(size, forex ? 4 : 10)} ${unit}</strong><p>ریسک واقعی: ${money(r.effective_risk || 0, 'USD')} (${num(r.effective_risk_percent, 4)}%)</p><span>حجم به پایین گرد شده تا ریسک از سقف تعیین‌شده عبور نکند.</span></div></section><div class="metric-grid">${metric('بودجه ریسک', money(r.risk_amount || 0, 'USD'), `${num(r.risk_budget_usage_percent, 2)}% مصرف`, 'info')}${metric('ارزش پوزیشن', money(r.notional || 0, 'USD'), '', '')}${metric('مارجین لازم', money(r.estimated_margin || 0, 'USD'), `${num(r.margin_usage_percent, 2)}% مارجین آزاد`, r.margin_usage_percent > 90 ? 'warn' : '')}${metric('مارجین آزاد', money(r.available_margin || payload.available_margin, 'USD'), '', '')}</div>${advanced}${r.below_minimum || r.below_min_notional ? `<div class="notice danger"><strong>حجم زیر حداقل بروکر / صرافی است</strong><p>مشخصات Contract، گام حجم و حداقل Notional را با نماد واقعی تطبیق دهید.</p></div>` : ''}${r.capped_by_margin ? `<div class="notice warning"><strong>حجم به‌دلیل محدودیت مارجین کاهش یافت</strong><p>حجم مبتنی بر ریسک بیشتر بود، اما با مارجین آزاد و اهرم فعلی قابل اجرا نبود.</p></div>` : `<div class="notice good"><strong>حجم با بودجه ریسک محدود شده است</strong><p>مارجین فعلی برای حجم محاسبه‌شده کافی است.</p></div>`}<div class="notice info"><small>پیش از سفارش، Contract Size، Tick/Pip Value، حداقل حجم و گام سفارش را از مشخصات زنده بروکر یا صرافی بررسی کنید.</small></div></div></section>`;
    } catch (err) { toast(err.message, 'error'); } finally { setBusy(false); }
}
async function campaignsModal() {
    setBusy(true);
    try {
        const data = await loadResource('adminCampaigns', true), rows = data?.items || [], summary = data?.summary || {};
        openModal('CAMPAIGN CONTROL', 'مرکز دقیق کمپین‌ها', `<div class="campaign-head"><div class="metric-grid">${metric('کل', num(summary.total || rows.length, 0), '', 'info')}${metric('فعال', num(summary.active || 0, 0), '', 'good')}${metric('زمان‌بندی', num(summary.scheduled || 0, 0), '', 'warn')}${metric('تکمیل', num(summary.completed || 0, 0), '', '')}</div><button class="button primary" data-campaign-new>${icon('plus')} کمپین جدید</button></div><div class="campaign-list">${rows.map(row => `<article class="campaign-card"><div class="row-between"><div><small>${esc(row.category || 'CAMPAIGN')}</small><h3>${esc(row.name)}</h3></div><span class="status-badge ${row.status === 'active' ? 'good' : row.status === 'draft' ? 'warn' : 'info'}">${esc(row.status)}</span></div><div class="campaign-funnel"><span style="--funnel:100">مخاطب <b>${num(row.metrics?.audience_size || 0, 0)}</b></span><span style="--funnel:${Math.max(10, row.metrics?.delivery_success_rate || 0)}">تحویل <b>${num(row.metrics?.sent || 0, 0)}</b></span><span style="--funnel:${Math.max(10, row.metrics?.conversion_rate || 0)}">تبدیل <b>${num(row.metrics?.approved_orders || 0, 0)}</b></span></div><div class="row-between"><small>کیفیت داده: ${esc(row.measurement?.quality || 'unknown')}</small><button class="button secondary small" data-campaign-detail="${esc(row.id)}">گزارش دقیق</button></div></article>`).join('') || empty()}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function campaignCreateModal() {
    openModal('CAMPAIGN BUILDER', 'ساخت کمپین قابل‌اندازه‌گیری', `<form id="campaignForm"><div class="form-grid"><div class="field"><label>نام کمپین</label><input id="campaignName" maxlength="100" required></div><div class="field"><label>دسته</label><select id="campaignCategory"><option value="retention">نگهداشت</option><option value="conversion">فروش و تبدیل</option><option value="activation">فعال‌سازی</option><option value="winback">بازگشت کاربر</option><option value="vip_upgrade">ارتقای VIP</option><option value="announcement">اطلاع‌رسانی</option></select></div><div class="field"><label>مخاطب</label><select id="campaignAudience"><option value="all">همه کاربران</option><option value="vip_active">VIP فعال</option><option value="never_vip">بدون سابقه VIP</option><option value="inactive_user">غیرفعال</option><option value="renewal_due">نزدیک تمدید</option><option value="abandoned_checkout">خرید نیمه‌تمام</option></select></div><div class="field"><label>مسیر ارسال</label><select id="campaignDelivery"><option value="link_bot">لینک اختصاصی ربات</option><option value="link_channel">لینک اختصاصی کانال</option><option value="link_both">ربات و کانال</option><option value="direct">پیام مستقیم ربات</option><option value="public">کانال عمومی</option><option value="private">کانال VIP</option></select></div><div class="field full"><label>هدف قابل‌اندازه‌گیری</label><input id="campaignObjective" maxlength="240" placeholder="مثلاً تبدیل کاربران عمومی به VIP"></div><div class="field full"><label>متن کمپین</label><textarea id="campaignMessage" maxlength="3500" required></textarea></div></div></form>`, [{ label: 'ذخیره پیش‌نویس', kind: 'primary', action: async () => { const form = $('#campaignForm'); if (!form.reportValidity())
                return; await action('campaign_create', { name: $('#campaignName').value, category: $('#campaignCategory').value, audience: $('#campaignAudience').value, delivery: $('#campaignDelivery').value, objective: $('#campaignObjective').value, message: $('#campaignMessage').value, tracking: { source: 'miniapp', created_version: APP_VERSION } }, false); invalidate('adminCampaigns'); closeModal(); await campaignsModal(); toast('کمپین ایجاد شد'); } }]);
}
async function campaignDetailModal(id) {
    setBusy(true);
    try {
        const row = await request(`./api/v1/admin/campaigns/${encodeURIComponent(id)}`), m = row.metrics || {}, measure = row.measurement || m.measurement || {}, anomalies = measure.anomalies || [];
        openModal('CAMPAIGN REPORT', row.name || id, `<div class="metric-grid">${metric('مخاطب', num(m.audience_size || 0, 0), '', 'info')}${metric('تحویل موفق', pct(m.delivery_success_rate || 0), '', 'good')}${metric('تبدیل', pct(m.conversion_rate || 0), '', 'warn')}${metric('درآمد', money(m.revenue || 0, 'T'), '', '')}</div><div class="campaign-quality ${measure.quality === 'high' ? 'good' : 'warn'}">${icon(measure.quality === 'high' ? 'check' : 'alert')}<div><strong>کیفیت اندازه‌گیری: ${esc(measure.quality || 'unknown')}</strong><p>${esc(measure.attribution_model || '')}</p></div></div>${anomalies.length ? `<div class="notice warning">${anomalies.map(esc).join(' · ')}</div>` : ''}<pre class="campaign-message">${esc(row.message || '')}</pre><div class="card-actions">${['draft', 'active', 'paused', 'failed'].includes(row.status) ? `<button class="button primary" data-campaign-schedule="${esc(id)}">انتشار امن</button>` : ''}${row.status === 'draft' ? `<button class="button secondary" data-campaign-status="${esc(id)}" data-status="active">فعال‌کردن</button>` : ''}${row.status === 'active' ? `<button class="button secondary" data-campaign-status="${esc(id)}" data-status="paused">توقف</button>` : ''}</div>`, []);
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
function adminSignalValues(id) { return ($(id)?.value || '').split(/[,،؛]+/).map(x => Number(String(x).trim())).filter(Number.isFinite); }
function adminSignalQuoteHtml(q) { const current = Number(q?.price), entries = adminSignalValues('#asEntries'), targets = adminSignalValues('#asTargets'), stop = Number($('#asStop')?.value), side = String($('#asSide')?.value || 'buy'), entry = entries.length ? entries.reduce((a, b) => a + b, 0) / entries.length : NaN; if (!Number.isFinite(current))
    return '<div class="notice warning">قیمت معتبر دریافت نشد.</div>'; const low = entries.length ? Math.min(...entries) : NaN, high = entries.length ? Math.max(...entries) : NaN, inside = Number.isFinite(low) && current >= low && current <= high, entryDistance = Number.isFinite(low) ? (inside ? 0 : Math.min(Math.abs(current - low), Math.abs(current - high)) / current * 100) : NaN, risk = Number.isFinite(entry) && Number.isFinite(stop) ? Math.abs(entry - stop) : NaN; const nearest = targets.map((v, i) => ({ v, i, d: Math.abs(v - current) / current * 100, reached: side === 'buy' ? current >= v : current <= v })).sort((a, b) => a.d - b.d)[0]; const targetRows = targets.map((v, i) => { const rr = Number.isFinite(risk) && risk > 0 ? Math.abs(v - entry) / risk : NaN, d = Math.abs(v - current) / current * 100, reached = side === 'buy' ? current >= v : current <= v; return `<div class="account-card"><div class="row-between"><strong>TP${i + 1} · ${num(v, 7)}</strong><span class="status-badge ${reached ? 'good' : 'info'}">${reached ? 'رسیده' : `${pct(d, 3)} فاصله`}</span></div><p>${Number.isFinite(rr) ? `${num(rr, 2)}R` : 'R نامشخص'}</p></div>`; }).join(''); return `<section class="panel"><div class="panel-head"><div><small class="eyebrow">LIVE CONSENSUS TRACKER</small><h3>${esc(q.symbol || '')}</h3></div><span class="status-badge ${q.stale ? 'warn' : 'good'}">${q.consensus ? 'CONSENSUS' : 'LIVE'} · ${num(q.provider_count || 1, 0)} API</span></div><div class="panel-body"><div class="metric-grid">${metric('قیمت فعلی', num(current, 7), '', 'good')}${metric('فاصله تا Entry', Number.isFinite(entryDistance) ? pct(entryDistance, 3) : '—', '', inside ? 'good' : 'info')}${metric('نزدیک‌ترین تارگت', nearest ? `TP${nearest.i + 1} · ${pct(nearest.d, 3)}` : '—', '', '')}</div><div class="notice ${inside ? 'good' : 'info'}"><strong>${inside ? 'قیمت داخل محدوده ورود است' : Number.isFinite(entryDistance) ? `${pct(entryDistance, 3)} تا محدوده ورود باقی مانده` : 'سطوح Entry را وارد کنید'}</strong><small>${esc(q.source || q.provider || '')} · ${date(q.updated_at)} · confidence ${pct(Number(q.confidence || 0) * 100, 0)}</small></div>${targetRows}</div></section>`; }
async function refreshAdminSignalQuote(silent = false) { const form = $('#adminSignalForm'), box = $('#adminSignalQuote'); if (!form || !box)
    return; const symbol = String($('#asSymbol')?.value || '').trim(); if (symbol.length < 2) {
    box.innerHTML = '<div class="notice info">نماد را وارد کنید تا ردیاب چندمنبعی فعال شود.</div>';
    return;
} if (!silent)
    box.innerHTML = '<div class="notice info">در حال دریافت بهترین قیمت از APIهای فعال…</div>'; try {
    const q = await request(`./api/v1/market/quote?symbol=${encodeURIComponent(symbol)}&live=1`, {}, 16000);
    state.adminSignalQuote = q;
    box.innerHTML = adminSignalQuoteHtml(q);
}
catch (err) {
    box.innerHTML = `<div class="notice warning">${esc(err.message)}</div>`;
} }
function adminSignalComposer() {
    openModal('SIGNAL DESK', 'ارسال سیگنال با ردیاب زنده', `<form id="adminSignalForm"><div class="form-grid"><div class="field"><label>نماد</label><input id="asSymbol" required maxlength="20" value="XAUUSD" placeholder="XAUUSD"></div><div class="field"><label>جهت</label><select id="asSide"><option value="buy">BUY</option><option value="sell">SELL</option></select></div><div class="field"><label>ورودها</label><input id="asEntries" required placeholder="2350 یا 2350,2347"></div><div class="field"><label>تارگت‌ها</label><input id="asTargets" required placeholder="2360,2370,2380"></div><div class="field"><label>حد ضرر</label><input id="asStop" required inputmode="decimal"></div><div class="field"><label>ریسک درصدی</label><input id="asRisk" required inputmode="decimal" value="1"></div><div class="field"><label>مقصد</label><select id="asTarget"><option value="public">کانال عمومی</option><option value="private">کانال VIP</option><option value="both">هر دو کانال</option></select></div><div class="field"><label>تایم‌فریم</label><input id="asTimeframe" value="1H" maxlength="20"></div></div><div class="card-actions"><button type="button" class="button secondary" data-admin-quote-refresh>${icon('refresh')} دریافت قیمت و محاسبه فاصله‌ها</button></div><div id="adminSignalQuote"><div class="notice info">نماد و سطوح را وارد کنید؛ قیمت اجماعی، فاصله Entry، نزدیک‌ترین TP و R/R محاسبه می‌شود.</div></div><div class="field"><label>یادداشت/تحلیل</label><textarea id="asNote" maxlength="2000"></textarea></div><div class="notice info">سیگنال از مسیر امن ربات منتشر و همان لحظه در کانال و مینی‌اپ ثبت می‌شود.</div></form>`, [{ label: 'اعتبارسنجی و انتشار', kind: 'primary', action: async () => { const f = $('#adminSignalForm'); if (!f.reportValidity())
                return; const split = id => $(id).value.split(/[,،؛]+/).map(x => x.trim()).filter(Boolean); setBusy(true); try {
                const result = await action('miniapp_signal_publish', { symbol: $('#asSymbol').value, side: $('#asSide').value, entries: split('#asEntries'), targets: split('#asTargets'), stop: $('#asStop').value, risk: $('#asRisk').value, target: $('#asTarget').value, timeframe: $('#asTimeframe').value, note: $('#asNote').value }, false);
                closeModal();
                invalidate('signals', 'feed', 'overview', 'adminSignalJobs');
                toast(`سیگنال Q-${result.queue_id || '—'} برای انتشار در ربات، کانال و مینی‌اپ ثبت شد`);
                if (result.queue_id)
                    await adminSignalJobDetail(result.queue_id, { poll: true });
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
    setTimeout(() => refreshAdminSignalQuote(true), 80);
}
function adminAnnouncementComposer() {
    openModal('ANNOUNCEMENT DESK', 'انتشار اعلان کانال', `<form id="adminAnnouncementForm"><div class="form-grid"><div class="field"><label>عنوان</label><input id="aaTitle" required minlength="3" maxlength="100"></div><div class="field"><label>مقصد</label><select id="aaDelivery"><option value="public">کانال عمومی</option><option value="private">کانال VIP</option></select></div></div><div class="field"><label>متن اعلان</label><textarea id="aaMessage" required maxlength="3500" rows="8"></textarea></div><div class="notice info">اعلان از صف پایدار کمپین منتشر می‌شود تا ارسال دوباره، قطع سرویس یا کلیک تکراری باعث انتشار چندباره نشود.</div></form>`, [{ label: 'ثبت و انتشار', kind: 'primary', action: async () => { const f = $('#adminAnnouncementForm'); if (!f.reportValidity())
                return; setBusy(true); try {
                await action('miniapp_announcement_publish', { title: $('#aaTitle').value, message: $('#aaMessage').value, delivery: $('#aaDelivery').value }, false);
                closeModal();
                invalidate('adminCampaigns', 'feed');
                toast('اعلان در صف پایدار انتشار قرار گرفت');
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
}
function signalJobTone(status) { return status === 'sent' ? 'good' : status === 'dead' || status === 'failed' ? 'bad' : status === 'processing' || status === 'retrying' ? 'warn' : status === 'cancelled' ? 'muted' : 'info'; }
function signalJobStatusLabel(status) { const fa = { pending: 'در انتظار', processing: 'در حال انتشار', retrying: 'در انتظار تلاش مجدد', sent: 'ارسال‌شده', dead: 'شکست دائمی', cancelled: 'لغوشده', failed: 'ناموفق' }; return state.lang === 'fa' ? (fa[status] || status) : status; }
function signalJobHtml(job) { const status = String(job?.status || 'pending'), delivered = (job?.delivered_channels || []).length, deliveryRows = (job?.deliveries || []).map(x => `<div class="health-card"><strong>${esc(x.channel || 'channel')}</strong><span class="status-badge good">#${esc(x.message_id || '—')}</span><small>${esc(String(x.chat_id || ''))}</small></div>`).join(''); return `<section class="panel"><div class="panel-head"><div><small class="eyebrow">SIGNAL DELIVERY Q-${esc(job?.id || '—')}</small><h3>${esc(job?.symbol || '—')} · ${esc(job?.side || '—')}</h3></div><span class="status-badge ${signalJobTone(status)}">${esc(signalJobStatusLabel(status))}</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'مقصد' : 'Target', esc(job?.target || '—'), '', 'info')}${metric(state.lang === 'fa' ? 'شناسه سیگنال' : 'Signal ID', job?.signal_id ? `#${esc(job.signal_id)}` : '—', '', '')}${metric(state.lang === 'fa' ? 'تلاش‌ها' : 'Attempts', `${num(job?.attempts || 0, 0)}/${num(job?.max_attempts || 3, 0)}`, '', '')}${metric(state.lang === 'fa' ? 'تحویل‌ها' : 'Delivered', num(delivered, 0), 'channel', 'good')}</div><p>${state.lang === 'fa' ? 'ورود' : 'Entry'}: ${esc((job?.entries || []).join(' / ') || '—')} · SL: ${esc(job?.stop ?? '—')}</p><p>TP: ${esc((job?.targets || []).join(' / ') || '—')}</p>${deliveryRows ? `<div class="health-grid">${deliveryRows}</div>` : ''}${job?.last_error ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'خطای انتشار' : 'Delivery error'}</strong><p>${esc(job.last_error)}</p></div>` : `<div class="notice ${status === 'sent' ? 'good' : 'info'}"><strong>${status === 'sent' ? (state.lang === 'fa' ? 'سیگنال در کانال و مینی‌اپ ثبت شد.' : 'Signal is live in channel and Mini App.') : (state.lang === 'fa' ? 'انتشار از صف امن ربات در حال انجام است…' : 'Publishing through the bot delivery queue…')}</strong></div>`}<div class="card-actions">${job?.can_retry ? `<button class="button primary small" data-signal-job-retry="${esc(job.id)}">${state.lang === 'fa' ? 'تلاش مجدد' : 'Retry'}</button>` : ''}${job?.can_edit ? `<button class="button secondary small" data-signal-job-edit="${esc(job.id)}">${state.lang === 'fa' ? 'ویرایش صف' : 'Edit queue'}</button>` : ''}${job?.can_cancel ? `<button class="button danger small" data-signal-job-cancel="${esc(job.id)}">${state.lang === 'fa' ? 'لغو' : 'Cancel'}</button>` : ''}</div></div></section>`; }
async function adminSignalJobDetail(id, { poll = true } = {}) { openModal('SIGNAL DELIVERY', `Q-${id}`, `<div id="signalJobStatus">${skeleton(2)}</div>`, []); const box = () => $('#signalJobStatus'); let attempts = 0; while (attempts < 24) {
    try {
        const job = await request(`./api/v1/admin/signal-jobs/${encodeURIComponent(id)}`, {}, 12000);
        if (box())
            box().innerHTML = signalJobHtml(job);
        if (['sent', 'dead', 'cancelled'].includes(job.status)) {
            if (job.status === 'sent') {
                invalidate('signals', 'feed', 'overview', 'adminSignalJobs');
                await Promise.allSettled([loadOverview(true), loadResource('signals', true), refreshFeed(true)]);
                renderChrome();
                if (state.page === 'home')
                    renderHome();
            }
            return job;
        }
    }
    catch (err) {
        if (box())
            box().innerHTML = `<div class="notice danger">${esc(err.message)}</div>`;
        if (!poll)
            throw err;
    }
    if (!poll)
        return null;
    attempts++;
    await new Promise(resolve => setTimeout(resolve, 2000));
} if (box())
    box().insertAdjacentHTML('beforeend', `<div class="notice warning">${state.lang === 'fa' ? 'انتشار هنوز در صف است؛ این صفحه را بعداً دوباره باز کنید.' : 'Delivery is still queued; reopen this page shortly.'}</div>`); return null; }
async function adminSignalJobsCenter() { setBusy(true); try {
    const d = await loadResource('adminSignalJobs', true), rows = d?.items || [];
    openModal('SIGNAL DELIVERY', 'وضعیت انتشار سیگنال‌ها', `<div class="notice info"><strong>BOT ↔ CHANNEL ↔ MINI APP</strong><p>هر ارسال تا نتیجه نهایی قابل ردیابی است.</p></div><div class="journal-list">${rows.map(x => `<article class="journal-card"><div class="row-between"><strong>Q-${esc(x.id)} · ${esc(x.symbol)} ${esc(x.side)}</strong><span class="status-badge ${signalJobTone(x.status)}">${esc(x.status)}</span></div><p>${esc(x.target)} · ${date(x.created_at || x.run_at)}</p>${x.last_error ? `<small class="text-bad">${esc(x.last_error)}</small>` : ''}<div class="card-actions"><button class="button secondary small" data-admin-signal-job="${esc(x.id)}">${esc(t('details'))}</button></div></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminTicketCenter() { setBusy(true); try {
    const d = await loadResource('adminTickets', true), rows = d?.items || [];
    openModal('ADMIN SUPPORT', 'مدیریت تیکت‌های ربات و مینی‌اپ', `<div class="notice info"><strong>LIVE TWO-WAY SUPPORT</strong><p>پاسخ ادمین در مینی‌اپ و ربات کاربر هم‌زمان اطلاع‌رسانی می‌شود.</p></div><div class="journal-list">${rows.map(x => `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>User ${esc(x.user_id)} · ${esc(x.priority || 'normal')} · ${esc(x.waiting_for || 'admin')}</p><small>${date(x.updated_at || x.created_at)} · ${num((x.messages || []).length, 0)} message</small><div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${state.lang === 'fa' ? 'بازکردن و پاسخ' : 'Open & reply'}</button></div></article>`).join('') || empty()}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function adminPlatformCenter() { return adminModuleControlCenter(); }
renderMore = async function () {
    const page = $('#page-more'), o = state.resources.overview || {}, admin = Boolean(o.admin_available), adminInfo = o.admin || {}, permissions = new Set(adminInfo.permissions || []), owner = String(adminInfo.role || '').toLowerCase() === 'owner', can = permission => owner || permissions.has(permission);
    const adminServices = [
        admin ? sentinelService('shield', 'کنسول عملیات', 'حاکمیت، شیفت و سلامت', 'admin') : '',
        admin && can('signals') ? sentinelService('signal', 'ارسال سیگنال', 'انتشار در کانال، ربات و مینی‌اپ', 'admin-signal') : '',
        admin && can('signals') ? sentinelService('history', 'پیگیری ارسال سیگنال', 'صف، تحویل و خطاها', 'admin-signal-jobs') : '',
        admin && (can('signals') || can('signal_edit') || can('signal_results') || can('signal_delete')) ? sentinelService('chart', 'مدیریت سیگنال‌ها', 'ویرایش، نتیجه و حذف', 'admin-signals') : '',
        admin && can('users') ? sentinelService('account', 'کنترل کاربران', 'جست‌وجو، VIP و مسدودی', 'admin-users') : '',
        admin && can('admin_management') ? sentinelService('shield', 'مدیریت ادمین‌ها', 'افزودن و سطح دسترسی', 'admin-admins') : '',
        admin && can('tickets') ? sentinelService('support', 'تیکت‌های پشتیبانی', 'مشاهده و پاسخ دوطرفه', 'admin-tickets', o.account?.open_tickets || 0) : '',
        admin && can('payments') ? sentinelService('wallet', 'پرداخت و رسید VIP', 'تأیید یا رد از مینی‌اپ', 'admin') : '',
        admin && can('signal_templates') ? sentinelService('chart', 'قالب‌های سیگنال', 'پس‌زمینه و چیدمان', 'admin') : '',
        admin && can('announcements') ? sentinelService('bell', 'میز اعلان', 'انتشار امن اطلاعیه', 'admin-announcement') : '',
        admin && can('campaigns') ? sentinelService('market', 'مرکز کمپین', 'ساخت، ارسال و آمار دقیق', 'campaigns') : '',
        admin && can('system_control') ? sentinelService('settings', 'وضعیت تمام ماژول‌ها', 'دسترسی، اتصال و زیرسامانه‌ها', 'admin-platform') : ''
    ].filter(Boolean).join('');
    page.innerHTML = pageHead('SENTINEL HUB', 'تمام خدمات', 'ابزارها بر اساس کاری که می‌خواهید انجام دهید دسته‌بندی شده‌اند.') +
        `<div class="service-groups">
  <section><div class="service-title">${icon('signal')}<div><h2>معامله و تصمیم</h2><p>از سیگنال تا ثبت نتیجه</p></div></div><div class="service-list">${sentinelService('shield', 'مرکز معامله', 'تمرین، Prop و مربی ریسک', 'tradeCenter')}${sentinelService('chart', 'محاسبه‌گر حجم', 'فارکس و کریپتو', 'calculator')}${sentinelService('journal', 'ژورنال و معاملات', 'ورود، خروج و تحلیل', 'journal-route')}${sentinelService('market', 'قیمت و بازار', 'واچ‌لیست و رژیم بازار', 'market')}</div></section>
  <section><div class="service-title">${icon('crown')}<div><h2>اشتراک و دسترسی</h2><p>VIP، سفارش و پرداخت</p></div></div><div class="service-list">${sentinelService('crown', 'اشتراک VIP', o.account?.vip_active ? 'اشتراک شما فعال است' : 'مشاهده پلن‌ها و خرید', 'vip', 0, o.account?.vip_active ? 'vip' : '')}${sentinelService('wallet', 'سفارش‌ها', 'رسید و وضعیت پرداخت', 'orders', o.account?.pending_orders || 0)}${sentinelService('signal', 'نبض کانال', 'سیگنال، خبر و اعلان', 'feed')}</div></section>
  <section><div class="service-title">${icon('bell')}<div><h2>اطلاعات و ارتباط</h2><p>اعلان، تقویم و پشتیبانی</p></div></div><div class="service-list">${sentinelService('trophy', 'مسابقه‌ها', 'شرکت مستقیم و مشاهده نتیجه', 'contests')}${sentinelService('bell', 'مرکز اعلان', 'فیلتر و ساعات سکوت', 'notifications')}${sentinelService('calendar', 'تقویم اقتصادی', 'خبرهای مهم بازار', 'calendar')}${sentinelService('support', 'پشتیبانی', 'تیکت و پاسخ', 'support', o.account?.open_tickets || 0)}${sentinelService('search', 'جست‌وجوی سراسری', 'تمام اطلاعات حساب', 'search')}</div></section>
  <section><div class="service-title">${icon('shield')}<div><h2>اعتماد و حساب</h2><p>شفافیت، قوانین و تنظیمات</p></div></div><div class="service-list">${sentinelService('chart', 'عملکرد تأییدشده', 'Track Record و شواهد', 'track')}${sentinelService('history', 'تغییرات سیگنال', 'نسخه‌ها و اصلاحیه‌ها', 'revisions', o.revision_count || 0)}${sentinelService('settings', 'تنظیمات حساب', 'زبان، قوانین و نشست', 'settings')}</div></section>
  ${adminServices ? `<section class="admin-service-group"><div class="service-title">${icon('shield')}<div><h2>مدیریت SENTINEL</h2><p>فقط ابزارهای مجاز برای این مدیر</p></div></div><div class="service-list">${adminServices}</div></section>` : ''}
 </div>`;
};
openMore = async function (target) {
    if (target === 'calculator')
        return calculatorModal();
    if (target === 'tradeCenter')
        return tradeCenterModal();
    if (target === 'feed')
        return feedModal();
    if (target === 'campaigns')
        return campaignsModal();
    if (target === 'contests')
        return contestsModal();
    if (target === 'admin-signal')
        return adminSignalComposer();
    if (target === 'admin-signal-jobs')
        return adminSignalJobsCenter();
    if (target === 'admin-signals')
        return adminSignalsCenter();
    if (target === 'admin-users')
        return adminUsersCenter();
    if (target === 'admin-admins')
        return adminAdminsCenter();
    if (target === 'admin-tickets')
        return adminTicketCenter();
    if (target === 'admin-platform')
        return adminPlatformCenter();
    if (target === 'admin-announcement')
        return adminAnnouncementComposer();
    if (target === 'journal-route') {
        closeModal();
        return navigate('journal');
    }
    return sentinelLegacyOpenMore(target);
};
document.addEventListener('click', async (event) => {
    const el = event.target.closest('[data-signal-access],[data-vip-locked],[data-signal-scope-home],[data-feed-filter],[data-trade-tab],[data-risk-calculate],[data-campaign-new],[data-campaign-detail],[data-campaign-status],[data-campaign-schedule],[data-admin-quote-refresh],[data-admin-signal-job],[data-signal-job-retry],[data-signal-job-cancel],[data-signal-job-edit]');
    if (!el)
        return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.vipLocked !== undefined && !state.resources.overview?.account?.vip_active)
        return openMore('vip');
    if (el.dataset.signalAccess) {
        state.signalAccessFilter = el.dataset.signalAccess;
        invalidate('signals');
        return renderSignals(true);
    }
    if (el.dataset.signalScopeHome) {
        state.signalAccessFilter = el.dataset.signalScopeHome;
        if (state.signalAccessFilter === 'vip' && !state.resources.overview?.account?.vip_active)
            return openMore('vip');
        return navigate('signals');
    }
    if (el.dataset.feedFilter) {
        state.feedFilter = el.dataset.feedFilter;
        return feedModal();
    }
    if (el.dataset.tradeTab) {
        state.tradeHubTab = el.dataset.tradeTab;
        const data = state.resources.expansion || await loadResource('expansion', true);
        const body = $('#modalBody');
        if (body)
            body.innerHTML = tradeCenterBody(data);
        return;
    }
    if (el.dataset.riskCalculate !== undefined)
        return runRiskCalculator();
    if (el.dataset.adminQuoteRefresh !== undefined)
        return refreshAdminSignalQuote(false);
    if (el.dataset.adminSignalJob)
        return adminSignalJobDetail(el.dataset.adminSignalJob, { poll: true });
    if (el.dataset.signalJobRetry) {
        await action('signal_job_retry', { job_id: el.dataset.signalJobRetry }, false);
        invalidate('adminSignalJobs');
        toast(state.lang === 'fa' ? 'سیگنال دوباره وارد صف شد.' : 'Signal requeued.');
        return adminSignalJobDetail(el.dataset.signalJobRetry, { poll: true });
    }
    if (el.dataset.signalJobCancel) {
        await action('signal_job_cancel', { job_id: el.dataset.signalJobCancel, reason: 'لغو از پنل ادمین مینی‌اپ' }, false);
        invalidate('adminSignalJobs');
        toast(state.lang === 'fa' ? 'انتشار لغو شد.' : 'Delivery cancelled.');
        return adminSignalJobDetail(el.dataset.signalJobCancel, { poll: false });
    }
    if (el.dataset.signalJobEdit) {
        const id = el.dataset.signalJobEdit;
        openModal('SIGNAL QUEUE', state.lang === 'fa' ? 'ویرایش مقصد و زمان انتشار' : 'Edit queued signal', `<form id="signalJobEditForm"><div class="field"><label>مقصد</label><select id="signalJobTarget"><option value="public">عمومی</option><option value="private">VIP</option><option value="both">هر دو</option></select></div><div class="field"><label>زمان ISO (اختیاری)</label><input id="signalJobRunAt" placeholder="2026-07-25T18:30:00+00:00"></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { await action('signal_job_update', { job_id: id, target: $('#signalJobTarget').value, run_at: $('#signalJobRunAt').value || undefined }, false); invalidate('adminSignalJobs'); closeModal(); toast(t('success')); adminSignalJobDetail(id, { poll: false }); } }]);
        return;
    }
    if (el.dataset.campaignNew !== undefined)
        return campaignCreateModal();
    if (el.dataset.campaignDetail)
        return campaignDetailModal(el.dataset.campaignDetail);
    if (el.dataset.campaignSchedule) {
        await action('campaign_schedule', { campaign_id: el.dataset.campaignSchedule, scheduled_for: new Date(Date.now() + 45000).toISOString(), priority: 1 }, false);
        invalidate('adminCampaigns');
        closeModal();
        toast('کمپین در صف پایدار انتشار قرار گرفت');
        return campaignsModal();
    }
    if (el.dataset.campaignStatus) {
        await action('campaign_status_update', { campaign_id: el.dataset.campaignStatus, status: el.dataset.status }, false);
        invalidate('adminCampaigns');
        closeModal();
        return campaignsModal();
    }
}, true);
