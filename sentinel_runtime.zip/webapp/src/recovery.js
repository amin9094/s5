/* Client recovery is a convenience only; server auth, RBAC and ledgers remain authoritative. */
function safeSessionRead(key, fallback = null) { try { return JSON.parse(sessionStorage.getItem(key)) ?? fallback; } catch { return fallback; } }
function safeSessionWrite(key, value) { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch { /* Storage may be unavailable in a WebView. */ } }
function recoveryScope() { return String(state.resources.overview?.user?.id || state.resources.overview?.user?.user_id || ''); }
const pendingActionKeys = new Map();
async function stableActionKey(name, payload) {
    const fingerprint = `${recoveryScope()}:${name}:${JSON.stringify(payload)}`;
    const bytes = new TextEncoder().encode(fingerprint);
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))).map(x => x.toString(16).padStart(2,'0')).join('');
    const storageKey = `sentinelPending:${hash}`;
    let record = pendingActionKeys.get(storageKey) || safeSessionRead(storageKey);
    if (record && Date.now() - record.at >= 23 * 3600000) {
        throw Object.assign(new Error(state.lang === 'fa' ? 'نتیجه درخواست قبلی هنوز نامشخص است؛ پیش از ثبت دوباره، تاریخچه یا پشتیبانی را بررسی کنید.' : 'The previous result is uncertain. Check history or support before submitting again.'), {code:'OUTCOME_REVIEW_REQUIRED'});
    }
    if (!record) record = {id:`${name}:${crypto.randomUUID()}`, at:Date.now()};
    pendingActionKeys.set(storageKey,record); safeSessionWrite(storageKey,record);
    return {id:record.id, storageKey};
}
function completeActionKey(key) {
    pendingActionKeys.delete(key.storageKey);
    try { sessionStorage.removeItem(key.storageKey); } catch { }
}
function draftKey(form) { const scope=recoveryScope(); return scope && form.id ? `sentinelDraft:${scope}:${form.id}:${state.modalDraftContext || state.page}` : ''; }
function saveFormDraft(form) {
    const key=draftKey(form); if (!key || form.dataset.draftCommitted==='true') return;
    const values={};
    for (const input of form.querySelectorAll('input,textarea,select')) {
        const id=input.id || input.name;
        if (!id || ['file','password','hidden'].includes(input.type) || input.autocomplete === 'one-time-code') continue;
        values[id]=input.type === 'checkbox' || input.type === 'radio' ? input.checked : input.value;
    }
    safeSessionWrite(key,{at:Date.now(),values});
}
function restoreFormDrafts() {
    for (const form of document.querySelectorAll('#modalBody form')) {
        const row=safeSessionRead(draftKey(form));
        if (!row || Date.now()-row.at > 24*3600000) continue;
        for (const input of form.querySelectorAll('input,textarea,select')) {
            const value=row.values?.[input.id || input.name];
            if (value == null || ['file','password','hidden'].includes(input.type)) continue;
            if (input.type==='checkbox' || input.type==='radio') input.checked=Boolean(value); else input.value=String(value);
        }
        const hint=document.createElement('p'); hint.className='draft-hint';
        hint.textContent=state.lang==='fa'?'پاسخ‌های ذخیره‌شده بازیابی شدند. فایل‌ها را دوباره انتخاب کنید.':'Saved answers restored. Select attachments again.';
        form.prepend(hint);
    }
}
function clearCurrentDrafts() { for (const form of document.querySelectorAll('#modalBody form')) { try {sessionStorage.removeItem(draftKey(form));} catch {} } }
function saveVisibleDrafts() { document.querySelectorAll('#modalBody form').forEach(saveFormDraft); }
let connectionRecoveryInflight=null;
async function recoverConnection() {
    if (connectionRecoveryInflight || state.preview || !navigator.onLine || !state.csrf) return connectionRecoveryInflight;
    saveVisibleDrafts();
    connectionRecoveryInflight=(async()=>{
        for (let attempt=0;attempt<3;attempt++) {
            try {
                setConnection('loading',state.lang==='fa'?'در حال بازیابی اتصال…':'Reconnecting…');
                await loadOverview(true);
                renderChrome();
                if ($('#modalLayer')?.hidden) await navigate(state.page,false);
                return;
            } catch (err) {
                setConnection('offline',state.lang==='fa'?'اتصال برقرار نشد؛ فرم شما حفظ شده است.':'Connection unavailable. Your form is preserved.');
                if (['UNAUTHORIZED','INIT_DATA_MISSING'].includes(err.code)) return;
                if (attempt<2) await sleep(1000*(2**attempt));
            }
        }
    })();
    try {return await connectionRecoveryInflight;} finally {connectionRecoveryInflight=null;}
}
document.addEventListener('input',event=>{const form=event.target.closest?.('#modalBody form');if(form) {delete form.dataset.draftCommitted;saveFormDraft(form);}});
document.addEventListener('change',event=>{const form=event.target.closest?.('#modalBody form');if(form) {delete form.dataset.draftCommitted;saveFormDraft(form);}});
window.addEventListener('pagehide',saveVisibleDrafts);
window.addEventListener('online',()=>recoverConnection());
window.addEventListener('offline',saveVisibleDrafts);
