function contestKindMeta(kind) {
    const fa = state.lang === 'fa';
    const rows = {
        price: { icon: 'market', title: fa ? 'پیش‌بینی قیمت' : 'Price prediction', desc: fa ? 'نزدیک‌ترین قیمت برنده است' : 'Closest price wins' },
        chart: { icon: 'chart', title: fa ? 'مسابقه چارت' : 'Chart challenge', desc: fa ? 'جهت بعدی بازار را انتخاب کنید' : 'Choose the next market direction' },
        candle: { icon: 'signal', title: fa ? 'مسابقه کندل' : 'Candle challenge', desc: fa ? 'قیمت بسته‌شدن کندل را حدس بزنید' : 'Predict the candle close' },
        news_direction: { icon: 'calendar', title: fa ? 'جهت بازار بعد از خبر' : 'News direction', desc: fa ? 'حرکت بازار بعد از خبر را پیش‌بینی کنید' : 'Predict the post-news move' },
    };
    return rows[kind] || { icon: 'trophy', title: fa ? 'مسابقه' : 'Contest', desc: '' };
}
function contestChoiceLabel(kind, value) {
    const key = String(value ?? '').toUpperCase(), fa = state.lang === 'fa';
    const labels = {
        UP: fa ? 'صعودی' : 'Bullish',
        DOWN: fa ? 'نزولی' : 'Bearish',
        FLAT: fa ? 'خنثی' : 'Flat',
        RANGE: fa ? 'رنج' : 'Range',
    };
    return labels[key] || String(value ?? '—');
}
function contestRewardText(row) {
    if(row.prize_by_rank && Object.keys(row.prize_by_rank).length) return Object.entries(row.prize_by_rank).map(([rank,prize])=>`#${rank}: ${clientPrizeLabel(prize)}`).join(" · ");
    if (row.kind === 'candle') {
        const r = row.reward_by_rank || {};
        return state.lang === 'fa'
            ? `رتبه ۱: ${num(r['1'] || 10, 0)} · رتبه ۲: ${num(r['2'] || 7, 0)} · رتبه ۳: ${num(r['3'] || 5, 0)} امتیاز`
            : `1st: ${num(r['1'] || 10, 0)} · 2nd: ${num(r['2'] || 7, 0)} · 3rd: ${num(r['3'] || 5, 0)} pts`;
    }
    return state.lang === 'fa' ? `${num(row.reward_points || 0, 0)} امتیاز جایزه` : `${num(row.reward_points || 0, 0)} reward points`;
}
function contestAnswerControls(row) {
    if (row.participated) {
        const shown = row.kind === 'price' || row.kind === 'candle' ? num(row.my_answer, 8) : contestChoiceLabel(row.kind, row.my_answer);
        return `<div class="contest-submitted">${icon('check')}<div><strong>${state.lang === 'fa' ? 'پاسخ شما ثبت شده' : 'Your answer is registered'}</strong><small>${esc(shown)}${row.submitted_at ? ` · ${date(row.submitted_at)}` : ''}</small></div></div>`;
    }
    if (row.kind === 'price' || row.kind === 'candle') {
        return `<div class="contest-entry"><input id="contest-answer-${esc(row.kind)}" inputmode="decimal" autocomplete="off" placeholder="${row.kind === 'price' ? (state.lang === 'fa' ? 'قیمت پیش‌بینی‌شده' : 'Predicted price') : (state.lang === 'fa' ? 'قیمت بسته‌شدن' : 'Closing price')}"><button class="button primary" data-contest-submit="${esc(row.kind)}">${state.lang === 'fa' ? 'ثبت پاسخ' : 'Submit'}</button></div>`;
    }
    const choices = row.kind === 'news_direction' ? ['UP', 'DOWN', 'RANGE'] : ['UP', 'DOWN', 'FLAT'];
    return `<div class="contest-choices">${choices.map(choice => `<button class="button secondary" data-contest-submit="${esc(row.kind)}" data-contest-answer="${choice}">${choice === 'UP' ? '📈' : choice === 'DOWN' ? '📉' : '↔️'} ${esc(contestChoiceLabel(row.kind, choice))}</button>`).join('')}</div>`;
}
function contestCard(row) {
    const meta = contestKindMeta(row.kind), title = row.question || row.news_name || meta.desc;
    return `<article class="contest-card ${row.participated ? 'joined' : ''}">
      <div class="contest-card-head"><span class="contest-icon">${icon(meta.icon)}</span><div><h3>${esc(meta.title)}</h3><p>${esc(meta.desc)}</p></div><span class="status-badge good">${state.lang === 'fa' ? 'فعال' : 'Active'}</span></div>
      ${row.image_available ? `<img class="contest-image" src="${esc(row.image_url)}" alt="${esc(meta.title)}" loading="lazy">` : ''}
      <div class="contest-question">${row.symbol ? `<span class="contest-symbol">${esc(row.symbol)}</span>` : ''}<strong>${esc(title)}</strong></div>
      <div class="contest-meta"><span>${icon('history')}${state.lang === 'fa' ? 'پایان' : 'Ends'}: ${date(row.ends_at)}</span><span>${icon('crown')}${esc(contestRewardText(row))}</span><span>${icon('user')}${num(row.participants_count || 0, 0)} ${state.lang === 'fa' ? 'شرکت‌کننده' : 'entries'}</span></div>
      ${contestAnswerControls(row)}
    </article>`;
}
function contestResultCard(row) {
    const meta = contestKindMeta(row.kind), answer = row.kind === 'price' || row.kind === 'candle' ? num(row.my_answer, 8) : contestChoiceLabel(row.kind, row.my_answer);
    const outcome = row.won ? (state.lang === 'fa' ? 'برنده' : 'Winner') : (state.lang === 'fa' ? 'پایان‌یافته' : 'Completed');
    return `<article class="contest-result ${row.won ? 'winner' : ''}"><span class="contest-icon">${icon(row.won ? 'crown' : meta.icon)}</span><div><strong>${esc(meta.title)}</strong><p>${state.lang === 'fa' ? 'پاسخ شما' : 'Your answer'}: ${esc(answer)}${row.rank ? ` · ${state.lang === 'fa' ? 'رتبه' : 'Rank'} ${num(row.rank, 0)}` : ''}</p><small>${date(row.closed_at)}</small></div><span class="status-badge ${row.won ? 'good' : 'info'}">${esc(outcome)}${row.prize && Object.keys(row.prize).length ? ` · ${esc(clientPrizeLabel(row.prize))}` : row.points ? ` · +${num(row.points, 0)}` : ''}</span></article>`;
}
async function contestsModal(force = false) {
    setBusy(true);
    try {
        const d = await loadResource('contests', force), rows = d?.items || [], history = d?.recent_results || [];
        const body = `<div class="contest-hero"><div>${icon('trophy')}<div><strong>${state.lang === 'fa' ? 'مسابقه‌های SENTINEL' : 'SENTINEL Contests'}</strong><p>${state.lang === 'fa' ? 'بدون خروج از مینی‌اپ در مسابقه فعال شرکت کنید؛ پاسخ دقیقاً در همان سیستم مسابقات ربات ثبت می‌شود.' : 'Join active contests without leaving the Mini App. Your entry is saved in the same contest system as the bot.'}</p></div></div><button class="icon-button" data-contest-refresh aria-label="refresh">${icon('refresh')}</button></div>
          <div class="contest-grid">${rows.map(contestCard).join('') || empty(state.lang === 'fa' ? 'در حال حاضر مسابقه فعالی وجود ندارد.' : 'There are no active contests right now.')}</div>
          ${history.length ? `<div class="contest-history"><div class="panel-head"><div><h3>${state.lang === 'fa' ? 'نتایج اخیر من' : 'My recent results'}</h3><p>${state.lang === 'fa' ? 'فقط مسابقه‌هایی که در آن‌ها شرکت کرده‌اید' : 'Only contests you joined'}</p></div></div>${history.map(contestResultCard).join('')}</div>` : ''}`;
        openModal('CONTESTS', state.lang === 'fa' ? 'مسابقه‌ها' : 'Contests', body, []);
    }
    catch (err) {
        toast(translateUiText(err.message || t('error')), 'error');
    }
    finally { setBusy(false); }
}
async function submitContestEntry(kind, answer) {
    if (answer == null || String(answer).trim() === '') {
        toast(state.lang === 'fa' ? 'پاسخ را وارد کنید.' : 'Enter your answer.', 'error');
        return;
    }
    setBusy(true);
    try {
        const result = await action('contest_submit', { kind, answer }, false);
        if (result?.result === 'OK') toast(state.lang === 'fa' ? 'پاسخ مسابقه با موفقیت ثبت شد.' : 'Contest entry submitted.', 'success');
        else if (result?.result === 'ALREADY') toast(state.lang === 'fa' ? 'قبلاً در این مسابقه پاسخ ثبت کرده‌اید.' : 'You already entered this contest.', 'info');
        else if (result?.result === 'NO_ACTIVE') toast(state.lang === 'fa' ? 'زمان مسابقه تمام شده یا دیگر فعال نیست.' : 'This contest is no longer active.', 'error');
        else toast(state.lang === 'fa' ? 'ثبت پاسخ انجام نشد.' : 'Could not submit the entry.', 'error');
        invalidate('contests', 'overview');
        await contestsModal(true);
    }
    catch (err) {
        const message = String(err?.message || '');
        toast(message.includes('CONTEST_ANSWER_INVALID') ? (state.lang === 'fa' ? 'پاسخ واردشده معتبر نیست.' : 'The submitted answer is invalid.') : translateUiText(message || t('error')), 'error');
    }
    finally { setBusy(false); }
}
document.addEventListener('click', async event => {
    const el = event.target.closest('[data-contest-submit],[data-contest-refresh]');
    if (!el) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (el.dataset.contestRefresh !== undefined) {
        invalidate('contests');
        return contestsModal(true);
    }
    const kind = String(el.dataset.contestSubmit || ''), answer = el.dataset.contestAnswer !== undefined ? el.dataset.contestAnswer : $(`#contest-answer-${kind}`)?.value;
    await submitContestEntry(kind, answer);
});
