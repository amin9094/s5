from __future__ import annotations

from types import SimpleNamespace

import pytest

from core.webapp_auth import TelegramWebAppIdentity
from repositories.v2.journal import JournalRepository
from repositories.v2.signals import SignalRepository
from services import miniapp_read_service_v2 as read
from services import live_market_service


def identity(uid: int = 77) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(uid, "user", "First", "Last", 1, "q")


@pytest.mark.parametrize(
    "value,expected",
    [(None, None), ("", None), ("1.25", 1.25), (3, 3.0), (float("nan"), None), (float("inf"), None), ("no", None)],
)
def test_float_value(value, expected) -> None:
    assert read._float_value(value) == expected


def test_numeric_values_and_signal_live_metrics() -> None:
    assert read._numeric_values(["1", 2, None, "bad"]) == [1.0, 2.0]
    assert read._numeric_values("1, 2 / 3") == [1.0, 2.0, 3.0]
    buy = read._signal_live_metrics(
        {"side": "buy", "entry": 100, "stop": 95, "targets": [105, 110], "status": "open"},
        {"price": 107, "provider": "p", "stale": False},
    )
    assert buy["current_price"] == 107
    assert buy["entry_status"] == "passed"
    assert buy["risk_unit"] == pytest.approx(5)
    assert buy["target_rr"][0]["r"] == pytest.approx(1)
    sell = read._signal_live_metrics(
        {"side": "sell", "entry_price": 100, "stop_loss": 105, "take_profits": [95, 90]},
        {"price": 93},
    )
    assert sell["target_rr"][0]["r"] == pytest.approx(1)
    assert sell["current_price"] == 93
    assert read._signal_live_metrics({}, None)["current_price"] is None


def test_signal_dto_access_and_market_helpers() -> None:
    row = {
        "id": "s1", "symbol": "BTC/USDT", "side": "BUY", "status": "tp1",
        "market_category": "crypto", "destination": "private", "targets": [65000],
        "entry": 60000, "stop": 59000, "revision": 2,
    }
    dto = read._signal_dto(row, {"choice": "taken"}, {"price": 62000})
    assert dto["id"] == "s1"
    assert dto["market_category"] == "crypto"
    assert dto["access_tier"] == "vip"
    assert dto["choice"]["choice"] == "taken"
    assert read._signal_access_tier({"destination": "public"}) == "public"
    assert read._signal_access_tier({"visibility": "vip"}) == "vip"
    assert read._signal_market({"market": "crypto"}) == "crypto"
    assert read._signal_market({"symbol": "ETHUSD"}) == "crypto"
    assert read._signal_market({"symbol": "EURUSD"}) == "forex"
    assert read._visible_signal({"destination": "private"}, vip_active=False) is False
    assert read._visible_signal({"destination": "private"}, vip_active=True) is True


def test_journal_stats_from_normalized_rows(sqlite_engine) -> None:
    repo = JournalRepository(sqlite_engine)
    repo.add(77, {
        "id": "j1", "symbol": "XAUUSD", "side": "BUY", "status": "closed",
        "pnl_amount": 100, "pnl_percent": 1, "result_r": 2,
        "entry_reason_type": "channel_signal", "commission": 2, "fees": 1,
    })
    repo.add(77, {
        "id": "j2", "symbol": "EURUSD", "side": "SELL", "status": "closed",
        "pnl_amount": -50, "pnl_percent": -0.5, "result_r": -1,
        "entry_reason_type": "personal_analysis",
    })
    stats = read._journal_stats(sqlite_engine, 77)
    assert stats["total"] == 2
    assert stats["closed"] == 2
    assert stats["wins"] == 1 and stats["losses"] == 1
    assert stats["win_rate"] == 50.0
    assert stats["net_pnl"] == pytest.approx(50)
    assert stats["avg_r"] == pytest.approx(0.5)
    assert stats["channel_signal_entries"] == 1
    assert stats["personal_entries"] == 1


def test_signals_cursor_filter_dedupe_and_live_quote(monkeypatch) -> None:
    pages = [
        {
            "items": [
                {"id": "1", "cycle_id": 1, "display_number": 1, "symbol": "BTCUSD", "market_category": "crypto", "destination": "public", "status": "open", "created_at": "2026-01-02", "updated_at": "2026-01-02"},
                {"id": "old", "cycle_id": 1, "display_number": 1, "symbol": "BTCUSD", "market_category": "crypto", "destination": "public", "status": "open", "created_at": "2026-01-01", "updated_at": "2026-01-01"},
                {"id": "vip", "display_number": 2, "symbol": "XAUUSD", "market_category": "forex", "destination": "private", "status": "open", "created_at": "2026-01-03"},
            ],
            "next_cursor": "next",
        },
        {"items": [{"id": "2", "display_number": 3, "symbol": "ETHUSD", "market_category": "crypto", "destination": "public", "status": "closed", "created_at": "2026-01-04"}], "next_cursor": None},
    ]

    class Repo:
        def list(self, **kwargs):
            return pages.pop(0)

    monkeypatch.setattr(read, "SignalRepository", lambda *a, **k: Repo())
    monkeypatch.setattr(read, "_safe_shell", lambda _identity: {"vip_active": False})
    monkeypatch.setattr(read, "_signal_choices", lambda _uid: {"1": {"choice": "watching"}})
    monkeypatch.setattr(live_market_service, "live_quotes_for_symbols", lambda symbols, force=False: {"BTCUSD": {"price": 61000}, "ETHUSD": {"price": 3000}})
    result = read.signals(identity(), limit=2, scope="all", live=True)
    assert [row["id"] for row in result["items"]] == ["2", "1"]
    assert result["items"][1]["choice"]["choice"] == "watching"
    assert result["items"][1]["entry_state"]["current_price"] == 61000
    assert result["groups"]["crypto"] == 2
    assert result["scan_pages"] == 2


def test_signals_invalid_scope_and_vip_filter(monkeypatch) -> None:
    class Repo:
        def list(self, **kwargs):
            return {"items": [
                {"id": "p", "display_number": 1, "symbol": "EURUSD", "destination": "public", "status": "open", "created_at": "2"},
                {"id": "v", "display_number": 2, "symbol": "XAUUSD", "destination": "private", "status": "open", "created_at": "1"},
            ], "next_cursor": None}
    monkeypatch.setattr(read, "SignalRepository", lambda *a, **k: Repo())
    monkeypatch.setattr(read, "_safe_shell", lambda _identity: {"vip_active": True})
    monkeypatch.setattr(read, "_signal_choices", lambda _uid: {})
    monkeypatch.setattr(live_market_service, "live_quotes_for_symbols", lambda *a, **k: {})
    assert read.signals(identity(), scope="bad")["access"]["scope"] == "all"
    vip = read.signals(identity(), scope="vip")
    assert [item["id"] for item in vip["items"]] == ["v"]


def test_market_live_partial_recovery_and_total_fallback(monkeypatch) -> None:
    cached = {"quotes": [{"symbol": "XAUUSD", "price": 2400, "source": "disk"}, {"symbol": "BTCUSD", "price": 60000}], "watchlist": []}
    monkeypatch.setattr(read.legacy, "market", lambda _identity: dict(cached))
    monkeypatch.setattr(live_market_service, "live_market_snapshot", lambda *_a, **_k: {
        "quotes": [{"symbol": "BTCUSD", "price": 61000}],
        "failed_quotes": [{"symbol": "XAUUSD", "error": "timeout"}, {"symbol": "EURUSD", "error": "timeout"}],
    })
    result = read.market(identity(), live=True)
    assert "XAUUSD" in result["recovered_from_cache"]
    assert result["failed_quotes"] == [{"symbol": "EURUSD", "error": "timeout"}]
    assert any(row["symbol"] == "XAUUSD" and row["stale"] for row in result["quotes"])

    def explode(*_a, **_k):
        raise RuntimeError("down")
    monkeypatch.setattr(live_market_service, "live_market_snapshot", explode)
    fallback = read.market(identity())
    assert fallback["degraded"] is True and fallback["live"] is False


def test_order_dto_does_not_expose_receipt_storage() -> None:
    dto = read._user_order_dto({
        "id": "o1", "status": "pending", "receipt_path": "/secret", "receipt_file_id": "telegram-secret",
        "transaction_hash": "abc", "amount_toman": 100,
    })
    assert dto == {"id": "o1", "status": "pending", "transaction_hash": "abc", "amount_toman": 100}
    assert "receipt_path" not in dto


def test_safe_shell_uses_shared_preferences_entitlement_and_onboarding(monkeypatch) -> None:
    stored = {
        "user_profiles": {"language": "en", "username": "stored"},
        "user_notification_preferences": {"signals": True},
        "miniapp_onboarding": {"experience": "advanced", "goal": "income", "completed": False},
        "rules_acceptances": {"version": 3, "content_hash": "hash-3"},
    }
    writes = []

    class Preferences:
        def get(self, uid, namespace, default=None):
            return stored.get(namespace, default)

        def set(self, uid, namespace, value):
            writes.append((str(uid), namespace, dict(value)))
            stored[namespace] = value
            return value

    class Accounts:
        def get(self, uid, account_id=None):
            return {
                "id": "a1", "name": "Main", "balance": 10000, "equity": 10100,
                "created_at": "2026-01-01T00:00:00+00:00",
            }

    class Commerce:
        def entitlement_for_user(self, uid):
            return {"active": True, "expires_at": "2027-01-01T00:00:00+00:00"}

    db = {"user_profiles": {"77": {"username": "shared", "first_name": "Saved", "last_name": "Name"}}, "users": {"77": {"username": "legacy"}}, "user_points": {"77": 44}, "vip_users": {}}
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: db)
    monkeypatch.setattr(read, "PreferenceRepository", Preferences)
    monkeypatch.setattr(read, "AccountRepository", Accounts)
    monkeypatch.setattr(read, "CommerceRepository", Commerce)
    monkeypatch.setattr(read, "user_language", lambda _db, _uid: "en")
    monkeypatch.setattr(read, "is_vip", lambda _db, _uid: False)
    monkeypatch.setattr(read, "current_rules", lambda _db, lang: {"enabled": True, "version": 3, "content_hash": "hash-3", "text": "rules"})
    monkeypatch.setattr(read, "is_primary_admin", lambda _uid: False)
    monkeypatch.setattr(read, "get_delegated_admin", lambda _db, _uid: None)
    monkeypatch.setattr(read, "is_any_admin", lambda _db, _uid: False)
    monkeypatch.setattr(read, "enabled_feature_payload", lambda _db: {"market": True})
    monkeypatch.setattr(read, "vip_catalog", lambda _db, _uid, vip_active: {"active": vip_active})
    monkeypatch.setattr(read, "user_has_accepted_rules", lambda *_a: True)
    import modules.miniapp_runtime
    monkeypatch.setattr(modules.miniapp_runtime, "miniapp_runtime_state", lambda _db: {"enabled": True})

    shell = read._safe_shell(TelegramWebAppIdentity(77, "", "", "", 1, "q"))
    assert shell["user"]["username"] == "shared"
    assert shell["user"]["first_name"] == "Saved"
    assert shell["user"]["last_name"] == "Name"
    assert shell["language"] == "en"
    assert shell["vip_active"] is True
    assert shell["vip_entitlement_source"] == "normalized"
    assert shell["points"] == 44
    assert shell["onboarding"]["completed"] is True
    assert shell["onboarding"]["account_name"] == "Main"
    assert shell["rules"]["accepted"] is True
    assert shell["user"]["role"] == "user"
    assert writes and writes[-1][1] == "miniapp_onboarding"
    assert read.access_context(identity()) == {"vip_active": True, "is_admin": False, "role": "user"}


def test_safe_shell_delegated_admin_and_legacy_fallbacks(monkeypatch) -> None:
    class Preferences:
        def get(self, uid, namespace, default=None):
            return "broken" if namespace == "user_profiles" else default
        def set(self, *args, **kwargs):
            raise AssertionError("no write expected")

    class Accounts:
        def get(self, uid, account_id=None):
            return None

    class Commerce:
        def entitlement_for_user(self, uid):
            return None

    db = {"users": {"77": {"first_name": "Legacy"}}, "user_points": {"77": -5}, "vip_users": {"77": {"expires_at": "later"}}}
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: db)
    monkeypatch.setattr(read, "PreferenceRepository", Preferences)
    monkeypatch.setattr(read, "AccountRepository", Accounts)
    monkeypatch.setattr(read, "CommerceRepository", Commerce)
    monkeypatch.setattr(read, "user_language", lambda _db, _uid: "fa")
    monkeypatch.setattr(read, "is_vip", lambda _db, _uid: True)
    monkeypatch.setattr(read, "notification_preferences", lambda _db, _uid: {"fallback": True})
    monkeypatch.setattr(read, "onboarding_snapshot", lambda _db, _uid: {"completed": False})
    monkeypatch.setattr(read, "current_rules", lambda _db, lang: {"enabled": False, "version": 0, "content_hash": "", "text": ""})
    monkeypatch.setattr(read, "is_primary_admin", lambda _uid: False)
    monkeypatch.setattr(read, "get_delegated_admin", lambda _db, _uid: {"permissions": ["payments", "not-real"]})
    monkeypatch.setattr(read, "ALL_PERMISSIONS", {"payments", "tickets"})
    monkeypatch.setattr(read, "is_any_admin", lambda _db, _uid: True)
    monkeypatch.setattr(read, "enabled_feature_payload", lambda _db: {})
    monkeypatch.setattr(read, "vip_catalog", lambda *_a, **_k: {})
    monkeypatch.setattr(read, "user_has_accepted_rules", lambda *_a: False)
    import modules.miniapp_runtime
    monkeypatch.setattr(modules.miniapp_runtime, "miniapp_runtime_state", lambda _db: {"enabled": False})

    shell = read._safe_shell(identity())
    assert shell["user"]["role"] == "admin"
    assert shell["user"]["permissions"] == ["payments"]
    assert shell["points"] == 0
    assert shell["vip_active"] is True
    assert shell["vip_entitlement_source"] == "legacy"
    assert shell["notifications"] == {"fallback": True}
    assert shell["rules"]["accepted"] is True


def test_account_risk_unconfigured(monkeypatch) -> None:
    class Accounts:
        def list_for_user(self, uid):
            return []
        def get(self, uid, account_id=None):
            return None

    class Positions:
        pass

    class Rules:
        def __init__(self, _engine):
            pass

        def list_templates(self):
            return [{"id": "personal-standard", "provider": "SENTINEL", "name": "Personal Standard", "version": 1}]

    monkeypatch.setattr(read, "_repos", lambda: (object(), Accounts(), Positions(), None, None, None, None, None))
    monkeypatch.setattr(read, "PropRuleEngine", Rules)
    result = read._account_risk(77)
    assert result["selected_account"] is None
    assert result["exposure"]["open_count"] == 0
    assert result["prop"]["decision"] == "unconfigured"
    assert result["prop_templates"][0]["id"] == "personal-standard"
    assert result["positions"] == []


def test_account_risk_configured_full_projection(monkeypatch) -> None:
    import contextlib
    import sys
    import types

    selected = {"id": "a1", "balance": 10000, "equity": 9800, "starting_balance": 10000}

    class Cursor:
        def execute(self, query, params=()):
            if "v8_positions" in query:
                return SimpleNamespace(fetchone=lambda: {"open_count": 2, "risk_percent": 2.5, "risk_money": 250})
            return SimpleNamespace(fetchone=lambda: {"payload": '{"balance":9800}'})

    class Engine:
        @contextlib.contextmanager
        def transaction(self, read_only=False):
            yield Cursor()

    class Accounts:
        def list_for_user(self, uid):
            return [selected]
        def get(self, uid, account_id=None):
            return selected

    class Positions:
        def active_exposure(self, uid, account_id):
            return {"open_count": 2, "risk_percent": 2.5, "risk_money": 250}
        def list_for_user(self, uid, **kwargs):
            return {"items": [
                {"symbol": "EURUSD", "risk_money": 100},
                {"symbol": "GBPUSD", "risk_money": 150},
            ], "next_cursor": "next"}

    decision = SimpleNamespace(
        decision="allow", allowed=True, warnings=["near-limit"], hard_blocks=[], template_id="p1", rules_version=2,
        metrics={
            "daily_loss_percent": 1, "daily_loss_limit_percent": 5,
            "total_drawdown_percent": 2, "total_loss_limit_percent": 10,
            "profit_progress_percent": 40, "trading_days": 3, "min_trading_days": 5,
        },
    )

    class Prop:
        def __init__(self, engine): pass
        def evaluate(self, **kwargs): return decision
        def list_templates(self): return [{"id": "p1"}]

    class Correlation:
        def __init__(self, engine): pass
        def rolling(self, symbols): return {"kind": "rolling_pearson", "symbols": symbols, "confidence": 0.8}

    class Confidence:
        def __init__(self, engine): pass
        def get(self, entity, key, field): return {"field": field, "score": 1.0}

    risk_module = types.ModuleType("services.risk_coach_service")
    risk_module.weekly_signal_risk_summary = lambda uid, account: {"user_id": uid, "account_id": account["id"]}
    monkeypatch.setitem(sys.modules, "services.risk_coach_service", risk_module)
    monkeypatch.setattr(read, "_repos", lambda: (Engine(), Accounts(), Positions(), None, None, None, None, None))
    monkeypatch.setattr(read, "PropRuleEngine", Prop)
    monkeypatch.setattr(read, "CorrelationService", Correlation)
    monkeypatch.setattr(read, "DataConfidenceService", Confidence)

    result = read._account_risk(77, "a1")
    assert result["selected_account"]["id"] == "a1"
    assert result["portfolio_exposure"]["risk_money"] == 250
    assert result["prop"]["status"] == "warning"
    assert result["what_if"]["all_stops_loss_amount"] == -250
    assert result["what_if"]["worst_case_equity"] == 9550
    assert result["correlation"]["confidence"] == 0.8
    assert result["broker_snapshot"] == {"balance": 9800}
    assert result["positions"][0]["symbol"] == "EURUSD"
    assert result["next_cursor"] == "next"


def test_signal_detail_exposes_safety_news_and_revision_history(monkeypatch, sqlite_engine) -> None:
    from datetime import UTC, datetime, timedelta
    from repositories.v2.accounts import AccountRepository
    from services import live_market_service

    signal_repo = SignalRepository(sqlite_engine)
    signal_repo.upsert({
        "id": "501", "display_number": 1, "symbol": "XAUUSD", "side": "BUY",
        "status": "open", "market_category": "forex", "destination": "public",
        "entry": 2400, "stop": 2390, "targets": [2410],
        "created_at": "2026-07-25T12:00:00+00:00",
    })
    signal_repo.upsert({
        "id": "501", "display_number": 1, "symbol": "XAUUSD", "side": "BUY",
        "status": "open", "market_category": "forex", "destination": "public",
        "entry": 2401, "stop": 2390, "targets": [2410],
        "created_at": "2026-07-25T12:00:00+00:00", "updated_at": "2026-07-25T12:05:00+00:00",
    })
    AccountRepository(sqlite_engine).upsert(77, {
        "name": "Main", "balance": 10_000, "equity": 10_000, "type": "personal",
    })
    event_time = (datetime.now(UTC) + timedelta(minutes=45)).isoformat()

    monkeypatch.setattr(read, "normalized_engine", lambda: sqlite_engine)
    monkeypatch.setattr(read, "_safe_shell", lambda _identity: {"vip_active": True})
    monkeypatch.setattr(read, "_signal_choices", lambda _uid: {})
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: {
        "economic_calendar": {
            "cached_events": [{
                "title": "US CPI", "currency": "USD", "importance": "high", "datetime": event_time,
            }],
            "cached_events_updated_at": datetime.now(UTC).isoformat(),
        }
    })
    monkeypatch.setattr(
        live_market_service,
        "live_quotes_for_symbols",
        lambda symbols, force=False: {"XAUUSD": {"symbol": "XAUUSD", "price": 2402.0, "provider": "test", "updated_at": datetime.now(UTC).isoformat()}},
    )

    result = read.signal_detail(identity(), "501", live=True)

    assert result["pretrade_gate"]["status"] in {"green", "yellow", "red"}
    assert result["pretrade_gate"]["reasons"]
    assert result["nearby_news"][0]["title"] == "US CPI"
    assert result["nearby_news_meta"]["status"] == "ready"
    assert len(result["trust_passport"]["revisions"]) == 2
    assert result["trust_passport"]["evidence_hash"]


def test_signal_detail_without_account_still_returns_all_information(monkeypatch, sqlite_engine) -> None:
    from services import live_market_service

    SignalRepository(sqlite_engine).upsert({
        "id": "502", "display_number": 2, "symbol": "EURUSD", "side": "SELL",
        "status": "open", "market_category": "forex", "destination": "public",
        "entry": 1.1, "stop": 1.11, "targets": [1.09],
        "created_at": "2026-07-25T12:00:00+00:00",
    })
    monkeypatch.setattr(read, "normalized_engine", lambda: sqlite_engine)
    monkeypatch.setattr(read, "_safe_shell", lambda _identity: {"vip_active": False})
    monkeypatch.setattr(read, "_signal_choices", lambda _uid: {})
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: {"economic_calendar": {"cached_events": []}})
    monkeypatch.setattr(live_market_service, "live_quotes_for_symbols", lambda *a, **k: {})

    result = read.signal_detail(identity(88), "502")

    assert result["pretrade_gate"]["status"] == "yellow"
    assert result["pretrade_gate"]["reasons"][0]["code"] == "TRADING_ACCOUNT_REQUIRED"
    assert result["nearby_news"] == []
    assert result["nearby_news_meta"]["status"] == "calendar_not_synced"
    assert len(result["trust_passport"]["revisions"]) == 1


def test_signal_detail_exposes_chart_and_lifecycle_media(monkeypatch) -> None:
    signal = {
        "id": "sig-visual",
        "display_number": 9,
        "symbol": "XAUUSD",
        "side": "BUY",
        "status": "tp1",
        "entry": 100,
        "stop": 90,
        "targets": [110, 120],
        "destination": "public",
        "chart_photo_file_id": "telegram-chart-file",
        "lifecycle_history": [
            {"event": "entry_hit", "at": "2026-07-31T12:20:00+00:00"},
            {"event": "tp1", "at": "2026-07-31T13:00:00+00:00"},
        ],
        "created_at": "2026-07-31T12:00:00+00:00",
        "updated_at": "2026-07-31T13:00:00+00:00",
    }

    class Repo:
        def __init__(self, *_args, **_kwargs):
            pass

        def get(self, signal_id):
            assert str(signal_id) == "sig-visual"
            return dict(signal)

        def replay(self, signal_id):
            return {"timeline": [], "outcome": None}

    class Accounts:
        def __init__(self, *_args, **_kwargs):
            pass

        def get(self, *_args, **_kwargs):
            return None

    class Positions:
        def __init__(self, *_args, **_kwargs):
            pass

        def active_for_signal(self, *_args, **_kwargs):
            return []

    class Confidence:
        def __init__(self, *_args, **_kwargs):
            pass

        def get(self, *_args, **_kwargs):
            return {"confidence": 1.0}

    monkeypatch.setattr(read, "normalized_engine", lambda: object())
    monkeypatch.setattr(read, "SignalRepository", Repo)
    monkeypatch.setattr(read, "AccountRepository", Accounts)
    monkeypatch.setattr(read, "PositionRepository", Positions)
    monkeypatch.setattr(read, "DataConfidenceService", Confidence)
    monkeypatch.setattr(read, "_safe_shell", lambda _identity: {"vip_active": False})
    monkeypatch.setattr(read, "_signal_choices", lambda _uid: {})
    monkeypatch.setattr(read, "_nearby_news_for_signal", lambda *_a, **_k: {"items": [], "status": "ready"})
    monkeypatch.setattr(live_market_service, "live_quotes_for_symbols", lambda *_a, **_k: {"XAUUSD": {"price": 110}})

    result = read.signal_detail(identity(), "sig-visual", live=True)
    assert result["media"] == {
        "chart_available": True,
        "chart_url": "./api/v1/signals/sig-visual/chart",
        "result_chart_available": False,
        "result_chart_url": "",
        "result_chart_caption": "",
        "result_chart_added_at": None,
        "status_key": "tp1",
    }
    assert [event["event"] for event in result["lifecycle_report"]] == ["entry_hit", "tp1"]
    assert result["trust_passport"]["signal_id"] == "sig-visual"
