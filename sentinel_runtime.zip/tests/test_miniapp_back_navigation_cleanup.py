from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "webapp" / "src"


def _source(name: str) -> str:
    return (SRC / name).read_text(encoding="utf-8")


def test_closing_confirmation_is_disabled_and_vertical_swipes_remain_enabled() -> None:
    core = _source("core.js")
    assert "enableClosingConfirmation" not in core
    assert "disableClosingConfirmation" in core
    assert "enableVerticalSwipes" in core


def test_telegram_back_handler_is_single_and_owned_by_navigation_bridge() -> None:
    core = _source("core.js")
    shell = _source("shell-events.js")
    assert "function handleTelegramBack()" in core
    assert core.count("BackButton?.onClick?.(handleTelegramBack)") == 1
    assert "BackButton.onClick?.(closeModal)" not in shell
    assert "BackButton.offClick?.(closeModal)" not in shell
    assert "installTelegramNavigation(); syncTelegramNavigation();" in shell


def test_root_state_hides_back_button_and_modal_state_shows_it() -> None:
    core = _source("core.js")
    assert "state.telegramBackMode = modalOpen ? 'modal' : 'none'" in core
    assert "if (modalOpen || pageOpen)" in core
    assert "state.telegramBackMode='page'" in core
    assert "navigateWorkspaceBack()" in core
    assert "BackButton?.show?.()" in core
    assert "BackButton?.hide?.()" in core
    assert "BackButton?.offClick?.(handleTelegramBack)" in core
    assert "state.telegramNavigationInstalled = false" in core


def test_lifecycle_cleanup_releases_handlers_before_webview_exit() -> None:
    bootstrap = _source("bootstrap.js")
    assert "window.addEventListener('pagehide', () => releaseTelegramNavigation(true)" in bootstrap
    assert "window.addEventListener('beforeunload', () => releaseTelegramNavigation(true)" in bootstrap
    assert "window.addEventListener('pageshow', () => { installTelegramNavigation(); syncTelegramNavigation(); }" in bootstrap
    assert "if (document.hidden) releaseTelegramNavigation(true)" in bootstrap
    assert "releaseTelegramNavigation(true);\n    tg?.close?.();" in bootstrap
