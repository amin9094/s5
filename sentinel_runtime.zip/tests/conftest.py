from __future__ import annotations

from pathlib import Path

import os
import pytest

os.environ.setdefault("PRIMARY_ADMIN_ID", "354678485")
os.environ.setdefault("ADMIN_IDS", "354678485")

# Production installs python-telegram-bot. The repository test suite can still
# execute domain and release contracts in restricted/offline environments.
from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.storage.engine import DatabaseEngine


@pytest.fixture
def sqlite_engine(tmp_path: Path) -> DatabaseEngine:
    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "sentinel-test.sqlite3")
    engine.ensure_schema()
    try:
        yield engine
    finally:
        engine.close()
