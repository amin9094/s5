from __future__ import annotations

import asyncio
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest


@pytest.mark.asyncio
async def test_run_blocking_keeps_capacity_until_timed_out_thread_finishes(monkeypatch):
    import core.async_runtime as runtime

    old_max = runtime._MAX_BLOCKING
    monkeypatch.setattr(runtime, "_MAX_BLOCKING", 1)
    monkeypatch.setattr(runtime, "_SEMAPHORE", None)
    monkeypatch.setattr(runtime, "_SEMAPHORE_LOOP", None)
    release = threading.Event()

    def stuck() -> str:
        release.wait(1.0)
        return "done"

    try:
        with pytest.raises(TimeoutError):
            await runtime.run_blocking(stuck, timeout=0.05, acquire_timeout=0.05)

        # The first worker is still alive, so its permit must remain reserved.
        with pytest.raises(TimeoutError, match="capacity exhausted"):
            await runtime.run_blocking(lambda: "should-not-run", timeout=0.2, acquire_timeout=0.05)

        release.set()
        await asyncio.sleep(0.08)
        assert await runtime.run_blocking(lambda: "ok", timeout=0.2, acquire_timeout=0.2) == "ok"
    finally:
        release.set()
        runtime._MAX_BLOCKING = old_max


def test_payload_backups_are_unique_and_atomic(tmp_path: Path):
    from core.backup_service import create_payload_backup

    first = create_payload_backup({"schema_version": 1, "value": 1}, tmp_path)
    second = create_payload_backup({"schema_version": 1, "value": 2}, tmp_path)

    assert first != second
    assert first.exists() and second.exists()
    assert first.with_suffix(first.suffix + ".meta.json").exists()
    assert second.with_suffix(second.suffix + ".meta.json").exists()
    assert not list(tmp_path.glob("*.tmp"))


def test_corrupt_google_outbox_forces_full_snapshot(monkeypatch, tmp_path: Path):
    import core.google_sheets_backup as sheets

    outbox = tmp_path / "google-sheets-sync-outbox.json"
    outbox.write_text("{broken", encoding="utf-8")
    monkeypatch.setattr(sheets, "_pending_path", lambda: outbox)

    state = sheets._read_pending_state_unlocked()

    assert state == {sheets.FULL_SNAPSHOT_MARKER: 1}
    assert not outbox.exists()
    assert list(tmp_path.glob("google-sheets-sync-outbox.json.corrupt-*"))


@pytest.mark.asyncio
async def test_miniapp_background_tasks_are_cancelled_on_drain():
    import core.miniapp_server as miniapp

    started = asyncio.Event()
    cancelled = asyncio.Event()

    async def worker() -> None:
        started.set()
        try:
            await asyncio.sleep(60)
        except asyncio.CancelledError:
            cancelled.set()
            raise

    task = miniapp._track_background_task(worker(), name="reliability-test")
    await started.wait()
    await miniapp.drain_background_tasks(timeout=0.5)

    assert task.done()
    assert cancelled.is_set()
    assert task not in miniapp._BACKGROUND_TASKS


def test_storage_failover_only_accepts_connectivity_errors():
    from core.storage.engine import DatabaseEngine

    class PoolTimeout(Exception):
        pass

    assert DatabaseEngine._is_primary_connectivity_error(TimeoutError("network stalled")) is True
    assert DatabaseEngine._is_primary_connectivity_error(ConnectionError("connection lost")) is True
    assert DatabaseEngine._is_primary_connectivity_error(ValueError("bad SQL payload")) is False
    assert DatabaseEngine._is_primary_connectivity_error(PoolTimeout("pool exhausted")) is False


@pytest.mark.asyncio
async def test_distributed_job_fails_open_only_for_single_replica(monkeypatch):
    import core.distributed_jobs as jobs

    async def redis_down():
        return None

    monkeypatch.setattr(jobs, "SETTINGS", SimpleNamespace(redis_url="redis://down", database_url=""))
    monkeypatch.setattr(jobs, "_redis_client", redis_down)
    monkeypatch.setattr(jobs, "_LOCAL_RUNNING", set())
    calls: list[str] = []

    async def callback() -> str:
        calls.append("run")
        return "ok"

    wrapped = jobs.distributed_job("reliability-local-fallback", callback)

    monkeypatch.setenv("SENTINEL_REPLICA_COUNT", "1")
    assert await wrapped() == "ok"
    assert calls == ["run"]

    calls.clear()
    monkeypatch.setenv("SENTINEL_REPLICA_COUNT", "2")
    assert await wrapped() is None
    assert calls == []
