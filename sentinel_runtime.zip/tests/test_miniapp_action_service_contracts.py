from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace

import pytest

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.webapp_auth import TelegramWebAppIdentity
from services import miniapp_action_service_v2 as service


def identity(uid: int = 42) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(uid, "trader", "A", "B", 1, "q")


@dataclass
class Spec:
    handler: object
    mutation: bool = True
    idempotency_required: bool = True
    admin_only: bool = False
    permission: str = ""


class FakeEvents:
    def __init__(self):
        self.calls = []

    def append(self, **kwargs):
        self.calls.append(kwargs)
        return {"id": "evt-1"}


class FakeIdempotency:
    def __init__(self, state="reserved", response=None):
        self.state = state
        self.response = response
        self.calls = []

    def reserve(self, *args, **kwargs):
        self.calls.append(("reserve", args, kwargs))
        return SimpleNamespace(state=self.state, response=self.response, token="tok")

    def complete(self, *args, **kwargs):
        self.calls.append(("complete", args, kwargs))

    def replace_completed_response(self, *args, **kwargs):
        self.calls.append(("replace", args, kwargs))

    def abort(self, *args, **kwargs):
        self.calls.append(("abort", args, kwargs))


def install_common(monkeypatch, *, handler=None, state="reserved", mutation=True, rules=True):
    events = FakeEvents()
    idem = FakeIdempotency(state=state, response={"replayed": True})
    captured = {}

    def actual_handler(context):
        captured["context"] = context
        if handler:
            return handler(context)
        return {"ok": True, "choice": {"choice": "taken"}, "position": {"id": "pos-1"}}

    monkeypatch.setattr(service, "get_action", lambda _name: Spec(actual_handler, mutation=mutation, idempotency_required=mutation))
    monkeypatch.setattr(service, "read_db_sections", lambda _sections: {"runtime_safety": {}})
    monkeypatch.setattr(service, "enforce_action_policy", lambda *a, **k: None)
    monkeypatch.setattr(service, "is_any_admin", lambda *_a, **_k: False)
    monkeypatch.setattr(service, "_normalized_rules_accepted", lambda *_a, **_k: rules)
    monkeypatch.setattr(service, "rate_limit_allow", lambda *_a, **_k: True)
    monkeypatch.setattr(service, "IdempotencyRepository", lambda: idem)
    monkeypatch.setattr(service, "create_context", lambda ident, **kwargs: SimpleNamespace(identity=ident, events=events, **kwargs))
    return idem, events, captured


def test_helper_contracts_are_stable() -> None:
    assert service._valid_request_id("req-1:abc.test")
    assert not service._valid_request_id("")
    assert not service._valid_request_id("x" * 101)
    assert not service._valid_request_id("bad key")
    assert service._fingerprint("a", {"b": 1}) == service._fingerprint("a", {"b": 1})
    assert service._fingerprint("a", {"b": 1}) != service._fingerprint("a", {"b": 2})
    assert service._policy_for("payment_approve", admin_only=True, permission="payments").admin_only is True
    assert service._policy_for("language_update", admin_only=False, permission="").rules_required is False
    assert service._event_type("signal_choice_update", {"choice": {"choice": "taken"}, "position": {"id": "p1"}}) == "position.opened"
    assert service._event_type("signal_choice_update", {"choice": {"choice": "taken", "retrospective": True}, "position": None}) == "signal.choice_updated"
    assert service._event_type("signal_choice_update", {"choice": {"choice": "skipped"}}) == "signal.choice_updated"
    assert service._event_type("position_close", {"status": "closed"}) == "position.closed"
    assert service._event_type("position_close", {"status": "partial"}) == "position.risk_changed"
    assert service._event_type("journal_add", {}) == "journal.updated"
    assert service._event_type("unknown", {}) == "action.unknown.completed"


def test_mutation_requires_explicit_idempotency_key(monkeypatch) -> None:
    install_common(monkeypatch)
    with pytest.raises(ValueError, match="IDEMPOTENCY_KEY_REQUIRED"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "watchlist_toggle", "payload": {"symbol": "BTCUSD"}})
    with pytest.raises(ValueError, match="INVALID_REQUEST_ID"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "watchlist_toggle", "request_id": "bad key", "payload": {}})


def test_runtime_read_only_rules_and_rate_limit(monkeypatch) -> None:
    install_common(monkeypatch)
    monkeypatch.setattr(service, "read_db_sections", lambda _sections: {"runtime_safety": {"read_only": True}})
    with pytest.raises(PermissionError, match="SYSTEM_READ_ONLY"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": "r1", "payload": {}})

    install_common(monkeypatch, rules=False)
    with pytest.raises(PermissionError, match="RULES_ACCEPTANCE_REQUIRED"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": "r2", "payload": {}})

    install_common(monkeypatch)
    monkeypatch.setattr(service, "rate_limit_allow", lambda *_a, **_k: False)
    with pytest.raises(ValueError, match="RATE_LIMITED"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": "r3", "payload": {}})


def test_idempotency_conflict_in_progress_and_replay(monkeypatch) -> None:
    for state, error in (("conflict", "IDEMPOTENCY_CONFLICT"), ("in_progress", "REQUEST_IN_PROGRESS")):
        install_common(monkeypatch, state=state)
        with pytest.raises(ValueError, match=error):
            service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": f"r-{state}", "payload": {}})
    install_common(monkeypatch, state="replay")
    assert service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": "r-replay", "payload": {}}) == {"replayed": True}


def test_success_completes_idempotency_and_appends_event(monkeypatch) -> None:
    idem, events, captured = install_common(monkeypatch)
    result = service.handle_miniapp_action_for_identity_v2(
        identity(),
        {"action": "signal_choice_update", "request_id": "req-1", "payload": {"signal_id": "s1"}},
        transport_request_id="http-1",
        transport_context={"ip": "127.0.0.1"},
    )
    assert result["action"] == "signal_choice_update"
    assert result["event_id"] == "evt-1"
    assert events.calls[0]["event_type"] == "position.opened"
    assert [call[0] for call in idem.calls] == ["reserve", "complete", "replace"]
    assert captured["context"].transport == {"ip": "127.0.0.1"}


def test_failure_aborts_reservation(monkeypatch) -> None:
    def fail(_context):
        raise RuntimeError("boom")

    idem, _events, _captured = install_common(monkeypatch, handler=fail)
    with pytest.raises(RuntimeError, match="boom"):
        service.handle_miniapp_action_for_identity_v2(identity(), {"action": "journal_add", "request_id": "req-fail", "payload": {}})
    assert [call[0] for call in idem.calls] == ["reserve", "abort"]


def test_non_mutation_can_run_without_request_id(monkeypatch) -> None:
    idem, events, _captured = install_common(monkeypatch, mutation=False)
    result = service.handle_miniapp_action_for_identity_v2(identity(), {"action": "mission_control_refresh", "payload": {}})
    assert result["request_id"] == ""
    assert events.calls
    assert idem.calls == []


def test_rules_accept_enriches_server_authoritative_version(monkeypatch) -> None:
    idem, _events, captured = install_common(monkeypatch)
    monkeypatch.setattr(service, "_rules_snapshot", lambda _db, _uid: ("fa", {"version": 7, "content_hash": "sha"}))
    service.handle_miniapp_action_for_identity_v2(identity(), {"action": "rules_accept", "request_id": "rules-1", "payload": {"version": 999}})
    payload = captured["context"].payload
    assert payload == {"version": 7, "language": "fa", "content_hash": "sha"}
