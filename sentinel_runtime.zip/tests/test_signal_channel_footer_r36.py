from __future__ import annotations

from pathlib import Path

import pytest

from modules.advanced_features import (
    normalize_signal_message_channel_id,
    set_signal_message_channel_id,
    signal_message_channel_id,
)
from modules.signal import create_signal


def test_signal_message_channel_id_is_normalized_persisted_and_clearable() -> None:
    db: dict = {}

    assert set_signal_message_channel_id(db, "My_Channel", 42) == "@My_Channel"
    assert signal_message_channel_id(db) == "@My_Channel"
    assert db["settings"]["signalMessageChannelIdUpdatedBy"] == "42"

    assert normalize_signal_message_channel_id("t.me/My_Channel") == "https://t.me/My_Channel"
    assert set_signal_message_channel_id(db, "حذف", 42) == ""
    assert signal_message_channel_id(db) == ""

    with pytest.raises(ValueError):
        normalize_signal_message_channel_id("invalid channel id")


def test_signal_caption_ends_with_configured_channel_id(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    image_path = tmp_path / "signal.png"
    monkeypatch.setattr("modules.signal.signal_template_render_settings", lambda _side: ({}, None))
    monkeypatch.setattr("modules.signal.create_signal_image", lambda **_kwargs: str(image_path))

    signal = create_signal(
        "XAUUSD",
        "2300",
        ["2310", "2320"],
        "2290",
        "buy",
        "1",
        signal_id=9,
        message_channel_id="@My_Channel",
    )

    assert signal["text"].endswith("\n\n@My_Channel")
    assert signal["text"].count("@My_Channel") == 1


def test_signal_channel_footer_bot_flow_is_registered() -> None:
    root = Path(__file__).resolve().parents[1]
    growth = (root / "bot_runtime" / "growth_campaigns.py").read_text(encoding="utf-8")
    runtime = (root / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    shared = (root / "bot_runtime" / "shared.py").read_text(encoding="utf-8")

    assert "SIGNAL_CHANNEL_ID_INPUT = 98303" in shared
    assert 'callback_data="sig_channel_id_start"' in growth
    assert 'data["message_channel_id"] = signal_message_channel_id(snapshot)' in growth
    assert 'message_channel_id=str(data.get("message_channel_id") or "")' in growth
    assert 'CallbackQueryHandler(signal_channel_id_start, pattern=r"^sig_channel_id_start$")' in runtime
    assert "MessageHandler(filters.TEXT & ~filters.COMMAND, signal_channel_id_input)" in runtime
