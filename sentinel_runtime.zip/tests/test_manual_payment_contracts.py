from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

from services.vip_entitlement_projection import merge_entitlement_rows
from services.vip_order_projection import merge_order_row

ROOT = Path(__file__).resolve().parents[1]


def test_frontend_txid_is_optional_and_receipt_is_required():
    text = (ROOT / "webapp/src/commerce-support.js").read_text(encoding="utf-8")
    assert 'id="orderTxid" class="ltr" maxlength="128"' in text
    assert 'id="orderTxid" class="ltr" minlength="64" maxlength="66" required' not in text
    assert 'id="receiptFile" type="file"' in text and "required" in text
    assert "بررسی دستی ادمین" in text


def test_admin_can_only_approve_pending_order():
    text = (ROOT / "webapp/src/shell-events.js").read_text(encoding="utf-8")
    assert "x.status==='pending'?`<button" in text
    assert "['pending','rejected','needs_receipt'].includes(x.status)" not in text
    assert "تأیید دستی و ارسال لینک" in text


def test_telegram_usdt_flow_does_not_auto_verify_or_require_txid():
    text = (ROOT / "bot_runtime/commerce_calculator.py").read_text(encoding="utf-8")
    submit = text[text.index("async def submit_vip_order"):text.index("async def buy_receipt", text.index("async def submit_vip_order"))]
    assert "verify_usdt_transaction" not in submit
    assert "TXID اختیاری" in text
    assert "return BUY_TXID if method" not in text


def test_normalized_order_projection_is_idempotent_and_keeps_receipt():
    db = {"vip_orders": []}
    order = {"id": "ord-1", "user_id": "10", "status": "pending", "amount_toman": 1000, "updated_at": "now"}
    receipt = {"id": "R-1", "storage_backend": "local", "object_key": "x", "checksum": "a" * 64}
    assert merge_order_row(db, order, receipt) is True
    assert merge_order_row(db, order, receipt) is False
    assert len(db["vip_orders"]) == 1
    assert db["vip_orders"][0]["receipt_object_key"] == "x"
    changed = {**order, "status": "approved", "updated_at": "later"}
    assert merge_order_row(db, changed, receipt) is True
    assert db["vip_orders"][0]["status"] == "approved"


def test_entitlement_projection_keeps_invite_link_and_expiry():
    now = datetime.now(UTC)
    db = {"vip_users": {}}
    rows = [{
        "user_id": "10", "order_id": "ord-1", "status": "active",
        "expires_at": (now + timedelta(days=30)).isoformat(),
        "updated_at": now.isoformat(), "invite_link": "https://t.me/+safe",
    }]
    assert merge_entitlement_rows(db, rows, now=now) == 1
    assert db["vip_users"]["10"]["status"] == "active"
    assert db["vip_users"]["10"]["invite_link"] == "https://t.me/+safe"
