from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

from core.webapp_auth import TelegramWebAppIdentity


def _identity(uid: int = 354678485) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(uid, "owner", "Sentinel", "Admin", 1, "query")


@pytest.mark.asyncio
async def test_ptb_error_handler_outcome_prevents_false_done(monkeypatch: pytest.MonkeyPatch) -> None:
    from telegram import Update
    from core.telegram_update_outcome import record_update_failure
    from core.update_processor import KeyedUpdateProcessor
    import core.telegram_update_store as store

    calls: list[tuple[str, str]] = []
    monkeypatch.setattr(store, "mark_done", lambda update_id: calls.append(("done", str(update_id))))
    monkeypatch.setattr(store, "mark_failed", lambda update_id, error: calls.append(("failed", str(error))) or "failed")

    # ``effective_user`` and ``effective_chat`` are derived read-only properties
    # in real python-telegram-bot releases and are not accepted constructor
    # arguments.  Keep this regression test compatible with both the production
    # PTB package and the lightweight offline test stub by constructing the
    # smallest valid Update and bypassing key derivation, which is not the
    # behavior under test here.
    update = Update(update_id=501)
    monkeypatch.setattr(KeyedUpdateProcessor, "_key", staticmethod(lambda _update: "update:501"))

    async def handled_by_ptb_error_pipeline() -> None:
        record_update_failure(501, "RuntimeError")

    processor = KeyedUpdateProcessor(2)
    await processor.do_process_update(update, handled_by_ptb_error_pipeline())

    assert calls == [("failed", "RuntimeError")]


def test_gemini_admin_action_runs_shared_telegram_finalizer(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import ai_control_service as service
    import core.miniapp_server as server
    import repositories.v2.idempotency as idem_module

    monkeypatch.setattr(service, "is_ai_operational_action_allowed", lambda _name: True)
    monkeypatch.setattr(service, "requester_may_request_action", lambda *_args: True)
    monkeypatch.setattr(
        service,
        "action_specs",
        lambda: {"payment_approve": SimpleNamespace(admin_only=True, permission="payments")},
    )
    intermediate = {"action": "payment_approve", "data": {"status": "approving"}, "request_id": "exec-1"}
    monkeypatch.setattr(service, "handle_miniapp_action_for_identity_v2", lambda *_args, **_kwargs: intermediate)

    finalized: list[str] = []

    def finalize(action, result, identity):
        finalized.append(f"{action}:{identity.user_id}")
        result["data"] = {"status": "approved", "invite_link": "https://t.me/+test"}

    monkeypatch.setattr(server, "finalize_action_telegram_sync", finalize)

    replaced: list[dict] = []

    class FakeIdempotency:
        def replace_completed_response(self, _uid, _request_id, *, response):
            replaced.append(dict(response))

        def reset_completed(self, *_args, **_kwargs):
            raise AssertionError("successful finalizer must not reset idempotency")

    monkeypatch.setattr(idem_module, "IdempotencyRepository", FakeIdempotency)

    result = service.execute_registered_admin_action(
        354678485,
        "payment_approve",
        {"order_id": "ord-1"},
        request_id="exec-1",
    )

    assert finalized == ["payment_approve:354678485"]
    assert result["data"]["status"] == "approved"
    assert replaced[0]["data"]["status"] == "approved"


def test_event_failure_never_reopens_successful_mutation(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import miniapp_action_service_v2 as service

    mutations = 0

    class Spec:
        mutation = True
        idempotency_required = True
        admin_only = False
        permission = ""

        @staticmethod
        def handler(_context):
            nonlocal mutations
            mutations += 1
            return {"id": "entity-1"}

    class Idempotency:
        def __init__(self):
            self.complete_response = None
            self.aborts = 0

        def reserve(self, *_args, **_kwargs):
            if self.complete_response is not None:
                return SimpleNamespace(state="replay", response=self.complete_response, token="")
            return SimpleNamespace(state="new", response=None, token="tok")

        def complete(self, *_args, response, **_kwargs):
            self.complete_response = dict(response)

        def replace_completed_response(self, *_args, response, **_kwargs):
            self.complete_response = dict(response)

        def abort(self, *_args, **_kwargs):
            self.aborts += 1

    idem = Idempotency()
    events = SimpleNamespace(append=lambda **_kwargs: (_ for _ in ()).throw(OSError("event db unavailable")))
    monkeypatch.setattr(service, "get_action", lambda _name: Spec())
    monkeypatch.setattr(service, "read_db_sections", lambda _sections: {"runtime_safety": {}})
    monkeypatch.setattr(service, "enforce_action_policy", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(service, "is_any_admin", lambda *_args, **_kwargs: False)
    monkeypatch.setattr(service, "_normalized_rules_accepted", lambda *_args, **_kwargs: True)
    monkeypatch.setattr(service, "rate_limit_allow", lambda *_args, **_kwargs: True)
    monkeypatch.setattr(service, "IdempotencyRepository", lambda: idem)
    monkeypatch.setattr(
        service,
        "create_context",
        lambda ident, **kwargs: SimpleNamespace(identity=ident, events=events, **kwargs),
    )

    request = {"action": "journal_add", "request_id": "stable-1", "payload": {}}
    first = service.handle_miniapp_action_for_identity_v2(_identity(42), request)
    second = service.handle_miniapp_action_for_identity_v2(_identity(42), request)

    assert mutations == 1
    assert idem.aborts == 0
    assert first["event_pending"] is True
    assert second["event_pending"] is True


def test_primary_admin_scope_is_recomputed_for_each_message(monkeypatch: pytest.MonkeyPatch) -> None:
    from bot_runtime import platform_expansion

    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor: True)
    assert platform_expansion._infer_primary_admin_ai_scope(
        "سیگنال‌های باز را بررسی کن", "tickets", 354678485
    ) == "signals"


def test_broker_account_reference_is_validated_and_encoded(monkeypatch: pytest.MonkeyPatch) -> None:
    from modules.broker_readonly import HttpBrokerSnapshotAdapter
    import modules.broker_readonly as broker

    adapter = HttpBrokerSnapshotAdapter(base_url="https://bridge.example", api_key="k", secret="s")
    with pytest.raises(ValueError, match="BROKER_ACCOUNT_REFERENCE_INVALID"):
        adapter.fetch_snapshot("../admin?x=1")

    requested: list[str] = []

    class Response:
        def raise_for_status(self):
            return None

        def json(self):
            return {
                "provider": "mt5",
                "observed_at": datetime.now(UTC).isoformat(),
                "balance": 1000,
                "equity": 995,
                "floating_pnl": -5,
                "positions": [],
                "confidence": 0.99,
            }

    class Client:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def get(self, url, **_kwargs):
            requested.append(url)
            return Response()

    monkeypatch.setattr(broker.httpx, "Client", Client)
    snapshot = adapter.fetch_snapshot("server:123@live")

    assert requested == ["https://bridge.example/v1/accounts/server%3A123%40live/snapshot"]
    assert snapshot.account_reference == "server:123@live"


def test_audit_failure_is_reported_without_raising(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import ai_control_service as service

    monkeypatch.setattr(
        service,
        "_record_execution_result",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("audit unavailable")),
    )
    status = service._safe_record_execution_result(
        1,
        action="ticket_admin_reply",
        execution_key="x",
        status="executed",
        risk="reversible",
    )
    assert status == "pending:RuntimeError"
