from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from telegram_test_stub import install
install()

from ui.button_factory import InlineKeyboardButton, canonical_navigation_text


def _text(button):
    # ``getattr(obj, name, fallback)`` evaluates ``fallback`` eagerly.
    # The old helper used ``button.args[0]`` as that fallback, but the real
    # python-telegram-bot InlineKeyboardButton has ``text`` and no ``args``.
    # Read the production attribute first and use the local stub only when
    # that attribute is genuinely absent.
    text = getattr(button, "text", None)
    if text is not None:
        return text
    args = getattr(button, "args", ())
    if not args:
        raise AssertionError("button exposes neither text nor positional test-stub args")
    return args[0]


def test_legacy_market_back_label_is_forced_to_canonical_back() -> None:
    button = InlineKeyboardButton("↩️ میز بازار زنده", callback_data="nav_user:markets", style="primary")
    assert _text(button) == "⬅️ برگشت"
    assert button.callback_data == "nb:nav_user:markets"
    assert button.style == "danger"


def test_admin_legacy_back_label_is_forced_to_canonical_back() -> None:
    button = InlineKeyboardButton("🔙 پنل مدیریت", callback_data="admin_home")
    assert _text(button) == "⬅️ برگشت"
    assert button.callback_data == "nb:admin_home"
    assert button.style == "danger"


def test_pagination_and_arrow_controls_are_not_rewritten_as_back() -> None:
    previous = InlineKeyboardButton("◀️ قبلی", callback_data="a_pending:2")
    move = InlineKeyboardButton("⬅️", callback_data="sig_tpl_move:buy:entry:-5:0")
    refund = InlineKeyboardButton("↩️ ثبت بازپرداخت کامل", callback_data="discount_refund_confirm:42:full")
    assert previous.callback_data == "a_pending:2"
    assert move.callback_data.startswith("sig_tpl_move:")
    assert refund.callback_data.startswith("discount_refund_confirm:")
    assert canonical_navigation_text(_text(previous), previous.callback_data) is None


def test_cancel_is_canonical_and_red() -> None:
    button = InlineKeyboardButton("↩️ انصراف", callback_data="portfolio_user:12")
    assert _text(button) == "✖️ لغو"
    assert button.callback_data == "cancel_current"
    assert button.style == "danger"


def test_miniapp_exposes_shared_full_module_control_contract() -> None:
    read_source = Path("services/miniapp_read_service_v2.py").read_text(encoding="utf-8")
    action_source = Path("services/actions_v2/admin.py").read_text(encoding="utf-8")
    frontend = Path("webapp/src/admin-parity.js").read_text(encoding="utf-8")
    shell = Path("webapp/src/shell-events.js").read_text(encoding="utf-8")
    assert 'payload["control_modules"] = modules' in read_source
    assert '"write_path": "shared_actions_v2_registry"' in read_source
    for name in (
        "control_change", "control_reset", "control_preset",
        "governance_request_approve", "governance_request_reject",
        "governance_request_apply", "governance_request_retry",
    ):
        assert f'@action("{name}"' in action_source
        assert f"action('{name}'" in frontend
    assert "adminModuleControlCenter" in frontend
    assert "admin.control_updated" in shell
    assert "admin.governance_updated" in shell


def test_release_version_v8156() -> None:
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "8.34.0"
