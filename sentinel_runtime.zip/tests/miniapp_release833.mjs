import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url);
const core=fs.readFileSync(new URL('webapp/src/core.js',root),'utf8');
const shell=fs.readFileSync(new URL('webapp/src/shell-events.js',root),'utf8');
const hub=fs.readFileSync(new URL('webapp/src/user-hub.js',root),'utf8');
const results=[];
function context(){
 const modal={hidden:true},eyebrow={textContent:''};let shown=false;
 const page={innerHTML:'',hidden:true,querySelector:()=>null,append:()=>{},prepend:()=>{}};
 const c=vm.createContext({console,URLSearchParams,Set,Map,Number,String,Math,Promise,I18N:{fa:{},en:{}},
  state:{lang:'en',page:'home',pageHistory:[],loaded:new Set(),resources:{overview:{bot_username:'Sentinel_bot'},hub:{points:{balance:10},referral:{code:'secure'}}}},
  window:{scrollTo:()=>{},Telegram:{WebApp:{BackButton:{show:()=>shown=true,hide:()=>shown=false,onClick:()=>{},offClick:()=>{}},MainButton:{hide:()=>{},offClick:()=>{}},disableClosingConfirmation:()=>{},enableVerticalSwipes:()=>{}}}},
  document:{addEventListener:()=>{},createElement:()=>page},navigator:{},tg:null,
  $:s=>s==='#modalLayer'?modal:s==='#modalEyebrow'?eyebrow:page,$$:()=>[],
  renderHome:()=>{},renderSignals:async()=>{},renderRisk:async()=>{},renderJournal:async()=>{},renderMore:async()=>{},localizeUiTree:()=>{},openMore:async()=>{},
  t:v=>v,esc:v=>String(v??''),num:v=>String(v),date:v=>String(v||''),icon:()=>'',pageHead:()=>'',skeleton:()=>'',metric:()=>'',empty:()=>'',errorPanel:()=>'',toast:()=>{},sentinelService:()=>'',
  openModal:(name)=>{eyebrow.textContent=name;modal.hidden=false;},closeModal:()=>{modal.hidden=true;},setBusy:()=>{},invalidate:()=>{},loadOverview:async()=>{},renderChrome:()=>{},
  loadResource:async()=>c.state.resources.hub});
 vm.runInContext(core.slice(core.indexOf('async function navigateWorkspaceBack()'),core.indexOf('function prepareTelegramChrome()')),c);
 vm.runInContext(shell.slice(shell.indexOf('async function navigate('),shell.indexOf('function applyLanguage()')),c);
 vm.runInContext(hub,c);
 return {c,modal,eyebrow,shown:()=>shown};
}
async function test(name,fn){try{await fn();results.push({name,status:'PASS'});}catch(e){results.push({name,status:'FAIL',reason:e.message});}}
await test('SDK Back becomes visible on actual page navigation',async()=>{
 const {c,shown}=context();vm.runInContext('syncTelegramNavigation()',c);
 assert.equal(shown(),false);
 await vm.runInContext("navigate('rewards')",c);
 assert.equal(c.state.page,'rewards');assert.equal(shown(),true,'Back still hidden after navigating from Home to Rewards');
});
await test('SDK Back hides when actual navigation returns Home',async()=>{
 const {c,shown}=context();c.state.page='rewards';vm.runInContext('syncTelegramNavigation()',c);assert.equal(shown(),true);
 await vm.runInContext("navigate('home')",c);
 assert.equal(shown(),false,'Back remains visible after returning Home');
});
await test('Background refresh must not reopen a closed referral dialog',async()=>{
 const {c,modal,eyebrow}=context();modal.hidden=false;eyebrow.textContent='REFERRAL';
 let finish;c.loadResource=async()=>{const d=await new Promise(r=>finish=r);c.state.resources.hub=d;return d;};
 const task=vm.runInContext('refreshVisibleHub()',c);
 modal.hidden=true;
 c.loadResource=async()=>c.state.resources.hub;
 finish({points:{balance:15},referral:{code:'secure'}});await task;
 assert.equal(modal.hidden,true,'Background response reopened the dialog after it had been closed');
});
// Run real loadResource in a fresh realm so all its bindings are explicit.
await test('Old resource response must not replace newly selected point history page',async()=>{
 const c=vm.createContext({URLSearchParams,Map,Set,state:{preview:false,pageSize:20,ticketFilter:'all',resources:{},loaded:new Set()},resourceInflight:new Map()});
 vm.runInContext('let pointCursor=0;',c);
 vm.runInContext(core.slice(core.indexOf('function resourceRoute('),core.indexOf('function moreButton(')),c);
 let finish;c.request=()=>new Promise(r=>finish=r);
 const task=vm.runInContext("loadResource('hub',true)",c);
 vm.runInContext('pointCursor=20;',c);
 c.state.resources.hub={points:{history:[{id:20}]}};
 finish({points:{history:[{id:0}]}});await task;
 assert.equal(c.state.resources.hub.points.history[0].id,20,'Old page 0 overwrote newer page 20');
});
await test('Changed history queries deduplicate identical calls and keep the latest response',async()=>{
 const c=vm.createContext({URLSearchParams,Map,Set,state:{preview:false,pageSize:20,ticketFilter:'all',resources:{},loaded:new Set()},resourceInflight:new Map()});
 vm.runInContext('let pointCursor=0;',c);
 vm.runInContext(core.slice(core.indexOf('function resourceRoute('),core.indexOf('function moreButton(')),c);
 const pending=[];c.request=route=>new Promise(resolve=>pending.push({route,resolve}));
 const first=vm.runInContext("loadResource('hub',true)",c);
 const duplicate=vm.runInContext("loadResource('hub',true)",c);
 assert.equal(pending.length,1);
 vm.runInContext('pointCursor=20;',c);
 const latest=vm.runInContext("loadResource('hub',true)",c);
 assert.equal(pending.length,2);
 pending[1].resolve({points:{history:[{id:20}]}});await latest;
 pending[0].resolve({points:{history:[{id:0}]}});await Promise.all([first,duplicate]);
 assert.equal(c.state.resources.hub.points.history[0].id,20);
 assert.equal(c.resourceInflight.size,0);
});
await test('Post-mutation invalidation must not reuse or publish a pre-mutation response',async()=>{
 const c=vm.createContext({URLSearchParams,Map,Set,state:{preview:false,pageSize:20,ticketFilter:'all',resources:{},loaded:new Set()},resourceInflight:new Map()});
 vm.runInContext('let pointCursor=0;',c);
 vm.runInContext(core.slice(core.indexOf('function resourceRoute('),core.indexOf('function moreButton(')),c);
 vm.runInContext(shell.slice(shell.indexOf('function invalidate('),shell.indexOf('async function navigate(')),c);
 const pending=[];c.request=route=>new Promise(resolve=>pending.push(resolve));
 const old=vm.runInContext("loadResource('hub',true)",c);
 vm.runInContext("invalidate('hub')",c);
 const fresh=vm.runInContext("loadResource('hub',true)",c);
 assert.equal(pending.length,2);
 pending[1]({points:{balance:155}});await fresh;
 pending[0]({points:{balance:10}});await old;
 assert.equal(c.state.resources.hub.points.balance,155);
});
await test('Old refresh must not replace a newly opened dialog of the same type',async()=>{
 const {c,modal,eyebrow}=context();modal.hidden=false;eyebrow.textContent='REFERRAL';c.state.modalGeneration=1;
 let finish;c.loadResource=async()=>{const d=await new Promise(r=>finish=r);c.state.resources.hub=d;return d;};
 const task=vm.runInContext('refreshVisibleHub()',c);
 c.state.modalGeneration=3; // Close old dialog and open a new one.
 let redraw=0;c.openModal=()=>redraw++;c.loadResource=async()=>c.state.resources.hub;
 finish({points:{balance:15},referral:{code:'secure'}});await task;
 assert.equal(redraw,0);
});
console.log(JSON.stringify(results,null,2));process.exitCode=results.some(r=>r.status==='FAIL')?1:0;
