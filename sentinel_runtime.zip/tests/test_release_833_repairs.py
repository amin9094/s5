"""Fresh read-only release review: expected safety behavior, no product edits."""

from datetime import timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock
import pytest
from tests.test_master_upgrade import state, canonical_store, OWNER


@pytest.fixture
def combined_store(canonical_store, monkeypatch):
    from core.storage.engine import DatabaseEngine
    import repositories.v2.commerce as commerce

    engine = DatabaseEngine(database_url="", sqlite_path=canonical_store.path)
    engine.ensure_schema()
    monkeypatch.setattr(commerce, "normalized_engine", lambda: engine)
    try:
        yield commerce.CommerceRepository(engine)
    finally:
        engine.close()


def test_refunding_purchase_must_reverse_points_used_to_repay_previous_debt(state, canonical_store):
    from core.db import with_db, load_db
    from core.domain import add_points, activate_vip, record_vip_purchase_rewards
    from modules.economic_refunds import record_order_refund, outstanding_point_debt

    def setup(db):
        for oid in ("first", "second"):
            db["vip_orders"].append({"order_id": oid, "user_id": "1", "status": "approved", "price": 100000})
            activate_vip(db, 1, 30, source_order_id=oid)
        record_vip_purchase_rewards(db, db["vip_orders"][0])
        add_points(db, 1, -80, "spending")
        record_order_refund(db, "first", "full", OWNER)

    with_db(setup)
    assert outstanding_point_debt(load_db(), 1) == 80
    with_db(lambda db: record_vip_purchase_rewards(db, db["vip_orders"][1]))
    assert load_db()["user_points"]["1"] == 20
    assert outstanding_point_debt(load_db(), 1) == 0
    with_db(lambda db: record_order_refund(db, "second", "full", OWNER))
    assert load_db()["user_points"]["1"] == 0
    assert outstanding_point_debt(load_db(), 1) == 80, "Refund must not permanently erase 80 points of previous debt"


@pytest.mark.asyncio
async def test_normalized_only_expired_vip_is_removed_from_private_channel(state, combined_store):
    from core.db import with_db, load_db
    from core.domain import record_vip_purchase_rewards
    from core.utils import utc_now, utc_iso
    from modules.vip import check_expired_vips

    repo = combined_store
    order = repo.create_order(1, {"id": "web-purchase", "status": "approved", "amount_toman": 150000})
    with repo.engine.transaction() as cursor:
        repo._grant_entitlement_in_cursor(
            cursor, order, utc_now() - timedelta(days=31), invite_link="https://t.me/+old"
        )
    with_db(lambda db: record_vip_purchase_rewards(db, order))
    assert "1" not in load_db()["vip_users"], "New Mini App buyer does not have a legacy VIP row"
    assert repo.entitlement_for_user(1)["active"] is False
    context = SimpleNamespace(bot=SimpleNamespace(ban_chat_member=AsyncMock(), unban_chat_member=AsyncMock()))
    await check_expired_vips(context)
    context.bot.ban_chat_member.assert_awaited_once()


@pytest.mark.asyncio
async def test_refunded_normalized_order_must_not_deliver_old_approval_and_invite(state, combined_store):
    from core.db import with_db
    from core.utils import utc_now
    from modules.economic_refunds import record_order_refund
    from core.domain import record_vip_purchase_rewards
    from services.vip_payment_orchestrator import notify_manual_order_user

    repo = combined_store
    order = repo.create_order(
        1,
        {
            "id": "refund-before-notify",
            "status": "approved",
            "amount_toman": 150000,
            "invite_link": "https://t.me/+stale",
        },
    )
    with repo.engine.transaction() as cursor:
        repo._grant_entitlement_in_cursor(cursor, order, utc_now(), invite_link=order["invite_link"])
        import json

        cursor.execute("UPDATE v8_vip_orders SET payload=? WHERE id=?", (json.dumps(order), order["id"]))
    with_db(lambda db: record_vip_purchase_rewards(db, order))
    stale = repo.pending_user_notifications()[0]
    with_db(lambda db: record_order_refund(db, order["id"], "full", OWNER))
    queued = repo.pending_user_notifications()
    assert not queued
    bot = SimpleNamespace(send_message=AsyncMock())
    await notify_manual_order_user(bot, stale)
    messages = " ".join(str(call.args) for call in bot.send_message.await_args_list)
    assert "https://t.me/+stale" not in messages, "Refunded order still sends a VIP invite"
    assert "اشتراک VIP فعال شد" not in messages


@pytest.mark.parametrize("spent", [80, 100])
def test_zero_net_purchase_and_historical_refund_shortfall_repair(state, canonical_store, spent):
    from core.db import with_db, load_db
    from core.domain import add_points
    from core.economy_integrity import economic_event
    from modules.economic_refunds import reverse_points, repair_refunded_purchase_points, outstanding_point_debt

    def old_release(db):
        add_points(db, 1, 100, "old")
        add_points(db, 1, -spent, "spent")
        reverse_points(db, 1, 100, "old", OWNER)
        add_points(db, 1, 100, "vip_purchase:second", source_event="vip_purchase:second")
        reverse_points(db, 1, 100 - spent, "vip_purchase:second", OWNER)
        economic_event(
            db,
            "order_refund:second:full",
            1,
            kind="order_refund",
            value=1,
            metadata={"result": {"user_id": "1", "refund_status": "full"}},
        )

    with_db(old_release)
    assert outstanding_point_debt(load_db(), 1) == 0
    history = load_db()["point_history"]
    assert with_db(repair_refunded_purchase_points) == 1
    assert outstanding_point_debt(load_db(), 1) == spent
    assert with_db(repair_refunded_purchase_points) == 0
    assert load_db()["point_history"][: len(history)] == history


@pytest.mark.asyncio
async def test_expired_normalized_removal_retries_and_preserves_independent_renewal(state, combined_store):
    import json
    from telegram.error import TimedOut
    from core.db import with_db, load_db
    from core.domain import activate_vip
    from core.utils import utc_now, utc_iso
    from modules.vip import check_expired_vips

    repo = combined_store
    for uid in (1, 2):
        order = repo.create_order(uid, {"id": f"old-{uid}", "status": "approved"})
        with repo.engine.transaction() as cursor:
            repo._grant_entitlement_in_cursor(cursor, order, utc_now() - timedelta(days=31))
    with_db(lambda db: activate_vip(db, 2, 7, source_order_id="independent"))
    bot = SimpleNamespace(ban_chat_member=AsyncMock(), unban_chat_member=AsyncMock(side_effect=TimedOut()))
    await check_expired_vips(SimpleNamespace(bot=bot))
    assert bot.ban_chat_member.await_args.kwargs["user_id"] == 1
    assert load_db()["vip_users"]["1"]["channel_removal_phase"] == "unban"
    assert load_db()["vip_users"]["1"]["channel_removal_attempts"] == 1
    with_db(lambda db: db["vip_users"]["1"].update(channel_removal_next_retry_at=None))
    bot.unban_chat_member.side_effect = None
    await check_expired_vips(SimpleNamespace(bot=bot))
    assert bot.ban_chat_member.await_count == 1  # Resume unban, do not repeat ban.
    assert load_db()["vip_users"]["1"]["channel_removal_status"] == "done"
    assert load_db()["vip_users"]["2"]["status"] == "active"
    # A new normalized renewal must reset old removal evidence on the next scan.
    order = repo.create_order(1, {"id": "new-renewal", "status": "approved"})
    with repo.engine.transaction() as cursor:
        repo._grant_entitlement_in_cursor(cursor, order, utc_now())
    await check_expired_vips(SimpleNamespace(bot=bot))
    assert bot.ban_chat_member.await_count == 1
    assert load_db()["vip_users"]["1"]["channel_removed_at"] is None
    with repo.engine.transaction() as cursor:
        expiry = utc_iso(utc_now() - timedelta(seconds=1))
        cursor.execute(
            "UPDATE v8_vip_entitlements SET expires_at=?,updated_at=? WHERE user_id=?", (expiry, utc_iso(), "1")
        )
    await check_expired_vips(SimpleNamespace(bot=bot))
    assert bot.ban_chat_member.await_count == 2


@pytest.mark.asyncio
@pytest.mark.parametrize("normalized", [False, True])
async def test_refund_invite_retry_is_durable_and_idempotent(state, combined_store, normalized):
    import json
    from telegram.error import TimedOut
    from core.db import with_db, load_db
    from core.domain import activate_vip
    from core.utils import utc_now
    from modules.economic_refunds import record_order_refund
    from services.vip_payment_orchestrator import reconcile_refunded_invites, _finish_approved_order

    repo = combined_store
    oid = "revoke-order"
    if normalized:
        order = repo.create_order(1, {"id": oid, "status": "approved", "invite_link": "https://t.me/+refund"})
        with repo.engine.transaction() as cursor:
            repo._grant_entitlement_in_cursor(cursor, order, utc_now())
            cursor.execute("UPDATE v8_vip_orders SET payload=? WHERE id=?", (json.dumps(order), oid))
    else:

        def setup(db):
            db["vip_orders"].append(
                {"order_id": oid, "user_id": "1", "status": "approved", "invite_link": "https://t.me/+refund"}
            )
            activate_vip(db, 1, 30, source_order_id=oid)

        with_db(setup)
    with_db(lambda db: record_order_refund(db, oid, "full", OWNER))
    bot = SimpleNamespace(revoke_chat_invite_link=AsyncMock(side_effect=TimedOut()), send_message=AsyncMock())
    await reconcile_refunded_invites(bot, order_id=oid)
    row = repo.get(oid) if normalized else load_db()["vip_orders"][0]
    assert row["refund_invite_status"] == "pending" and row["refund_invite_attempts"] == 1
    assert load_db()["incidents"]
    if normalized:
        row["refund_invite_next_retry_at"] = None
        with repo.engine.transaction() as cursor:
            cursor.execute("UPDATE v8_vip_orders SET payload=? WHERE id=?", (json.dumps(row), oid))
    else:
        with_db(lambda db: db["vip_orders"][0].update(refund_invite_next_retry_at=None))
    bot.revoke_chat_invite_link.side_effect = None
    await reconcile_refunded_invites(bot, order_id=oid)
    await reconcile_refunded_invites(bot, order_id=oid)
    assert bot.revoke_chat_invite_link.await_count == 2
    row = repo.get(oid) if normalized else load_db()["vip_orders"][0]
    assert row["refund_invite_status"] == "revoked"
    if normalized:
        await _finish_approved_order(bot, repo.get(oid), OWNER)
        assert repo.get(oid)["finalization_status"] == "done"
        bot.send_message.assert_not_awaited()


def test_real_miniapp_review_regressions():
    import os, subprocess
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    completed = subprocess.run(
        [os.environ.get("CODEX_PRIMARY_RUNTIME_NODE", "node"), str(root / "tests/miniapp_release833.mjs")],
        cwd=root,
        text=True,
        capture_output=True,
        timeout=20,
    )
    assert completed.returncode == 0, completed.stdout + completed.stderr
