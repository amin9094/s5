from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

import bot  # noqa: F401 - injects cross-feature runtime exports
from bot_runtime import navigation, platform_expansion
from modules import gemini_ai
from modules.education import add_lesson_attachment, create_lesson, set_lesson_status, visible_lessons
from services import ai_control_service

ADMIN_ID = 354678485


def test_main_menu_uses_owner_approved_flat_r17_layout(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(navigation, "load_db", lambda: {"users": {}})
    monkeypatch.setattr(navigation, "_language_for_user", lambda _uid: "fa")
    monkeypatch.setattr(navigation, "is_vip", lambda _db, _uid: False)
    monkeypatch.setattr(navigation, "_is_any_admin", lambda _uid: False)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *_args: False)
    monkeypatch.setattr(navigation, "with_webapp", lambda rows: rows)

    rows = navigation.main_menu(1001)
    callbacks = [[getattr(button, "callback_data", None) for button in row] for row in rows]

    assert callbacks[0] == ['u_signal_portal','nav_user:trade']
    flat={callback for row in callbacks for callback in row}
    assert {'u_vip','u_edu','u_price','u_calc','u_contests','u_missions','u_account','nav_user:trade','u_calendar:today','u_support','language_menu','u_referral','u_rewards','u_settings','u_today','home'} <= flat
    assert all("nav_user:account" not in row for row in callbacks)


def test_admin_education_link_is_published_to_user_lesson_catalog() -> None:
    db: dict = {}
    lesson = create_lesson(
        db,
        category="مقدماتی",
        course="کار با ربات",
        chapter="فصل ۱",
        title="ورود به مینی اپ",
        access_type="free",
        price=0,
        duration_minutes=5,
        status="draft",
        text="متن آموزش",
        actor_id=ADMIN_ID,
    )
    from bot_runtime.admin_operations import _lesson_link_from_text

    link = _lesson_link_from_text("ویدیوی کامل | https://example.com/training/video")
    assert link == {
        "type": "link",
        "url": "https://example.com/training/video",
        "caption": "ویدیوی کامل",
    }
    add_lesson_attachment(db, lesson["id"], link)
    set_lesson_status(db, lesson["id"], "published")

    published = visible_lessons(db)
    assert len(published) == 1
    assert published[0]["attachments"][0]["type"] == "link"
    assert published[0]["attachments"][0]["url"] == "https://example.com/training/video"


@pytest.mark.asyncio
async def test_first_gemini_message_restores_missing_state_and_stays_active(monkeypatch: pytest.MonkeyPatch) -> None:
    replies: list[tuple[str, object]] = []

    async def fake_reply(_update, text, rows=None):
        replies.append((text, rows))

    async def allow_admin(*_args, **_kwargs):
        return True

    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor: True)
    monkeypatch.setattr(platform_expansion, "reply", fake_reply)
    monkeypatch.setattr(platform_expansion, "require_admin", allow_admin)
    monkeypatch.setattr(
        gemini_ai,
        "admin_ai_query",
        lambda *_args, **_kwargs: {
            "answer": "عملیات انجام شد.",
            "execution_requested": True,
            "execution": {
                "executions": [
                    {"action": "miniapp_runtime_toggle", "status": "executed", "result": {"status": "disabled"}}
                ],
                "queued": [],
            },
        },
    )

    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=ADMIN_ID),
        effective_message=SimpleNamespace(text="مینی اپ را غیرفعال کن"),
    )
    context = SimpleNamespace(user_data={}, chat_data={})

    state = await platform_expansion.ai_chat_message_router(update, context)

    assert state == "AI_CHAT_INPUT"
    assert context.user_data["sentinel_ai_chat"]["role"] == "admin"
    assert context.chat_data["sentinel_ai_chat"]["active"] is True
    assert "miniapp_runtime_toggle" in replies[0][0]
    assert "اجراشده: <b>1</b>" in replies[0][0]


@pytest.mark.asyncio
async def test_primary_admin_enters_gemini_without_scope_screen(monkeypatch: pytest.MonkeyPatch) -> None:
    edits: list[str] = []

    async def allow_admin(*_args, **_kwargs):
        return True

    async def fake_edit(_query, text, _rows):
        edits.append(text)

    query = SimpleNamespace(
        from_user=SimpleNamespace(id=ADMIN_ID),
        answer=lambda *args, **kwargs: None,
    )

    async def answer(*_args, **_kwargs):
        return None

    query.answer = answer
    update = SimpleNamespace(callback_query=query)
    context = SimpleNamespace(user_data={}, chat_data={})
    monkeypatch.setattr(platform_expansion, "require_admin", allow_admin)
    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor: True)
    monkeypatch.setattr(platform_expansion, "edit", fake_edit)

    result = await platform_expansion.a_ai_chat_start(update, context)

    assert result == "AI_CHAT_INPUT"
    assert context.user_data["sentinel_ai_chat"]["scope"] == "management"
    assert "موضوع را از متن تشخیص می‌دهد" in edits[0]


def test_explicit_admin_operation_uses_single_native_function_planning_pass(monkeypatch: pytest.MonkeyPatch) -> None:
    provider_calls: list[str] = []

    def provider(system_prompt: str, *_args, **_kwargs):
        provider_calls.append(system_prompt)
        if len(provider_calls) == 1:
            payload = {
                "answer": "در حال انجام.",
                "findings": [],
                "recommended_actions": [],
                "tool_calls": [],
            }
        else:
            payload = {
                "answer": "دستور اجرایی آماده شد.",
                "findings": [],
                "recommended_actions": [],
                "tool_calls": [
                    {
                        "action": "miniapp_runtime_toggle",
                        "payload": {"enabled": False, "reason": "درخواست مستقیم مدیر اصلی"},
                        "reason": "مدیر اصلی درخواست غیرفعال‌سازی داده است",
                        "risk": "reversible",
                    }
                ],
            }
        return {"text": json.dumps(payload, ensure_ascii=False), "model": "gemini-test", "usage": {}}

    monkeypatch.setattr(gemini_ai, "_gemini_request", provider)
    monkeypatch.setattr(gemini_ai, "admin_ai_context", lambda *_args, **_kwargs: {"scope": "system"})
    monkeypatch.setattr(gemini_ai, "operational_tool_catalog", lambda: [{"action": "miniapp_runtime_toggle"}])
    monkeypatch.setattr(gemini_ai, "ai_execution_settings", lambda: {"execution_enabled": True})
    monkeypatch.setattr(
        gemini_ai,
        "_record_ai_result",
        lambda **_kwargs: {"conversation": {"id": 8001}, "proposals": []},
    )
    monkeypatch.setattr(gemini_ai, "_update_ai_conversation_execution", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda _actor, calls, **_kwargs: {
            "mode": "autonomous_primary",
            "executions": [{"action": calls[0]["action"], "status": "executed"}],
            "queued": [],
            "tool_calls": calls,
        },
    )

    result = gemini_ai.admin_ai_query(
        ADMIN_ID,
        "مینی اپ را غیرفعال کن",
        scope="system",
    )

    # Exact high-confidence admin commands execute through the deterministic
    # Sentinel router before the external provider is called.
    assert provider_calls == []
    assert result["execution_requested"] is True
    assert result["tool_calls"][0]["action"] == "miniapp_runtime_toggle"
    assert result["execution"]["executions"][0]["status"] == "executed"


def test_quality_gate_runs_finalizer_in_reapable_isolated_process():
    source = Path("scripts/quality_gate.py").read_text(encoding="utf-8")
    assert "finalize_quality_proof.py" in source
    assert "subprocess.Popen" in source
    assert "close_fds=True" in source
    assert "start_new_session" in source
    assert "SENTINEL_QUALITY_FINALIZER_TIMEOUT" in source
    assert "os.execv(sys.executable, command)" not in source
