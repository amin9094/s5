from __future__ import annotations

from pathlib import Path

from bot_runtime import FEATURE_MODULES


ROOT = Path(__file__).resolve().parents[1]


def test_v826_feature_modules_and_callbacks_are_wired_end_to_end():
    assert "system_center" in FEATURE_MODULES
    assert "user_today" in FEATURE_MODULES

    routes = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    for marker in (
        "a_system_center",
        "a_google_sheets_monitor",
        "gsmon_",
        "a_job_control",
        "a_config_wizard",
        "u_today",
        "notification_digest_time",
    ):
        assert marker in routes


def test_v826_signal_actions_enter_their_real_conversations():
    runtime = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    assert 'pattern=r"^signal_calc:\\d+$"' in runtime
    assert 'pattern=r"^signal_alert:\\d+$"' in runtime


def test_v826_digest_job_is_scheduled_and_job_control_is_reapplied_after_registration():
    runtime = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    digest = runtime.index('name="user-notification-digest"')
    apply_controls = runtime.index("apply_persisted_job_controls(application.job_queue, startup_db)")
    assert digest < apply_controls
    assert 'feature_job("notify", user_notification_digest_job)' in runtime
