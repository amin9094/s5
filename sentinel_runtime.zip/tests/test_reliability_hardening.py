from __future__ import annotations

from datetime import UTC, datetime, timedelta
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace

import pytest
from PIL import Image

from modules.admin_command_os import admin_command_center_snapshot, admin_global_search
from modules.automation_event_bus import collect_scheduled_automation_events, dispatch_automation_events_inplace
from modules.automation_v2 import create_automation_rule, process_automation_event

OWNER_ID = 354678485


def _message_rule(db: dict, *, trigger: str = "user_registered", guards: dict | None = None) -> dict:
    return create_automation_rule(
        db,
        name="welcome",
        trigger=trigger,
        conditions=[],
        actions=[{"type": "send_message", "payload": {"user_id": "{{user_id}}", "text": "hello {{user_id}}"}}],
        guards=guards or {},
        actor_id=OWNER_ID,
        enabled=True,
    )


def test_dry_run_does_not_consume_live_idempotency() -> None:
    db: dict = {}
    _message_rule(db, trigger="vip_expiring")
    event = {"event_id": "same-event", "user_id": "10", "days_left": 2, "dry_run": True}
    dry = process_automation_event(db, "vip_expiring", event, actor_id=OWNER_ID)
    assert dry["matched"][0]["status"] == "completed"
    assert not db.get("automation_outbox")
    live_event = dict(event, dry_run=False)
    live = process_automation_event(db, "vip_expiring", live_event, actor_id=OWNER_ID)
    assert live["matched"][0]["status"] == "completed"
    assert len(db["automation_outbox"]) == 1


def test_failed_rule_rolls_back_and_can_retry_same_event() -> None:
    db: dict = {}
    rule = create_automation_rule(
        db,
        name="atomic",
        trigger="ticket_created",
        conditions=[],
        actions=[
            {"type": "add_tag", "payload": {"user_id": "{{user_id}}", "tag": "needs-review"}},
            {"type": "assign_admin", "payload": {"admin_id": str(OWNER_ID), "target_id": "{{ticket_id}}", "target_type": "ticket"}},
        ],
        guards={"disable_after_failures": 3},
        actor_id=OWNER_ID,
        enabled=True,
    )
    event = {"event_id": "ticket-event-1", "user_id": "20", "ticket_id": "T-1"}
    first = process_automation_event(db, "ticket_created", event, actor_id=OWNER_ID)
    assert first["matched"][0]["status"] == "failed"
    assert "20" not in db.get("crm_profiles", {})
    assert db["automation_rules_v2"][rule["id"]]["consecutive_failure_count"] == 1
    db["tickets"] = [{"id": "T-1", "user_id": "20", "status": "open"}]
    second = process_automation_event(db, "ticket_created", event, actor_id=OWNER_ID)
    assert second["matched"][0]["status"] == "completed"
    assert db["crm_profiles"]["20"]["tags"] == ["needs-review"]
    assert db["tickets"][0]["assigned_admin"] == str(OWNER_ID)
    assert db["automation_rules_v2"][rule["id"]]["consecutive_failure_count"] == 0


def test_event_bus_dispatches_real_registration_event() -> None:
    before: dict = {}
    _message_rule(before)
    after = {key: value.copy() if isinstance(value, dict) else value[:] if isinstance(value, list) else value for key, value in before.items()}
    after["users"] = {"42": {"id": "42", "user_id": "42", "created_at": datetime.now(UTC).isoformat()}}
    result = dispatch_automation_events_inplace(before, after)
    assert result["events"] == 1
    assert result["runs"] == 1
    assert len(after["automation_outbox"]) == 1


def test_scheduled_vip_event_uses_persistent_watermark() -> None:
    now = datetime(2026, 8, 3, 12, tzinfo=UTC)
    db = {"vip_users": {"7": {"user_id": "7", "expires_at": (now + timedelta(days=2)).isoformat()}}}
    first = collect_scheduled_automation_events(db, now=now)
    second = collect_scheduled_automation_events(db, now=now)
    assert first[0][0] == "vip_expiring"
    assert second == []


def test_corrupt_ai_ad_image_is_rejected(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from modules import gemini_ads

    monkeypatch.setattr(gemini_ads, "SETTINGS", SimpleNamespace(gemini_generated_ads_dir=str(tmp_path), run_mode="development"))
    monkeypatch.setattr(gemini_ads, "gemini_generate_ad_copy", lambda *_a, **_k: {
        "variants": ["تبلیغ معتبر برای مدیریت ریسک"] * 3,
        "selected": "تبلیغ معتبر برای مدیریت ریسک",
        "rationale": "test",
        "model": "copy",
    })
    monkeypatch.setattr(gemini_ads, "gemini_generate_admin_image", lambda *_a, **_k: {
        "image_bytes": b"\x89PNG\r\n\x1a\nnot-a-real-image", "mime_type": "image/png", "model": "image",
    })
    db: dict = {}
    campaign = gemini_ads.create_ai_ad_campaign(db, actor_id=OWNER_ID, name="risk-ad", product="risk", objective="sale")
    with pytest.raises(ValueError, match="ASSET_CORRUPT"):
        gemini_ads.generate_ai_ad_image(db, campaign["id"], actor_id=OWNER_ID)


def test_ai_ad_approval_revalidates_current_bytes(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from modules import gemini_ads

    monkeypatch.setattr(gemini_ads, "SETTINGS", SimpleNamespace(gemini_generated_ads_dir=str(tmp_path), run_mode="development"))
    monkeypatch.setattr(gemini_ads, "gemini_generate_ad_copy", lambda *_a, **_k: {
        "variants": ["تبلیغ معتبر Sentinel برای مدیریت ریسک"] * 3,
        "selected": "تبلیغ معتبر Sentinel برای مدیریت ریسک",
        "rationale": "test",
        "model": "copy",
    })
    buffer = BytesIO()
    Image.new("RGB", (512, 512), "black").save(buffer, "PNG")
    monkeypatch.setattr(gemini_ads, "gemini_generate_admin_image", lambda *_a, **_k: {
        "image_bytes": buffer.getvalue(), "mime_type": "image/png", "model": "image",
    })
    db: dict = {}
    campaign = gemini_ads.create_ai_ad_campaign(db, actor_id=OWNER_ID, name="risk-ad", product="risk", objective="sale")
    generated = gemini_ads.generate_ai_ad_image(db, campaign["id"], actor_id=OWNER_ID)
    Path(generated["asset"]["path"]).write_bytes(b"tampered")
    with pytest.raises(ValueError, match="AI_AD_QA_FAILED"):
        gemini_ads.approve_ai_ad(db, campaign["id"], actor_id=OWNER_ID)


def test_command_center_deduplicates_and_excludes_expired_vip() -> None:
    now = datetime.now(UTC)
    db = {
        "users": {"1": {"id": "1", "last_seen_at": now.isoformat()}},
        "vip_users": {
            "1": {"user_id": "1", "status": "active", "expires_at": (now + timedelta(days=2)).isoformat()},
            "2": {"user_id": "2", "status": "active", "expires_at": (now - timedelta(days=1)).isoformat()},
        },
        "tickets": [{"id": "T1", "status": "open", "waiting_for": "admin"}],
        "support_tickets": [{"id": "T1", "status": "open", "waiting_for": "admin"}],
        "signals": [{"id": "S1", "status": "active"}],
        "scheduled_signals": [{"id": "S1", "status": "scheduled"}],
    }
    snapshot = admin_command_center_snapshot(db, OWNER_ID)
    assert snapshot["metrics"]["active_vip"] == 1
    assert snapshot["metrics"]["waiting_tickets"] == 1
    assert snapshot["metrics"]["active_signals"] == 1
    snapshot["taxonomy"].clear()
    assert admin_command_center_snapshot(db, OWNER_ID)["taxonomy"]


def test_search_returns_cursor_metadata_and_uses_bounded_candidates() -> None:
    db = {"users": {str(i): {"id": str(i), "username": f"member-{i}"} for i in range(3000)}}
    result = admin_global_search(db, OWNER_ID, "member-2999", limit=10)
    assert result["items"][0]["id"] == "2999"
    assert result["candidate_count"] < result["indexed_documents"]
    assert result["items"][0]["deep_link"].startswith("sentinel://admin/users/")


def test_voice_command_requires_one_time_transcript_confirmation() -> None:
    root = Path(__file__).resolve().parents[1]
    source = (root / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    jobs = (root / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    assert "pending_ai_voice_command" in source
    assert "تا زمانی که «تأیید و اجرا» را نزنید" in source
    assert "context.user_data.pop(\"pending_ai_voice_command\", None)  # one-time token" in source
    assert "ai_voice_transcript_action" in jobs


def test_search_results_include_registered_action_callbacks() -> None:
    db = {
        "users": {"42": {"id": "42", "user_id": "42", "username": "search-target"}},
        "tickets": [{"id": 7, "subject": "search-target ticket", "status": "open"}],
        "marketing_campaigns": [{"id": "CMP-12", "name": "search-target campaign"}],
    }
    result = admin_global_search(db, OWNER_ID, "search-target", limit=10)
    callbacks = {item["type"]: item.get("open_callback") for item in result["items"]}
    assert callbacks["users"] == "crm_open:42"
    assert callbacks["tickets"] == "ticket_a:7"
    assert callbacks["campaigns"] == "campaign_view:CMP-12"


def test_read_only_ai_actions_do_not_use_write_transaction() -> None:
    source = (Path(__file__).resolve().parents[1] / "services" / "actions_v2" / "ai.py").read_text(encoding="utf-8")
    for function_name in (
        "admin_command_center_snapshot_action",
        "admin_global_search_action",
        "automation_v2_rule_list_action",
        "ai_ad_summary_action",
    ):
        block = source.split(f"def {function_name}", 1)[1].split("\n\n@action", 1)[0]
        assert "with_db_read(" in block
        assert "with_db(" not in block


def test_quality_gate_enforces_performance_budget() -> None:
    source = (Path(__file__).resolve().parents[1] / "scripts" / "quality_gate.py").read_text(encoding="utf-8")
    assert 'results["performance_budgets"]' in source
    assert 'scripts/performance_smoke.py' in source
