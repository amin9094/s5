from __future__ import annotations

from pathlib import Path

import pytest

from bot_runtime import platform_expansion
from modules import gemini_ai
from modules.gemini_admin_control import (
    gemini_function_declarations,
    operational_tool_catalog,
    selected_operational_tool_catalog,
)
from modules.gemini_command_router import deterministic_local_plan, infer_admin_scope
from services import ai_control_service

ADMIN_ID = 354678485
ROOT = Path(__file__).resolve().parents[1]


def _patch_storage(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        gemini_ai,
        "_record_ai_result",
        lambda **_kwargs: {"conversation": {"id": 9001}, "proposals": []},
    )
    monkeypatch.setattr(gemini_ai, "_update_ai_conversation_execution", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(gemini_ai, "_safe_gemini_status", lambda: {"configured": True})


def test_scope_is_recomputed_per_primary_admin_message() -> None:
    assert infer_admin_scope("ریسک حساب پراپ را بررسی کن") == "risk"
    assert infer_admin_scope("کد تخفیف عمومی بساز") == "crm"
    assert infer_admin_scope("قالب سیگنال BUY را عوض کن") == "signals"
    assert infer_admin_scope("تیکت های باز را بررسی کن") == "tickets"
    assert infer_admin_scope("مشتری های غیرفعال را پیدا کن") == "crm"


def test_platform_router_does_not_reuse_previous_risk_scope(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(platform_expansion, "is_primary_admin", lambda _actor: True)
    assert platform_expansion._infer_primary_admin_ai_scope(
        "کد تخفیف عمومی بساز", "risk", ADMIN_ID
    ) == "crm"


def test_every_registered_ai_tool_is_reachable_by_exact_action_name() -> None:
    catalog = operational_tool_catalog()
    assert len(catalog) >= 80
    for row in catalog:
        action = row["action"]
        selected = selected_operational_tool_catalog(action, scope="management", limit=18)
        assert action in {item["action"] for item in selected}, action


def test_native_function_schemas_do_not_use_union_types() -> None:
    selected = selected_operational_tool_catalog(
        "کد تخفیف ۱۵ درصدی با کد WELCOME15 بساز", scope="crm"
    )
    declarations = gemini_function_declarations(selected)
    assert declarations

    def inspect(value):
        if isinstance(value, dict):
            assert not isinstance(value.get("type"), list)
            assert "additionalProperties" not in value
            for item in value.values():
                inspect(item)
        elif isinstance(value, list):
            for item in value:
                inspect(item)

    inspect(declarations)


def test_deterministic_discount_and_template_plans_are_exact() -> None:
    discount = deterministic_local_plan(
        "کد تخفیف ۱۵ درصدی عمومی بساز مدت هفت روزه با کد welcome15"
    )
    assert discount.calls == [{
        "action": "public_discount_create",
        "payload": {
            "code": "WELCOME15", "percent": 15, "days": 7,
            "max_uses": 0, "one_per_user": True,
        },
        "reason": "فرمان صریح ادمین برای ساخت کد تخفیف عمومی",
    }]
    template = deterministic_local_plan("قالب سیگنال BUY را با آخرین عکس عوض کن")
    assert template.calls[0]["action"] == "ai_signal_template_apply_asset"
    assert template.calls[0]["payload"] == {"side": "BUY", "asset_id": "latest", "autodetect": True}


def test_native_function_call_response_is_sanitized() -> None:
    response = {
        "text": "",
        "function_calls": [{
            "name": "public_discount_create",
            "args": {"code": "WELCOME15", "percent": 15, "days": 7, "max_uses": 0, "one_per_user": True},
            "id": "call-1",
        }],
    }
    calls, rejected, clarification = gemini_ai._native_calls_from_response(
        response,
        command="کد تخفیف WELCOME15 با ۱۵ درصد و اعتبار ۷ روز بساز",
    )
    assert rejected == []
    assert clarification is None
    assert calls[0]["action"] == "public_discount_create"


def test_provider_failure_still_executes_high_confidence_discount(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_storage(monkeypatch)
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("offline")))
    monkeypatch.setattr(gemini_ai, "admin_ai_context", lambda *_a, **_k: {"scope": "crm"})
    captured: list[dict] = []

    def execute(_actor, calls, **_kwargs):
        captured.extend(calls)
        return {
            "mode": "primary_autonomous",
            "executions": [{"action": calls[0]["action"], "status": "executed", "result": {"code": "WELCOME15"}}],
            "queued": [], "tool_calls": calls,
        }

    monkeypatch.setattr(ai_control_service, "execute_or_queue_ai_tool_calls", execute)
    result = gemini_ai.admin_ai_query(
        ADMIN_ID,
        "کد تخفیف 15 درصدی عمومی بساز مدت هفت روزه با کد welcome15",
        scope="risk",  # stale scope must not matter
    )
    assert result["selected_scope"] == "crm"
    assert captured[0]["action"] == "public_discount_create"
    assert "WELCOME15" in result["answer"]
    assert result["execution"]["executions"][0]["status"] == "executed"


def test_provider_failure_still_executes_template_asset_change(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_storage(monkeypatch)
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("offline")))
    monkeypatch.setattr(gemini_ai, "admin_ai_context", lambda *_a, **_k: {"scope": "signals"})
    captured: list[dict] = []
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda _actor, calls, **_kwargs: captured.extend(calls) or {
            "mode": "primary_autonomous",
            "executions": [{"action": calls[0]["action"], "status": "executed", "result": {"status": "applied"}}],
            "queued": [], "tool_calls": calls,
        },
    )
    result = gemini_ai.admin_ai_query(
        ADMIN_ID, "قالب سیگنال BUY را با آخرین عکس عوض کن", scope="risk"
    )
    assert result["selected_scope"] == "signals"
    assert captured[0]["action"] == "ai_signal_template_apply_asset"
    assert captured[0]["payload"]["asset_id"] == "latest"


def test_customer_analysis_fallback_is_crm_specific_not_risk_report(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_storage(monkeypatch)
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("offline")))
    monkeypatch.setattr(
        gemini_ai,
        "admin_ai_context",
        lambda *_a, **_k: {
            "scope": "crm",
            "users": {"total": 2},
            "behavior_segments": {"inactive": 1},
            "journey_intelligence": {"total_users": 2, "dropoffs": {"inactive": 1}, "next_best_actions": {}},
            "recent_users": [{"user_id": "user_A1", "username": "username_B2", "last_seen_at": "2026-07-01"}],
        },
    )
    monkeypatch.setattr(
        ai_control_service,
        "execute_or_queue_ai_tool_calls",
        lambda *_a, **_k: {"mode": "analysis_only", "executions": [], "queued": [], "tool_calls": []},
    )
    result = gemini_ai.admin_ai_query(
        ADMIN_ID, "مشتری های غیرفعال را پیدا کن", scope="risk"
    )
    assert result["selected_scope"] == "crm"
    assert "user_A1" in result["answer"]
    assert "risk_tools" not in result["answer"]
    assert "introduce_risk_review" not in result["answer"]


def test_source_uses_native_function_declarations_not_generic_payload_schema() -> None:
    source = (ROOT / "modules" / "gemini_ai.py").read_text(encoding="utf-8")
    assert 'body["tools"] = [{"functionDeclarations": function_declarations}]' in source
    assert 'function_mode="ANY"' in source
    assert "selected_operational_tool_catalog" in source


def test_every_registered_action_has_persian_or_english_routing_alias() -> None:
    from modules.gemini_command_router import _ACTION_HINTS

    catalog = operational_tool_catalog()
    assert len(catalog) >= 85
    for row in catalog:
        action = row["action"]
        hints = _ACTION_HINTS.get(action)
        assert hints, action
        command = hints[0]
        scope = infer_admin_scope(command)
        selected = selected_operational_tool_catalog(command, scope=scope, limit=18)
        assert action in {item["action"] for item in selected}, (action, command, scope)


def test_all_function_declarations_are_json_serializable_and_bounded() -> None:
    import json

    declarations = gemini_function_declarations(operational_tool_catalog())
    assert len(declarations) >= 85
    encoded = json.dumps(declarations, ensure_ascii=False)
    assert len(encoded) < 150_000
    assert all(row.get("name") and isinstance(row.get("parameters"), dict) for row in declarations)


def test_nested_object_arguments_accept_json_string_from_gemini() -> None:
    from modules.ai_action_firewall import validate_payload

    result = validate_payload(
        "content_render",
        {"template_key": "news", "values": '{"title":"خبر مهم","priority":2}'},
        ["template_key", "values"],
    )
    assert result["values"] == {"title": "خبر مهم", "priority": 2}


def test_execution_language_covers_all_common_persian_mutation_verbs() -> None:
    for command in (
        "مسابقه جدید شروع کن",
        "مسابقه را پایان بده",
        "درس را آرشیو کن",
        "اتوماسیون را دوباره اجرا کن",
        "پیام مشتری را طبقه‌بندی کن",
        "کارت محتوا را رندر کن",
        "ارتباط ربات و مینی اپ را همگام کن",
        "قالب سیگنال را عوض کن",
    ):
        assert gemini_ai._admin_command_requests_execution(command), command


def test_execution_planner_prompt_has_no_legacy_json_tool_call_conflict() -> None:
    prompt = gemini_ai._system_prompt(
        role="administrative execution planner", scope="crm", language="fa"
    )
    assert "native functions" in prompt
    assert "Never write JSON tool_calls" in prompt
    assert "return JSON with answer" not in prompt


def test_user_behavior_local_fallback_is_specific() -> None:
    result = gemini_ai._admin_local_fallback(
        "user_behavior",
        {
            "users_total": 12,
            "aggregate_activity": {"events_90d": 84, "active_days_90d": 19},
            "behavior_segments": {"inactive": 4},
            "journey_intelligence": {"dropoffs": {"miniapp_opened": 3}},
        },
        "fa",
        question="رفتار کاربران را بررسی کن",
    )
    assert "کاربران بررسی‌شده: 12" in result["answer"]
    assert "بخش‌بندی رفتاری" in result["answer"]
    assert "risk_tools" not in result["answer"]
