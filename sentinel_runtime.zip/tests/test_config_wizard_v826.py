from modules.config_wizard import config_wizard_snapshot


def test_config_wizard_never_returns_secret_values():
    env = {
        'BOT_TOKEN': '123:SUPER-SECRET',
        'ADMIN_IDS': '123',
        'DATABASE_URL': 'postgresql://secret',
        'SENSITIVE_DATA_KEY': 'secret-key',
        'WEBAPP_SESSION_SECRET': 'session-secret',
        'RUN_MODE': 'polling',
        'WEBAPP_API_ENABLED': 'false',
    }
    result = config_wizard_snapshot(env)
    rendered = repr(result)
    assert 'SUPER-SECRET' not in rendered
    assert 'postgresql://secret' not in rendered
    assert 'session-secret' not in rendered


def test_google_requirements_are_conditional():
    base = {
        'BOT_TOKEN': 'token', 'ADMIN_IDS': '1', 'DATABASE_URL': 'db',
        'SENSITIVE_DATA_KEY': 'key', 'WEBAPP_API_ENABLED': 'false', 'RUN_MODE': 'polling',
    }
    disabled = config_wizard_snapshot(base)
    assert not any('Google Sheets:' in item for item in disabled['missing_required'])
    enabled = config_wizard_snapshot({**base, 'GOOGLE_SHEETS_BACKUP_ENABLED': 'true'})
    assert any('GOOGLE_SHEETS_SPREADSHEET_ID' in item for item in enabled['missing_required'])
    ready = config_wizard_snapshot({**base, 'GOOGLE_SHEETS_BACKUP_ENABLED': 'true', 'GOOGLE_SHEETS_SPREADSHEET_ID': 'sheet', 'GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_B64': 'abc'})
    assert not any('Google Sheets:' in item for item in ready['missing_required'])


def test_webhook_secret_and_url_required_only_in_webhook_mode():
    base = {'BOT_TOKEN': 't', 'ADMIN_IDS': '1', 'DATABASE_URL': 'd', 'SENSITIVE_DATA_KEY': 's', 'WEBAPP_API_ENABLED': 'false'}
    polling = config_wizard_snapshot({**base, 'RUN_MODE': 'polling'})
    assert not any('WEBHOOK' in item for item in polling['missing_required'])
    webhook = config_wizard_snapshot({**base, 'RUN_MODE': 'webhook'})
    assert any('WEBHOOK_SECRET_TOKEN' in item for item in webhook['missing_required'])
    assert any('WEBHOOK_URL' in item for item in webhook['missing_required'])
