"""Callback acknowledgements are cosmetic; expired acknowledgements must not abort navigation."""
from __future__ import annotations
import logging
from telegram.error import BadRequest, NetworkError, RetryAfter
from telegram.ext import ExtBot
from telegram.request import HTTPXRequest

logger = logging.getLogger(__name__)


class ResilientBot(ExtBot):
    async def answer_callback_query(self, *args, **kwargs):
        for key in ("read_timeout", "write_timeout", "connect_timeout", "pool_timeout"):
            kwargs.setdefault(key, 2.0)
        try:
            return await super().answer_callback_query(*args, **kwargs)
        except BadRequest as exc:
            if any(value in str(exc).lower() for value in ("query is too old", "query id is invalid", "query_id_invalid")):
                return False
            raise
        except (NetworkError, RetryAfter) as exc:
            logger.info("Callback acknowledgement unavailable: %s", type(exc).__name__)
            return False


def make_bot(token: str) -> ResilientBot:
    return ResilientBot(token, request=HTTPXRequest(connection_pool_size=32, read_timeout=15,
                        write_timeout=15, connect_timeout=5, pool_timeout=3),
                        get_updates_request=HTTPXRequest(connection_pool_size=1, read_timeout=30,
                        write_timeout=10, connect_timeout=5, pool_timeout=3))
