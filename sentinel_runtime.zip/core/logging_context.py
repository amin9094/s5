from __future__ import annotations

import contextvars
import hashlib
import json
import logging
import re
from datetime import UTC, datetime
from typing import Any

_CORRELATION_ID: contextvars.ContextVar[str] = contextvars.ContextVar("sentinel_correlation_id", default="")
_SECRET_PATTERNS = (
    re.compile(r"(?i)(bot[_-]?token|api[_-]?key|secret|password|authorization)\s*[=:]\s*([^\s,;]+)"),
    re.compile(r"\b\d{12,19}\b"),
)


def set_correlation_id(value: str) -> contextvars.Token[str]:
    clean = str(value or "").strip()[:128]
    return _CORRELATION_ID.set(clean)


def reset_correlation_id(token: contextvars.Token[str]) -> None:
    _CORRELATION_ID.reset(token)


def correlation_id() -> str:
    return _CORRELATION_ID.get()


def redact(value: Any) -> str:
    text = str(value)
    text = re.sub(r"gift_[A-Za-z0-9_-]{20,64}", "gift_[REDACTED]", text)
    text = re.sub(r"(?i)(gift[_-]?(?:token|code)|coupon[_-]?(?:code|secret))([\"\']?\s*[:=]\s*[\"\']?)[A-Za-z0-9_-]+", r"\1\2[REDACTED]", text)
    for pattern in _SECRET_PATTERNS:
        if pattern.pattern.startswith("\\b"):
            text = pattern.sub(lambda match: f"card:{hashlib.sha256(match.group(0).encode()).hexdigest()[:10]}", text)
        else:
            text = pattern.sub(lambda match: f"{match.group(1)}=[REDACTED]", text)
    return text


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            record.msg = "[log redaction failed]"
            record.args = ()
        record.correlation_id = correlation_id() or "-"
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": redact(record.getMessage()),
            "correlation_id": getattr(record, "correlation_id", "-") or "-",
        }
        if record.exc_info:
            payload["exception"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
