from __future__ import annotations

"""Small dependency-free Persian/Arabic display shaper.

Railway images intentionally keep the runtime dependency set compact.  When a
PDF backend does not provide HarfBuzz/BiDi support, this module converts common
Arabic and Persian letters to Unicode presentation forms and computes a stable
visual order for ReportLab.  The source database always keeps the original
Unicode text; this helper is only used at the final PDF drawing boundary.
"""

import unicodedata
from typing import Any

# isolated, final, initial, medial; None means that positional form is invalid.
_FORMS: dict[str, tuple[str, str | None, str | None, str | None]] = {
    "ء": ("\uFE80", None, None, None),
    "آ": ("\uFE81", "\uFE82", None, None),
    "أ": ("\uFE83", "\uFE84", None, None),
    "ؤ": ("\uFE85", "\uFE86", None, None),
    "إ": ("\uFE87", "\uFE88", None, None),
    "ئ": ("\uFE89", "\uFE8A", "\uFE8B", "\uFE8C"),
    "ا": ("\uFE8D", "\uFE8E", None, None),
    "ب": ("\uFE8F", "\uFE90", "\uFE91", "\uFE92"),
    "ة": ("\uFE93", "\uFE94", None, None),
    "ت": ("\uFE95", "\uFE96", "\uFE97", "\uFE98"),
    "ث": ("\uFE99", "\uFE9A", "\uFE9B", "\uFE9C"),
    "ج": ("\uFE9D", "\uFE9E", "\uFE9F", "\uFEA0"),
    "ح": ("\uFEA1", "\uFEA2", "\uFEA3", "\uFEA4"),
    "خ": ("\uFEA5", "\uFEA6", "\uFEA7", "\uFEA8"),
    "د": ("\uFEA9", "\uFEAA", None, None),
    "ذ": ("\uFEAB", "\uFEAC", None, None),
    "ر": ("\uFEAD", "\uFEAE", None, None),
    "ز": ("\uFEAF", "\uFEB0", None, None),
    "س": ("\uFEB1", "\uFEB2", "\uFEB3", "\uFEB4"),
    "ش": ("\uFEB5", "\uFEB6", "\uFEB7", "\uFEB8"),
    "ص": ("\uFEB9", "\uFEBA", "\uFEBB", "\uFEBC"),
    "ض": ("\uFEBD", "\uFEBE", "\uFEBF", "\uFEC0"),
    "ط": ("\uFEC1", "\uFEC2", "\uFEC3", "\uFEC4"),
    "ظ": ("\uFEC5", "\uFEC6", "\uFEC7", "\uFEC8"),
    "ع": ("\uFEC9", "\uFECA", "\uFECB", "\uFECC"),
    "غ": ("\uFECD", "\uFECE", "\uFECF", "\uFED0"),
    "ف": ("\uFED1", "\uFED2", "\uFED3", "\uFED4"),
    "ق": ("\uFED5", "\uFED6", "\uFED7", "\uFED8"),
    "ك": ("\uFED9", "\uFEDA", "\uFEDB", "\uFEDC"),
    "ک": ("\uFB8E", "\uFB8F", "\uFB90", "\uFB91"),
    "گ": ("\uFB92", "\uFB93", "\uFB94", "\uFB95"),
    "ل": ("\uFEDD", "\uFEDE", "\uFEDF", "\uFEE0"),
    "م": ("\uFEE1", "\uFEE2", "\uFEE3", "\uFEE4"),
    "ن": ("\uFEE5", "\uFEE6", "\uFEE7", "\uFEE8"),
    "ه": ("\uFEEB", "\uFEEC", "\uFEED", "\uFEEE"),
    "و": ("\uFEE9", "\uFEEA", None, None),
    "ى": ("\uFEEF", "\uFEF0", None, None),
    "ي": ("\uFEF1", "\uFEF2", "\uFEF3", "\uFEF4"),
    "ی": ("\uFBFC", "\uFBFD", "\uFBFE", "\uFBFF"),
    "پ": ("\uFB56", "\uFB57", "\uFB58", "\uFB59"),
    "چ": ("\uFB7A", "\uFB7B", "\uFB7C", "\uFB7D"),
    "ژ": ("\uFB8A", "\uFB8B", None, None),
    "ڤ": ("\uFB6A", "\uFB6B", "\uFB6C", "\uFB6D"),
}

_DIACRITICS = {chr(code) for code in range(0x064B, 0x0660)} | {"\u0670"}


def _can_join_previous(char: str) -> bool:
    forms = _FORMS.get(char)
    return bool(forms and forms[1])


def _can_join_next(char: str) -> bool:
    forms = _FORMS.get(char)
    return bool(forms and forms[2])


def _nearest_letter(chars: list[str], start: int, step: int) -> str | None:
    index = start + step
    while 0 <= index < len(chars):
        char = chars[index]
        if char in _DIACRITICS:
            index += step
            continue
        return char
    return None


def shape_arabic(text: str) -> str:
    chars = list(str(text or ""))
    shaped: list[str] = []
    for index, char in enumerate(chars):
        forms = _FORMS.get(char)
        if not forms:
            shaped.append(char)
            continue
        previous = _nearest_letter(chars, index, -1)
        following = _nearest_letter(chars, index, 1)
        joins_previous = bool(previous and _can_join_next(previous) and _can_join_previous(char))
        joins_next = bool(following and _can_join_next(char) and _can_join_previous(following))
        if joins_previous and joins_next and forms[3]:
            shaped.append(forms[3])
        elif joins_previous and forms[1]:
            shaped.append(forms[1])
        elif joins_next and forms[2]:
            shaped.append(forms[2])
        else:
            shaped.append(forms[0])
    return "".join(shaped)


def _direction(char: str) -> str:
    bidi = unicodedata.bidirectional(char)
    if bidi in {"R", "AL", "AN"} or "ARABIC" in unicodedata.name(char, ""):
        return "rtl"
    if bidi in {"L", "EN"} or char.isdigit():
        return "ltr"
    return "neutral"


def visual_rtl(value: Any) -> str:
    """Return display-order text for a renderer without native BiDi support."""
    text = shape_arabic(str(value or ""))
    if not any(_direction(char) == "rtl" for char in text):
        return text
    runs: list[tuple[str, str]] = []
    current_dir = "neutral"
    current: list[str] = []
    for char in text:
        direction = _direction(char)
        if direction == "neutral":
            current.append(char)
            continue
        if current and current_dir not in {"neutral", direction}:
            runs.append((current_dir, "".join(current)))
            current = []
        if current_dir == "neutral":
            current_dir = direction
        elif current_dir != direction and current:
            runs.append((current_dir, "".join(current)))
            current = []
            current_dir = direction
        else:
            current_dir = direction
        current.append(char)
    if current:
        runs.append((current_dir, "".join(current)))
    visual: list[str] = []
    for direction, run in reversed(runs):
        visual.append(run[::-1] if direction == "rtl" else run)
    return "".join(visual)
