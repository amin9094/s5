from __future__ import annotations

import threading
from typing import Any

_LOCK = threading.RLock()
_FAILURES: dict[str, str] = {}


def _key(update_id: Any) -> str:
    try:
        return str(int(update_id))
    except (TypeError, ValueError):
        return str(update_id or "unknown")


def clear_update_failure(update_id: Any) -> None:
    with _LOCK:
        _FAILURES.pop(_key(update_id), None)


def record_update_failure(update_id: Any, error_code: str) -> None:
    with _LOCK:
        _FAILURES[_key(update_id)] = str(error_code or "PROCESSING_FAILED")[:160]


def consume_update_failure(update_id: Any) -> str | None:
    with _LOCK:
        return _FAILURES.pop(_key(update_id), None)
