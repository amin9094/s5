from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any, Iterable

from core.db import read_db_sections
from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.accounts import AccountRepository
from repositories.v2.commerce import CommerceRepository
from repositories.v2.journal import JournalRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.signals import SignalRepository
from repositories.v2.common import json_dump, utc_iso

logger = logging.getLogger(__name__)
MIGRATION_KEY = "legacy_import_v8_1"
MIGRATION_RUN_KEY = f"{MIGRATION_KEY}:run"

_SECTIONS = (
    "signals", "trading_accounts", "user_positions", "position_pnl_events", "vip_orders", "tickets",
    "trade_journal", "user_notification_preferences", "economic_calendar_preferences", "user_watchlists",
    "miniapp_onboarding", "personal_risk_profiles", "rules_acceptances", "user_profiles",
)


class MigrationError(RuntimeError):
    """Raised when the legacy import cannot be completed without losing data."""


def _write_run_state(engine: DatabaseEngine, state: str, **details: Any) -> None:
    payload = {"state": state, "at": utc_iso(), **details}
    with engine.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_meta(key,value,updated_at) VALUES(?,?,?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
            (MIGRATION_RUN_KEY, json_dump(payload), utc_iso()),
        )


def _sqlite_pre_migration_backup(engine: DatabaseEngine) -> str:
    if engine.dialect.name != "sqlite" or not engine.sqlite_path.is_file():
        return ""
    from config import SETTINGS
    from core.backup_service import create_operational_backup
    target = create_operational_backup(
        engine.sqlite_path,
        SETTINGS.backup_dir,
        encryption_key=SETTINGS.backup_encryption_key,
        key_version=SETTINGS.backup_key_version,
    )
    return str(target)


def _clean_id(value: Any) -> str:
    clean = str(value or "").strip()
    return "" if clean.lower() in {"", "none", "null", "undefined"} else clean


def _deterministic_id(prefix: str, *parts: Any) -> str:
    payload = json.dumps(parts, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return f"{prefix}_{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:24]}"


def _assign_id(prefix: str, raw: Any, *, identity: tuple[Any, ...], used: set[str]) -> str:
    candidate = _clean_id(raw) or _deterministic_id(prefix, *identity)
    if candidate in used:
        # Duplicate explicit IDs must never overwrite one another. Derive a
        # stable, source-bound replacement rather than silently merging rows.
        candidate = _deterministic_id(prefix, "duplicate", candidate, *identity)
    if candidate in used:
        raise MigrationError(f"DUPLICATE_MIGRATION_ID:{prefix}:{candidate}")
    used.add(candidate)
    return candidate


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _prepare_plan(source: dict[str, Any]) -> dict[str, Any]:
    """Validate the entire source and assign stable IDs before the first write."""
    plan: dict[str, Any] = {
        "signals": [], "accounts": [], "positions": [], "pnl_events": [],
        "orders": [], "tickets": [], "journal": [], "preferences": [],
    }
    used: dict[str, set[str]] = {name: set() for name in ("sig", "acct", "pos", "pnl", "ord", "tkt", "msg", "jnl")}
    account_map: dict[tuple[str, str], str] = {}
    default_account: dict[str, str] = {}

    for index, row in enumerate(_list(source.get("signals"))):
        if not isinstance(row, dict):
            raise MigrationError(f"INVALID_SIGNAL_ROW:{index}")
        item = dict(row)
        item["id"] = _assign_id("sigmig", row.get("id"), identity=(index, row), used=used["sig"])
        plan["signals"].append(item)

    raw_accounts = source.get("trading_accounts", {})
    if raw_accounts not in ({}, None) and not isinstance(raw_accounts, dict):
        raise MigrationError("INVALID_TRADING_ACCOUNTS_SECTION")
    for uid, rows in (raw_accounts or {}).items():
        if not isinstance(rows, list):
            raise MigrationError(f"INVALID_ACCOUNT_LIST:{uid}")
        seen_source_ids: set[str] = set()
        for index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise MigrationError(f"INVALID_ACCOUNT_ROW:{uid}:{index}")
            old_id = _clean_id(row.get("id"))
            if old_id and old_id in seen_source_ids:
                raise MigrationError(f"DUPLICATE_LEGACY_ACCOUNT_ID:{uid}:{old_id}")
            if old_id:
                seen_source_ids.add(old_id)
            assigned = _assign_id("acctmig", old_id, identity=(str(uid), index, row), used=used["acct"])
            item = dict(row)
            item["id"] = assigned
            plan["accounts"].append((str(uid), item, old_id))
            if old_id:
                account_map[(str(uid), old_id)] = assigned
            if bool(row.get("is_default")) or str(uid) not in default_account:
                default_account[str(uid)] = assigned

    raw_positions = source.get("user_positions", {})
    if raw_positions not in ({}, None) and not isinstance(raw_positions, dict):
        raise MigrationError("INVALID_USER_POSITIONS_SECTION")
    position_map: dict[tuple[str, str], str] = {}
    for uid, rows in (raw_positions or {}).items():
        iterator = list(rows.values()) if isinstance(rows, dict) else rows if isinstance(rows, list) else None
        if iterator is None:
            raise MigrationError(f"INVALID_POSITION_LIST:{uid}")
        seen_source_ids: set[str] = set()
        for index, row in enumerate(iterator):
            if not isinstance(row, dict):
                raise MigrationError(f"INVALID_POSITION_ROW:{uid}:{index}")
            old_id = _clean_id(row.get("id"))
            if old_id and old_id in seen_source_ids:
                raise MigrationError(f"DUPLICATE_LEGACY_POSITION_ID:{uid}:{old_id}")
            if old_id:
                seen_source_ids.add(old_id)
            assigned = _assign_id("posmig", old_id, identity=(str(uid), index, row), used=used["pos"])
            old_account = _clean_id(row.get("account_id"))
            account_id = account_map.get((str(uid), old_account)) or default_account.get(str(uid)) or old_account
            item = dict(row)
            item.update({"id": assigned, "user_id": str(uid), "account_id": account_id})
            plan["positions"].append(item)
            if old_id:
                position_map[(str(uid), old_id)] = assigned

    raw_events = source.get("position_pnl_events", {})
    if isinstance(raw_events, dict):
        event_groups: Iterable[tuple[Any, Any]] = raw_events.items()
    elif isinstance(raw_events, list):
        event_groups = ((str(row.get("user_id") or "0"), [row]) for row in raw_events if isinstance(row, dict))
    elif raw_events in (None, {}):
        event_groups = ()
    else:
        raise MigrationError("INVALID_POSITION_PNL_EVENTS_SECTION")
    for uid, rows in event_groups:
        iterator = rows.values() if isinstance(rows, dict) else rows if isinstance(rows, list) else []
        for index, row in enumerate(iterator):
            if not isinstance(row, dict):
                raise MigrationError(f"INVALID_PNL_EVENT_ROW:{uid}:{index}")
            old_position = _clean_id(row.get("position_id"))
            position_id = position_map.get((str(uid), old_position), old_position)
            item = dict(row)
            item["id"] = _assign_id("pnlmig", row.get("id"), identity=(str(uid), index, row), used=used["pnl"])
            item["user_id"] = str(uid)
            item["position_id"] = position_id
            plan["pnl_events"].append(item)

    for index, row in enumerate(_list(source.get("vip_orders"))):
        if not isinstance(row, dict):
            raise MigrationError(f"INVALID_ORDER_ROW:{index}")
        item = dict(row)
        item["id"] = _assign_id("ordmig", row.get("id"), identity=(index, row), used=used["ord"])
        plan["orders"].append(item)

    for index, row in enumerate(_list(source.get("tickets"))):
        if not isinstance(row, dict):
            raise MigrationError(f"INVALID_TICKET_ROW:{index}")
        item = dict(row)
        item["id"] = _assign_id("tktmig", row.get("id"), identity=(index, row), used=used["tkt"])
        messages: list[dict[str, Any]] = []
        for message_index, message in enumerate(_list(row.get("messages"))):
            if not isinstance(message, dict):
                raise MigrationError(f"INVALID_TICKET_MESSAGE:{index}:{message_index}")
            msg = dict(message)
            msg["id"] = _assign_id("msgmig", message.get("id"), identity=(index, message_index, message), used=used["msg"])
            messages.append(msg)
        item["messages"] = messages
        plan["tickets"].append(item)

    raw_journal = source.get("trade_journal", {})
    if raw_journal not in ({}, None) and not isinstance(raw_journal, dict):
        raise MigrationError("INVALID_TRADE_JOURNAL_SECTION")
    for uid, rows in (raw_journal or {}).items():
        if not isinstance(rows, list):
            raise MigrationError(f"INVALID_JOURNAL_LIST:{uid}")
        for index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise MigrationError(f"INVALID_JOURNAL_ROW:{uid}:{index}")
            item = dict(row)
            item["id"] = _assign_id("jnlmig", row.get("id"), identity=(str(uid), index, row), used=used["jnl"])
            old_account = _clean_id(row.get("account_id"))
            old_position = _clean_id(row.get("position_id"))
            if old_account:
                item["account_id"] = account_map.get((str(uid), old_account), old_account)
            if old_position:
                item["position_id"] = position_map.get((str(uid), old_position), old_position)
            plan["journal"].append((str(uid), item))

    for section in (
        "user_notification_preferences", "economic_calendar_preferences", "user_watchlists",
        "miniapp_onboarding", "personal_risk_profiles", "rules_acceptances", "user_profiles",
    ):
        values = source.get(section, {})
        if values not in ({}, None) and not isinstance(values, dict):
            raise MigrationError(f"INVALID_PREFERENCE_SECTION:{section}")
        for uid, payload in (values or {}).items():
            plan["preferences"].append((str(uid), section, payload))
    return plan


def _count_ids(engine: DatabaseEngine, table: str, ids: list[str]) -> int:
    allowed = {
        "v8_signals", "v8_trading_accounts", "v8_positions", "v8_position_pnl_events",
        "v8_vip_orders", "v8_tickets", "v8_journal_entries",
    }
    if table not in allowed:
        raise ValueError("UNSAFE_RECONCILIATION_TABLE")
    if not ids:
        return 0
    total = 0
    with engine.transaction(read_only=True) as cursor:
        for offset in range(0, len(ids), 400):
            chunk = ids[offset:offset + 400]
            placeholders = ",".join("?" for _ in chunk)
            row = cursor.execute(
                f"SELECT COUNT(*) AS total FROM {table} WHERE id IN ({placeholders})",  # nosec B608
                chunk,
            ).fetchone() or {}
            total += int(row.get("total") or 0)
    return total


def _reconcile(engine: DatabaseEngine, plan: dict[str, Any]) -> dict[str, int]:
    expected = {
        "signals": len(plan["signals"]),
        "accounts": len(plan["accounts"]),
        "positions": len(plan["positions"]),
        "pnl_events": len(plan["pnl_events"]),
        "orders": len(plan["orders"]),
        "tickets": len(plan["tickets"]),
        "journal": len(plan["journal"]),
    }
    actual = {
        "signals": _count_ids(engine, "v8_signals", [row["id"] for row in plan["signals"]]),
        "accounts": _count_ids(engine, "v8_trading_accounts", [row[1]["id"] for row in plan["accounts"]]),
        "positions": _count_ids(engine, "v8_positions", [row["id"] for row in plan["positions"]]),
        "pnl_events": _count_ids(engine, "v8_position_pnl_events", [row["id"] for row in plan["pnl_events"]]),
        "orders": _count_ids(engine, "v8_vip_orders", [row["id"] for row in plan["orders"]]),
        "tickets": _count_ids(engine, "v8_tickets", [row["id"] for row in plan["tickets"]]),
        "journal": _count_ids(engine, "v8_journal_entries", [row[1]["id"] for row in plan["journal"]]),
    }
    mismatches = {name: {"expected": expected[name], "actual": actual[name]} for name in expected if expected[name] != actual[name]}
    if mismatches:
        raise MigrationError(f"MIGRATION_RECONCILIATION_FAILED:{json.dumps(mismatches, sort_keys=True)}")
    return actual


def legacy_source_summary() -> dict[str, int]:
    """Return record counts without mutating normalized storage."""
    source = read_db_sections(_SECTIONS)
    summary: dict[str, int] = {}
    for section in _SECTIONS:
        value = source.get(section)
        if isinstance(value, list):
            summary[section] = len(value)
        elif isinstance(value, dict):
            total = 0
            for nested in value.values():
                if isinstance(nested, (list, dict)):
                    total += len(nested)
                elif nested not in (None, "", [], {}):
                    total += 1
            summary[section] = total
        else:
            summary[section] = 0
    return summary


def _migrate_legacy_state_unlocked(engine: DatabaseEngine | None = None, *, force: bool = False) -> dict[str, Any]:
    db_engine = engine or normalized_engine()
    with db_engine.transaction(read_only=True) as cursor:
        marker = cursor.execute("SELECT value FROM v8_meta WHERE key=?", (MIGRATION_KEY,)).fetchone()
    if marker and not force:
        return {"status": "already_applied", "details": marker.get("value")}

    source = read_db_sections(_SECTIONS)
    plan = _prepare_plan(source)
    counters = {name: 0 for name in ("signals", "accounts", "positions", "pnl_events", "orders", "tickets", "journal", "preferences")}
    signal_repo = SignalRepository(db_engine)
    account_repo = AccountRepository(db_engine)
    position_repo = PositionRepository(db_engine)
    order_repo = CommerceRepository(db_engine)
    journal_repo = JournalRepository(db_engine)

    for signal in plan["signals"]:
        signal_repo.upsert(signal)
        counters["signals"] += 1

    for uid, row, _old_id in plan["accounts"]:
        account_repo.upsert(uid, row, account_id=row["id"])
        counters["accounts"] += 1

    for row in plan["positions"]:
        uid = str(row["user_id"])
        account_id = _clean_id(row.get("account_id"))
        if not account_id or not account_repo.get(uid, account_id):
            fallback = account_repo.upsert(uid, {"name": "Migrated Account", "is_default": True}, account_id=account_id or None)
            account_id = str(fallback["id"])
        payload = {
            **row,
            "account_id": account_id,
            "symbol": row.get("symbol") or "UNKNOWN",
            "side": row.get("side") or "BUY",
            "status": row.get("status") or "open",
            "actual_entry": row.get("actual_entry") or row.get("entry_price") or 1,
            "actual_stop": row.get("actual_stop") or row.get("stop") or 0.99,
            "actual_volume": row.get("actual_volume") or row.get("volume") or 0.01,
            "remaining_volume": row.get("remaining_volume", row.get("actual_volume") or row.get("volume") or 0.01),
            "risk_percent": row.get("actual_risk_percent") or row.get("risk_percent") or 0,
            "risk_money": row.get("risk_money") or row.get("actual_risk_money") or 0,
        }
        existing = position_repo.get(uid, row["id"])
        if not existing:
            position_repo.open(payload)
        counters["positions"] += 1

    with db_engine.transaction() as cursor:
        for event in plan["pnl_events"]:
            if not _clean_id(event.get("position_id")):
                raise MigrationError(f"PNL_EVENT_POSITION_REQUIRED:{event['id']}")
            cursor.execute(
                """INSERT INTO v8_position_pnl_events(id,user_id,account_id,position_id,event_type,realized_pnl,
                   commission,swap,fees,closed_volume,occurred_at,account_local_date,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                (
                    event["id"], str(event.get("user_id") or "0"), str(event.get("account_id") or ""),
                    str(event["position_id"]), str(event.get("event_type") or "migration"),
                    float(event.get("realized_pnl") or 0), float(event.get("commission") or 0),
                    float(event.get("swap") or 0), float(event.get("fees") or 0),
                    float(event.get("closed_volume") or 0), str(event.get("occurred_at") or utc_iso()),
                    str(event.get("account_local_date") or str(event.get("occurred_at") or utc_iso())[:10]), json_dump(event),
                ),
            )
            counters["pnl_events"] += 1

    for order in plan["orders"]:
        if not order_repo.get(order["id"]):
            order_repo.create_order(order.get("user_id") or order.get("telegram_id") or "0", order)
        counters["orders"] += 1

    with db_engine.transaction() as cursor:
        for ticket in plan["tickets"]:
            uid = str(ticket.get("user_id") or "0")
            now = str(ticket.get("created_at") or utc_iso())
            status = str(ticket.get("status") or "open")
            cursor.execute(
                """INSERT INTO v8_tickets(id,user_id,subject,category,priority,status,created_at,updated_at,closed_at,satisfaction,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                   user_id=excluded.user_id,subject=excluded.subject,category=excluded.category,priority=excluded.priority,
                   status=excluded.status,updated_at=excluded.updated_at,closed_at=excluded.closed_at,
                   satisfaction=excluded.satisfaction,payload=excluded.payload""",
                (
                    ticket["id"], uid, str(ticket.get("subject") or "Support")[:120],
                    str(ticket.get("category") or "general")[:40], str(ticket.get("priority") or "normal")[:20],
                    status, now, str(ticket.get("updated_at") or now), ticket.get("closed_at"),
                    ticket.get("satisfaction"), json_dump(ticket),
                ),
            )
            messages = ticket.get("messages") or []
            if not messages:
                messages = [{
                    "id": _deterministic_id("msgmig", ticket["id"], "fallback"),
                    "body": str(ticket.get("text") or "Migrated ticket"),
                    "sender_type": "user", "sender_id": uid, "created_at": now,
                }]
            for message in messages:
                body = str(message.get("text") or message.get("body") or "Migrated ticket")[:5000]
                cursor.execute(
                    """INSERT INTO v8_ticket_messages(id,ticket_id,sender_type,sender_id,body,created_at,payload)
                       VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                    (
                        message["id"], ticket["id"], str(message.get("sender_type") or "user"),
                        str(message.get("sender_id") or uid), body, str(message.get("created_at") or now), json_dump(message),
                    ),
                )
            counters["tickets"] += 1

    for uid, row in plan["journal"]:
        journal_repo.add(uid, row)
        counters["journal"] += 1

    with db_engine.transaction() as cursor:
        for uid, section, payload in plan["preferences"]:
            cursor.execute(
                """INSERT INTO v8_user_preferences(user_id,section,updated_at,payload) VALUES(?,?,?,?)
                   ON CONFLICT(user_id,section) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload""",
                (uid, section, utc_iso(), json_dump(payload)),
            )
            counters["preferences"] += 1

    reconciliation = _reconcile(db_engine, plan)
    result = {"status": "applied", **counters, "reconciliation": reconciliation, "errors": 0}
    with db_engine.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_meta(key,value,updated_at) VALUES(?,?,?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
            (MIGRATION_KEY, json_dump(result), utc_iso()),
        )
    return result


@contextlib.contextmanager
def _migration_lock(engine: DatabaseEngine):
    """Serialize the one-way migration across replicas and rolling deploys."""
    if engine.dialect.name == "postgres":
        connection = engine.connect()
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT pg_advisory_lock(hashtextextended(%s, 0))", (MIGRATION_KEY,))
            yield
        finally:
            with contextlib.suppress(Exception):
                cursor.execute("SELECT pg_advisory_unlock(hashtextextended(%s, 0))", (MIGRATION_KEY,))
                connection.commit()
            with contextlib.suppress(Exception):
                connection.close()
        return
    lock_path = Path(str(engine.sqlite_path) + ".migration.lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+b")
    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            if not handle.read(1):
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        with contextlib.suppress(Exception):
            if os.name == "nt":
                import msvcrt
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def migration_status(engine: DatabaseEngine | None = None) -> dict[str, Any]:
    db_engine = engine or normalized_engine()
    with db_engine.transaction(read_only=True) as cursor:
        completed = cursor.execute("SELECT value,updated_at FROM v8_meta WHERE key=?", (MIGRATION_KEY,)).fetchone()
        run = cursor.execute("SELECT value,updated_at FROM v8_meta WHERE key=?", (MIGRATION_RUN_KEY,)).fetchone()
    run_details: Any = (run or {}).get("value")
    if isinstance(run_details, str):
        try:
            run_details = json.loads(run_details)
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
    state = str(run_details.get("state") if isinstance(run_details, dict) else "")
    complete = bool(completed) and state in {"", "complete"}
    return {
        "complete": complete,
        "state": "complete" if complete else state or "pending",
        "details": (completed or {}).get("value"),
        "run": run_details,
        "updated_at": (run or completed or {}).get("updated_at"),
    }


def migrate_legacy_state(engine: DatabaseEngine | None = None, *, force: bool = False) -> dict[str, Any]:
    db_engine = engine or normalized_engine()
    with _migration_lock(db_engine):
        current = migration_status(db_engine)
        if current.get("complete") and not force:
            return {"status": "already_applied", "details": current.get("details")}
        backup_path = ""
        try:
            backup_path = _sqlite_pre_migration_backup(db_engine)
            _write_run_state(db_engine, "running", backup=backup_path)
            result = _migrate_legacy_state_unlocked(db_engine, force=force)
            if result.get("errors"):
                raise MigrationError(f"MIGRATION_REPORTED_ERRORS:{result['errors']}")
            _write_run_state(db_engine, "complete", backup=backup_path, result=result)
            return result
        except Exception as exc:
            with contextlib.suppress(Exception):
                _write_run_state(
                    db_engine,
                    "failed",
                    backup=backup_path,
                    error=exc.__class__.__name__,
                    error_code=str(exc).split(":", 1)[0][:120],
                )
            raise
