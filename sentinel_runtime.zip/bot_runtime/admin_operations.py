"""Feature-owned Telegram handlers extracted from the v7 runtime: admin_operations."""

from urllib.parse import urlsplit

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

def _dashboard_snapshot() -> dict[str, Any]:
    db = load_db()
    snapshot = admin_dashboard_snapshot(db, timezone=SETTINGS.timezone)
    snapshot["discounts"] = {
        "active": sum(1 for row in db.get("discount_codes", {}).values() if isinstance(row, dict) and row.get("status") == "active")
    }
    try:
        backups = list_payload_backups(SETTINGS.backup_dir)
        latest_backup = backups[0] if backups else None
        latest_at = datetime.fromtimestamp(latest_backup.stat().st_mtime, tz=UTC).isoformat() if latest_backup else None
    except OSError:
        logger.exception("Could not read backup metadata for dashboard")
        backups = []
        latest_at = None
    snapshot["backups"] = {"count": len(backups), "latest_at": latest_at}
    snapshot["storage"] = persistent_storage_status(database_url=SETTINGS.database_url, db_file=SETTINGS.db_file)
    signal_controls = control_module_state(db, "signals")
    snapshot["signal_safety"] = {
        "owner_approval": bool(signal_controls.get("owner_approval", False)),
        "pending_approvals": len(pending_signal_approvals(db)),
        "max_risk_percent": float(signal_controls.get("max_risk_percent", 2) or 2),
        "rr_enforced": False,
    }
    snapshot["exposure"] = exposure_snapshot(db)
    snapshot["incidents"] = incident_summary(db)
    snapshot["trust"] = build_trust_snapshot(db)
    snapshot["repositories"] = repository_metrics()
    snapshot["capabilities"] = capability_summary()
    snapshot["commercial"] = commercial_dashboard(db)
    return snapshot


async def _render_admin_dashboard(query: Any, page: str) -> None:
    allowed_pages = {"overview", "business", "sales", "users", "support", "signals", "system"}
    normalized = page if page in allowed_pages else "overview"
    snapshot = await run_blocking(_dashboard_snapshot)
    await edit(query, _dashboard_text(snapshot, normalized), _dashboard_rows(query.from_user.id, normalized))


async def a_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DASHBOARD):
        return
    query = update.callback_query
    await query.answer()
    await _render_admin_dashboard(query, "overview")


async def admin_dashboard_page(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DASHBOARD):
        return
    query = update.callback_query
    await query.answer()
    page = query.data.split(":", 1)[1] if ":" in query.data else "overview"
    await _render_admin_dashboard(query, page)


async def a_logs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_AUDIT_LOGS):
        return
    query = update.callback_query
    await query.answer()
    logs = (await async_snapshot()).get("admin_logs", [])[-15:]
    lines = ["📜 <b>آخرین رویدادهای مدیریتی</b>", ""]
    for item in reversed(logs):
        lines.append(
            f"• {display_dt(item.get('created_at'))} | <code>{esc(item.get('admin_id'))}</code> | {esc(item.get('action'))} | {esc(item.get('details', ''))}"
        )
    if not logs:
        lines.append("لاگی ثبت نشده است.")
    await edit(query, "\n".join(lines), back("admin_home"))


async def a_runtime_logs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RUNTIME_LOGS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    snapshot = observability_snapshot()
    errors = [row for row in snapshot.get("recent_errors", []) if isinstance(row, dict)][-15:]
    jobs = [
        (name, row) for name, row in (snapshot.get("jobs") or {}).items()
        if isinstance(row, dict) and str(row.get("status") or "") in {"failed", "degraded", "retrying"}
    ]
    lines = [
        "🧯 <b>لاگ امن Runtime</b>",
        "",
        f"وضعیت: <b>{esc(snapshot.get('status') or 'unknown')}</b> | Uptime: <b>{int(snapshot.get('uptime_seconds') or 0)} ثانیه</b>",
        f"خطاهای ثبت‌شده: <b>{len(errors)}</b> | Jobهای نیازمند بررسی: <b>{len(jobs)}</b>",
        "",
    ]
    if errors:
        lines.append("<b>آخرین خطاها</b>")
        for row in reversed(errors):
            lines.append(
                f"• {display_dt(row.get('created_at'))} | <code>{esc(row.get('component') or 'runtime')}</code> | "
                f"{esc(str(row.get('type') or 'Error'))}: {esc(str(row.get('error') or '')[:240])}"
            )
    else:
        lines.append("✅ خطای Runtime ثبت نشده است.")
    if jobs:
        lines.extend(["", "<b>Jobهای ناپایدار</b>"])
        for name, row in jobs[:12]:
            lines.append(
                f"• <code>{esc(name)}</code> — {esc(row.get('status') or '')}"
                + (f" — {esc(str(row.get('last_error') or '')[:180])}" if row.get('last_error') else "")
            )
    lines.extend(["", "<i>توکن‌ها، کلیدهای API و مسیرهای محرمانه در این نما نمایش داده نمی‌شوند.</i>"])
    await edit(query, "\n".join(lines), back("admin_home"))


async def a_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_LEADERBOARD):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    top = sorted(db.get("user_points", {}).items(), key=lambda item: (-int(item[1]), item[0]))[:20]
    lines = ["🏆 <b>لیدربورد مدیریتی TOP 20</b>", ""]
    for index, (uid, points) in enumerate(top, start=1):
        user = db.get("users", {}).get(str(uid), {})
        name = user.get("username") or user.get("first_name") or uid
        lines.append(f"{index}. {esc(name)} — <code>{esc(uid)}</code> — <b>{int(points)}</b>")
    if not top:
        lines.append("هنوز امتیازی ثبت نشده است.")
    await edit(query, "\n".join(lines), back("admin_home"))


async def a_contest_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CONTEST_STATS):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    price_contests = db.get("contests", [])
    chart = db.get("chart_contest", {})
    candle = db.get("candle_contest", {})
    total_price_participants = sum(len(item.get("participants", {})) for item in price_contests)
    await edit(
        query,
        "📊 <b>آمار مسابقات</b>\n\n"
        f"🎯 مسابقات قیمت: <b>{len(price_contests)}</b>\n"
        f"👥 مجموع شرکت قیمت: <b>{total_price_participants}</b>\n"
        f"📊 وضعیت چارت: <b>{esc(chart.get('status', 'ندارد'))}</b> — {len(chart.get('answers', {}))} پاسخ\n"
        f"🕯 وضعیت کندل: <b>{esc(candle.get('status', 'ندارد'))}</b> — {len(candle.get('answers', {}))} پاسخ",
        back("admin_home"),
    )


async def a_reward_requests(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_REWARD_REQUESTS):
        return
    query = update.callback_query
    await query.answer()
    requests = [item for item in reversed((await async_snapshot()).get("reward_requests", [])) if item.get("status") == "pending"][:30]
    if not requests:
        await edit(query, "🎁 درخواست جایزه معلقی وجود ندارد.", back("admin_home"))
        return
    rows = [
        [InlineKeyboardButton(f"✅ #{item['id']} | {item['reward_name']} | {item['user_id']}", callback_data=f"reward_done:{item['id']}")]
        for item in requests
    ]
    rows += back("admin_home")
    await edit(query, "🎁 <b>درخواست‌های جایزه</b>", rows)


async def reward_done(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_REWARD_REQUESTS):
        return
    query = update.callback_query
    await query.answer()
    try:
        request_id = int(query.data.split(":", 1)[1])
    except ValueError:
        await query.answer("شناسه نامعتبر است.", show_alert=True)
        return

    def done(db: dict):
        item = next((item for item in db.get("reward_requests", []) if int(item.get("id", -1)) == request_id), None)
        if not item or item.get("status") != "pending":
            return None
        item.update({"status": "completed", "completed_at": utc_iso(), "completed_by": query.from_user.id})
        update_reward_status(db, request_id, "delivered")
        audit(db, query.from_user.id, "reward_completed", str(request_id))
        return dict(item)

    item = await async_with_db(done)
    if not item:
        await query.answer("درخواست قبلاً پردازش شده است.", show_alert=True)
        return
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message, int(item["user_id"]), f"✅ درخواست جایزه «{item['reward_name']}» توسط ادمین انجام شد."
        )
    except TelegramError:
        logger.exception("Could not notify reward user")
    await edit(query, "✅ درخواست جایزه انجام‌شده ثبت شد.", back("a_reward_requests"))


def _funnel_percent(current: int, previous: int) -> float:
    return current / max(1, previous) * 100


async def a_sales_funnel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DASHBOARD):
        return
    query = update.callback_query
    await query.answer()
    try:
        days = int(str(query.data or "").split(":", 1)[1]) if ":" in str(query.data or "") else 30
    except ValueError:
        days = 30
    snapshot = sales_funnel_snapshot((await async_snapshot()), days=days)
    counts = snapshot["counts"]
    stages = [
        ("ورود به ربات", "entered"),
        ("مشاهده VIP", "vip_viewed"),
        ("انتخاب پلن", "plan_selected"),
        ("شروع پرداخت", "checkout_started"),
        ("ثبت سفارش", "order_created"),
        ("تأیید خرید", "approved"),
    ]
    lines = [f"📈 <b>قیف فروش اشتراک — {days} روز اخیر</b>", ""]
    previous = None
    for title, key in stages:
        value = int(counts.get(key, 0) or 0)
        conversion = "" if previous is None else f" | تبدیل: <b>{_funnel_percent(value, previous):.1f}٪</b>"
        lines.append(f"• {title}: <b>{value}</b>{conversion}")
        previous = value
    lines.extend(
        [
            "",
            f"🟠 خرید رهاشده: <b>{len(snapshot.get('abandoned_users', []))}</b>",
            f"🟡 بازدید بدون انتخاب پلن: <b>{len(snapshot.get('viewer_dropoff_users', []))}</b>",
            f"⏳ سفارش معلق: <b>{int(snapshot.get('pending_orders', 0))}</b>",
            f"❌ سفارش ردشده: <b>{int(snapshot.get('rejected_orders', 0))}</b>",
        ]
    )
    rows = [
        [
            InlineKeyboardButton("۷ روز", callback_data="a_sales_funnel:7"),
            InlineKeyboardButton("۳۰ روز", callback_data="a_sales_funnel:30"),
            InlineKeyboardButton("۹۰ روز", callback_data="a_sales_funnel:90"),
        ],
        [
            InlineKeyboardButton("🧩 پلن‌ساز", callback_data="a_vip_plans"),
            InlineKeyboardButton("🌐 کمپین تخفیف", callback_data="a_public_discounts"),
        ],
    ]
    if _has_admin_permission(query.from_user.id, PERMISSION_CRM):
        rows.append(
            [
                InlineKeyboardButton("🟠 کاربران خرید رهاشده", callback_data=f"funnel_users:abandoned:{days}:0"),
                InlineKeyboardButton("🟡 بازدید بدون انتخاب", callback_data=f"funnel_users:viewers:{days}:0"),
            ]
        )
    rows.append([InlineKeyboardButton("↩️ فروش و اشتراک", callback_data="admin_cat:sales")])
    await edit(query, "\n".join(lines), rows)


async def sales_funnel_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    _, kind, days_text, page_text = str(query.data).split(":", 3)
    days = int(days_text)
    page = max(0, int(page_text))
    snapshot = sales_funnel_snapshot((await async_snapshot()), days=days)
    source_key = "abandoned_users" if kind == "abandoned" else "viewer_dropoff_users"
    user_ids = [str(uid) for uid in snapshot.get(source_key, [])]
    page_size = 10
    total_pages = max(1, (len(user_ids) + page_size - 1) // page_size)
    page = min(page, total_pages - 1)
    selected = user_ids[page * page_size : (page + 1) * page_size]
    db = await async_snapshot()
    rows: list[list[InlineKeyboardButton]] = []
    lines = [
        "🟠 <b>خریدهای رهاشده</b>" if kind == "abandoned" else "🟡 <b>بازدید بدون انتخاب پلن</b>",
        "",
        f"بازه: <b>{days} روز</b> | تعداد: <b>{len(user_ids)}</b>",
        "",
    ]
    for uid in selected:
        user = db.get("users", {}).get(uid, {})
        name = str(user.get("first_name") or user.get("username") or uid)
        lines.append(f"• {esc(name)} — <code>{uid}</code>")
        rows.append([InlineKeyboardButton(f"👤 {name} · {uid}"[:62], callback_data=f"crm_open:{uid}")])
    if not selected:
        lines.append("کاربری در این گروه نیست.")
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"funnel_users:{kind}:{days}:{page - 1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"funnel_users:{kind}:{days}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton("↩️ قیف فروش", callback_data=f"a_sales_funnel:{days}")])
    await edit(query, "\n".join(lines), rows)


def _vip_plan_admin_text(plan: dict[str, Any]) -> str:
    audience_labels = {"all": "همه", "new": "فقط مشتری جدید", "renewal": "فقط تمدید"}
    features = "، ".join(str(item) for item in plan.get("features", [])[:8]) or "تعریف نشده"
    limit = int(plan.get("sales_limit", 0) or 0)
    return (
        f"🧩 <b>{esc(plan.get('name'))}</b>\n\n"
        f"شناسه: <code>{int(plan.get('id', 0) or 0)}</code>\n"
        f"قیمت: <b>{int(plan.get('price', 0) or 0):,} تومان</b>\n"
        f"قیمت قبل: <b>{int(plan.get('original_price', 0) or 0):,}</b>\n"
        f"مدت: <b>{int(plan.get('duration_days', 0) or 0)} روز</b>\n"
        f"مخاطب: <b>{audience_labels.get(str(plan.get('audience')), plan.get('audience'))}</b>\n"
        f"وضعیت: <b>{'فعال' if plan.get('active', True) else 'غیرفعال'}</b> | ویژه: <b>{'بله' if plan.get('highlight') else 'خیر'}</b>\n"
        f"فروش: <b>{int(plan.get('sales_count', 0) or 0)}</b> / <b>{limit if limit else 'نامحدود'}</b>\n"
        f"شروع: <code>{esc(plan.get('starts_at') or 'همین حالا')}</code>\n"
        f"پایان: <code>{esc(plan.get('ends_at') or 'بدون محدودیت')}</code>\n\n"
        f"امکانات: {esc(features)}\n\n"
        f"{esc(plan.get('description') or '')}"
    )


def _vip_plan_admin_rows(plan: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    plan_id = int(plan.get("id", 0) or 0)
    return [
        [InlineKeyboardButton("✏️ ویرایش پلن", callback_data=f"vip_plan_edit_menu:{plan_id}")],
        [
            state_button(
                "وضعیت پلن",
                bool(plan.get("active", True)),
                callback_data=f"vip_plan_toggle:{plan_id}",
                enabled_label="فعال",
                disabled_label="غیرفعال",
            ),
            state_button(
                "نمایش ویژه",
                bool(plan.get("highlight", False)),
                callback_data=f"vip_plan_highlight:{plan_id}",
                enabled_label="ویژه",
                disabled_label="عادی",
            ),
        ],
        [InlineKeyboardButton("👥 تغییر گروه مخاطب", callback_data=f"vip_plan_audience_cycle:{plan_id}")],
        [InlineKeyboardButton("🗑 حذف پلن", callback_data=f"vip_plan_delete:{plan_id}")],
        [InlineKeyboardButton("↩️ فهرست پلن‌ها", callback_data="a_vip_plans")],
    ]


def _vip_plan_list_payload(db: dict[str, Any]) -> tuple[str, list[list[InlineKeyboardButton]]]:
    plans = ensure_vip_plans(db)
    rows = [
        [InlineKeyboardButton(_vip_plan_label(plan), callback_data=f"vip_plan_admin:{int(plan['id'])}")]
        for plan in sorted(plans, key=lambda row: int(row.get("sort_order", 100) or 100))
    ]
    rows.extend(
        [
            [InlineKeyboardButton("➕ ساخت پلن جدید", callback_data="vip_plan_add")],
            [InlineKeyboardButton("💳 تنظیمات روش‌های پرداخت", callback_data="a_vip_settings")],
            [InlineKeyboardButton("↩️ فروش و اشتراک", callback_data="admin_cat:sales")],
        ]
    )
    active = sum(1 for plan in plans if plan.get("active", True))
    return f"🧩 <b>پلن‌ساز حرفه‌ای VIP</b>\n\nکل پلن‌ها: <b>{len(plans)}</b> | فعال: <b>{active}</b>\nیک پلن را برای مدیریت انتخاب کنید.", rows


async def a_vip_plans(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_VIEW):
        return
    query = update.callback_query
    await query.answer()
    text_value, rows = _vip_plan_list_payload(await async_snapshot())
    await edit(query, text_value, rows)


async def vip_plan_admin_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_VIEW):
        return
    query = update.callback_query
    await query.answer()
    plan_id = int(str(query.data).split(":", 1)[1])
    plan = get_vip_plan((await async_snapshot()), plan_id)
    if not plan:
        await edit(query, "پلن پیدا نشد.", [[InlineKeyboardButton("↩️ فهرست پلن‌ها", callback_data="a_vip_plans")]])
        return
    await edit(query, _vip_plan_admin_text(plan), _vip_plan_admin_rows(plan))


async def vip_plan_edit_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_EDIT):
        return
    query = update.callback_query
    await query.answer()
    plan_id = int(str(query.data).split(":", 1)[1])
    plan = get_vip_plan((await async_snapshot()), plan_id)
    if not plan:
        await edit(query, "پلن پیدا نشد.", [[InlineKeyboardButton("↩️ پلن‌ها", callback_data="a_vip_plans")]])
        return
    rows = [
        [
            InlineKeyboardButton("نام", callback_data=f"vip_plan_edit:{plan_id}:name"),
            InlineKeyboardButton("توضیح", callback_data=f"vip_plan_edit:{plan_id}:description"),
        ],
        [
            InlineKeyboardButton("قیمت", callback_data=f"vip_plan_edit:{plan_id}:price"),
            InlineKeyboardButton("قیمت قبل", callback_data=f"vip_plan_edit:{plan_id}:original_price"),
        ],
        [
            InlineKeyboardButton("مدت", callback_data=f"vip_plan_edit:{plan_id}:duration_days"),
            InlineKeyboardButton("سقف فروش", callback_data=f"vip_plan_edit:{plan_id}:sales_limit"),
        ],
        [
            InlineKeyboardButton("امکانات", callback_data=f"vip_plan_edit:{plan_id}:features"),
            InlineKeyboardButton("بازه زمانی", callback_data=f"vip_plan_edit:{plan_id}:window"),
        ],
        [InlineKeyboardButton("↩️ جزئیات پلن", callback_data=f"vip_plan_admin:{plan_id}")],
    ]
    await edit(query, f"✏️ <b>ویرایش {esc(plan.get('name'))}</b>\n\nفیلد موردنظر را انتخاب کنید.", rows)


async def vip_plan_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_PLAN_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    _, plan_id_text, field = str(query.data).split(":", 2)
    plan_id = int(plan_id_text)
    if not get_vip_plan((await async_snapshot()), plan_id):
        await edit(query, "پلن پیدا نشد.", [[InlineKeyboardButton("↩️ پلن‌ها", callback_data="a_vip_plans")]])
        return ConversationHandler.END
    prompts = {
        "name": "نام جدید پلن را وارد کنید.",
        "description": "توضیح جدید را وارد کنید؛ برای خالی‌کردن <code>-</code> بفرستید.",
        "price": "قیمت جدید را به تومان وارد کنید.",
        "original_price": "قیمت قبل را وارد کنید؛ برای حذف قیمت قبلی <code>0</code> بفرستید.",
        "duration_days": "مدت جدید را به روز وارد کنید.",
        "sales_limit": "سقف فروش جدید را وارد کنید؛ برای نامحدود <code>0</code> بفرستید.",
        "features": "امکانات جدید را با ویرگول جدا کنید؛ برای خالی‌کردن <code>-</code> بفرستید.",
        "window": "بازه جدید را با قالب <code>شروع | پایان</code> بفرستید؛ برای بدون محدودیت <code>- | -</code> بفرستید.",
    }
    if field not in prompts:
        await query.answer("فیلد نامعتبر است", show_alert=True)
        return ConversationHandler.END
    context.user_data["vip_plan_edit"] = {"plan_id": plan_id, "field": field}
    await edit(
        query, f"✏️ <b>ویرایش پلن</b>\n\n{prompts[field]}", [[InlineKeyboardButton("↩️ لغو", callback_data=f"vip_plan_edit_menu:{plan_id}")]]
    )
    return VIP_PLAN_EDIT_INPUT


async def vip_plan_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    state = dict(context.user_data.get("vip_plan_edit") or {})
    try:
        plan_id = int(state["plan_id"])
        field = str(state["field"])
    except (KeyError, TypeError, ValueError):
        await reply(update, "❌ اطلاعات ویرایش از دست رفته است.", [[InlineKeyboardButton("↩️ پلن‌ها", callback_data="a_vip_plans")]])
        return ConversationHandler.END
    raw = str(update.effective_message.text or "").strip()
    try:
        if field in {"price", "original_price", "duration_days", "sales_limit"}:
            value: Any = int(_ascii_digits(raw).replace(",", ""))
        elif field == "features":
            value = [] if raw in {"", "-"} else [part.strip() for part in re.split(r"[,،]", raw) if part.strip()]
        elif field == "description":
            value = "" if raw == "-" else raw
        elif field == "window":
            parts = [part.strip() for part in raw.split("|", 1)]
            if len(parts) != 2:
                raise ValueError("شروع و پایان باید با | جدا شوند")
            value = {
                "starts_at": None if parts[0] in {"", "-"} else parts[0],
                "ends_at": None if parts[1] in {"", "-"} else parts[1],
            }
        else:
            value = raw
        row = await async_with_db(lambda db: update_vip_plan(db, plan_id, field, value))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "vip_plan_edit", f"{plan_id}:{field}"))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_PLAN_EDIT_INPUT
    context.user_data.pop("vip_plan_edit", None)
    await reply(update, "✅ پلن ویرایش شد.", [[InlineKeyboardButton("مشاهده پلن", callback_data=f"vip_plan_admin:{row['id']}")]])
    return ConversationHandler.END


async def vip_plan_audience_cycle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_EDIT):
        return
    query = update.callback_query
    plan_id = int(str(query.data).split(":", 1)[1])
    row = await async_with_db(lambda db: cycle_vip_plan_audience(db, plan_id))
    labels = {"all": "همه کاربران", "new": "مشتری جدید", "renewal": "تمدید"}
    await query.answer(f"مخاطب: {labels.get(str(row.get('audience')), row.get('audience'))}", show_alert=True)
    await edit(query, _vip_plan_admin_text(row), _vip_plan_admin_rows(row))


async def vip_plan_edit_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("vip_plan_edit", None)
    await vip_plan_edit_menu(update, context)
    return ConversationHandler.END


async def vip_plan_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_PLAN_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "➕ <b>ساخت پلن VIP</b>\n\nبرای راحتی مدیریت، ساخت مرحله‌ای پیشنهاد می‌شود. ورود سریع هم برای ادمین‌های باتجربه باقی مانده است.",
        [
            [InlineKeyboardButton("🧭 ساخت مرحله‌ای", callback_data="vip_plan_wizard")],
            [InlineKeyboardButton("⚡ ورود سریع در یک پیام", callback_data="vip_plan_quick")],
            [InlineKeyboardButton("↩️ فهرست پلن‌ها", callback_data="a_vip_plans")],
        ],
    )
    return ConversationHandler.END


async def vip_plan_quick_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_PLAN_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "⚡ <b>ورود سریع پلن حرفه‌ای</b>\n\n"
        "اطلاعات را در یک خط و با جداکننده <code>|</code> بفرستید:\n"
        "<code>نام | قیمت | روز | مخاطب | قیمت قبل | سقف فروش | ویژه | امکانات | توضیح | شروع | پایان</code>\n\n"
        "مخاطب: <code>all</code>، <code>new</code> یا <code>renewal</code>\n"
        "ویژه: <code>yes</code> یا <code>no</code>\n"
        "امکانات با ویرگول جدا شوند. برای موارد اختیاری <code>-</code> بگذارید.\n"
        "زمان‌ها باید ISO باشند؛ مثال <code>2026-07-01T12:00:00+03:30</code>.\n\n"
        "نمونه:\n<code>VIP سه ماهه | 2500000 | 90 | all | 3000000 | 100 | yes | سیگنال ویژه,پشتیبانی VIP | پلن اقتصادی سه ماهه | - | -</code>",
        back("a_vip_plans"),
    )
    return VIP_PLAN_INPUT


async def vip_plan_wizard_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_PLAN_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["vip_plan_draft"] = {}
    await edit(query, "🧩 <b>مرحله ۱ از ۱۰</b>\nنام پلن را وارد کنید؛ مثال: <code>VIP سه ماهه</code>", back("a_vip_plans"))
    return VIP_PLAN_NAME_INPUT


async def vip_plan_wizard_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    value = str(update.effective_message.text or "").strip()
    if len(value) < 2:
        await reply(update, "❌ نام پلن باید حداقل دو کاراکتر باشد.")
        return VIP_PLAN_NAME_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["name"] = value[:80]
    await reply(update, "🧩 <b>مرحله ۲ از ۱۰</b>\nقیمت پلن را به تومان وارد کنید؛ مثال: <code>2500000</code>", back("a_vip_plans"))
    return VIP_PLAN_PRICE_INPUT


async def vip_plan_wizard_price(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        value = int(_ascii_digits(str(update.effective_message.text or "")).replace(",", ""))
        if value < 0:
            raise ValueError
    except ValueError:
        await reply(update, "❌ قیمت معتبر وارد کنید.")
        return VIP_PLAN_PRICE_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["price"] = value
    await reply(update, "🧩 <b>مرحله ۳ از ۱۰</b>\nمدت پلن را به روز وارد کنید؛ مثال: <code>90</code>", back("a_vip_plans"))
    return VIP_PLAN_DAYS_INPUT


async def vip_plan_wizard_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        value = int(_ascii_digits(str(update.effective_message.text or "")))
        if not 1 <= value <= 3650:
            raise ValueError
    except ValueError:
        await reply(update, "❌ مدت باید بین ۱ تا ۳۶۵۰ روز باشد.")
        return VIP_PLAN_DAYS_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["duration_days"] = value
    await reply(
        update,
        "🧩 <b>مرحله ۴ از ۱۰</b>\nاین پلن برای چه کاربرانی نمایش داده شود؟",
        [
            [InlineKeyboardButton("👥 همه کاربران", callback_data="vip_plan_audience:all")],
            [InlineKeyboardButton("🆕 فقط مشتری جدید", callback_data="vip_plan_audience:new")],
            [InlineKeyboardButton("♻️ فقط تمدید", callback_data="vip_plan_audience:renewal")],
            [InlineKeyboardButton("↩️ لغو", callback_data="a_vip_plans")],
        ],
    )
    return VIP_PLAN_AUDIENCE_INPUT


async def vip_plan_wizard_audience(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    audience = str(query.data).split(":", 1)[1]
    if audience not in {"all", "new", "renewal"}:
        await query.answer("مخاطب نامعتبر است", show_alert=True)
        return VIP_PLAN_AUDIENCE_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["audience"] = audience
    await edit(
        query,
        "🧩 <b>مرحله ۵ از ۱۰</b>\nقیمت قبل از تخفیف را وارد کنید یا برای نداشتن قیمت قبلی <code>-</code> بفرستید.",
        back("a_vip_plans"),
    )
    return VIP_PLAN_ORIGINAL_INPUT


async def vip_plan_wizard_original(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    raw = str(update.effective_message.text or "").strip()
    try:
        value = 0 if raw in {"", "-"} else int(_ascii_digits(raw).replace(",", ""))
        if value < 0:
            raise ValueError
    except ValueError:
        await reply(update, "❌ قیمت قبلی معتبر نیست؛ عدد یا خط تیره بفرستید.")
        return VIP_PLAN_ORIGINAL_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["original_price"] = value
    await reply(update, "🧩 <b>مرحله ۶ از ۱۰</b>\nسقف فروش را وارد کنید؛ برای نامحدود <code>0</code> بفرستید.", back("a_vip_plans"))
    return VIP_PLAN_LIMIT_INPUT


async def vip_plan_wizard_limit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        value = int(_ascii_digits(str(update.effective_message.text or "")))
        if value < 0:
            raise ValueError
    except ValueError:
        await reply(update, "❌ سقف فروش باید صفر یا یک عدد مثبت باشد.")
        return VIP_PLAN_LIMIT_INPUT
    context.user_data.setdefault("vip_plan_draft", {})["sales_limit"] = value
    await reply(
        update,
        "🧩 <b>مرحله ۷ از ۱۰</b>\nآیا این پلن به‌عنوان پیشنهاد ویژه نمایش داده شود؟",
        [
            [
                InlineKeyboardButton("⭐ بله، ویژه", callback_data="vip_plan_featured:yes"),
                InlineKeyboardButton("عادی", callback_data="vip_plan_featured:no"),
            ],
            [InlineKeyboardButton("↩️ لغو", callback_data="a_vip_plans")],
        ],
    )
    return VIP_PLAN_HIGHLIGHT_INPUT


async def vip_plan_wizard_highlight(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    value = str(query.data).split(":", 1)[1]
    context.user_data.setdefault("vip_plan_draft", {})["highlight"] = value == "yes"
    await edit(
        query,
        "🧩 <b>مرحله ۸ از ۱۰</b>\nامکانات پلن را با ویرگول جدا کنید؛ مثال: <code>سیگنال ویژه، پشتیبانی VIP</code>\nبرای نداشتن مورد <code>-</code> بفرستید.",
        back("a_vip_plans"),
    )
    return VIP_PLAN_FEATURES_INPUT


async def vip_plan_wizard_features(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    raw = str(update.effective_message.text or "").strip()
    features = [] if raw in {"", "-"} else [part.strip() for part in re.split(r"[,،]", raw) if part.strip()]
    context.user_data.setdefault("vip_plan_draft", {})["features"] = features[:10]
    await reply(update, "🧩 <b>مرحله ۹ از ۱۰</b>\nتوضیح کوتاه پلن را بنویسید یا <code>-</code> بفرستید.", back("a_vip_plans"))
    return VIP_PLAN_DESCRIPTION_INPUT


async def vip_plan_wizard_description(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    raw = str(update.effective_message.text or "").strip()
    context.user_data.setdefault("vip_plan_draft", {})["description"] = "" if raw == "-" else raw[:500]
    await reply(
        update,
        "🧩 <b>مرحله ۱۰ از ۱۰</b>\nبازه نمایش را با قالب زیر بفرستید:\n"
        "<code>شروع | پایان</code>\n"
        "برای شروع فوری یا پایان نامحدود از <code>-</code> استفاده کنید.\n"
        "مثال: <code>- | 2026-08-01T23:59:00+03:30</code>\n"
        "برای بدون محدودیت کامل: <code>- | -</code>",
        back("a_vip_plans"),
    )
    return VIP_PLAN_WINDOW_INPUT


async def vip_plan_wizard_window(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 1)]
    if len(parts) != 2:
        await reply(update, "❌ زمان شروع و پایان را با یک علامت | جدا کنید.")
        return VIP_PLAN_WINDOW_INPUT
    starts, ends = parts
    draft = dict(context.user_data.get("vip_plan_draft") or {})
    try:
        row = await async_with_db(
            lambda db: create_vip_plan(
                db,
                name=draft["name"],
                price=int(draft["price"]),
                duration_days=int(draft["duration_days"]),
                audience=str(draft.get("audience") or "all"),
                original_price=int(draft.get("original_price", 0) or 0),
                sales_limit=int(draft.get("sales_limit", 0) or 0),
                highlight=bool(draft.get("highlight")),
                features=list(draft.get("features") or []),
                description=str(draft.get("description") or ""),
                starts_at=None if starts in {"", "-"} else starts,
                ends_at=None if ends in {"", "-"} else ends,
                created_by=update.effective_user.id,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "vip_plan_create", str(row["id"])))
    except (KeyError, ValueError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_PLAN_WINDOW_INPUT
    context.user_data.pop("vip_plan_draft", None)
    await reply(
        update,
        f"✅ پلن <b>{esc(row['name'])}</b> ساخته شد.",
        [
            [InlineKeyboardButton("مدیریت پلن", callback_data=f"vip_plan_admin:{row['id']}")],
            [InlineKeyboardButton("↩️ فهرست پلن‌ها", callback_data="a_vip_plans")],
        ],
    )
    return ConversationHandler.END


async def vip_plan_add_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_PLAN_CREATE):
        return ConversationHandler.END
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if len(parts) != 11:
        await reply(update, "❌ دقیقاً ۱۱ بخش لازم است. قالب را دوباره بررسی کنید.", back("a_vip_plans"))
        return VIP_PLAN_INPUT
    try:
        name, price, days, audience, original, limit, highlight, features, description, starts, ends = parts
        row = await async_with_db(
            lambda db: create_vip_plan(
                db,
                name=name,
                price=int(_ascii_digits(price).replace(",", "")),
                duration_days=int(_ascii_digits(days)),
                audience=audience.lower(),
                original_price=0 if original in {"", "-"} else int(_ascii_digits(original).replace(",", "")),
                sales_limit=0 if limit in {"", "-"} else int(_ascii_digits(limit).replace(",", "")),
                highlight=highlight.lower() in {"yes", "true", "1", "بله"},
                features=[item.strip() for item in features.split(",") if item.strip()] if features not in {"", "-"} else [],
                description="" if description == "-" else description,
                starts_at=None if starts in {"", "-"} else starts,
                ends_at=None if ends in {"", "-"} else ends,
                created_by=update.effective_user.id,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "vip_plan_create", str(row["id"])))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_PLAN_INPUT
    await reply(
        update,
        f"✅ پلن <b>{esc(row['name'])}</b> ساخته شد.",
        [[InlineKeyboardButton("مدیریت پلن", callback_data=f"vip_plan_admin:{row['id']}")]],
    )
    return ConversationHandler.END


async def vip_plan_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_ACTIVATE):
        return
    query = update.callback_query
    plan_id = int(str(query.data).split(":", 1)[1])
    row = await async_with_db(lambda db: toggle_vip_plan(db, plan_id))
    await query.answer("پلن فعال شد" if row.get("active") else "پلن غیرفعال شد", show_alert=True)
    await edit(query, _vip_plan_admin_text(row), _vip_plan_admin_rows(row))


async def vip_plan_highlight_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_EDIT):
        return
    query = update.callback_query
    plan_id = int(str(query.data).split(":", 1)[1])
    row = await async_with_db(lambda db: toggle_vip_plan_highlight(db, plan_id))
    await query.answer("پلن ویژه شد" if row.get("highlight") else "حالت ویژه برداشته شد", show_alert=True)
    await edit(query, _vip_plan_admin_text(row), _vip_plan_admin_rows(row))


async def vip_plan_delete_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_VIP_PLAN_DELETE):
        return
    query = update.callback_query
    plan_id = int(str(query.data).split(":", 1)[1])
    try:
        deleted = await async_with_db(lambda db: delete_vip_plan(db, plan_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("پلن حذف شد" if deleted else "پلن پیدا نشد", show_alert=True)
    text_value, rows = _vip_plan_list_payload(await async_snapshot())
    await edit(query, text_value, rows)


async def a_public_discounts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    codes = await async_with_db(lambda db: public_discount_codes(db))
    lines = [
        "🌐 <b>کدهای عمومی زمان‌دار</b>",
        "",
        "این کدها برای همه کاربران قابل استفاده‌اند، اما فقط ادمین آن‌ها را ایجاد و ارسال می‌کند.",
        "",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for item in codes[:20]:
        state = str(item.get("status") or "")
        status = "✅" if state == "active" else "⏸" if state == "disabled" else "⌛️"
        lines.append(
            f"{status} <code>{esc(item.get('code'))}</code> | {int(item.get('percent', 0))}٪ | استفاده {int(item.get('used_count', 0))}/{int(item.get('max_uses', 0)) or '∞'} | پایان {display_dt(item.get('expires_at'))}"
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"{status} {item.get('code')} — {item.get('percent')}٪", callback_data=f"public_discount_view:{item.get('code')}"
                )
            ]
        )
    if not codes:
        lines.append("هنوز کد عمومی ساخته نشده است.")
    rows.extend(
        [
            [InlineKeyboardButton("➕ ساخت کد عمومی", callback_data="cw:mode:discount")],
            [InlineKeyboardButton("↩️ فروش و اشتراک", callback_data="admin_cat:sales")],
        ]
    )
    await edit(query, "\n".join(lines)[:3900], rows)


async def public_discount_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "🌐 <b>ساخت کد عمومی</b>\n\n"
        "برای ساخت سریع، فقط کد و درصد را وارد می‌کنید؛ کد همان لحظه فعال می‌شود و دقیقاً هفت روز بعد خودکار منقضی خواهد شد. "
        "ارسال کد فقط از پنل ادمین انجام می‌شود.",
        [
            [InlineKeyboardButton("⚡ ساخت خودکار ۷ روزه", callback_data="public_discount_quick")],
            [InlineKeyboardButton("🧭 تنظیمات پیشرفته", callback_data="public_discount_wizard")],
            [InlineKeyboardButton("↩️ کدهای عمومی", callback_data="a_public_discounts")],
        ],
    )
    return ConversationHandler.END


async def public_discount_quick_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "⚡ <b>ساخت خودکار کد هفت‌روزه</b>\n\n"
        "قالب: <code>کد | درصد</code>\n\n"
        "مثال: <code>WEEK20 | 20</code>\n\n"
        "کد بلافاصله فعال می‌شود، برای هر کاربر یک‌بار قابل استفاده است، سقف استفاده نامحدود دارد و بعد از ۷ روز خودکار منقضی می‌شود.",
        back("a_public_discounts"),
    )
    return PUBLIC_DISCOUNT_INPUT


async def public_discount_wizard_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["public_discount_draft"] = {}
    await edit(
        query,
        "🌐 <b>مرحله ۱ از ۵</b>\nنام کد را وارد کنید؛ فقط حروف لاتین، عدد، خط تیره و زیرخط. مثال: <code>SUMMER20</code>",
        back("a_public_discounts"),
    )
    return PUBLIC_CODE_INPUT


async def public_discount_wizard_code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    raw = str(update.effective_message.text or "").strip().upper()
    clean = "".join(ch for ch in raw if ch.isalnum() or ch in {"-", "_"})
    if not 4 <= len(clean) <= 24:
        await reply(update, "❌ کد باید بین ۴ تا ۲۴ کاراکتر مجاز باشد.")
        return PUBLIC_CODE_INPUT
    if clean in (await async_snapshot()).get("discount_codes", {}):
        await reply(update, "❌ این کد قبلاً ساخته شده است.")
        return PUBLIC_CODE_INPUT
    context.user_data.setdefault("public_discount_draft", {})["code"] = clean
    await reply(update, "🌐 <b>مرحله ۲ از ۵</b>\nدرصد تخفیف را بین ۱ تا ۱۰۰ وارد کنید.", back("a_public_discounts"))
    return PUBLIC_PERCENT_INPUT


async def public_discount_wizard_percent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        value = int(_ascii_digits(str(update.effective_message.text or "")))
        if not 1 <= value <= 100:
            raise ValueError
    except ValueError:
        await reply(update, "❌ درصد باید بین ۱ تا ۱۰۰ باشد.")
        return PUBLIC_PERCENT_INPUT
    context.user_data.setdefault("public_discount_draft", {})["percent"] = value
    await reply(
        update,
        "🌐 <b>مرحله ۳ از ۵</b>\nبازه زمانی را با قالب زیر بفرستید:\n"
        "<code>شروع | پایان</code>\n"
        "شروع فوری: <code>-</code>؛ پایان الزامی است.\n"
        "مثال: <code>- | 2026-08-01T23:59:00+03:30</code>",
        back("a_public_discounts"),
    )
    return PUBLIC_WINDOW_INPUT


async def public_discount_wizard_window(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 1)]
    if len(parts) != 2 or parts[1] in {"", "-"}:
        await reply(update, "❌ زمان پایان الزامی است و شروع/پایان باید با | جدا شوند.")
        return PUBLIC_WINDOW_INPUT
    starts, ends = parts
    from core.utils import parse_dt

    start_dt = parse_dt(starts) if starts not in {"", "-"} else utc_now()
    end_dt = parse_dt(ends)
    if start_dt is None or end_dt is None or end_dt <= start_dt:
        await reply(update, "❌ بازه زمانی نامعتبر است یا پایان قبل از شروع قرار دارد.")
        return PUBLIC_WINDOW_INPUT
    draft = context.user_data.setdefault("public_discount_draft", {})
    draft["starts_at"] = None if starts in {"", "-"} else starts
    draft["ends_at"] = ends
    await reply(
        update, "🌐 <b>مرحله ۴ از ۵</b>\nسقف کل استفاده را وارد کنید؛ برای نامحدود <code>0</code> بفرستید.", back("a_public_discounts")
    )
    return PUBLIC_MAX_USES_INPUT


async def public_discount_wizard_max_uses(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        value = int(_ascii_digits(str(update.effective_message.text or "")))
        if value < 0:
            raise ValueError
    except ValueError:
        await reply(update, "❌ سقف استفاده باید صفر یا عدد مثبت باشد.")
        return PUBLIC_MAX_USES_INPUT
    context.user_data.setdefault("public_discount_draft", {})["max_uses"] = value
    await reply(
        update,
        "🌐 <b>مرحله ۵ از ۵</b>\nآیا هر کاربر فقط یک‌بار بتواند از این کد استفاده کند؟",
        [
            [
                InlineKeyboardButton("✅ بله، یک‌بار", callback_data="public_user_limit:yes"),
                InlineKeyboardButton("♾ خیر", callback_data="public_user_limit:no"),
            ],
            [InlineKeyboardButton("↩️ لغو", callback_data="a_public_discounts")],
        ],
    )
    return PUBLIC_USER_LIMIT_INPUT


async def public_discount_wizard_user_limit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    choice = str(query.data).split(":", 1)[1]
    draft = dict(context.user_data.get("public_discount_draft") or {})
    try:
        row = await async_with_db(
            lambda db: create_public_discount(
                db,
                code=str(draft["code"]),
                percent=int(draft["percent"]),
                starts_at=draft.get("starts_at"),
                ends_at=str(draft["ends_at"]),
                max_uses=int(draft.get("max_uses", 0) or 0),
                one_per_user=choice == "yes",
                created_by=query.from_user.id,
            )
        )
        await async_with_db(lambda db: audit(db, query.from_user.id, "public_discount_create", row["code"]))
    except (KeyError, ValueError) as exc:
        await edit(query, f"❌ {esc(exc)}", back("a_public_discounts"))
        return ConversationHandler.END
    context.user_data.pop("public_discount_draft", None)
    await edit(
        query,
        f"✅ کد عمومی <code>{row['code']}</code> ساخته شد.\nارسال آن فقط از پنل ادمین انجام می‌شود.",
        [
            [InlineKeyboardButton("📣 مدیریت و ارسال کد", callback_data=f"public_discount_view:{row['code']}")],
            [InlineKeyboardButton("↩️ فهرست کدهای عمومی", callback_data="a_public_discounts")],
        ],
    )
    return ConversationHandler.END


async def public_discount_add_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|")]
    if len(parts) != 2:
        await reply(update, "❌ قالب صحیح: <code>کد | درصد</code>\nمثال: <code>WEEK20 | 20</code>")
        return PUBLIC_DISCOUNT_INPUT
    try:
        code, percent = parts
        row = await async_with_db(
            lambda db: create_weekly_public_discount(
                db,
                code=code,
                percent=int(_ascii_digits(percent)),
                created_by=update.effective_user.id,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "public_discount_create_weekly", row["code"]))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PUBLIC_DISCOUNT_INPUT
    await reply(
        update,
        f"✅ کد عمومی <code>{row['code']}</code> ساخته و فعال شد.\n"
        f"درصد: <b>{int(row['percent'])}٪</b>\n"
        f"انقضای خودکار: <b>{display_dt(row.get('expires_at'))}</b>",
        [[InlineKeyboardButton("مدیریت و ارسال کد", callback_data=f"public_discount_view:{row['code']}")]],
    )
    return ConversationHandler.END


def _public_discount_status_label(status: str) -> str:
    return {
        "active": "فعال",
        "disabled": "موقتاً غیرفعال",
        "expired": "منقضی‌شده",
    }.get(str(status or ""), str(status or "نامشخص"))


def _public_discount_detail_payload(item: dict[str, Any]) -> tuple[str, list[list[InlineKeyboardButton]]]:
    code = str(item.get("code") or "").upper()
    status = str(item.get("status") or "")
    plans = ", ".join(str(value) for value in item.get("applicable_plan_ids", [])) or "همه پلن‌ها"
    segments = ", ".join(str(value) for value in item.get("allowed_crm_segments", [])) or "همه کاربران"
    payments = ", ".join(str(value).upper() for value in item.get("allowed_payment_methods", [])) or "همه روش‌ها"
    customer_types = ", ".join(str(value) for value in item.get("customer_types", [])) or "بدون محدودیت"
    cap = int(item.get("maximum_discount_amount", 0) or 0)
    min_amount = int(item.get("minimum_order_amount", 0) or 0)
    max_amount = int(item.get("maximum_order_amount", 0) or 0)
    affiliate = str(item.get("affiliate_user_id") or "—")
    commission = int(item.get("affiliate_commission_percent", 0) or 0)
    text_value = (
        f"🌐 <b>کمپین تخفیف {esc(code)}</b>\n\n"
        f"درصد اسمی: <b>{int(item.get('percent', 0))}٪</b>\n"
        f"سقف تخفیف: <b>{cap:,} تومان</b>" + ("\n" if cap else " (نامحدود)\n") +
        f"وضعیت: <b>{esc(_public_discount_status_label(status))}</b>\n"
        f"شروع: {display_dt(item.get('starts_at'))}\n"
        f"پایان: {display_dt(item.get('expires_at'))}\n"
        f"استفاده: <b>{int(item.get('used_count', 0))}</b> / <b>{int(item.get('max_uses', 0)) or 'نامحدود'}</b>\n"
        f"سقف هر کاربر: <b>{int(item.get('max_uses_per_user', 1) or 0) or 'نامحدود'}</b>\n\n"
        f"📦 پلن‌های مجاز: <code>{esc(plans)}</code>\n"
        f"🎯 گروه‌های CRM: <code>{esc(segments)}</code>\n"
        f"💳 روش پرداخت: <code>{esc(payments)}</code>\n"
        f"👤 نوع مشتری: <code>{esc(customer_types)}</code>\n"
        f"💰 بازه سفارش: <b>{min_amount:,}</b> تا <b>{max_amount:,}</b> تومان"
        + ("\n" if max_amount else " (بدون سقف)\n") +
        f"🆕 فقط خرید اول: <b>{'بله' if item.get('first_purchase_only') else 'خیر'}</b>\n"
        f"♻️ فقط تمدید: <b>{'بله' if item.get('renewal_only') else 'خیر'}</b>\n"
        f"🤝 معرف: <code>{esc(affiliate)}</code> | پورسانت <b>{commission}٪</b>\n"
        f"🛡 ضدتقلب: <b>{'فعال' if item.get('fraud_protection_enabled', True) else 'غیرفعال'}</b>\n"
        f"↩️ آزادسازی بعد رد: <b>{'بله' if item.get('release_on_reject', True) else 'خیر'}</b> | "
        f"بازگردانی بعد بازپرداخت کامل: <b>{'بله' if item.get('restore_on_full_refund') else 'خیر'}</b>"
    )
    rows: list[list[InlineKeyboardButton]] = []
    rows.append([InlineKeyboardButton("⚙️ ویرایش قوانین کمپین", callback_data=f"public_discount_edit:{code}")])
    rows.append([
        InlineKeyboardButton("📊 گزارش", callback_data=f"public_discount_report:{code}"),
        InlineKeyboardButton("🎫 کد یک‌بارمصرف", callback_data=f"public_discount_batch:{code}"),
    ])
    rows.append([InlineKeyboardButton("🤝 معرف و پورسانت", callback_data=f"public_discount_affiliate:{code}")])
    if status != "expired":
        rows.append([
            state_button(
                "وضعیت کمپین",
                status == "active",
                callback_data=f"public_discount_toggle:{code}",
                enabled_label="فعال",
                disabled_label="غیرفعال",
            )
        ])
        rows.append([InlineKeyboardButton("⛔ منقضی‌کردن فوری", callback_data=f"public_discount_expire:{code}")])
    if status == "active":
        rows.append([InlineKeyboardButton("📣 ارسال به همه کاربران", callback_data=f"public_discount_broadcast:{code}")])
        rows.append([InlineKeyboardButton("🎯 ارسال و محدودسازی به گروه CRM", callback_data=f"public_discount_segment:{code}")])
    rows.append([InlineKeyboardButton("↩️ فهرست کدهای عمومی", callback_data="a_public_discounts")])
    return text_value[:3900], rows


async def public_discount_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    # Calling public_discount_codes synchronizes automatic expiry before display.
    await async_with_db(lambda db: public_discount_codes(db))
    item = (await async_snapshot()).get("discount_codes", {}).get(code)
    if not isinstance(item, dict) or item.get("scope") != "public":
        await edit(query, "کد عمومی پیدا نشد.", [[InlineKeyboardButton("↩️ فهرست کدهای عمومی", callback_data="a_public_discounts")]])
        return
    text_value, rows = _public_discount_detail_payload(item)
    await edit(query, text_value, rows)


async def public_discount_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    code = str(query.data).split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: toggle_public_discount(db, code))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(f"وضعیت: {_public_discount_status_label(item['status'])}", show_alert=True)
    text_value, rows = _public_discount_detail_payload(item)
    await edit(query, text_value, rows)


async def public_discount_expire_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    code = str(query.data).split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: expire_public_discount(db, code, expired_by=query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "public_discount_expire", str(code).upper()))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("کد فوراً منقضی شد", show_alert=True)
    text_value, rows = _public_discount_detail_payload(item)
    await edit(query, text_value, rows)


async def public_discount_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    item = (await async_snapshot()).get("discount_codes", {}).get(code)
    if not isinstance(item, dict):
        await query.answer("کد پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["public_campaign_edit_code"] = code
    await edit(
        query,
        "⚙️ <b>ویرایش قوانین کمپین</b>\n\n"
        "تنظیم‌ها را با قالب <code>کلید=مقدار</code> و جداکننده <code>|</code> بفرستید.\n\n"
        "نمونه کامل:\n"
        "<code>percent=25 | plans=1,2 | segments=expired_vip,lead | payments=card,usdt | "
        "min=500000 | max=0 | cap=300000 | first=no | renewal=yes | uses=100 | per_user=1 | "
        "reject=yes | refund=yes | fraud=yes</code>\n\n"
        "برای حذف محدودیت یک فهرست، مقدار <code>all</code> بفرستید. "
        "کلیدهای دیگر: <code>customers</code>، <code>start</code>، <code>end</code>، <code>weekdays</code>، "
        "<code>hour_start</code>، <code>hour_end</code>، <code>sale_plans</code>.",
        back(f"public_discount_view:{code}"),
    )
    return PUBLIC_CAMPAIGN_EDIT_INPUT


async def public_discount_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    code = str(context.user_data.get("public_campaign_edit_code") or "").upper()
    if not code:
        await reply(update, "❌ اطلاعات کمپین از دست رفته است.")
        return ConversationHandler.END
    try:
        changes = parse_campaign_update_text(update.effective_message.text or "")
        item = await async_with_db(
            lambda db: update_discount_campaign(db, code, changes, admin_id=update.effective_user.id)
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "discount_campaign_update", f"{code}:{sorted(changes)}"))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PUBLIC_CAMPAIGN_EDIT_INPUT
    context.user_data.pop("public_campaign_edit_code", None)
    text_value, rows = _public_discount_detail_payload(item)
    await reply(update, "✅ قوانین کمپین بروزرسانی شد.\n\n" + text_value, rows)
    return ConversationHandler.END


async def public_discount_batch_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    context.user_data["public_batch_parent"] = code
    await edit(
        query,
        "🎫 <b>تولید گروهی کد یک‌بارمصرف</b>\n\nقالب: <code>تعداد | پیشوند</code>\n"
        "مثال: <code>50 | NOWRUZ</code>\n\nهر کد تمام قوانین کمپین مادر را به ارث می‌برد و فقط یک‌بار قابل استفاده است.",
        back(f"public_discount_view:{code}"),
    )
    return PUBLIC_BATCH_INPUT


async def public_discount_batch_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    parent = str(context.user_data.get("public_batch_parent") or "").upper()
    raw = str(update.effective_message.text or "")
    parts = [part.strip() for part in raw.split("|", 1)]
    try:
        count = int(_ascii_digits(parts[0]))
        prefix = parts[1] if len(parts) > 1 else parent[:8]
        rows = await async_with_db(
            lambda db: generate_one_time_codes(db, parent, count=count, prefix=prefix, created_by=update.effective_user.id)
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "discount_batch_generate", f"{parent}:{len(rows)}"))
    except (ValueError, IndexError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PUBLIC_BATCH_INPUT
    context.user_data.pop("public_batch_parent", None)
    codes = "\n".join(str(row["code"]) for row in rows)
    chunks = chunk_text(codes, 3500)
    await reply(update, f"✅ <b>{len(rows)}</b> کد یک‌بارمصرف ساخته شد.")
    for index, chunk in enumerate(chunks, start=1):
        await reply(update, f"<b>بخش {index}/{len(chunks)}</b>\n<code>{esc(chunk)}</code>")
    await reply(update, "مدیریت کمپین:", [[InlineKeyboardButton("↩️ بازگشت", callback_data=f"public_discount_view:{parent}")]])
    return ConversationHandler.END


async def public_discount_affiliate_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    context.user_data["public_affiliate_code"] = code
    await edit(
        query,
        "🤝 <b>تنظیم معرف و پورسانت</b>\n\nقالب: <code>آیدی عددی معرف | درصد پورسانت</code>\n"
        "مثال: <code>123456789 | 10</code>\nبرای حذف معرف: <code>0 | 0</code>",
        back(f"public_discount_view:{code}"),
    )
    return PUBLIC_AFFILIATE_INPUT


async def public_discount_affiliate_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    code = str(context.user_data.get("public_affiliate_code") or "").upper()
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 1)]
    try:
        if len(parts) != 2:
            raise ValueError("قالب باید آیدی | درصد باشد")
        affiliate_id = _ascii_digits(parts[0])
        commission = int(_ascii_digits(parts[1]))
        if affiliate_id not in {"", "0"} and not affiliate_id.isdigit():
            raise ValueError("آیدی معرف نامعتبر است")
        if not 0 <= commission <= 100:
            raise ValueError("درصد پورسانت باید بین ۰ تا ۱۰۰ باشد")
        item = await async_with_db(
            lambda db: update_discount_campaign(
                db,
                code,
                {"affiliate_user_id": "" if affiliate_id == "0" else affiliate_id, "affiliate_commission_percent": commission},
                admin_id=update.effective_user.id,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "discount_affiliate_update", f"{code}:{affiliate_id}:{commission}"))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PUBLIC_AFFILIATE_INPUT
    context.user_data.pop("public_affiliate_code", None)
    text_value, rows = _public_discount_detail_payload(item)
    await reply(update, "✅ تنظیم معرف ذخیره شد.\n\n" + text_value, rows)
    return ConversationHandler.END


async def public_discount_report_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    try:
        report = await async_with_db(lambda db: campaign_report(db, code))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    text_value = (
        f"📊 <b>گزارش کمپین {esc(code)}</b>\n\n"
        f"کدهای زیرمجموعه: <b>{report['related_code_count']}</b>\n"
        f"ارسال‌شده: <b>{report['distributed']}</b>\n"
        f"تلاش اعتبارسنجی: <b>{report['attempts']}</b> | معتبر: <b>{report['valid_attempts']}</b> | نامعتبر: <b>{report['invalid_attempts']}</b>\n"
        f"رزرو: <b>{report['reservations']}</b>\n"
        f"سفارش موفق: <b>{report['approved_orders']}</b> | معلق: <b>{report['pending_orders']}</b> | رد: <b>{report['rejected_orders']}</b>\n"
        f"بازپرداخت: <b>{report['refunds']}</b>\n"
        f"فروش خالص: <b>{report['revenue']:,} تومان</b>\n"
        f"هزینه تخفیف: <b>{report['discount_total']:,} تومان</b>\n"
        f"پورسانت معرف: <b>{report['affiliate_commission']:,} تومان</b>\n"
        f"نرخ تبدیل ارسال به خرید: <b>{report['conversion_rate']}٪</b>"
    )
    await edit(query, text_value, [[InlineKeyboardButton("↩️ کمپین", callback_data=f"public_discount_view:{code}")]])


async def public_discount_segment_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    if not _has_admin_permission(query.from_user.id, PERMISSION_CRM):
        await query.answer("برای ارسال گروهی، دسترسی CRM لازم است.", show_alert=True)
        return
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    await async_with_db(lambda db: public_discount_codes(db))
    item = (await async_snapshot()).get("discount_codes", {}).get(code)
    if not isinstance(item, dict) or item.get("scope") != "public" or item.get("status") != "active":
        await edit(query, "کد عمومی فعال پیدا نشد.", [[InlineKeyboardButton("↩️ کدهای عمومی", callback_data="a_public_discounts")]])
        return
    snapshot = await async_with_db(crm_segment_snapshot)
    ordered = sorted(snapshot.items(), key=lambda pair: (-len(pair[1]), SEGMENT_LABELS.get(pair[0], pair[0])))
    rows: list[list[InlineKeyboardButton]] = []
    lines = [f"🎯 <b>ارسال کد {esc(code)} به گروه CRM</b>", "", "گروه مقصد را انتخاب کنید:", ""]
    for segment, members in ordered[:24]:
        label = SEGMENT_LABELS.get(segment, segment)
        lines.append(f"• {esc(label)}: <b>{len(members)}</b>")
        rows.append([InlineKeyboardButton(f"{label} · {len(members)}", callback_data=f"pdcseg:{code}:{segment}")])
    if not ordered:
        lines.append("گروه فعالی وجود ندارد.")
    rows.append([InlineKeyboardButton("↩️ مدیریت کد", callback_data=f"public_discount_view:{code}")])
    await edit(query, "\n".join(lines)[:3900], rows)


async def public_discount_segment_do(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    if not _has_admin_permission(query.from_user.id, PERMISSION_CRM):
        await query.answer("دسترسی CRM لازم است.", show_alert=True)
        return
    await query.answer("در حال ساخت صف…")
    _, code, segment = str(query.data).split(":", 2)
    code = code.upper()
    await async_with_db(lambda current: public_discount_codes(current))
    db = await async_snapshot()
    item = db.get("discount_codes", {}).get(code)
    if not isinstance(item, dict) or item.get("scope") != "public" or item.get("status") != "active":
        await edit(query, "کد فعال نیست.", [[InlineKeyboardButton("↩️ کدهای عمومی", callback_data="a_public_discounts")]])
        return
    member_ids = await async_with_db(crm_segment_snapshot).get(segment, [])
    recipients = [int(uid) for uid in member_ids if str(uid).isdigit()]
    if not recipients:
        await edit(
            query,
            "در این گروه کاربری وجود ندارد.",
            [[InlineKeyboardButton("↩️ انتخاب گروه", callback_data=f"public_discount_segment:{code}")]],
        )
        return
    label = SEGMENT_LABELS.get(segment, segment)
    message = (
        f"🎉 <b>کد تخفیف عمومی {int(item.get('percent', 0))}٪</b>\n\n"
        f"کد: <code>{code}</code>\n"
        f"مهلت استفاده: <b>{display_dt(item.get('expires_at'))}</b>\n\n"
        "از بخش خرید اشتراک، پلن را انتخاب و این کد را وارد کنید."
    )
    job = await async_with_db(
        lambda current: enqueue_broadcast(
            current,
            admin_id=query.from_user.id,
            segment=f"crm:{segment}:public_discount:{code}",
            recipients=recipients,
            message=message,
            priority="low",
        )
    )
    await async_with_db(
        lambda current: (
            register_discount_distribution(
                current, code, recipients, segment=segment, campaign_job_id=str(job["id"])
            ),
            audit(
                current, query.from_user.id, "public_discount_segment_broadcast",
                f"{code}:{segment}:{job['id']}:{len(recipients)}"
            ),
        )
    )
    await edit(
        query,
        f"✅ کد برای گروه <b>{esc(label)}</b> در صف قرار گرفت.\nشناسه صف: <code>{job['id']}</code>\nگیرندگان: <b>{len(recipients)}</b>",
        [
            [
                InlineKeyboardButton("📣 مشاهده صف ارسال", callback_data="broadcast_queue_panel"),
                InlineKeyboardButton("↩️ مدیریت کد", callback_data=f"public_discount_view:{code}"),
            ]
        ],
    )


async def public_discount_broadcast_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    code = str(query.data).split(":", 1)[1].upper()
    await async_with_db(lambda db: public_discount_codes(db))
    item = (await async_snapshot()).get("discount_codes", {}).get(code)
    if not isinstance(item, dict) or item.get("scope") != "public" or item.get("status") != "active":
        await query.answer("کد فعال پیدا نشد", show_alert=True)
        return
    count = len((await async_snapshot()).get("users", {}))
    await edit(
        query,
        f"📣 کد <code>{code}</code> برای <b>{count}</b> کاربر در صف ارسال همگانی قرار بگیرد؟",
        [
            [InlineKeyboardButton("✅ تأیید و افزودن به صف", callback_data=f"public_discount_broadcast_do:{code}")],
            [InlineKeyboardButton("❌ انصراف", callback_data=f"public_discount_view:{code}")],
        ],
    )


async def public_discount_broadcast_do(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer("در حال ساخت صف…")
    code = str(query.data).split(":", 1)[1].upper()
    await async_with_db(lambda current: public_discount_codes(current))
    db = await async_snapshot()
    item = db.get("discount_codes", {}).get(code)
    if not isinstance(item, dict) or item.get("scope") != "public" or item.get("status") != "active":
        await query.answer("کد فعال نیست", show_alert=True)
        return
    recipients = [int(uid) for uid in db.get("users", {}) if str(uid).isdigit()]
    message = (
        f"🎉 <b>کد تخفیف عمومی {int(item.get('percent', 0))}٪</b>\n\n"
        f"کد: <code>{code}</code>\n"
        f"مهلت استفاده: <b>{display_dt(item.get('expires_at'))}</b>\n\n"
        "از بخش خرید اشتراک، پلن را انتخاب و این کد را وارد کنید."
    )
    job = await async_with_db(
        lambda current: enqueue_broadcast(
            current,
            admin_id=query.from_user.id,
            segment=f"public_discount:{code}",
            recipients=recipients,
            message=message,
        )
    )
    await async_with_db(
        lambda current: (
            register_discount_distribution(
                current, code, recipients, segment="", campaign_job_id=str(job["id"])
            ),
            audit(current, query.from_user.id, "public_discount_broadcast", f"{code}:{job['id']}:{len(recipients)}"),
        )
    )
    await edit(
        query,
        f"✅ ارسال کد در صف قرار گرفت.\nشناسه صف: <code>{job['id']}</code>\nگیرندگان: <b>{len(recipients)}</b>",
        [
            [
                InlineKeyboardButton("📣 مشاهده صف ارسال", callback_data="broadcast_queue_panel"),
                InlineKeyboardButton("↩️ کد", callback_data=f"public_discount_view:{code}"),
            ]
        ],
    )


async def a_crm_segments(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    snapshot = await async_with_db(crm_segment_snapshot)
    ordered = sorted(snapshot.items(), key=lambda item: (-len(item[1]), SEGMENT_LABELS.get(item[0], item[0])))
    lines = [
        "🧩 <b>تقسیم خودکار مشتریان در CRM</b>",
        "",
        "گروه‌ها از خرید، فعالیت، وضعیت VIP، قیف فروش و استفاده از تخفیف ساخته می‌شوند.",
        "",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for code, members in ordered[:24]:
        label = SEGMENT_LABELS.get(code, code)
        lines.append(f"• {esc(label)}: <b>{len(members)}</b>")
        rows.append([InlineKeyboardButton(f"{label} · {len(members)}", callback_data=f"crm_segment:{code}:0")])
    if not ordered:
        lines.append("هنوز اطلاعات کافی برای گروه‌بندی وجود ندارد.")
    rows.append([InlineKeyboardButton("↩️ کاربران و CRM", callback_data="admin_cat:users")])
    await edit(query, "\n".join(lines)[:3900], rows)


async def crm_segment_members(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    _, code, page_text = str(query.data).split(":", 2)
    page = max(0, int(page_text))
    members = (await async_with_db(crm_segment_snapshot)).get(code, [])
    page_size = 10
    total_pages = max(1, (len(members) + page_size - 1) // page_size)
    page = min(page, total_pages - 1)
    selected = members[page * page_size : (page + 1) * page_size]
    db = await async_snapshot()
    rows: list[list[InlineKeyboardButton]] = []
    for uid in selected:
        user = db.get("users", {}).get(uid, {})
        name = str(user.get("first_name") or user.get("username") or uid)
        rows.append([InlineKeyboardButton(f"👤 {name} · {uid}"[:62], callback_data=f"crm_open:{uid}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"crm_segment:{code}:{page - 1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"crm_segment:{code}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton("↩️ گروه‌های CRM", callback_data="a_crm_segments")])
    await edit(
        query, f"🧩 <b>{esc(SEGMENT_LABELS.get(code, code))}</b>\n\nتعداد: <b>{len(members)}</b>\nصفحه {page + 1} از {total_pages}", rows
    )


async def crm_pipeline_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    snapshot = await async_with_db(crm_pipeline_snapshot)
    rows: list[list[InlineKeyboardButton]] = []
    lines = ["📊 <b>خط فروش CRM</b>", ""]
    for stage, label in CRM_STAGES.items():
        count = len(snapshot.get(stage, []))
        lines.append(f"• {esc(label)}: <b>{count:,}</b>")
        rows.append([InlineKeyboardButton(f"{label} · {count}", callback_data=f"crm_pipeline_stage:{stage}:0")])
    due_count = len(await async_with_db(lambda db: due_crm_followups(db, horizon_minutes=1440)))
    lines.extend(["", f"⏰ پیگیری‌های ۲۴ ساعت آینده: <b>{due_count:,}</b>"])
    rows.append([InlineKeyboardButton("🔄 بروزرسانی", callback_data="crm_pipeline"), InlineKeyboardButton("↩️ CRM", callback_data="a_crm")])
    await edit(query, "\n".join(lines), rows)


async def crm_pipeline_stage_members(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    _, stage, page_text = str(query.data).split(":", 2)
    if stage not in CRM_STAGES:
        await query.answer("مرحله نامعتبر است", show_alert=True)
        return
    page = max(0, int(page_text))
    members = (await async_with_db(crm_pipeline_snapshot)).get(stage, [])
    page_size = 10
    total_pages = max(1, (len(members) + page_size - 1) // page_size)
    page = min(page, total_pages - 1)
    db = await async_snapshot()
    rows: list[list[InlineKeyboardButton]] = []
    for uid in members[page * page_size : (page + 1) * page_size]:
        user = db.get("users", {}).get(str(uid), {})
        crm_row = db.get("crm_profiles", {}).get(str(uid), {})
        name = str(user.get("first_name") or user.get("username") or uid)
        score = int(crm_row.get("lead_score", 0) or 0)
        rows.append([InlineKeyboardButton(f"👤 {name} · {score}/100"[:62], callback_data=f"crm_open:{uid}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"crm_pipeline_stage:{stage}:{page - 1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"crm_pipeline_stage:{stage}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton("↩️ خط فروش", callback_data="crm_pipeline")])
    await edit(query, f"🪜 <b>{esc(CRM_STAGES[stage])}</b>\n\nتعداد: <b>{len(members):,}</b>\nصفحه {page + 1} از {total_pages}", rows)


async def crm_stage_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    uid = query.data.split(":", 1)[1]
    if uid not in (await async_snapshot()).get("users", {}):
        await query.answer("کاربر پیدا نشد", show_alert=True)
        return
    rows = [[InlineKeyboardButton(label, callback_data=f"crm_stage_set:{uid}:{stage}")] for stage, label in CRM_STAGES.items()]
    rows.append([InlineKeyboardButton("↩️ پرونده CRM", callback_data=f"crm_open:{uid}")])
    await edit(query, f"🪜 مرحله جدید کاربر <code>{uid}</code> را انتخاب کنید:", rows)


async def crm_stage_set_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    _, uid, stage = str(query.data).split(":", 2)
    try:
        row = await async_with_db(lambda db: set_crm_stage(db, uid, stage, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "crm_stage", f"{uid}:{stage}"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    context.user_data["admin_user_uid"] = uid
    text, rows = _crm_view_payload(uid)
    await edit(query, f"✅ مرحله به <b>{esc(row.get('stage_label'))}</b> تغییر کرد.\n\n{text}", rows)


async def a_vip_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_SETTINGS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    snapshot = await async_snapshot()
    settings = snapshot.get("vip_settings", {})
    usdt_enabled = bool(settings.get("usdt_enabled", False))
    if not usdt_enabled:
        usdt_status = "غیرفعال ⛔"
    elif usdt_payment_settings_ready(snapshot):
        usdt_status = "فعال و آماده ✅"
    else:
        usdt_status = "فعال اما ناقص ⚠️"
    rows = [
        [InlineKeyboardButton("🧩 مدیریت پلن‌های فروش", callback_data="a_vip_plans")],
        [InlineKeyboardButton("💰 قیمت پیش‌فرض قدیمی", callback_data="vip_field:price")],
        [InlineKeyboardButton("💳 تغییر شماره کارت", callback_data="vip_field:card_number")],
        [InlineKeyboardButton("👤 تغییر نام صاحب کارت", callback_data="vip_field:owner_name")],
        [
            state_button(
                "پرداخت تتر",
                bool(usdt_enabled and usdt_payment_settings_ready(snapshot)),
                callback_data="vip_usdt_toggle",
                enabled_label="فعال و آماده",
                disabled_label="خاموش یا ناقص",
            )
        ],
        [
            InlineKeyboardButton("👛 آدرس کیف پول تتر", callback_data="vip_field:usdt_wallet_address"),
            InlineKeyboardButton("🌐 شبکه تتر", callback_data="vip_field:usdt_network"),
        ],
        [InlineKeyboardButton("💱 نرخ هر USDT به تومان", callback_data="vip_field:usdt_rate_toman")],
        [InlineKeyboardButton("⏱ اعتبار نرخ تتر (دقیقه)", callback_data="vip_field:usdt_quote_valid_minutes")],
        [InlineKeyboardButton("🗓 مدت پیش‌فرض قدیمی", callback_data="vip_field:duration_days")],
        [InlineKeyboardButton("↩️ فروش و اشتراک", callback_data="admin_cat:sales")],
    ]
    await edit(
        query,
        "💳 <b>تنظیمات VIP و روش‌های پرداخت</b>\n\n"
        f"💰 قیمت: <b>{int(settings.get('price', 0)):,}</b> تومان\n"
        f"💳 کارت: <code>{esc(settings.get('card_number') or '—')}</code>\n"
        f"👤 نام: <b>{esc(settings.get('owner_name') or '—')}</b>\n"
        f"🗓 مدت پیش‌فرض: <b>{int(settings.get('duration_days', 30))} روز</b>\n\n"
        f"₮ پرداخت تتر: <b>{usdt_status}</b>\n"
        f"🌐 شبکه: <b>{esc(settings.get('usdt_network') or 'TRC20')}</b>\n"
        f"👛 کیف پول: <code>{esc(settings.get('usdt_wallet_address') or '—')}</code>\n"
        f"💱 نرخ هر تتر: <b>{float(settings.get('usdt_rate_toman', 0) or 0):,.0f} تومان</b>\n"
        f"⏱ اعتبار نرخ: <b>{int(settings.get('usdt_quote_valid_minutes', SETTINGS.usdt_quote_valid_minutes) or SETTINGS.usdt_quote_valid_minutes)} دقیقه</b>\n"
        f"🕒 آخرین بروزرسانی نرخ: <b>{display_dt(settings.get('usdt_rate_updated_at'))}</b>\n\n"
        "پس از تأیید فیش کارت یا تتر، همان فرایند استاندارد فعال‌سازی VIP اجرا می‌شود: لینک ورود یک‌بارمصرف ساخته می‌شود و کاربر در پایان مدت پلن از کانال خصوصی حذف خواهد شد.",
        rows,
    )
    return VIP_FIELD_VALUE


async def vip_usdt_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_SETTINGS):
        return ConversationHandler.END
    query = update.callback_query

    def mutate(db: dict[str, Any]) -> bool:
        settings = db.setdefault("vip_settings", {})
        enabled = not bool(settings.get("usdt_enabled", False))
        settings["usdt_enabled"] = enabled
        audit(db, query.from_user.id, "vip_usdt_toggle", "enabled" if enabled else "disabled")
        return enabled

    await async_with_db(mutate)
    return await a_vip_settings(update, context)


async def vip_field_select(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_SETTINGS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    field = query.data.split(":", 1)[1]
    allowed = {
        "price",
        "card_number",
        "owner_name",
        "duration_days",
        "usdt_wallet_address",
        "usdt_network",
        "usdt_rate_toman",
        "usdt_quote_valid_minutes",
    }
    if field not in allowed:
        await query.answer("فیلد نامعتبر است.", show_alert=True)
        return ConversationHandler.END
    context.user_data["vip_field"] = field
    prompts = {
        "price": "💰 قیمت جدید را به تومان وارد کنید:",
        "card_number": "💳 شماره کارت جدید را وارد کنید:",
        "owner_name": "👤 نام صاحب کارت را وارد کنید:",
        "duration_days": "🗓 تعداد روز اشتراک را وارد کنید:",
        "usdt_wallet_address": "👛 آدرس کیف پول تتر را دقیق وارد کنید:",
        "usdt_network": "🌐 نام شبکه تتر را وارد کنید؛ مثال: TRC20 یا BEP20:",
        "usdt_rate_toman": "💱 قیمت هر ۱ تتر را به تومان وارد کنید؛ مثال: 95000:",
        "usdt_quote_valid_minutes": "⏱ مدت اعتبار نرخ پرداخت را بین ۵ تا ۱۴۴۰ دقیقه وارد کنید:",
    }
    await edit(query, prompts[field], back("a_vip_settings"))
    return VIP_FIELD_VALUE


async def vip_field_value(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_SETTINGS):
        return ConversationHandler.END
    field = context.user_data.get("vip_field")
    raw = (update.message.text or "").strip()
    allowed = {
        "price",
        "card_number",
        "owner_name",
        "duration_days",
        "usdt_wallet_address",
        "usdt_network",
        "usdt_rate_toman",
        "usdt_quote_valid_minutes",
    }
    if field not in allowed:
        await reply(update, "❌ ابتدا یک فیلد را از پنل انتخاب کنید.")
        return ConversationHandler.END
    try:
        if field == "price":
            value: Any = parse_positive_int(_ascii_digits(raw), maximum=10_000_000_000)
        elif field == "duration_days":
            value = parse_positive_int(_ascii_digits(raw), maximum=3650)
        elif field == "card_number":
            value = _normalize_card_number(raw)
        elif field == "usdt_rate_toman":
            value = parse_positive_int(_ascii_digits(raw.replace(",", "")), maximum=10_000_000_000)
        elif field == "usdt_quote_valid_minutes":
            value = parse_positive_int(_ascii_digits(raw.replace(",", "")), maximum=1440)
            if value < 5:
                raise ValueError("اعتبار نرخ باید حداقل ۵ دقیقه باشد.")
        elif field == "usdt_wallet_address":
            if not 10 <= len(raw) <= 160 or any(char.isspace() or ord(char) < 33 for char in raw):
                raise ValueError("آدرس کیف پول باید بین ۱۰ تا ۱۶۰ کاراکتر و بدون فاصله باشد.")
            value = raw
        elif field == "usdt_network":
            value = raw.upper()
            if not 2 <= len(value) <= 32 or any(ord(char) < 33 for char in value):
                raise ValueError("نام شبکه باید بین ۲ تا ۳۲ کاراکتر معتبر باشد.")
        else:
            if not 2 <= len(raw) <= 60 or any(ord(char) < 32 for char in raw):
                raise ValueError("نام صاحب کارت باید بین ۲ تا ۶۰ کاراکتر معتبر باشد.")
            value = raw
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_FIELD_VALUE

    def mutate(db: dict) -> None:
        settings = db.setdefault("vip_settings", {})
        if field == "usdt_network":
            normalized = normalize_network(str(value))
            if normalized not in {"TRC20", "ERC20", "BEP20"}:
                raise ValueError("فقط شبکه‌های TRC20، ERC20 و BEP20 پشتیبانی می‌شوند.")
            settings[field] = normalized
        elif field == "usdt_wallet_address":
            network = normalize_network(str(settings.get("usdt_network") or "TRC20"))
            if not wallet_valid(network, str(value)):
                raise ValueError("فرمت آدرس کیف پول با شبکه انتخاب‌شده مطابقت ندارد.")
            settings[field] = value
        else:
            settings[field] = value
        if field == "usdt_rate_toman":
            settings["usdt_rate_updated_at"] = utc_iso()
        safe_detail = f"{field}=updated" if field in {"card_number", "owner_name", "usdt_wallet_address"} else f"{field}={value}"
        audit(db, update.effective_user.id, "vip_setting", safe_detail)

    try:
        await async_with_db(mutate)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_FIELD_VALUE
    context.user_data.pop("vip_field", None)
    await reply(update, "✅ تنظیمات ذخیره شد.", [[InlineKeyboardButton("🔙 تنظیمات VIP", callback_data="a_vip_settings")]])
    return ConversationHandler.END


def _discount_stock_text(db: dict[str, Any]) -> str:
    stock = discount_stock_snapshot(db)
    return " | ".join(f"{tier}٪: {stock[tier]}" for tier in DISCOUNT_TIERS)


async def a_disc(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    await async_with_db(ensure_discount_system)
    db = await async_snapshot()
    rows = [
        [InlineKeyboardButton("🌐 کدهای عمومی زمان‌دار", callback_data="a_public_discounts")],
        [InlineKeyboardButton("📦 شارژ موجودی کدهای اختصاصی", callback_data="disc_create")],
        [InlineKeyboardButton("📤 ارسال کد اختصاصی به کاربر", callback_data="disc_send")],
        [InlineKeyboardButton("🎲 ارسال رندوم به چند کاربر", callback_data="disc_random")],
        [InlineKeyboardButton("📋 موجودی و آخرین کدها", callback_data="disc_list")],
        [InlineKeyboardButton("↩️ فروش و اشتراک", callback_data="admin_cat:sales")],
    ]
    await edit(
        query,
        "🎟 <b>مدیریت کدهای تخفیف</b>\n\n"
        "پنج دسته ثابت فعال هستند: ۱۰، ۲۰، ۳۰، ۴۰ و ۵۰ درصد؛ موجودی پایه هر دسته ۵۰ کد است.\n"
        f"📦 موجودی فعلی: <code>{_discount_stock_text(db)}</code>",
        rows,
    )
    return ConversationHandler.END


async def disc_create_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    stock = discount_stock_snapshot(await async_snapshot())
    rows = [[InlineKeyboardButton(f"{tier}٪ — موجودی {stock[tier]}", callback_data=f"disc_percent:{tier}")] for tier in DISCOUNT_TIERS]
    rows.append(back("a_disc")[0])
    await edit(query, "دسته را انتخاب کنید؛ سپس تعداد تولید را از ۵ تا ۵۰ مشخص کنید:", rows)
    return DISC_PERCENT


async def disc_percent_select(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    percent = int(query.data.split(":", 1)[1])
    stock = discount_stock_snapshot(await async_snapshot()).get(percent, 0)
    counts = (5, 10, 20, 30, 40, 50)
    rows = [
        [InlineKeyboardButton(f"➕ ساخت {count} کد", callback_data=f"disc_refill_do:{percent}:{count}")]
        for count in counts
    ]
    rows.append([InlineKeyboardButton("❌ انصراف", callback_data="a_disc")])
    await edit(
        query,
        f"🎟 دسته <b>{percent}٪</b>\nموجودی فعلی: <b>{stock}</b>\n\nچند کد جدید ساخته شود؟",
        rows,
    )
    return DISC_PERCENT


async def disc_refill_do(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")
    try:
        percent = int(parts[1])
        count = int(parts[2]) if len(parts) > 2 else 5
        if count not in {5, 10, 20, 30, 40, 50}:
            raise ValueError("تعداد تولید نامعتبر است")
    except (ValueError, IndexError) as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END

    def refill(db: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[int, int]]:
        created = refill_discount_pool(db, percent, count=count)
        audit(db, query.from_user.id, "discount_pool_refill", f"{percent}% x{count}")
        return created, discount_stock_snapshot(db)

    created, stock = await async_with_db(refill)
    codes = "\n".join(f"<code>{esc(item['code'])}</code>" for item in created)
    chunks = chunk_text(codes, 3400)
    await edit(
        query,
        f"✅ <b>{len(created)}</b> کد {percent}٪ ساخته شد.\n📦 موجودی جدید: <b>{stock[percent]}</b>",
        back("a_disc"),
    )
    for index, chunk in enumerate(chunks, start=1):
        await query.message.reply_text(
            f"<b>کدهای ساخته‌شده {index}/{len(chunks)}</b>\n{chunk}",
            parse_mode=ParseMode.HTML,
        )
    return ConversationHandler.END


async def disc_send_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "👤 آیدی عددی یا نام کاربری کاربر را بفرستید.\n\n"
        "نمونه: <code>123456789</code> یا <code>@username</code>\n"
        "برای ارسال با نام کاربری، کاربر باید حداقل یک‌بار ربات را Start کرده باشد.",
        back("a_disc"),
    )
    return DISC_SEND_UID


async def disc_send_uid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    try:
        uid = resolve_registered_user_id((await async_snapshot()), update.effective_message.text)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return DISC_SEND_UID
    context.user_data["disc_target_uid"] = uid
    stock = discount_stock_snapshot(await async_snapshot())
    rows = [[InlineKeyboardButton(f"{tier}٪ — موجودی {stock[tier]}", callback_data=f"disc_send_percent:{tier}")] for tier in DISCOUNT_TIERS]
    rows.append(back("a_disc")[0])
    await reply(update, f"کاربر <code>{uid}</code> انتخاب شد. درصد را انتخاب کنید:", rows)
    return DISC_SEND_PERCENT


async def disc_send_percent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    uid = context.user_data.get("disc_target_uid")
    if not uid:
        await query.answer("شناسه کاربر موجود نیست؛ دوباره شروع کنید.", show_alert=True)
        return ConversationHandler.END
    percent = int(query.data.split(":", 1)[1])

    def assign(db: dict[str, Any]) -> tuple[dict[str, Any], bool, int]:
        item, auto_created = assign_discount_from_pool(
            db,
            percent,
            uid,
            issued_via=f"admin:{query.from_user.id}",
            allow_auto_create=True,
        )
        remaining = discount_stock_snapshot(db)[percent]
        record_user_reward(
            db,
            uid,
            f"کد تخفیف {percent}٪",
            reward_type="discount",
            detail=item["code"],
            source="admin_discount",
            status="delivered",
            reference_id=item["code"],
        )
        audit(db, query.from_user.id, "send_discount", f"{item['code']}->{uid}")
        return item, auto_created, remaining

    item, auto_created, remaining = await async_with_db(assign)
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            uid,
            f"🎟 کد تخفیف اختصاصی <b>{percent}٪</b> شما:\n<code>{item['code']}</code>\nمهلت: {display_dt(item['expires_at'])}",
            parse_mode=ParseMode.HTML,
        )
    except TelegramError:
        logger.exception("Could not send discount to user %s", uid)
        await async_with_db(
            lambda db: (return_discount_to_pool(db, item["code"], uid), update_reward_status(db, item["code"], "cancelled"))
        )
        await edit(
            query,
            "⚠️ ارسال تلگرام ناموفق بود و کد دوباره به موجودی برگشت. کاربر باید ابتدا ربات را Start کند.",
            back("a_disc"),
        )
        return ConversationHandler.END
    source_note = "\nℹ️ موجودی خالی بود و ربات یک کد جدید ساخت." if auto_created else ""
    await edit(
        query,
        f"✅ کد <code>{item['code']}</code> برای کاربر <code>{uid}</code> ارسال شد.\n"
        f"📦 موجودی باقی‌مانده دسته {percent}٪: <b>{remaining}</b>{source_note}",
        back("a_disc"),
    )
    context.user_data.pop("disc_target_uid", None)
    return ConversationHandler.END


async def disc_random_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    stock = discount_stock_snapshot(await async_snapshot())
    rows = [
        [InlineKeyboardButton(f"{tier}٪ — موجودی {stock[tier]}", callback_data=f"disc_random_percent:{tier}")] for tier in DISCOUNT_TIERS
    ]
    rows.append(back("a_disc")[0])
    await edit(query, "🎲 دسته تخفیف برای ارسال تصادفی را انتخاب کنید:", rows)
    return DISC_RANDOM_PERCENT


async def disc_random_percent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["disc_random_percent"] = int(query.data.split(":", 1)[1])
    eligible = len(random_reward_recipients((await async_snapshot()), 10_000))
    await edit(query, f"تعداد برندگان را وارد کنید. کاربران واجد شرایط: <b>{eligible}</b>\nحداکثر ۱۰۰ نفر.", back("a_disc"))
    return DISC_RANDOM_COUNT


async def disc_random_count(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return ConversationHandler.END
    try:
        count = int((update.effective_message.text or "").strip())
        if not 1 <= count <= 100:
            raise ValueError("تعداد باید بین ۱ تا ۱۰۰ باشد")
        percent = int(context.user_data["disc_random_percent"])
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return DISC_RANDOM_COUNT
    recipients = random_reward_recipients((await async_snapshot()), count)
    if not recipients:
        await reply(update, "❌ کاربر واجد شرایطی وجود ندارد.", back("a_disc"))
        return ConversationHandler.END
    sent: list[int] = []
    failed: list[int] = []
    for uid in recipients:

        def assign(db: dict[str, Any], user_id: int = uid):
            item, _ = assign_discount_from_pool(
                db, percent, user_id, issued_via=f"random:{update.effective_user.id}", allow_auto_create=True
            )
            record_user_reward(
                db,
                user_id,
                f"کد تخفیف تصادفی {percent}٪",
                reward_type="discount",
                detail=item["code"],
                source="admin_random_discount",
                status="delivered",
                reference_id=item["code"],
            )
            return item

        item = await async_with_db(assign)
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                uid,
                f"🎉 شما به‌صورت تصادفی برنده کد تخفیف <b>{percent}٪</b> شدید!\n<code>{item['code']}</code>\nمهلت: {display_dt(item['expires_at'])}",
                parse_mode=ParseMode.HTML,
            )
            sent.append(uid)
        except TelegramError:
            failed.append(uid)
            await async_with_db(
                lambda db, code=item["code"], user_id=uid: (
                    return_discount_to_pool(db, code, user_id),
                    update_reward_status(db, code, "cancelled"),
                )
            )
        await asyncio.sleep(0.05)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "random_discount", f"{percent}%:{len(sent)}/{len(failed)}"))
    context.user_data.pop("disc_random_percent", None)
    await reply(
        update,
        f"✅ قرعه‌کشی کد تخفیف تمام شد.\nارسال موفق: <b>{len(sent)}</b>\nارسال ناموفق: <b>{len(failed)}</b>",
        back("a_disc"),
    )
    return ConversationHandler.END


async def disc_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_DISCOUNTS):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    codes = list(db.get("discount_codes", {}).values())
    codes.sort(key=lambda item: item.get("created_at", ""), reverse=True)
    lines = [
        "📋 <b>موجودی کدهای تخفیف</b>",
        f"<code>{_discount_stock_text(db)}</code>",
        "",
        "<b>آخرین کدها</b>",
    ]
    for item in codes[:30]:
        lines.append(
            f"• <code>{esc(item.get('code'))}</code> | {int(item.get('percent', 0))}٪ | "
            f"{esc(item.get('status'))} | کاربر: <code>{esc(item.get('assigned_to') or 'موجودی')}</code>"
        )
    if not codes:
        lines.append("کدی وجود ندارد.")
    await edit(query, "\n".join(lines), back("a_disc"))


async def a_edu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_VIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    stats = education_statistics(await async_snapshot())
    rows: list[list[InlineKeyboardButton]] = []
    if _has_admin_permission(query.from_user.id, PERMISSION_EDUCATION_CREATE):
        rows.append([InlineKeyboardButton("➕ افزودن درس", callback_data="cw:mode:education")])
    rows.append([InlineKeyboardButton("📋 مدیریت همه درس‌ها", callback_data="lesson_list")])
    if _has_admin_permission(query.from_user.id, PERMISSION_FEATURE_TOGGLE_MANAGE):
        rows.append([InlineKeyboardButton("🧭 تنظیمات آموزش", callback_data="ecc_mod:edu")])
    rows.append(back("admin_home")[0])
    await edit(
        query,
        "📚 <b>مدیریت کامل آموزش</b>\n\n"
        f"کل: <b>{stats['total']}</b> | منتشرشده: <b>{stats['published']}</b> | "
        f"پیش‌نویس: <b>{stats['drafts']}</b> | آرشیو: <b>{stats['archived']}</b>\n"
        f"بازدید: <b>{stats['views']}</b> | تکمیل درس: <b>{stats['completions']}</b>",
        rows,
    )
    return ConversationHandler.END


async def lesson_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "📚 <b>ساخت آموزش چندرسانه‌ای</b>\n\n"
        "مشخصات درس را در ۸ بخش بفرستید:\n"
        "<code>دسته | دوره | فصل | عنوان | free/paid | قیمت | مدت‌دقیقه | draft/published</code>\n\n"
        "در صورت تمایل، متن اولیه را به‌عنوان بخش نهم اضافه کنید. بعد از ثبت مشخصات می‌توانید "
        "متن، لینک، ویدئو، وویس، فایل صوتی، عکس یا PDF بفرستید.",
        back("a_edu"),
    )
    return LESSON_INPUT


def _education_pricing_changed(current: dict[str, Any] | None, access_type: str, price: int) -> bool:
    normalized_access = str(access_type or "free").strip().lower()
    normalized_price = max(0, int(price or 0))
    if current is None:
        return normalized_access not in {"free", "public"} or normalized_price > 0
    old_access = str(current.get("access_type") or "free").strip().lower()
    old_price = max(0, int(current.get("price") or 0))
    return old_access != normalized_access or old_price != normalized_price


def _mission_rewards_changed(current: dict[str, Any] | None, payload: dict[str, Any]) -> bool:
    reward = max(0, int(payload.get("reward") or 0))
    bonus = max(0, int(payload.get("random_bonus_max") or 0))
    if current is None:
        return reward > 0 or bonus > 0
    return reward != max(0, int(current.get("reward") or 0)) or bonus != max(0, int(current.get("random_bonus_max") or 0))


async def lesson_add_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_CREATE):
        return ConversationHandler.END
    raw = str(update.effective_message.text or "")
    parts = [part.strip() for part in raw.split("|", 8)]
    if len(parts) not in {8, 9}:
        await reply(update, "❌ مشخصات باید ۸ بخش باشد؛ متن اولیه اختیاری و بخش نهم است.")
        return LESSON_INPUT
    category, course, chapter, title, access_type, price_raw, duration_raw, desired_status = parts[:8]
    initial_text = parts[8] if len(parts) == 9 else ""
    desired_status = desired_status.lower()
    if desired_status not in {"draft", "published"}:
        await reply(update, "❌ وضعیت باید draft یا published باشد.")
        return LESSON_INPUT
    try:
        parsed_price = int(price_raw.replace(",", ""))
        parsed_duration = int(duration_raw)
    except ValueError:
        await reply(update, "❌ قیمت و مدت باید عدد معتبر باشند.")
        return LESSON_INPUT
    if _education_pricing_changed(None, access_type, parsed_price) and not _has_admin_permission(
        update.effective_user.id, PERMISSION_EDUCATION_PRICE_MANAGE
    ):
        await reply(update, "❌ برای ساخت آموزش پولی یا تعیین قیمت، دسترسی «مدیریت قیمت آموزش» لازم است.")
        return LESSON_INPUT
    try:
        lesson = await async_with_db(
            lambda db: create_education_lesson(
                db,
                category=category,
                course=course,
                chapter=chapter,
                title=title,
                access_type=access_type,
                price=parsed_price,
                duration_minutes=parsed_duration,
                status="draft",
                text=initial_text,
                actor_id=update.effective_user.id,
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return LESSON_INPUT
    context.user_data["lesson_media_id"] = int(lesson["id"])
    context.user_data["lesson_media_desired_status"] = desired_status
    await async_with_db(lambda db: audit(db, update.effective_user.id, "lesson_add_draft", str(lesson["id"])))
    await reply(
        update,
        f"✅ مشخصات درس <b>{esc(lesson['title'])}</b> ثبت شد.\n\n"
        "حالا محتوا را یکی‌یکی بفرستید: متن، لینک، ویدئو، وویس، فایل صوتی، عکس یا PDF. "
        "برای لینک می‌توانید فقط URL یا قالب «عنوان لینک | https://example.com» را بفرستید. "
        "پس از پایان روی «اتمام و ذخیره» بزنید.",
        [[InlineKeyboardButton("✅ اتمام و ذخیره", callback_data=f"lesson_media_done:{lesson['id']}")],
         [InlineKeyboardButton("❌ لغو و بازگشت", callback_data="a_edu")]],
    )
    return LESSON_MEDIA_INPUT


def _lesson_attachment_from_message(message: Any) -> dict[str, Any] | None:
    caption = str(getattr(message, "caption", "") or "")
    if getattr(message, "animation", None):
        item = message.animation
        return {"type": "animation", "file_id": item.file_id, "file_unique_id": item.file_unique_id, "caption": caption}
    if getattr(message, "video", None):
        item = message.video
        return {"type": "video", "file_id": item.file_id, "file_unique_id": getattr(item, "file_unique_id", ""),
                "file_size": getattr(item, "file_size", 0), "duration": getattr(item, "duration", 0),
                "width": getattr(item, "width", 0), "height": getattr(item, "height", 0),
                "mime_type": getattr(item, "mime_type", "video/mp4"), "file_name": getattr(item, "file_name", ""), "caption": caption}
    if getattr(message, "voice", None):
        item = message.voice
        return {"type": "voice", "file_id": item.file_id, "file_unique_id": getattr(item, "file_unique_id", ""),
                "file_size": getattr(item, "file_size", 0), "duration": getattr(item, "duration", 0),
                "mime_type": getattr(item, "mime_type", "audio/ogg"), "caption": caption}
    if getattr(message, "audio", None):
        item = message.audio
        return {"type": "audio", "file_id": item.file_id, "file_unique_id": getattr(item, "file_unique_id", ""),
                "file_size": getattr(item, "file_size", 0), "duration": getattr(item, "duration", 0),
                "mime_type": getattr(item, "mime_type", "audio/mpeg"), "file_name": getattr(item, "file_name", ""), "caption": caption}
    if getattr(message, "document", None):
        item = message.document
        mime = str(getattr(item, "mime_type", "") or "")
        name = str(getattr(item, "file_name", "") or "")
        kind = "pdf" if mime == "application/pdf" or name.lower().endswith(".pdf") else "document"
        return {"type": kind, "file_id": item.file_id, "file_unique_id": getattr(item, "file_unique_id", ""),
                "file_size": getattr(item, "file_size", 0), "mime_type": mime, "file_name": name, "caption": caption}
    photos = getattr(message, "photo", None) or []
    if photos:
        item = photos[-1]
        return {"type": "photo", "file_id": item.file_id, "file_unique_id": getattr(item, "file_unique_id", ""),
                "file_size": getattr(item, "file_size", 0), "width": getattr(item, "width", 0),
                "height": getattr(item, "height", 0), "caption": caption}
    return None


def _lesson_link_from_text(value: Any) -> dict[str, Any] | None:
    """Parse a dedicated lesson URL without turning ordinary lesson text into a link."""
    raw = str(value or "").strip()
    if not raw:
        return None
    title = ""
    candidate = raw
    if "|" in raw:
        maybe_title, maybe_url = [part.strip() for part in raw.rsplit("|", 1)]
        if maybe_url.lower().startswith(("http://", "https://")):
            title, candidate = maybe_title, maybe_url
    if not candidate.lower().startswith(("http://", "https://")) or any(ch.isspace() for ch in candidate):
        return None
    parsed = urlsplit(candidate)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        return None
    caption = title or str(parsed.hostname or "لینک آموزش")
    return {"type": "link", "url": candidate, "caption": caption[:200]}


async def lesson_media_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    lesson_id = int(query.data.split(":", 1)[1])
    lesson = find_education_lesson((await async_snapshot()), lesson_id)
    if not lesson:
        await query.answer("درس پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["lesson_media_id"] = lesson_id
    context.user_data["lesson_media_desired_status"] = str(lesson.get("status") or "draft")
    await query.answer()
    await edit(
        query,
        f"🎞 <b>محتوای درس #{lesson_id}</b>\n\nمتن، لینک، ویدئو، وویس، فایل صوتی، عکس یا PDF را ارسال کنید. "
        "لینک را به‌صورت URL یا «عنوان | URL» بفرستید. "
        "می‌توانید چند فایل پشت‌سرهم بفرستید.",
        [[InlineKeyboardButton("✅ اتمام", callback_data=f"lesson_media_done:{lesson_id}")],
         [InlineKeyboardButton("↩️ بازگشت به درس", callback_data=f"lesson_manage:{lesson_id}")]],
    )
    return LESSON_MEDIA_INPUT


async def lesson_media_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return ConversationHandler.END
    lesson_id = context.user_data.get("lesson_media_id")
    if not lesson_id:
        await reply(update, "❌ شناسه درس موجود نیست؛ دوباره از مدیریت آموزش وارد شوید.", back("a_edu"))
        return ConversationHandler.END
    message = update.effective_message
    try:
        text_value = str(getattr(message, "text", "") or "").strip()
        if text_value:
            link_payload = _lesson_link_from_text(text_value)
            if link_payload:
                await async_with_db(lambda db: add_lesson_attachment(db, lesson_id, link_payload))
                lesson = find_education_lesson((await async_snapshot()), lesson_id) or {}
                label = "لینک"
            else:
                lesson = await async_with_db(lambda db: append_lesson_text(db, lesson_id, text_value))
                label = "متن"
        else:
            payload = _lesson_attachment_from_message(message)
            if not payload:
                await reply(update, "❌ فقط متن، لینک، ویدئو، وویس، فایل صوتی، عکس و PDF قابل ثبت است.")
                return LESSON_MEDIA_INPUT
            await async_with_db(lambda db: add_lesson_attachment(db, lesson_id, payload))
            lesson = find_education_lesson((await async_snapshot()), lesson_id) or {}
            label = {"video": "ویدئو", "voice": "وویس", "audio": "فایل صوتی", "pdf": "PDF", "photo": "عکس", "document": "فایل"}.get(payload["type"], "فایل")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return LESSON_MEDIA_INPUT
    count = len(lesson.get("attachments") or [])
    await reply(
        update,
        f"✅ {label} اضافه شد. فایل‌های درس: <b>{count}</b>\nمحتوای بعدی را بفرستید یا اتمام را بزنید.",
        [[InlineKeyboardButton("✅ اتمام و ذخیره", callback_data=f"lesson_media_done:{lesson_id}")]],
    )
    return LESSON_MEDIA_INPUT


async def lesson_media_done(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    lesson_id = int(query.data.split(":", 1)[1])
    lesson = find_education_lesson((await async_snapshot()), lesson_id)
    if not lesson or not lesson_has_content(lesson):
        await query.answer("حداقل یک متن یا فایل آموزشی اضافه کنید", show_alert=True)
        return LESSON_MEDIA_INPUT
    desired = str(context.user_data.get("lesson_media_desired_status") or lesson.get("status") or "draft")
    if desired not in {"draft", "published", "archived"}:
        desired = "draft"
    lesson = await async_with_db(lambda db: set_lesson_status(db, lesson_id, desired))
    await async_with_db(lambda db: audit(db, query.from_user.id, "lesson_media_complete", f"{lesson_id}:{len(lesson.get('attachments') or [])}"))
    context.user_data.pop("lesson_media_id", None)
    context.user_data.pop("lesson_media_desired_status", None)
    await query.answer("آموزش ذخیره شد", show_alert=True)
    await edit(
        query,
        f"✅ درس <b>{esc(lesson.get('title'))}</b> با {len(lesson.get('attachments') or [])} فایل و وضعیت <b>{esc(lesson.get('status'))}</b> ذخیره شد.",
        back(f"lesson_manage:{lesson_id}"),
    )
    return ConversationHandler.END


async def lesson_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_VIEW):
        return
    query = update.callback_query
    await query.answer()
    lessons = [item for item in (await async_snapshot()).get("lessons", []) if isinstance(item, dict)]
    lessons.sort(key=lambda item: int(item.get("id", 0) or 0), reverse=True)
    if not lessons:
        await edit(query, "درسی ثبت نشده است.", back("a_edu"))
        return
    rows = [
        [
            InlineKeyboardButton(
                f"{'✅' if item.get('status', 'published') == 'published' else '📝' if item.get('status') == 'draft' else '📦'} "
                f"#{item['id']} | {str(item.get('title'))[:34]}",
                callback_data=f"lesson_manage:{item['id']}",
            )
        ]
        for item in lessons[:80]
    ]
    rows += back("a_edu")
    await edit(query, "📋 <b>مدیریت درس‌ها</b>\nبرای مشاهده ابزارهای کامل، درس را انتخاب کنید:", rows)


def _lesson_manage_payload(lesson: dict[str, Any], admin_id: int | str | None = None) -> tuple[str, list[list[InlineKeyboardButton]]]:
    rating_count = int(lesson.get("rating_count", 0) or 0)
    average = float(lesson.get("rating_total", 0) or 0) / rating_count if rating_count else 0
    attachments = list(lesson.get("attachments") or [])
    can_edit = admin_id is None or _has_admin_permission(admin_id, PERMISSION_EDUCATION_EDIT)
    can_create = admin_id is None or _has_admin_permission(admin_id, PERMISSION_EDUCATION_CREATE)
    can_publish = admin_id is None or _has_admin_permission(admin_id, PERMISSION_EDUCATION_PUBLISH)
    can_delete = admin_id is None or _has_admin_permission(admin_id, PERMISSION_EDUCATION_DELETE)
    rows: list[list[InlineKeyboardButton]] = []
    if can_edit:
        rows.append([InlineKeyboardButton("🎞 افزودن متن/ویدئو/وویس/PDF", callback_data=f"lesson_media_add:{lesson['id']}")])
    edit_row: list[InlineKeyboardButton] = []
    if can_edit:
        edit_row.append(InlineKeyboardButton("✏️ ویرایش مشخصات", callback_data=f"lesson_edit:{lesson['id']}"))
    if can_create:
        edit_row.append(InlineKeyboardButton("📄 کپی", callback_data=f"lesson_duplicate:{lesson['id']}"))
    if edit_row:
        rows.append(edit_row)
    if can_publish:
        rows.append([InlineKeyboardButton("✅ انتشار", callback_data=f"lesson_status:{lesson['id']}:published"), InlineKeyboardButton("📝 پیش‌نویس", callback_data=f"lesson_status:{lesson['id']}:draft"), InlineKeyboardButton("📦 آرشیو", callback_data=f"lesson_status:{lesson['id']}:archived")])
    if can_delete:
        rows.append([InlineKeyboardButton("🗑 حذف دائمی", callback_data=f"lesson_delete:{lesson['id']}")])
    if can_edit:
        rows.extend([[InlineKeyboardButton(f"🗑 حذف فایل {index + 1} · {str(item.get('type') or 'file')}", callback_data=f"lesson_attachment_remove:{lesson['id']}:{index}")] for index, item in enumerate(attachments[:12])])
    rows.extend(back("lesson_list"))
    text = (
        f"📖 <b>درس #{lesson['id']}</b>\n\n"
        f"عنوان: <b>{esc(lesson.get('title'))}</b>\n"
        f"دوره: {esc(lesson.get('course'))} | فصل: {esc(lesson.get('chapter'))}\n"
        f"دسته: {esc(lesson.get('category'))}\n"
        f"نوع: <b>{esc(lesson.get('access_type'))}</b> | قیمت: <b>{int(lesson.get('price', 0) or 0):,}</b>\n"
        f"وضعیت: <b>{esc(lesson.get('status'))}</b> | مدت: <b>{int(lesson.get('duration_minutes', 5) or 5)} دقیقه</b>\n"
        f"بازدید: <b>{int(lesson.get('views', 0) or 0)}</b> | امتیاز: <b>{average:.1f}</b> ({rating_count}) | فایل: <b>{len(attachments)}</b>\n\n"
        f"{esc(str(lesson.get('text') or '')[:1000])}"
    )
    return text, rows


async def lesson_manage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_VIEW):
        return
    query = update.callback_query
    lesson_id = query.data.split(":", 1)[1]
    lesson = find_education_lesson((await async_snapshot()), lesson_id)
    if not lesson:
        await query.answer("درس پیدا نشد", show_alert=True)
        return
    await query.answer()
    text, rows = _lesson_manage_payload(lesson, query.from_user.id)
    await edit(query, text, rows)


async def lesson_attachment_remove_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return
    query = update.callback_query
    _, lesson_id_raw, index_raw = query.data.split(":", 2)
    lesson_id = int(lesson_id_raw)
    index = int(index_raw)
    lesson = find_education_lesson((await async_snapshot()), lesson_id)
    attachments = list((lesson or {}).get("attachments") or [])
    if not lesson or not 0 <= index < len(attachments):
        await query.answer("فایل پیدا نشد", show_alert=True)
        return
    attachment_id = str(attachments[index].get("id") or attachments[index].get("file_unique_id") or attachments[index].get("file_id"))
    await async_with_db(lambda db: remove_lesson_attachment(db, lesson_id, attachment_id))
    await async_with_db(lambda db: audit(db, query.from_user.id, "lesson_attachment_remove", f"{lesson_id}:{index}"))
    await query.answer("فایل حذف شد", show_alert=True)
    refreshed = find_education_lesson((await async_snapshot()), lesson_id)
    if refreshed:
        text, rows = _lesson_manage_payload(refreshed, query.from_user.id)
        await edit(query, text, rows)


async def lesson_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    lesson_id = query.data.split(":", 1)[1]
    lesson = find_education_lesson((await async_snapshot()), lesson_id)
    if not lesson:
        await query.answer("درس پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["lesson_edit_id"] = int(lesson_id)
    await query.answer()
    await edit(
        query,
        "نسخه جدید درس را با قالب زیر ارسال کنید:\n<code>دسته | دوره | فصل | عنوان | free/paid | قیمت | مدت‌دقیقه | متن</code>",
        back(f"lesson_manage:{lesson_id}"),
    )
    return LESSON_EDIT_INPUT


async def lesson_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_EDUCATION_EDIT):
        return ConversationHandler.END
    lesson_id = context.user_data.get("lesson_edit_id")
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 7)]
    if len(parts) != 8:
        await reply(update, "❌ قالب باید دقیقاً ۸ بخش داشته باشد.")
        return LESSON_EDIT_INPUT
    category, course, chapter, title, access_type, price, duration, text = parts
    try:
        parsed_price = int(price.replace(",", ""))
        parsed_duration = int(duration)
    except ValueError:
        await reply(update, "❌ قیمت و مدت باید عدد معتبر باشند.")
        return LESSON_EDIT_INPUT
    current_lesson = find_education_lesson((await async_snapshot()), lesson_id)
    if not current_lesson:
        await reply(update, "❌ درس پیدا نشد.")
        return ConversationHandler.END
    if _education_pricing_changed(current_lesson, access_type, parsed_price) and not _has_admin_permission(
        update.effective_user.id, PERMISSION_EDUCATION_PRICE_MANAGE
    ):
        await reply(update, "❌ برای تغییر نوع دسترسی یا قیمت، دسترسی «مدیریت قیمت آموزش» لازم است.")
        return LESSON_EDIT_INPUT
    try:
        lesson = await async_with_db(
            lambda db: update_education_lesson(
                db,
                lesson_id,
                category=category,
                course=course,
                chapter=chapter,
                title=title,
                access_type=access_type,
                price=parsed_price,
                duration_minutes=parsed_duration,
                text=text,
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return LESSON_EDIT_INPUT
    context.user_data.pop("lesson_edit_id", None)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "lesson_edit", str(lesson["id"])))
    await reply(update, f"✅ درس #{lesson['id']} ویرایش شد.", back(f"lesson_manage:{lesson['id']}"))
    return ConversationHandler.END


async def lesson_status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_PUBLISH):
        return
    query = update.callback_query
    _, lesson_id, status = query.data.split(":", 2)
    current = find_education_lesson((await async_snapshot()), lesson_id)
    if status == "published" and (not current or not lesson_has_content(current)):
        await query.answer("برای انتشار، حداقل یک متن یا فایل آموزشی اضافه کنید", show_alert=True)
        return
    try:
        lesson = await async_with_db(lambda db: set_lesson_status(db, lesson_id, status))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "lesson_status", f"{lesson_id}:{status}"))
    await query.answer("وضعیت درس تغییر کرد", show_alert=True)
    rows = [[InlineKeyboardButton("🔙 بازگشت به درس", callback_data=f"lesson_manage:{lesson['id']}")]]
    await edit(query, f"✅ وضعیت درس #{lesson['id']} به <b>{esc(status)}</b> تغییر کرد.", rows)


async def lesson_duplicate_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_CREATE):
        return
    query = update.callback_query
    lesson_id = query.data.split(":", 1)[1]
    try:
        lesson = await async_with_db(lambda db: duplicate_lesson(db, lesson_id, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "lesson_duplicate", f"{lesson_id}->{lesson['id']}"))
    await query.answer("کپی به‌صورت پیش‌نویس ساخته شد", show_alert=True)
    await edit(
        query,
        f"✅ کپی درس با شناسه <b>#{lesson['id']}</b> ساخته شد.",
        back(f"lesson_manage:{lesson['id']}"),
    )


async def lesson_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EDUCATION_DELETE):
        return
    query = update.callback_query
    lesson_id = query.data.split(":", 1)[1]
    lesson = await async_with_db(lambda db: delete_education_lesson(db, lesson_id))
    if not lesson:
        await query.answer("درس پیدا نشد", show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "lesson_delete", str(lesson_id)))
    await query.answer("درس حذف شد", show_alert=True)
    await edit(query, f"✅ درس <b>{esc(lesson.get('title'))}</b> حذف شد.", back("lesson_list"))


async def a_missions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_VIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    missions = [item for item in (await async_snapshot()).get("missions", []) if isinstance(item, dict)]
    active_count = sum(bool(item.get("active", True)) for item in missions)
    rows: list[list[InlineKeyboardButton]] = []
    if _has_admin_permission(query.from_user.id, PERMISSION_MISSION_CREATE):
        rows.append([InlineKeyboardButton("➕ افزودن مأموریت", callback_data="cw:mode:mission")])
    if _has_admin_permission(query.from_user.id, PERMISSION_MISSION_EVIDENCE_REVIEW):
        rows.append([InlineKeyboardButton("🎁 تکمیل دستی برای کاربر", callback_data="mission_manual")])
    if _has_admin_permission(query.from_user.id, PERMISSION_FEATURE_TOGGLE_MANAGE):
        rows.append([InlineKeyboardButton("🧭 تنظیمات مأموریت", callback_data="ecc_mod:missions")])
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    f"{'✅' if item.get('active', True) else '⛔️'} #{item.get('id')} — {str(item.get('title'))[:32]}",
                    callback_data=f"mission_manage:{item.get('id')}",
                )
            ]
            for item in sorted(missions, key=lambda row: int(row.get("id", 0) or 0), reverse=True)[:60]
        ]
    )
    rows += back("admin_home")
    await edit(
        query,
        "✅ <b>مدیریت کامل مأموریت‌ها</b>\n\n"
        f"کل: <b>{len(missions)}</b> | فعال: <b>{active_count}</b> | غیرفعال: <b>{len(missions) - active_count}</b>\n"
        "رویداد، هدف، دوره تکرار، بازه زمانی و پاداش از داخل هر مأموریت قابل مدیریت است.",
        rows,
    )
    return ConversationHandler.END


async def mission_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    events = "، ".join(sorted(MISSION_EVENTS))
    await edit(
        query,
        "مأموریت را با قالب زیر ارسال کنید:\n"
        "<code>عنوان | امتیاز | event | target | period | active | start | end | random_bonus | توضیح</code>\n\n"
        "period: <code>one_time/daily/weekly/monthly</code>\n"
        "active: <code>on/off</code>\n"
        "start/end: زمان ISO یا <code>-</code>\n"
        f"eventها: <code>{esc(events)}</code>",
        back("a_missions"),
    )
    return MISSION_INPUT


def _parse_mission_payload(raw: str) -> dict[str, Any]:
    parts = [part.strip() for part in raw.split("|", 9)]
    if len(parts) != 10:
        raise ValueError("قالب باید دقیقاً ۱۰ بخش داشته باشد")
    title, reward_raw, event, target_raw, period, active_raw, start, end, bonus_raw, description = parts
    active_text = active_raw.casefold()
    if active_text not in {"on", "off", "true", "false", "1", "0", "فعال", "غیرفعال"}:
        raise ValueError("active باید on یا off باشد")
    return {
        "title": title,
        "reward": int(reward_raw.replace(",", "")),
        "event": event,
        "target": int(target_raw),
        "period": period,
        "active": active_text in {"on", "true", "1", "فعال"},
        "starts_at": None if start in {"", "-"} else start,
        "ends_at": None if end in {"", "-"} else end,
        "random_bonus_max": int(bonus_raw.replace(",", "")),
        "description": description,
    }


async def mission_add_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_CREATE):
        return ConversationHandler.END
    try:
        payload = _parse_mission_payload(str(update.message.text or ""))
        if _mission_rewards_changed(None, payload) and not _has_admin_permission(
            update.effective_user.id, PERMISSION_MISSION_REWARD_MANAGE
        ):
            await reply(update, "❌ برای تعیین امتیاز یا جایزه تصادفی، دسترسی «مدیریت جایزه مأموریت» لازم است.")
            return MISSION_INPUT
        item = await async_with_db(
            lambda db: create_managed_mission(
                db,
                **payload,
                actor_id=update.effective_user.id,
            )
        )
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return MISSION_INPUT
    await async_with_db(lambda db: audit(db, update.effective_user.id, "mission_add", str(item["id"])))
    await reply(update, f"✅ مأموریت #{item['id']} ثبت شد.", back(f"mission_manage:{item['id']}"))
    return ConversationHandler.END


async def mission_manage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MISSION_VIEW):
        return
    query = update.callback_query
    mission_id = query.data.split(":", 1)[1]
    item = find_mission((await async_snapshot()), mission_id)
    if not item:
        await query.answer("مأموریت پیدا نشد", show_alert=True)
        return
    await query.answer()
    rows: list[list[InlineKeyboardButton]] = []
    if _has_admin_permission(query.from_user.id, PERMISSION_MISSION_CREATE):
        rows.append([
            InlineKeyboardButton("✏️ ویرایش", callback_data=f"mission_edit:{item['id']}"),
            InlineKeyboardButton("📄 کپی", callback_data=f"mission_duplicate:{item['id']}"),
        ])
    if _has_admin_permission(query.from_user.id, PERMISSION_MISSION_PUBLISH):
        rows.append([
            InlineKeyboardButton(
                "⛔️ غیرفعال" if item.get("active", True) else "✅ فعال",
                callback_data=f"mission_toggle:{item['id']}",
            )
        ])
    if _has_admin_permission(query.from_user.id, PERMISSION_MISSION_DELETE):
        rows.append([InlineKeyboardButton("🗑 حذف", callback_data=f"mission_delete:{item['id']}")])
    rows.extend(back("a_missions"))
    await edit(
        query,
        f"✅ <b>مأموریت #{item['id']}</b>\n\n"
        f"عنوان: <b>{esc(item.get('title'))}</b>\n"
        f"event: <code>{esc(item.get('event'))}</code>\n"
        f"هدف: <b>{int(item.get('target', 1) or 1)}</b> | دوره: <b>{esc(item.get('period'))}</b>\n"
        f"پاداش: <b>{int(item.get('reward', 0) or 0)}</b> | جایزه تصادفی تا: <b>{int(item.get('random_bonus_max', 0) or 0)}</b>\n"
        f"وضعیت: <b>{'فعال' if item.get('active', True) else 'غیرفعال'}</b>\n"
        f"شروع: <code>{esc(item.get('starts_at') or 'بدون محدودیت')}</code>\n"
        f"پایان: <code>{esc(item.get('ends_at') or 'بدون محدودیت')}</code>\n\n"
        f"{esc(item.get('description') or 'بدون توضیح')}",
        rows,
    )


async def mission_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_CREATE):
        return ConversationHandler.END
    query = update.callback_query
    mission_id = query.data.split(":", 1)[1]
    if not find_mission((await async_snapshot()), mission_id):
        await query.answer("مأموریت پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["mission_edit_id"] = int(mission_id)
    await query.answer()
    await edit(
        query,
        "اطلاعات کامل جدید را با همان قالب ۱۰ بخشی ارسال کنید:\n"
        "<code>عنوان | امتیاز | event | target | period | active | start | end | random_bonus | توضیح</code>",
        back(f"mission_manage:{mission_id}"),
    )
    return MISSION_EDIT_INPUT


async def mission_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_CREATE):
        return ConversationHandler.END
    mission_id = context.user_data.get("mission_edit_id")
    try:
        payload = _parse_mission_payload(str(update.effective_message.text or ""))
        current_mission = find_mission((await async_snapshot()), mission_id)
        if not current_mission:
            await reply(update, "❌ مأموریت پیدا نشد.")
            return ConversationHandler.END
        if _mission_rewards_changed(current_mission, payload) and not _has_admin_permission(
            update.effective_user.id, PERMISSION_MISSION_REWARD_MANAGE
        ):
            await reply(update, "❌ برای تغییر امتیاز یا جایزه، دسترسی «مدیریت جایزه مأموریت» لازم است.")
            return MISSION_EDIT_INPUT
        item = await async_with_db(lambda db: update_managed_mission(db, mission_id, **payload))
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return MISSION_EDIT_INPUT
    context.user_data.pop("mission_edit_id", None)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "mission_edit", str(item["id"])))
    await reply(update, f"✅ مأموریت #{item['id']} ویرایش شد.", back(f"mission_manage:{item['id']}"))
    return ConversationHandler.END


async def mission_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MISSION_PUBLISH):
        return
    query = update.callback_query
    mission_id = query.data.split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: toggle_mission(db, mission_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "mission_toggle", f"{mission_id}:{item.get('active')}"))
    await query.answer("فعال شد" if item.get("active") else "غیرفعال شد", show_alert=True)
    await edit(
        query,
        f"✅ وضعیت مأموریت #{item['id']} به <b>{'فعال' if item.get('active') else 'غیرفعال'}</b> تغییر کرد.",
        back(f"mission_manage:{item['id']}"),
    )


async def mission_duplicate_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MISSION_CREATE):
        return
    query = update.callback_query
    mission_id = query.data.split(":", 1)[1]
    source_mission = find_mission((await async_snapshot()), mission_id)
    if source_mission and _mission_rewards_changed(None, source_mission) and not _has_admin_permission(
        query.from_user.id, PERMISSION_MISSION_REWARD_MANAGE
    ):
        await query.answer("برای کپی مأموریت جایزه‌دار، دسترسی مدیریت جایزه لازم است.", show_alert=True)
        return
    try:
        item = await async_with_db(lambda db: duplicate_mission(db, mission_id, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "mission_duplicate", f"{mission_id}->{item['id']}"))
    await query.answer("کپی غیرفعال ساخته شد", show_alert=True)
    await edit(query, f"✅ مأموریت کپی با شناسه #{item['id']} ساخته شد.", back(f"mission_manage:{item['id']}"))


async def mission_manual_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_EVIDENCE_REVIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(query, "شناسه عددی کاربر را وارد کنید:", back("a_missions"))
    return MISSION_MANUAL_UID


async def mission_manual_uid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_EVIDENCE_REVIEW):
        return ConversationHandler.END
    try:
        uid = parse_positive_int(update.message.text)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return MISSION_MANUAL_UID
    context.user_data["mission_manual_uid"] = uid
    manual = [
        item
        for item in (await async_snapshot()).get("missions", [])
        if isinstance(item, dict) and item.get("event") == "manual" and mission_available(item)
    ]
    if not manual:
        await reply(update, "❌ مأموریت دستی فعالی ثبت نشده است.", back("a_missions"))
        return ConversationHandler.END
    rows = [
        [InlineKeyboardButton(f"#{item['id']} | {item['title']}", callback_data=f"mission_manual_id:{item['id']}")] for item in manual[:40]
    ]
    rows += back("a_missions")
    await reply(update, "مأموریت دستی را انتخاب کنید:", rows)
    return MISSION_MANUAL_ID


async def mission_manual_complete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_MISSION_EVIDENCE_REVIEW):
        return ConversationHandler.END
    query = update.callback_query
    uid = context.user_data.get("mission_manual_uid")
    try:
        mission_id = int(query.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("مأموریت نامعتبر است.", show_alert=True)
        return ConversationHandler.END

    def complete(db: dict[str, Any]) -> tuple[dict[str, Any] | None, bool]:
        mission = find_mission(db, mission_id)
        if not mission or mission.get("event") != "manual":
            return None, False
        changed = complete_mission(db, uid, mission)
        if changed:
            audit(db, query.from_user.id, "mission_manual_complete", f"{uid}/{mission_id}")
        return dict(mission), changed

    mission, changed = await async_with_db(complete)
    if not mission:
        await query.answer("مأموریت پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    if not changed:
        await query.answer("این مأموریت در دوره فعلی قبلاً تکمیل شده است", show_alert=True)
        return ConversationHandler.END
    await query.answer("تکمیل شد", show_alert=True)
    try:
        if await async_with_db(
            lambda db, user_id=uid: route_notification(db, int(user_id), "missions")
        ):
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(uid),
                f"🎁 مأموریت «{mission['title']}» تکمیل شد و حداقل {int(mission.get('reward', 0))} امتیاز گرفتید.",
            )
    except TelegramError:
        logger.info("Could not notify manual mission user %s", uid)
    await edit(query, "✅ مأموریت دستی تکمیل و امتیاز ثبت شد.", back("a_missions"))
    return ConversationHandler.END


async def mission_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MISSION_DELETE):
        return
    query = update.callback_query
    mission_id = query.data.split(":", 1)[1]
    item = await async_with_db(lambda db: delete_managed_mission(db, mission_id))
    if not item:
        await query.answer("مأموریت پیدا نشد", show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "mission_delete", str(mission_id)))
    await query.answer("حذف شد", show_alert=True)
    await edit(query, f"✅ مأموریت <b>{esc(item.get('title'))}</b> حذف شد.", back("a_missions"))


async def a_vip_ext(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_EXTENSION):
        return
    query = update.callback_query
    await query.answer()
    rows = [
        [InlineKeyboardButton("👤 تمدید یک کاربر", callback_data="vip_extend_one")],
        [InlineKeyboardButton("👥 تمدید همه VIPهای فعال", callback_data="vip_extend_all")],
        back("admin_home")[0],
    ]
    await edit(query, "👑 <b>تمدید اشتراک VIP</b>", rows)
    return ConversationHandler.END


async def vip_extend_one_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_EXTENSION):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["vip_extend_all"] = False
    await edit(query, "شناسه عددی کاربر را وارد کنید:", back("a_vip_ext"))
    return VIP_EXT_UID


async def vip_extend_all_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_EXTENSION):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["vip_extend_all"] = True
    rows = [[InlineKeyboardButton(f"{days} روز", callback_data=f"vip_days:{days}") for days in (7, 15, 30, 90)], back("a_vip_ext")[0]]
    await edit(query, "مدت تمدید همه کاربران فعال را انتخاب کنید:", rows)
    return VIP_EXT_DAYS


async def vip_extend_uid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_EXTENSION):
        return ConversationHandler.END
    try:
        uid = parse_positive_int(update.message.text)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return VIP_EXT_UID
    context.user_data["vip_extend_uid"] = uid
    rows = [[InlineKeyboardButton(f"{days} روز", callback_data=f"vip_days:{days}") for days in (7, 15, 30, 90)]]
    await reply(update, "مدت تمدید را انتخاب کنید:", rows)
    return VIP_EXT_DAYS


async def vip_extend_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_VIP_EXTENSION):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    days = int(query.data.split(":", 1)[1])
    extend_all = bool(context.user_data.get("vip_extend_all"))

    if extend_all:
        if operation_requires_approval((await async_snapshot()), "bulk_vip_extension"):
            row = await async_with_db(
                lambda db: create_pending_approval(
                    db,
                    "bulk_vip_extension",
                    {"days": days},
                    query.from_user.id,
                    description=f"تمدید همه VIPهای فعال به مدت {days} روز",
                )
            )
            await _notify_pending_approval(context, row)
            await edit(query, "🔐 تمدید گروهی برای تأیید ادمین دوم ارسال شد.", back("a_vip_ext"))
            return ConversationHandler.END

        def extend(db: dict):
            count = 0
            for uid in list(db.get("vip_users", {})):
                if is_vip(db, uid):
                    activate_vip(db, uid, days)
                    count += 1
            audit(db, query.from_user.id, "vip_extend_all", f"{days}d/{count}")
            return count

        count = await async_with_db(extend)
        await edit(query, f"✅ {count} کاربر فعال، {days} روز تمدید شدند.", back("a_vip_ext"))
        return ConversationHandler.END

    uid = context.user_data.get("vip_extend_uid")
    if not uid:
        await query.answer("شناسه کاربر مشخص نیست.", show_alert=True)
        return ConversationHandler.END

    snapshot = await async_snapshot()
    if str(uid) not in snapshot.get("users", {}) and str(uid) not in snapshot.get("vip_users", {}):
        await query.answer("کاربر در دیتابیس پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    expiry = projected_vip_expiry(snapshot, uid, days)

    invite_link: str | None = None
    try:
        # Access must be ready before committing the extension. This prevents an
        # active VIP record without a usable way to enter the private channel.
        invite_link = await restore_vip_channel_access(context.bot, int(uid), utc_iso(expiry))
    except TelegramError:
        logger.exception("Could not prepare channel access for VIP extension %s", uid)
        await edit(
            query,
            "❌ تمدید ثبت نشد؛ ساخت لینک ورود یا دسترسی کانال ناموفق بود. دسترسی‌های ربات را بررسی و دوباره تلاش کنید.",
            back("a_vip_ext"),
        )
        return ConversationHandler.END

    def commit_extension(db: dict):
        if str(uid) not in db.get("users", {}) and str(uid) not in db.get("vip_users", {}):
            return None
        record = activate_vip(
            db,
            uid,
            days,
            invite_link=invite_link,
            fixed_expires_at=expiry,
        )
        audit(db, query.from_user.id, "vip_extend_one", f"{uid}/{days}d")
        return record

    try:
        record = await async_with_db(commit_extension)
    except Exception:
        logger.exception("Could not commit VIP extension for %s", uid)
        record = None

    if not record:
        try:
            if invite_link:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_link,
                )
        except TelegramError:
            logger.warning("Could not revoke unused extension invite for %s", uid)
        await edit(query, "❌ ثبت نهایی تمدید انجام نشد؛ هیچ تغییری در اشتراک ثبت نشد.", back("a_vip_ext"))
        return ConversationHandler.END

    user_text = f"✅ اشتراک VIP شما {days} روز تمدید شد. پایان جدید: {display_dt(record['expires_at'])}\n🔗 لینک ورود جدید: {invite_link}"
    try:
        await _telegram_request_with_button_fallback(context.bot.send_message, uid, user_text)
    except TelegramError:
        logger.info("Could not notify extended VIP %s", uid)
    await edit(
        query,
        f"✅ کاربر <code>{uid}</code> تا {display_dt(record['expires_at'])} تمدید شد و لینک جدید ساخته شد.",
        back("a_vip_ext"),
    )
    return ConversationHandler.END


def _contest_reward_settings(db: dict[str, Any] | None = None) -> dict[str, int]:
    root = db if db is not None else load_db()
    settings = root.get("settings", {}) if isinstance(root, dict) else {}
    source = settings.get("contestRewards", {}) if isinstance(settings, dict) else {}
    source = source if isinstance(source, dict) else {}
    defaults = {"price": 5, "chart": 5, "candle1": 10, "candle2": 7, "candle3": 5, "candle4_10": 3, "news": 5}
    result: dict[str, int] = {}
    for key, default in defaults.items():
        try:
            result[key] = min(100_000, max(0, int(source.get(key, default))))
        except (TypeError, ValueError):
            result[key] = default
    return result


def _save_contest_rewards(db: dict[str, Any], values: dict[str, int]) -> dict[str, int]:
    normalized = {key: min(100_000, max(0, int(value))) for key, value in values.items()}
    db.setdefault("settings", {})["contestRewards"] = normalized
    return normalized


async def a_contest(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_VIEW):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    price = await async_with_db(get_unsettled_price_contest)
    chart = db.get("chart_contest", {})
    candle = db.get("candle_contest", {})
    news = db.get("news_direction_contest", {})
    rewards = _contest_reward_settings(db)
    text = (
        "🎯 <b>مدیریت مسابقات</b>\n\n"
        f"قیمت: <b>{esc(price.get('status') if price else 'ندارد')}</b> | جایزه: {rewards['price']}\n"
        f"چارت: <b>{esc(chart.get('status', 'ندارد'))}</b> | جایزه: {rewards['chart']}\n"
        f"کندل: <b>{esc(candle.get('status', 'ندارد'))}</b> | رتبه‌ها: "
        f"{rewards['candle1']}/{rewards['candle2']}/{rewards['candle3']}/{rewards['candle4_10']}\n"
        f"خبر: <b>{esc(news.get('status', 'ندارد'))}</b> | جایزه پاسخ صحیح: {rewards['news']}"
    )
    rows = [
        [
            InlineKeyboardButton("▶️ شروع قیمت", callback_data="cw:mode:contest"),
            InlineKeyboardButton("⏹ پایان قیمت", callback_data="price_contest_end"),
        ],
        [
            InlineKeyboardButton("▶️ شروع چارت", callback_data="chart_contest_start"),
            InlineKeyboardButton("⏹ پایان چارت", callback_data="chart_contest_end"),
        ],
        [
            InlineKeyboardButton("▶️ شروع کندل", callback_data="candle_contest_start"),
            InlineKeyboardButton("⏹ پایان کندل", callback_data="candle_contest_end"),
        ],
        [
            InlineKeyboardButton("📰 شروع مسابقه خبر", callback_data="news_contest_start"),
            InlineKeyboardButton("🏁 اعلام نتیجه خبر", callback_data="news_contest_end"),
        ],
        [InlineKeyboardButton("🎖 تنظیم امتیاز مسابقه‌ها", callback_data="contest_rewards_set")],
        back("admin_home")[0],
    ]
    await edit(query, text, rows)
    return ConversationHandler.END


async def contest_rewards_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_SCORE_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    rewards = _contest_reward_settings()
    await edit(
        query,
        "🎖 <b>تنظیم امتیاز مسابقه‌ها</b>\n\n"
        "هفت عدد را به این ترتیب ارسال کنید:\n"
        "قیمت | چارت | کندل رتبه اول | رتبه دوم | رتبه سوم | رتبه ۴ تا ۱۰ | مسابقه خبر\n\n"
        f"مقادیر فعلی: <code>{rewards['price']} | {rewards['chart']} | {rewards['candle1']} | {rewards['candle2']} | {rewards['candle3']} | {rewards['candle4_10']} | {rewards['news']}</code>",
        back("a_contest"),
    )
    return CONTEST_REWARD_INPUT


async def contest_rewards_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_SCORE_MANAGE):
        return ConversationHandler.END
    parts = [item for item in re.split(r"[,|/\s]+", update.effective_message.text.strip()) if item]
    if len(parts) != 7:
        await reply(update, "❌ دقیقاً هفت عدد بفرستید. مثال: <code>5 | 5 | 10 | 7 | 5 | 3 | 5</code>")
        return CONTEST_REWARD_INPUT
    try:
        values = [int(item) for item in parts]
    except ValueError:
        await reply(update, "❌ همه مقادیر باید عدد صحیح باشند.")
        return CONTEST_REWARD_INPUT
    if any(value < 0 or value > 100_000 for value in values):
        await reply(update, "❌ هر امتیاز باید بین صفر تا ۱۰۰٬۰۰۰ باشد.")
        return CONTEST_REWARD_INPUT
    payload = dict(zip(("price", "chart", "candle1", "candle2", "candle3", "candle4_10", "news"), values, strict=True))
    saved = await async_with_db(lambda db: _save_contest_rewards(db, payload))
    await async_with_db(lambda db: audit(db, update.effective_user.id, "contest_rewards_update", str(saved)))
    await reply(
        update,
        "✅ امتیاز مسابقه‌ها ذخیره شد. این مقادیر برای مسابقه‌های جدید استفاده می‌شوند.",
        [[InlineKeyboardButton("🔙 مسابقه‌ها", callback_data="a_contest")]],
    )
    return ConversationHandler.END


def _contest_duration_rows(prefix: str) -> list[list[InlineKeyboardButton]]:
    values = [(30, "۳۰ دقیقه"), (60, "۱ ساعت"), (360, "۶ ساعت"), (1440, "۲۴ ساعت")]
    default = SETTINGS.default_contest_duration_minutes
    if default not in {item[0] for item in values}:
        values.append((default, f"پیش‌فرض ({default} دقیقه)"))
    return [
        [InlineKeyboardButton(label, callback_data=f"{prefix}:{minutes}") for minutes, label in values[:2]],
        [InlineKeyboardButton(label, callback_data=f"{prefix}:{minutes}") for minutes, label in values[2:]],
        back("a_contest")[0],
    ]


async def price_contest_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if await async_with_db(get_unsettled_price_contest):
        await query.answer("یک مسابقه قیمت تسویه‌نشده وجود دارد.", show_alert=True)
        return ConversationHandler.END
    rows = [[InlineKeyboardButton(symbol, callback_data=f"pc_symbol:{symbol}")] for symbol in SYMBOLS]
    rows += back("a_contest")
    await edit(query, "نماد مسابقه را انتخاب کنید:", rows)
    return PRICE_CONTEST_SYMBOL


async def price_contest_symbol(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["price_contest"] = {"symbol": query.data.split(":", 1)[1], "question": "", "photo_file_id": None}
    rows = [[InlineKeyboardButton("⏭ بدون رسانه و سؤال", callback_data="pc_media_skip")], back("a_contest")[0]]
    await edit(query, "در صورت نیاز عکس مسابقه را با سؤال در کپشن ارسال کنید؛ یا فقط سؤال متنی بفرستید.", rows)
    return PRICE_CONTEST_MEDIA


async def price_contest_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    data = context.user_data.get("price_contest")
    if not data:
        await reply(update, "❌ فرایند مسابقه منقضی شده است.")
        return ConversationHandler.END
    if update.message.photo:
        data["photo_file_id"] = update.message.photo[-1].file_id
        data["question"] = (update.message.caption or "").strip()[:500]
    else:
        data["question"] = (update.message.text or "").strip()[:500]
    await reply(update, "مدت مسابقه را انتخاب کنید:", _duration_rows("pc_duration"))
    return PRICE_CONTEST_DURATION


async def price_contest_media_skip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(query, "مدت مسابقه را انتخاب کنید:", _duration_rows("pc_duration"))
    return PRICE_CONTEST_DURATION


def _duration_rows(prefix: str) -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("۱ ساعت", callback_data=f"{prefix}:60"),
            InlineKeyboardButton("۶ ساعت", callback_data=f"{prefix}:360"),
            InlineKeyboardButton("۲۴ ساعت", callback_data=f"{prefix}:1440"),
        ],
        back("a_contest")[0],
    ]


async def price_contest_duration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    duration = int(query.data.split(":", 1)[1])
    data = context.user_data.get("price_contest") or {}
    try:
        contest = await async_with_db(
            lambda db: start_price_contest(
                db,
                data["symbol"],
                duration,
                question=data.get("question", ""),
                photo_file_id=data.get("photo_file_id"),
                reward_points=_contest_reward_settings(db)["price"],
            )
        )
    except (ValueError, KeyError) as exc:
        await edit(query, f"❌ {esc(exc)}", back("a_contest"))
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, query.from_user.id, "price_contest_start", contest["id"]))
    context.user_data.pop("price_contest", None)
    await edit(
        query,
        f"✅ مسابقه {esc(contest['symbol'])} تا {display_dt(contest['ends_at'])} شروع شد. "
        f"جایزه برنده: {int(contest.get('reward_points', 5))} امتیاز.",
        back("a_contest"),
    )
    return ConversationHandler.END


async def price_contest_end(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_END):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    contest = await async_with_db(get_unsettled_price_contest)
    if not contest:
        await query.answer("مسابقه تسویه‌نشده‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    await edit(query, f"قیمت نهایی <b>{esc(contest.get('symbol'))}</b> را وارد کنید:", back("a_contest"))
    return PRICE_CONTEST_FINAL


async def price_contest_final(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_RESULT_MANAGE):
        return ConversationHandler.END
    try:
        final_price = parse_finite_float(update.message.text, positive=True)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PRICE_CONTEST_FINAL
    contest, results = await async_with_db(lambda db: end_price_contest(db, final_price))
    if not contest:
        await reply(update, "❌ مسابقه‌ای برای پایان وجود ندارد.")
        return ConversationHandler.END
    winners = [item for item in results if item.get("points") or item.get("prize")]
    await async_with_db(
        lambda db: [
            record_user_reward(
                db,
                winner["uid"],
                "جایزه مسابقه قیمت",
                reward_type="points",
                detail=f"{winner['points']} امتیاز",
                source="contest:price",
                reference_id=contest["id"],
            )
            for winner in winners if not winner.get("prize")
        ]
    )
    for winner in winners:
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message, int(winner["uid"]), f"🏆 جایزه مسابقه شما: {winner.get('prize_label') or str(winner['points'])+' امتیاز'}"
            )
        except TelegramError:
            logger.info("Could not notify price contest winner %s", winner["uid"])
    await async_with_db(lambda db: audit(db, update.effective_user.id, "price_contest_end", contest["id"]))
    lines = [f"✅ مسابقه با قیمت <b>{final_price}</b> پایان یافت.", f"شرکت‌کننده: {len(results)}"]
    for row in results[:5]:
        lines.append(f"#{row['rank']} | <code>{row['uid']}</code> | {row['guess']} | اختلاف {row['diff']:.6f} | {esc(row.get('prize_label') or str(row['points'])+' امتیاز')}")
    await reply(update, "\n".join(lines), [[InlineKeyboardButton("🔙 مسابقات", callback_data="a_contest")]])
    return ConversationHandler.END


async def chart_contest_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    existing = (await async_snapshot()).get("chart_contest", {})
    if existing.get("status") in {"active", "awaiting_result"}:
        await query.answer("مسابقه چارت تسویه‌نشده وجود دارد.", show_alert=True)
        return ConversationHandler.END
    await edit(query, "عکس چارت را با سؤال در کپشن ارسال کنید؛ یا سؤال را فقط به‌صورت متن بفرستید.", back("a_contest"))
    return CHART_CONTEST_INPUT


async def chart_contest_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    photo_id = update.message.photo[-1].file_id if update.message.photo else None
    question = (update.message.caption if update.message.photo else update.message.text) or "جهت بعدی بازار؟"
    context.user_data["chart_contest"] = {"question": question[:500], "photo_file_id": photo_id}
    await reply(update, "مدت مسابقه چارت را انتخاب کنید:", _contest_duration_rows("chart_duration"))
    return CHART_CONTEST_DURATION


async def chart_contest_duration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    data = context.user_data.get("chart_contest")
    if not data:
        await query.answer("اطلاعات مسابقه منقضی شده است.", show_alert=True)
        return ConversationHandler.END
    try:
        minutes = int(query.data.split(":", 1)[1])
        contest = await async_with_db(
            lambda db: start_chart_contest(
                db,
                data["question"],
                data.get("photo_file_id"),
                minutes,
                _contest_reward_settings(db)["chart"],
            )
        )
    except (ValueError, KeyError) as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, query.from_user.id, "chart_contest_start", f"{contest['id']}:{minutes}m"))
    context.user_data.pop("chart_contest", None)
    await edit(
        query,
        f"✅ مسابقه چارت تا {display_dt(contest['ends_at'])} شروع شد. امتیاز هر برنده: {int(contest.get('reward_points', 5))}.",
        back("a_contest"),
    )
    return ConversationHandler.END



__feature_exports__ = ('_dashboard_snapshot', '_render_admin_dashboard', 'a_dashboard', 'admin_dashboard_page', 'a_logs', 'a_runtime_logs', 'a_leaderboard', 'a_contest_stats', 'a_reward_requests', 'reward_done', '_funnel_percent', 'a_sales_funnel', 'sales_funnel_users', '_vip_plan_admin_text', '_vip_plan_admin_rows', '_vip_plan_list_payload', 'a_vip_plans', 'vip_plan_admin_view', 'vip_plan_edit_menu', 'vip_plan_edit_start', 'vip_plan_edit_input', 'vip_plan_audience_cycle_handler', 'vip_plan_edit_cancel', 'vip_plan_add_start', 'vip_plan_quick_start', 'vip_plan_wizard_start', 'vip_plan_wizard_name', 'vip_plan_wizard_price', 'vip_plan_wizard_days', 'vip_plan_wizard_audience', 'vip_plan_wizard_original', 'vip_plan_wizard_limit', 'vip_plan_wizard_highlight', 'vip_plan_wizard_features', 'vip_plan_wizard_description', 'vip_plan_wizard_window', 'vip_plan_add_input', 'vip_plan_toggle_handler', 'vip_plan_highlight_handler', 'vip_plan_delete_handler', 'a_public_discounts', 'public_discount_add_start', 'public_discount_quick_start', 'public_discount_wizard_start', 'public_discount_wizard_code', 'public_discount_wizard_percent', 'public_discount_wizard_window', 'public_discount_wizard_max_uses', 'public_discount_wizard_user_limit', 'public_discount_add_input', '_public_discount_status_label', '_public_discount_detail_payload', 'public_discount_view', 'public_discount_toggle_handler', 'public_discount_expire_handler', 'public_discount_edit_start', 'public_discount_edit_input', 'public_discount_batch_start', 'public_discount_batch_input', 'public_discount_affiliate_start', 'public_discount_affiliate_input', 'public_discount_report_view', 'public_discount_segment_menu', 'public_discount_segment_do', 'public_discount_broadcast_confirm', 'public_discount_broadcast_do', 'a_crm_segments', 'crm_segment_members', 'crm_pipeline_view', 'crm_pipeline_stage_members', 'crm_stage_menu', 'crm_stage_set_handler', 'a_vip_settings', 'vip_usdt_toggle_handler', 'vip_field_select', 'vip_field_value', '_discount_stock_text', 'a_disc', 'disc_create_start', 'disc_percent_select', 'disc_refill_do', 'disc_send_start', 'disc_send_uid', 'disc_send_percent', 'disc_random_start', 'disc_random_percent', 'disc_random_count', 'disc_list', 'a_edu', 'lesson_add_start', 'lesson_add_input', '_lesson_attachment_from_message', 'lesson_media_add_start', 'lesson_media_input', 'lesson_media_done', 'lesson_list', '_lesson_manage_payload', 'lesson_manage', 'lesson_attachment_remove_handler', 'lesson_edit_start', 'lesson_edit_input', 'lesson_status_handler', 'lesson_duplicate_handler', 'lesson_delete', 'a_missions', 'mission_add_start', '_parse_mission_payload', 'mission_add_input', 'mission_manage', 'mission_edit_start', 'mission_edit_input', 'mission_toggle_handler', 'mission_duplicate_handler', 'mission_manual_start', 'mission_manual_uid', 'mission_manual_complete', 'mission_delete', 'a_vip_ext', 'vip_extend_one_start', 'vip_extend_all_start', 'vip_extend_uid', 'vip_extend_days', '_contest_reward_settings', '_save_contest_rewards', 'a_contest', 'contest_rewards_start', 'contest_rewards_input', '_contest_duration_rows', 'price_contest_start', 'price_contest_symbol', 'price_contest_media', 'price_contest_media_skip', '_duration_rows', 'price_contest_duration', 'price_contest_end', 'price_contest_final', 'chart_contest_start', 'chart_contest_input', 'chart_contest_duration')
