"""Feature-owned Telegram handlers extracted from the v7 runtime: growth_campaigns."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

SIGNAL_TEMPLATE_UPLOAD_INPUT = 98101

async def chart_contest_end(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_END):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    contest = (await async_snapshot()).get("chart_contest", {})
    if contest.get("status") not in {"active", "awaiting_result"}:
        await query.answer("مسابقه تسویه‌نشده‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    rows = [
        [
            InlineKeyboardButton("📈 UP", callback_data="chart_final:UP"),
            InlineKeyboardButton("📉 DOWN", callback_data="chart_final:DOWN"),
            InlineKeyboardButton("➡️ FLAT", callback_data="chart_final:FLAT"),
        ],
        back("a_contest")[0],
    ]
    await edit(query, "پاسخ صحیح را انتخاب کنید:", rows)
    return CHART_CONTEST_FINAL


async def chart_contest_final(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_RESULT_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    answer = query.data.split(":", 1)[1]
    try:
        contest, winners = await async_with_db(lambda db: end_chart_contest(db, answer))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return CHART_CONTEST_FINAL
    if not contest:
        await query.answer("مسابقه‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    await async_with_db(
        lambda db: [
            record_user_reward(
                db,
                uid,
                "جایزه مسابقه چارت",
                reward_type="points",
                detail=f"{int(contest.get('reward_points', 5))} امتیاز",
                source="contest:chart",
                reference_id=contest["id"],
            )
            for uid in winners
        ]
    )
    for uid in winners:
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(uid),
                f"🏆 پاسخ مسابقه چارت شما صحیح بود و {int(contest.get('reward_points', 5))} امتیاز دریافت کردید.",
            )
        except TelegramError:
            logger.info("Could not notify chart winner %s", uid)
    await async_with_db(lambda db: audit(db, query.from_user.id, "chart_contest_end", f"{contest['id']}:{answer}"))
    await edit(query, f"✅ مسابقه با پاسخ <b>{answer}</b> پایان یافت. برندگان: <b>{len(winners)}</b>", back("a_contest"))
    return ConversationHandler.END


async def candle_contest_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    existing = (await async_snapshot()).get("candle_contest", {})
    if existing.get("status") in {"active", "awaiting_result"}:
        await query.answer("مسابقه کندل تسویه‌نشده وجود دارد.", show_alert=True)
        return ConversationHandler.END
    context.user_data.pop("candle_contest", None)
    await edit(
        query,
        "۱/۲ — سؤال مسابقه کندل را بنویسید. مثال: قیمت بسته‌شدن کندل XAUUSD یک‌ساعته چقدر خواهد بود؟",
        back("a_contest"),
    )
    return CANDLE_CONTEST_QUESTION


async def candle_contest_question(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    question = str(update.effective_message.text or "").strip()[:1000]
    if len(question) < 3:
        await reply(update, "❌ سؤال مسابقه را کامل‌تر بنویسید.")
        return CANDLE_CONTEST_QUESTION
    context.user_data["candle_contest"] = {"question": question}
    await reply(update, "۲/۲ — مدت مسابقه کندل را انتخاب کنید:", _contest_duration_rows("candle_duration"))
    return CANDLE_CONTEST_DURATION


async def candle_contest_duration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    try:
        minutes = int(query.data.split(":", 1)[1])
        question = str((context.user_data.get("candle_contest") or {}).get("question") or "").strip()
        contest = await async_with_db(
            lambda db: start_candle_contest(
                db,
                minutes,
                {
                    1: _contest_reward_settings(db)["candle1"],
                    2: _contest_reward_settings(db)["candle2"],
                    3: _contest_reward_settings(db)["candle3"],
                    **{rank: _contest_reward_settings(db)["candle4_10"] for rank in range(4, 11)},
                },
                question=question,
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, query.from_user.id, "candle_contest_start", f"{contest['id']}:{minutes}m"))
    context.user_data.pop("candle_contest", None)
    rewards = contest.get("reward_by_rank", {})
    await edit(
        query,
        f"✅ مسابقه کندل تا {display_dt(contest['ends_at'])} فعال شد. "
        f"امتیازها: اول {rewards.get('1', 0)}، دوم {rewards.get('2', 0)}، سوم {rewards.get('3', 0)}، رتبه‌های ۴ تا ۱۰ هرکدام {rewards.get('4', 0)}.",
        back("a_contest"),
    )
    return ConversationHandler.END


async def candle_contest_end(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_END):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    contest = (await async_snapshot()).get("candle_contest", {})
    if contest.get("status") not in {"active", "awaiting_result"}:
        await query.answer("مسابقه تسویه‌نشده‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    await edit(query, "قیمت نهایی بسته‌شدن کندل را وارد کنید:", back("a_contest"))
    return CANDLE_CONTEST_FINAL


async def candle_contest_final(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_RESULT_MANAGE):
        return ConversationHandler.END
    try:
        final_price = parse_finite_float(update.message.text, positive=True)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CANDLE_CONTEST_FINAL
    contest, results = await async_with_db(lambda db: end_candle_contest(db, final_price))
    if not contest:
        await reply(update, "❌ مسابقه‌ای وجود ندارد.")
        return ConversationHandler.END
    await async_with_db(
        lambda db: [
            record_user_reward(
                db,
                row["uid"],
                f"رتبه {row['rank']} مسابقه کندل",
                reward_type="points",
                detail=f"{row['points']} امتیاز",
                source="contest:candle",
                reference_id=contest["id"],
            )
            for row in results[:10]
            if int(row.get("points", 0) or 0) > 0
        ]
    )
    for row in results[:10]:
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message, int(row["uid"]), f"🏆 رتبه {row['rank']} مسابقه کندل؛ {row['points']} امتیاز دریافت کردید."
            )
        except TelegramError:
            logger.info("Could not notify candle winner %s", row["uid"])
    await async_with_db(lambda db: audit(db, update.effective_user.id, "candle_contest_end", contest["id"]))
    lines = [f"✅ مسابقه کندل با قیمت {final_price} پایان یافت."]
    for row in results[:5]:
        lines.append(f"#{row['rank']} | <code>{row['uid']}</code> | {row['guess']} | +{row['points']}")
    await reply(update, "\n".join(lines), [[InlineKeyboardButton("🔙 مسابقات", callback_data="a_contest")]])
    return ConversationHandler.END



async def news_contest_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    existing = (await async_snapshot()).get("news_direction_contest", {})
    if isinstance(existing, dict) and existing.get("status") in {"active", "awaiting_result"}:
        await query.answer("یک مسابقه خبر تسویه‌نشده وجود دارد.", show_alert=True)
        return ConversationHandler.END
    await edit(query, "نام خبر را وارد کنید؛ مثال: گزارش NFP آمریکا", back("a_contest"))
    return NEWS_CONTEST_NAME


async def news_contest_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_PUBLISH):
        return ConversationHandler.END
    name = str(update.effective_message.text or "").strip()[:500]
    try:
        contest = await async_with_db(
            lambda db: start_news_direction_contest(
                db, name, duration_minutes=30, reward_points=_contest_reward_settings(db)["news"]
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return NEWS_CONTEST_NAME
    await async_with_db(lambda db: audit(db, update.effective_user.id, "news_direction_contest_start", contest["id"]))
    await reply(
        update,
        f"✅ مسابقه خبر <b>{esc(contest['news_name'])}</b> برای ۳۰ دقیقه فعال شد. کاربران روند نیم‌ساعت بعد از خبر را صعودی، نزولی یا رنج پیش‌بینی می‌کنند.",
        [[InlineKeyboardButton("🔙 مسابقات", callback_data="a_contest")]],
    )
    return ConversationHandler.END


async def news_contest_end(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_END):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    contest = (await async_snapshot()).get("news_direction_contest", {})
    if not isinstance(contest, dict) or contest.get("status") not in {"active", "awaiting_result"}:
        await query.answer("مسابقه خبر تسویه‌نشده‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    rows = [[
        InlineKeyboardButton("📈 صعودی", callback_data="news_final:UP"),
        InlineKeyboardButton("📉 نزولی", callback_data="news_final:DOWN"),
        InlineKeyboardButton("↔️ رنج", callback_data="news_final:RANGE"),
    ], back("a_contest")[0]]
    await edit(query, f"نتیجه بازار نیم‌ساعت بعد از خبر <b>{esc(contest.get('news_name'))}</b> را انتخاب کنید:", rows)
    return NEWS_CONTEST_RESULT


async def news_contest_final(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CONTEST_RESULT_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    answer = query.data.split(":", 1)[1]
    try:
        contest, winners = await async_with_db(lambda db: end_news_direction_contest(db, answer))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return NEWS_CONTEST_RESULT
    if not contest:
        await query.answer("مسابقه‌ای وجود ندارد.", show_alert=True)
        return ConversationHandler.END
    points = int(contest.get("reward_points", 5) or 5)
    await async_with_db(
        lambda db: [
            record_user_reward(
                db, uid, "جایزه مسابقه جهت خبر", reward_type="points", detail=f"{points} امتیاز",
                source="contest:news_direction", reference_id=contest["id"]
            ) for uid in winners
        ]
    )
    for uid in winners:
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message, int(uid),
                f"🏆 پیش‌بینی شما برای خبر {contest.get('news_name')} صحیح بود و {points} امتیاز دریافت کردید."
            )
        except TelegramError:
            logger.info("Could not notify news contest winner %s", uid)
    await async_with_db(lambda db: audit(db, query.from_user.id, "news_direction_contest_end", f"{contest['id']}:{answer}"))
    await edit(query, f"✅ مسابقه خبر پایان یافت. نتیجه: <b>{answer}</b> | برندگان: <b>{len(winners)}</b>", back("a_contest"))
    return ConversationHandler.END

def _announcement_destination_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [InlineKeyboardButton("🌐 کانال عمومی", callback_data="announce_dest:public"), InlineKeyboardButton("🔒 کانال خصوصی", callback_data="announce_dest:private")],
        [InlineKeyboardButton("📣 هر دو کانال", callback_data="announce_dest:both")],
        [InlineKeyboardButton("❌ انصراف", callback_data="a_announcement")],
    ]


def _announcement_topic_rows() -> list[list[InlineKeyboardButton]]:
    buttons = [InlineKeyboardButton(label, callback_data=f"announce_topic:{key}") for key, label in ANNOUNCEMENT_TOPICS.items()]
    rows = [buttons[index:index+2] for index in range(0, len(buttons), 2)]
    rows.append([InlineKeyboardButton("❌ انصراف", callback_data="a_announcement")])
    return rows


async def a_announcement(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ANNOUNCEMENT_PREVIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data.pop("announcement", None)
    summary = announcement_summary(await async_snapshot())
    text_value = (
        "📣 <b>مرکز اعلان کانال</b>\n\n"
        "متن، عکس، ویدئو، فایل، صوت یا هر پیام تلگرامی را با عنوان دلخواه در کانال عمومی، خصوصی یا هر دو منتشر کنید.\n\n"
        f"کل اعلان‌ها: <b>{summary['total']}</b> | موفق: <b>{summary['sent']}</b> | ناقص/ناموفق: <b>{summary['partial'] + summary['failed']}</b>"
    )
    rows = [[InlineKeyboardButton("➕ اعلان جدید", callback_data="announce_new")], [InlineKeyboardButton("📋 تاریخچه و وضعیت", callback_data="announce_history")], back("admin_home")[0]]
    await edit(query, text_value, rows)
    return ConversationHandler.END


async def announcement_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ANNOUNCEMENT_PREVIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["announcement"] = {}
    await edit(query, "۱/۴ — مقصد اعلان را انتخاب کنید:", _announcement_destination_rows())
    return ANNOUNCE_DEST


async def announcement_destination(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    destination = query.data.split(":", 1)[1]
    if destination not in {"public", "private", "both"}:
        await query.answer("مقصد نامعتبر است", show_alert=True)
        return ANNOUNCE_DEST
    context.user_data.setdefault("announcement", {})["destination"] = destination
    await edit(query, "۲/۴ — سرفصل اعلان را انتخاب کنید. گزینه «سایر» امکان نوشتن عنوان دلخواه را می‌دهد:", _announcement_topic_rows())
    return ANNOUNCE_TOPIC


async def announcement_topic(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    topic = query.data.split(":", 1)[1]
    if topic not in ANNOUNCEMENT_TOPICS:
        await query.answer("سرفصل نامعتبر است", show_alert=True)
        return ANNOUNCE_TOPIC
    data = context.user_data.setdefault("announcement", {})
    data["topic"] = topic
    if topic == "other":
        await edit(query, "عنوان دلخواه اعلان را وارد کنید؛ حداکثر ۱۲۰ کاراکتر:", [[InlineKeyboardButton("❌ انصراف", callback_data="a_announcement")]])
        return ANNOUNCE_CUSTOM_TITLE
    data["title"] = ANNOUNCEMENT_TOPICS[topic]
    await edit(query, f"۳/۴ — محتوای اعلان <b>{esc(data['title'])}</b> را اکنون ارسال کنید.\n\nمتن، عکس، ویدئو، فایل، صوت، گیف و پیام‌های دیگر پذیرفته می‌شوند.", [[InlineKeyboardButton("❌ انصراف", callback_data="a_announcement")]])
    return ANNOUNCE_CONTENT


async def announcement_custom_title(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    title = (update.effective_message.text or "").strip()
    if not 2 <= len(title) <= 120:
        await reply(update, "❌ عنوان باید بین ۲ تا ۱۲۰ کاراکتر باشد.")
        return ANNOUNCE_CUSTOM_TITLE
    context.user_data.setdefault("announcement", {})["title"] = title
    await reply(update, f"۳/۴ — محتوای اعلان <b>{esc(title)}</b> را ارسال کنید.\nمتن، عکس، ویدئو، فایل، صوت یا هر پیام دیگری قابل ارسال است.")
    return ANNOUNCE_CONTENT


def _announcement_content_type(message: Any) -> str:
    for name in ("photo", "video", "document", "animation", "audio", "voice", "video_note", "sticker", "contact", "location", "venue", "poll"):
        if getattr(message, name, None):
            return name
    return "text" if getattr(message, "text", None) else "message"


async def announcement_content(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    message = update.effective_message
    data = context.user_data.get("announcement")
    if not data:
        await reply(update, "❌ اطلاعات اعلان منقضی شده است.", [[InlineKeyboardButton("شروع دوباره", callback_data="a_announcement")]])
        return ConversationHandler.END
    data.update({"source_chat_id": message.chat_id, "source_message_id": message.message_id, "content_type": _announcement_content_type(message), "text": (message.text or message.caption or "")[:4000]})
    destination_label = {"public": "عمومی", "private": "خصوصی", "both": "عمومی و خصوصی"}[data["destination"]]
    preview = f"۴/۴ — <b>تأیید اعلان</b>\n\nسرفصل: <b>{esc(data['title'])}</b>\nمقصد: <b>{destination_label}</b>\nنوع محتوا: <b>{esc(data['content_type'])}</b>"
    if data.get("text"):
        preview += f"\n\nپیش‌نمایش متن:\n{esc(data['text'][:700])}"
    await reply(update, preview, [[InlineKeyboardButton("✅ انتشار", callback_data="announce_publish"), InlineKeyboardButton("❌ لغو", callback_data="a_announcement")]])
    return ANNOUNCE_CONFIRM


async def announcement_publish(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ANNOUNCEMENT_PUBLISH):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer("در حال انتشار…")
    data = context.user_data.get("announcement") or {}
    if not data.get("source_message_id"):
        await edit(query, "❌ محتوای اعلان منقضی شده است.", [[InlineKeyboardButton("شروع دوباره", callback_data="a_announcement")]])
        return ConversationHandler.END
    destinations = [name for name in ("public", "private") if data.get("destination") in {name, "both"}]
    channel_ids = {"public": SETTINGS.public_channel_id, "private": SETTINGS.private_channel_id}
    deliveries: list[dict[str, Any]] = []
    errors: list[str] = []
    title_line = f"📣 <b>{esc(data.get('title'))}</b>"
    captionable = data.get("content_type") in {"photo", "video", "document", "animation", "audio"}
    for destination in destinations:
        channel_id = channel_ids.get(destination)
        if not channel_id:
            errors.append(f"{destination}: شناسه کانال تنظیم نشده است")
            continue
        try:
            if data.get("content_type") == "text":
                body = str(data.get("text") or "")
                sent = await context.bot.send_message(chat_id=channel_id, text=f"{title_line}\n\n{body}", parse_mode=ParseMode.HTML)
            elif captionable:
                raw_caption = str(data.get("text") or "")
                caption = f"{title_line}" + (f"\n\n{esc(raw_caption)}" if raw_caption else "")
                sent = await context.bot.copy_message(chat_id=channel_id, from_chat_id=data["source_chat_id"], message_id=data["source_message_id"], caption=caption[:1024], parse_mode=ParseMode.HTML)
            else:
                header = await context.bot.send_message(chat_id=channel_id, text=title_line, parse_mode=ParseMode.HTML)
                sent = await context.bot.copy_message(chat_id=channel_id, from_chat_id=data["source_chat_id"], message_id=data["source_message_id"])
                deliveries.append({"channel": destination, "message_id": int(header.message_id), "type": "header"})
            deliveries.append({"channel": destination, "message_id": int(sent.message_id), "type": data.get("content_type")})
        except Exception as exc:
            logger.exception("Announcement publish failed for %s", destination)
            errors.append(f"{destination}: {exc}")
    row = await async_with_db(lambda db: record_announcement(db, admin_id=query.from_user.id, topic=data.get("topic", "other"), title=data.get("title", "اعلان"), destination=data.get("destination", "public"), content_type=data.get("content_type", "message"), source_chat_id=data.get("source_chat_id"), source_message_id=data.get("source_message_id"), text=data.get("text", ""), deliveries=deliveries, errors=errors))
    try:
        from repositories.v2.events import EventRepository
        await run_blocking(
            EventRepository().append,
            "*",
            "channel.announcement",
            {
                "announcement_id": str(row.get("id") or ""),
                "title": row.get("title"),
                "status": row.get("status"),
                "destination": str(row.get("destination") or "public"),
                "access_tier": "vip" if str(row.get("destination") or "").lower() == "private" else "public",
            },
            entity_type="announcement",
            entity_id=str(row.get("id") or ""),
        )
    except Exception:
        logger.exception("Mini App announcement event could not be emitted")
    await async_with_db(lambda db: audit(db, query.from_user.id, "channel_announcement", f"{row['id']}:{row['destination']}:{row['status']}"))
    context.user_data.pop("announcement", None)
    status = "✅ اعلان منتشر شد." if not errors else "⚠️ اعلان ثبت شد اما بخشی از ارسال ناموفق بود."
    details = "" if not errors else "\n" + "\n".join(esc(item) for item in errors)
    await edit(query, f"{status}\nشناسه: <code>ANN-{row['id']}</code>{details}", [[InlineKeyboardButton("📋 تاریخچه", callback_data="announce_history"), InlineKeyboardButton("➕ اعلان جدید", callback_data="announce_new")], back("admin_home")[0]])
    return ConversationHandler.END


async def announcement_history_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ANNOUNCEMENT_PREVIEW):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    summary = announcement_summary(db)
    lines = ["📋 <b>تاریخچه اعلان‌ها</b>", f"کل: <b>{summary['total']}</b> | موفق: <b>{summary['sent']}</b> | ناقص: <b>{summary['partial']}</b> | ناموفق: <b>{summary['failed']}</b>", ""]
    for row in announcement_history(db, 15):
        icon = "✅" if row.get("status") == "sent" else "⚠️" if row.get("status") == "partial" else "❌"
        dest = {"public": "عمومی", "private": "خصوصی", "both": "هر دو"}.get(row.get("destination"), "—")
        lines.append(f"{icon} ANN-{row.get('id')} | <b>{esc(row.get('title'))}</b> | {dest} | {display_dt(row.get('created_at'))}")
    if len(lines) == 3:
        lines.append("هنوز اعلانی ثبت نشده است.")
    await edit(query, "\n".join(lines)[:3900], [[InlineKeyboardButton("🔄 بروزرسانی", callback_data="announce_history"), InlineKeyboardButton("➕ اعلان جدید", callback_data="announce_new")], [InlineKeyboardButton("🔙 مرکز اعلان", callback_data="a_announcement")]])


def _signal_template_side_label(side: str) -> str:
    return "BUY 🟢" if str(side).lower() == "buy" else "SELL 🔴"


def _signal_template_home_rows(send_template_image: bool = True) -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("🟢 قالب BUY", callback_data="sig_tpl_side:buy"),
            InlineKeyboardButton("🔴 قالب SELL", callback_data="sig_tpl_side:sell"),
        ],
        [
            state_button(
                "ارسال تصویر قالب",
                bool(send_template_image),
                callback_data="sig_tpl_delivery_toggle",
            )
        ],
        [InlineKeyboardButton("📡 بازگشت به ارسال سیگنال", callback_data="a_signal")],
        back("admin_home")[0],
    ]


async def _render_signal_template_home(query) -> None:
    await async_with_db(ensure_signal_template_settings)
    controls = control_module_state(await async_snapshot(), "signals")
    send_template_image = bool(controls.get("send_template_image", True))
    await edit(
        query,
        "🎨 <b>ویرایشگر قالب سیگنال</b>\n\n"
        "قالب اصلی BUY و SELL دست‌نخورده باقی می‌ماند. جای نوشته‌های نماد، قیمت‌ها و نشان ریسک و اندازه فونت آن‌ها تنظیم می‌شود.\n\n"
        f"ارسال تصویر قالب همراه سیگنال: <b>{'روشن' if send_template_image else 'خاموش'}</b>\n"
        + (
            "در حالت روشن، قالب ساخته‌شده ربات ارسال می‌شود و عکس چارت ادمین تصویر دوم آلبوم است."
            if send_template_image
            else "در حالت خاموش، قالب ربات ارسال نمی‌شود؛ عکس چارت ادمین با کپشن سیگنال فرستاده می‌شود و بدون عکس چارت فقط متن ارسال خواهد شد."
        )
        + "\n\nقالب موردنظر را انتخاب کنید:",
        _signal_template_home_rows(send_template_image),
    )


async def signal_template_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer()
    await _render_signal_template_home(query)


async def signal_template_delivery_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Toggle whether the generated BUY/SELL poster is sent with new signals."""
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    enabled = await async_with_db(
        lambda db: toggle_control_value(
            db, "signals", "send_template_image", query.from_user.id
        )
    )
    await async_with_db(
        lambda db: audit(
            db,
            query.from_user.id,
            "signal_template_delivery_toggle",
            "enabled" if enabled else "disabled",
        )
    )
    await query.answer(
        "ارسال تصویر قالب روشن شد." if enabled else "ارسال تصویر قالب خاموش شد.",
        show_alert=False,
    )
    await _render_signal_template_home(query)


def _signal_template_side_rows(side: str) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = []
    fields = list(SIGNAL_TEMPLATE_FIELDS)
    for index in range(0, len(fields), 2):
        row: list[InlineKeyboardButton] = []
        for field in fields[index:index + 2]:
            row.append(
                InlineKeyboardButton(
                    SIGNAL_TEMPLATE_FIELD_LABELS[field],
                    callback_data=f"sig_tpl_field:{side}:{field}",
                )
            )
        rows.append(row)
    rows.extend(
        [
            [InlineKeyboardButton("📤 ارسال عکس و تنظیم خودکار", callback_data=f"sig_tpl_upload:{side}", style="primary")],
            [InlineKeyboardButton("🖼 پیش‌نمایش آزمایشی", callback_data=f"sig_tpl_preview:{side}")],
            [
                InlineKeyboardButton("🧹 حذف عکس سفارشی", callback_data=f"sig_tpl_bg_reset:{side}"),
                InlineKeyboardButton("♻️ بازنشانی نوشته‌ها", callback_data=f"sig_tpl_reset:{side}"),
            ],
            [InlineKeyboardButton("🔙 انتخاب قالب", callback_data="sig_tpl_home")],
        ]
    )
    return rows


async def signal_template_side_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer()
    side = str(query.data).split(":", 1)[1].lower()
    try:
        template_state = await async_with_db(lambda db: {
            "layout": signal_template_layout(db, side),
            "background": signal_template_background_info(db, side),
        })
        layout = template_state["layout"]
        background = template_state["background"]
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    text = (
        f"🎨 <b>قالب {_signal_template_side_label(side)}</b>\n\n"
        "فیلد موردنظر را انتخاب کنید. تغییرات بلافاصله ذخیره و روی سیگنال بعدی اعمال می‌شوند.\n"
        f"پس‌زمینه: <b>{'سفارشی ✅' if background.get('custom') else 'پیش‌فرض'}</b>\n"
        f"اندازه پایه: <b>{int(layout.get('font_size', 46))}</b>\n\n"
        "برای مسیر ساده، «ارسال عکس و تنظیم خودکار» را بزنید؛ سیستم تصویر را استاندارد می‌کند، محل باکس‌ها را تشخیص می‌دهد و پیش‌نمایش می‌سازد."
    )
    await edit(query, text, _signal_template_side_rows(side))


async def signal_template_upload_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    side = str(query.data or "").split(":", 1)[1].lower()
    if side not in {"buy", "sell"}:
        await query.answer("قالب نامعتبر است.", show_alert=True)
        return ConversationHandler.END
    context.user_data["signal_template_upload_side"] = side
    text = (
        f"📤 <b>ارسال عکس قالب {_signal_template_side_label(side)}</b>\n\n"
        "عکس را همین‌جا به‌صورت Photo یا فایل تصویری بفرستید.\n"
        "سیستم تصویر را استاندارد می‌کند، محل Symbol/Entry/SL/TP/Risk را تشخیص می‌دهد و پیش‌نمایش می‌سازد.\n\n"
        "حداکثر حجم: ۱۲ مگابایت."
    )
    await edit(
        query,
        text,
        [[InlineKeyboardButton("لغو و بازگشت", callback_data=f"sig_tpl_side:{side}")]],
    )
    return SIGNAL_TEMPLATE_UPLOAD_INPUT


async def signal_template_upload_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return ConversationHandler.END
    message = update.effective_message
    side = str(context.user_data.get("signal_template_upload_side") or "").lower()
    if side not in {"buy", "sell"}:
        await reply(update, "❌ نشست ارسال قالب منقضی شده است.", back("sig_tpl_home"))
        return ConversationHandler.END
    file_id = ""
    original_name = f"sentinel_{side}_template.jpg"
    if message.photo:
        file_id = message.photo[-1].file_id
    elif message.document:
        mime = str(message.document.mime_type or "").lower()
        original_name = str(message.document.file_name or original_name)
        if not mime.startswith("image/") and Path(original_name).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
            await reply(update, "❌ فقط فایل تصویری PNG/JPG/WEBP قابل قبول است.")
            return SIGNAL_TEMPLATE_UPLOAD_INPUT
        file_id = message.document.file_id
    if not file_id:
        await reply(update, "❌ عکس یا فایل تصویری ارسال کنید.")
        return SIGNAL_TEMPLATE_UPLOAD_INPUT
    try:
        telegram_file = await context.bot.get_file(file_id)
        payload = bytes(await telegram_file.download_as_bytearray())
        result = await async_with_db(
            lambda db: store_and_autodetect_signal_template_background(
                db, side, payload, original_name=original_name
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "signal_template_upload", side))
    except (ValueError, TelegramError, OSError) as exc:
        await reply(update, f"❌ ذخیره قالب ناموفق بود: {esc(exc)}")
        return SIGNAL_TEMPLATE_UPLOAD_INPUT
    finally:
        context.user_data.pop("signal_template_upload_side", None)
    confidence = float((result.get("detection") or {}).get("confidence") or 0) * 100
    text = (
        f"✅ عکس قالب {_signal_template_side_label(side)} ذخیره شد.\n"
        f"تشخیص خودکار باکس‌ها: <b>{confidence:.0f}٪</b>\n"
        "اکنون پیش‌نمایش را ببینید؛ در صورت نیاز هر فیلد را کمی جابه‌جا کنید."
    )
    await reply(
        update,
        text,
        [
            [InlineKeyboardButton("🖼 ساخت پیش‌نمایش", callback_data=f"sig_tpl_preview:{side}", style="primary")],
            [InlineKeyboardButton("🎨 تنظیم دستی باکس‌ها", callback_data=f"sig_tpl_side:{side}")],
        ],
    )
    return ConversationHandler.END


async def signal_template_upload_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("signal_template_upload_side", None)
    await signal_template_side_menu(update, context)
    return ConversationHandler.END


async def signal_template_background_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    side = str(query.data or "").split(":", 1)[1].lower()
    try:
        await async_with_db(lambda db: reset_signal_template_background(db, side))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("عکس سفارشی حذف شد.", show_alert=True)
    await signal_template_side_menu(update, context)


def _signal_template_field_rows(side: str, field: str) -> list[list[InlineKeyboardButton]]:
    return [
        [InlineKeyboardButton("⬆️", callback_data=f"sig_tpl_move:{side}:{field}:0:-5")],
        [
            InlineKeyboardButton("⬅️", callback_data=f"sig_tpl_move:{side}:{field}:-5:0"),
            InlineKeyboardButton("🎯", callback_data=f"sig_tpl_preview:{side}"),
            InlineKeyboardButton("➡️", callback_data=f"sig_tpl_move:{side}:{field}:5:0"),
        ],
        [InlineKeyboardButton("⬇️", callback_data=f"sig_tpl_move:{side}:{field}:0:5")],
        [
            InlineKeyboardButton("A− کوچک‌تر", callback_data=f"sig_tpl_font:{side}:{field}:-2"),
            InlineKeyboardButton("A+ بزرگ‌تر", callback_data=f"sig_tpl_font:{side}:{field}:2"),
        ],
        [InlineKeyboardButton("🔙 فیلدهای قالب", callback_data=f"sig_tpl_side:{side}")],
    ]


async def _render_signal_template_field(query, side: str, field: str) -> None:
    layout = await async_with_db(lambda db: signal_template_layout(db, side))
    row = layout["fields"][field]
    x1, y1, x2, y2 = row["box"]
    await edit(
        query,
        f"✏️ <b>{SIGNAL_TEMPLATE_FIELD_LABELS[field]} — {_signal_template_side_label(side)}</b>\n\n"
        f"محدوده: <code>{x1},{y1} → {x2},{y2}</code>\n"
        f"اندازه فونت: <b>{int(row.get('font_size', 46))}</b>\n\n"
        "با فلش‌ها جای نوشته را هر بار ۵ پیکسل جابه‌جا کنید. دکمه وسط پیش‌نمایش آزمایشی می‌سازد.",
        _signal_template_field_rows(side, field),
    )


async def signal_template_field_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer()
    _, side, field = str(query.data).split(":", 2)
    if side not in {"buy", "sell"} or field not in SIGNAL_TEMPLATE_FIELDS:
        await query.answer("قالب یا فیلد نامعتبر است.", show_alert=True)
        return
    await _render_signal_template_field(query, side, field)


async def signal_template_move(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer("ذخیره شد")
    parts = str(query.data).split(":")
    if len(parts) != 5:
        await query.answer("دستور جابه‌جایی نامعتبر است.", show_alert=True)
        return
    _, side, field, dx, dy = parts
    try:
        await async_with_db(
            lambda db: move_signal_template_field(db, side, field, dx=int(dx), dy=int(dy))
        )
    except (ValueError, TypeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _render_signal_template_field(query, side, field)


async def signal_template_font(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer("ذخیره شد")
    parts = str(query.data).split(":")
    if len(parts) != 4:
        await query.answer("دستور فونت نامعتبر است.", show_alert=True)
        return
    _, side, field, delta = parts
    try:
        await async_with_db(lambda db: change_signal_template_font(db, side, field, int(delta)))
    except (ValueError, TypeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _render_signal_template_field(query, side, field)


async def signal_template_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer("قالب بازنشانی شد")
    side = str(query.data).split(":", 1)[1].lower()
    try:
        await async_with_db(lambda db: reset_signal_template_side(db, side))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await edit(
        query,
        f"✅ تنظیمات نوشته‌های قالب {_signal_template_side_label(side)} به حالت اولیه بازگشت.",
        _signal_template_side_rows(side),
    )


async def signal_template_preview(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_TEMPLATES):
        return
    query = update.callback_query
    await query.answer("در حال ساخت پیش‌نمایش…")
    side = str(query.data).split(":", 1)[1].lower()
    if side not in {"buy", "sell"}:
        await query.answer("قالب نامعتبر است.", show_alert=True)
        return
    template_settings = await async_with_db(lambda db: {
        "layout": signal_template_layout(db, side),
        "path": signal_template_background_path(db, side),
    })
    layout = template_settings["layout"]
    if side == "buy":
        entry, targets, stop = "68250", ["68800", "69400", "70200"], "67450"
    else:
        entry, targets, stop = "68250", ["67600", "66900", "66100"], "69050"
    path = await run_blocking(
        create_signal_image,
        "BTCUSDT",
        entry,
        targets,
        stop,
        side.upper(),
        "1",
        layout_overrides=layout,
        template_path=template_settings.get("path"),
    )
    try:
        with open(path, "rb") as photo:
            await _telegram_request_with_button_fallback(
                context.bot.send_photo,
                query.message.chat_id,
                photo,
                caption=f"🖼 پیش‌نمایش قالب {_signal_template_side_label(side)}\nفایل اصلی قالب تغییر نکرده است.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("🎨 بازگشت به ویرایشگر", callback_data=f"sig_tpl_side:{side}")]]
                ),
            )
    except TelegramError:
        logger.exception("Could not send signal template preview")
        await query.answer("ارسال پیش‌نمایش ناموفق بود.", show_alert=True)
    finally:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            logger.warning("Could not delete template preview %s", path)


async def a_signal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    cycle = current_signal_cycle(db)
    next_numbers = cycle.get("next_numbers", {}) if isinstance(cycle.get("next_numbers"), dict) else {}
    approvals = await async_with_db(pending_signal_approvals)
    signal_controls = control_module_state(db, "signals")
    footer_channel_id = signal_message_channel_id(db)
    rows = [
        [InlineKeyboardButton(f"💱 سیگنال فارکس — شماره بعد #{int(next_numbers.get('forex', 1) or 1)}", callback_data="sig_market:forex")],
        [InlineKeyboardButton(f"🪙 سیگنال کریپتو — شماره بعد #{int(next_numbers.get('crypto', 1) or 1)}", callback_data="sig_market:crypto")],
    ]
    if _is_owner_admin(query.from_user.id) and (bool(signal_controls.get("owner_approval", False)) or approvals):
        rows.append([InlineKeyboardButton(f"🛡 تأییدهای در انتظار ({len(approvals)})", callback_data="sig_approval_list")])
    rows.append(
        [InlineKeyboardButton("🆔 آیدی کانال انتهای پیام", callback_data="sig_channel_id_start")]
    )
    rows.extend(
        [
            *(
                [[
                    InlineKeyboardButton("🎨 قالب BUY / SELL", callback_data="sig_tpl_home"),
                    state_button(
                        "ارسال قالب",
                        bool(signal_controls.get("send_template_image", True)),
                        callback_data="sig_tpl_delivery_toggle",
                    ),
                ]]
                if _has_admin_permission(query.from_user.id, PERMISSION_SIGNAL_TEMPLATES)
                else []
            ),
            *(
                [[InlineKeyboardButton("📊 مدیریت نتایج", callback_data="a_signal_results")]]
                if _has_admin_permission(query.from_user.id, PERMISSION_SIGNAL_RESULTS)
                else []
            ),
            back("admin_home")[0],
        ]
    )
    safety = (
        "محدودیت تعداد و ریسک ارسال: <b>غیرفعال</b> | "
        "R/R اجباری: <b>غیرفعال</b> | "
        "تأیید مالک برای ارسال ادمین: <b>غیرفعال دائمی</b> | "
        f"ارسال قالب: <b>{'روشن' if signal_controls.get('send_template_image', True) else 'خاموش'}</b>\n"
        f"آیدی انتهای پیام: <code>{esc(footer_channel_id or 'تنظیم نشده')}</code>"
    )
    await edit(
        query,
        "📡 <b>ساخت سیگنال جدید</b>\n"
        "بازار را انتخاب کنید. شماره‌گذاری فارکس و کریپتو مستقل است.\n\n"
        + safety,
        rows,
    )
    return SIG_MARKET


async def signal_owner_approval_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Kept only for stale Telegram keyboards from older deployments. The
    # owner-approval restriction has been removed from human admin signals.
    query = update.callback_query
    await query.answer("محدودیت تأیید مالک برای ارسال سیگنال ادمین حذف شده است.", show_alert=True)
    await a_signal(update, context)


async def signal_channel_id_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    current = signal_message_channel_id(await async_snapshot())
    await edit(
        query,
        "🆔 <b>آیدی کانال در انتهای پیام سیگنال</b>\n\n"
        f"مقدار فعلی: <code>{esc(current or 'تنظیم نشده')}</code>\n\n"
        "آیدی جدید را مانند <code>@MyChannel</code> یا <code>t.me/MyChannel</code> ارسال کنید. "
        "این مقدار در آخر متن همه سیگنال‌های جدید قرار می‌گیرد.\n"
        "برای حذف آیدی، کلمه <code>حذف</code> را بفرستید.",
        [[InlineKeyboardButton("🔙 بازگشت", callback_data="a_signal")]],
    )
    return SIGNAL_CHANNEL_ID_INPUT


async def signal_channel_id_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    try:
        normalized = normalize_signal_message_channel_id(update.message.text or "")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nدوباره وارد کنید یا کلمه <code>حذف</code> را بفرستید.")
        return SIGNAL_CHANNEL_ID_INPUT
    saved = await async_with_db(
        lambda db: set_signal_message_channel_id(db, normalized, update.effective_user.id)
    )
    await async_with_db(
        lambda db: audit(
            db,
            update.effective_user.id,
            "signal_message_channel_id",
            saved or "cleared",
        )
    )
    await reply(
        update,
        (
            f"✅ آیدی <code>{esc(saved)}</code> ذخیره شد و از سیگنال بعدی در انتهای پیام قرار می‌گیرد."
            if saved
            else "✅ آیدی انتهای پیام حذف شد."
        ),
        [[InlineKeyboardButton("🔙 بازگشت به ارسال سیگنال", callback_data="a_signal")]],
    )
    return SIG_MARKET


def _signal_symbol_rows(category: str) -> list[list[InlineKeyboardButton]]:
    normalized = normalize_market_category(category)
    symbols = FOREX_SIGNAL_SYMBOLS if normalized == MARKET_FOREX else CRYPTO_SIGNAL_SYMBOLS
    rows = [[InlineKeyboardButton(symbol, callback_data=f"sig_symbol:{symbol}")] for symbol in symbols]
    rows.append([InlineKeyboardButton("✏️ وارد کردن نماد دلخواه", callback_data="sig_symbol:manual")])
    rows.append([InlineKeyboardButton("⬅️ مرحله قبل — انتخاب بازار", callback_data="sig_back:market")])
    return rows


async def signal_market_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    category = normalize_market_category(query.data.split(":", 1)[1])
    previous = context.user_data.get("signal") if isinstance(context.user_data.get("signal"), dict) else {}
    # Selecting a new market invalidates every downstream value but preserves
    # the draft container so Back navigation remains deterministic.
    context.user_data["signal"] = {"market_category": category}
    if previous.get("market_category") == category and previous.get("symbol"):
        context.user_data["signal"]["symbol"] = previous.get("symbol")
    await edit(
        query,
        f"📌 نماد سیگنال {market_label(category)} را انتخاب یا دقیقاً وارد کنید:",
        _signal_symbol_rows(category),
    )
    return SIG_SYMBOL


def _signal_side_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [InlineKeyboardButton("🟢 BUY", callback_data="sig_side:buy"), InlineKeyboardButton("🔴 SELL", callback_data="sig_side:sell")],
        [InlineKeyboardButton("⬅️ مرحله قبل — انتخاب نماد", callback_data="sig_back:symbol")],
    ]


async def signal_symbol(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    value = query.data.split(":", 1)[1]
    data = context.user_data.setdefault("signal", {"market_category": MARKET_FOREX})
    category = normalize_market_category(data.get("market_category"))
    if value == "manual":
        await edit(
            query,
            f"✏️ نماد {market_label(category)} را دقیقاً وارد کنید؛ مثال: <code>{'XAUUSD' if category == MARKET_FOREX else 'BTCUSDT'}</code>",
            [[InlineKeyboardButton("⬅️ مرحله قبل — فهرست نمادها", callback_data="sig_back:symbol")]],
        )
        return SIG_SYMBOL
    from modules.signal import normalize_signal_symbol
    symbol = normalize_signal_symbol(value)
    if classify_market_symbol(symbol) != category:
        await query.answer("نماد با دسته انتخابی مطابقت ندارد.", show_alert=True)
        return SIG_SYMBOL
    data["symbol"] = symbol
    await edit(query, "نوع سیگنال را انتخاب کنید:", _signal_side_rows())
    return SIG_TYPE


async def signal_symbol_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    from modules.signal import normalize_signal_symbol
    data = context.user_data.setdefault("signal", {"market_category": MARKET_FOREX})
    category = normalize_market_category(data.get("market_category"))
    try:
        symbol = normalize_signal_symbol(update.message.text or "")
        detected = classify_market_symbol(symbol)
        if detected != category:
            raise ValueError(f"این نماد در دسته {market_label(detected)} قرار دارد؛ دسته درست را انتخاب کنید.")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_SYMBOL
    data["symbol"] = symbol
    await reply(update, f"✅ نماد {market_label(category)} ثبت شد: <code>{esc(symbol)}</code>\nنوع سیگنال را انتخاب کنید:", _signal_side_rows())
    return SIG_TYPE


async def signal_side(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["signal"]["side"] = query.data.split(":", 1)[1]
    await edit(query, "📍 یک تا پنج قیمت ورود را با کاما جدا کنید؛ مثال: <code>1920, 1917.5, 1915</code>", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:type")]])
    return SIG_ENTRY


async def signal_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    try:
        entries = normalize_entries(update.message.text or "")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_ENTRY
    context.user_data["signal"]["entries"] = entries
    context.user_data["signal"]["entry"] = enrich_signal_payload({"entries": entries, "targets": [], "risk": 0})["entry"]
    await reply(
        update,
        f"✅ {len(entries)} نقطه ورود ثبت شد. میانگین ورود: <code>{esc(context.user_data['signal']['entry'])}</code>\n"
        "🎯 اهداف را با کاما جدا کنید؛ مثال: <code>1920, 1925, 1930</code>",
        [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:entry")]],
    )
    return SIG_TP


async def signal_targets(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    values = [part.strip() for part in (update.message.text or "").split(",") if part.strip()]
    if not 1 <= len(values) <= 3:
        await reply(update, "❌ قالب سیگنال فقط ۱ تا ۳ تارگت دارد؛ بین ۱ تا ۳ هدف وارد کنید.")
        return SIG_TP
    from modules.signal import normalize_signal_price, validate_signal_targets

    try:
        values = [normalize_signal_price(value, f"هدف {index}") for index, value in enumerate(values, start=1)]
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_TP

    data = context.user_data.get("signal", {})
    try:
        for entry_value in data.get("entries") or [data.get("entry", "")]:
            validate_signal_targets(entry_value, values, data.get("side", ""))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nاهداف را دوباره وارد کنید:")
        return SIG_TP
    context.user_data["signal"]["targets"] = values
    await reply(update, "🛑 حد ضرر را وارد کنید:", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:targets")]])
    return SIG_SL


async def signal_stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    from modules.signal import normalize_signal_price, validate_signal_stop

    try:
        value = normalize_signal_price(update.message.text or "", "حد ضرر")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_SL

    data = context.user_data.get("signal", {})
    try:
        for entry_value in data.get("entries") or [data.get("entry", "")]:
            validate_signal_stop(entry_value, value, data.get("side", ""))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nحد ضرر را دوباره وارد کنید:")
        return SIG_SL
    context.user_data["signal"]["stop"] = value
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(f"{preset:g}٪", callback_data=f"sig_risk:{preset:g}") for preset in (0.5, 1.0, 2.0)],
        [InlineKeyboardButton("✏️ دستی", callback_data="sig_risk:manual")],
        [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:stop")],
    ]
    await reply(update, "⚡ درصد ریسک را انتخاب کنید یا هر مقدار مثبت را دستی وارد کنید؛ سقف ریسک غیرفعال است:", rows)
    return SIG_RISK


def _signal_chart_prompt(send_template_image: bool) -> str:
    if send_template_image:
        return (
            "✅ ریسک ثبت شد. حالا می‌توانید <b>عکس چارت</b> را ارسال کنید تا همراه قالب سیگنال منتشر شود.\n\n"
            "• عکس ارسالی ادمین، تصویر دوم آلبوم خواهد بود.\n"
            "• تصویر اول را ربات از قالب BUY/SELL می‌سازد.\n"
            "• برای ادامه بدون عکس چارت، دکمه زیر را بزنید."
        )
    return (
        "✅ ریسک ثبت شد. ارسال تصویر قالب ربات در تنظیمات <b>خاموش</b> است.\n\n"
        "• در صورت ارسال عکس چارت، همان عکس با کپشن سیگنال منتشر می‌شود.\n"
        "• در صورت ادامه بدون عکس چارت، فقط متن سیگنال ارسال خواهد شد.\n"
        "• این وضعیت از دکمه «ارسال قالب» در بخش سیگنال قابل تغییر است."
    )


async def signal_risk_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    value = query.data.split(":", 1)[1]
    controls = control_module_state(await async_snapshot(), "signals")
    if value == "manual":
        await edit(query, "درصد ریسک را وارد کنید؛ هر مقدار مثبت مجاز است و سقف ریسک غیرفعال است:", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:stop")]])
        return SIG_RISK
    context.user_data["signal"]["risk"] = value
    await edit(
        query,
        _signal_chart_prompt(bool(controls.get("send_template_image", True))),
        _signal_chart_rows(),
    )
    return SIG_CHART_IMAGE


async def signal_risk_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    from modules.signal import normalize_signal_risk

    try:
        value = normalize_signal_risk(update.message.text or "")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_RISK
    controls = control_module_state(await async_snapshot(), "signals")
    context.user_data["signal"]["risk"] = value
    await reply(
        update,
        _signal_chart_prompt(bool(controls.get("send_template_image", True))),
        _signal_chart_rows(),
    )
    return SIG_CHART_IMAGE


def _signal_chart_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [InlineKeyboardButton("⏭ ادامه بدون عکس چارت", callback_data="sig_chart_skip")],
        [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:risk")],
    ]


async def signal_chart_image(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Attach one admin-provided chart image to the pending signal."""
    if not await require_admin(update, PERMISSION_SIGNAL_CHART_MANAGE):
        return ConversationHandler.END
    message = update.effective_message
    photos = list(getattr(message, "photo", None) or [])
    if not photos:
        await reply(
            update,
            "❌ لطفاً عکس را به‌صورت Photo بفرستید؛ ارسال فایل Document در این مرحله پذیرفته نمی‌شود.",
            _signal_chart_rows(),
        )
        return SIG_CHART_IMAGE
    data = context.user_data.get("signal")
    if not isinstance(data, dict):
        await reply(update, "❌ اطلاعات سیگنال منقضی شده است؛ دوباره شروع کنید.", back("a_signal"))
        return ConversationHandler.END
    photo = photos[-1]
    data["chart_photo_file_id"] = str(photo.file_id)
    data["chart_photo_unique_id"] = str(getattr(photo, "file_unique_id", "") or "")
    data["chart_photo_width"] = int(getattr(photo, "width", 0) or 0)
    data["chart_photo_height"] = int(getattr(photo, "height", 0) or 0)
    data["chart_photo_added_by"] = int(update.effective_user.id)
    controls = control_module_state(await async_snapshot(), "signals")
    template_enabled = bool(controls.get("send_template_image", True))
    await reply(
        update,
        (
            "✅ عکس چارت ثبت شد. هنگام انتشار، ابتدا قالب ساخته‌شده ربات و سپس عکس چارت شما ارسال می‌شود.\n\n"
            if template_enabled
            else "✅ عکس چارت ثبت شد. چون ارسال قالب خاموش است، فقط همین عکس با کپشن سیگنال منتشر می‌شود.\n\n"
        )
        + "مقصد ارسال سیگنال را انتخاب کنید:",
        _signal_target_rows(),
    )
    return SIG_TARGET


async def signal_chart_skip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    data = context.user_data.get("signal")
    if not isinstance(data, dict):
        await query.answer("اطلاعات سیگنال منقضی شده است.", show_alert=True)
        return ConversationHandler.END
    for key in (
        "chart_photo_file_id",
        "chart_photo_unique_id",
        "chart_photo_width",
        "chart_photo_height",
        "chart_photo_added_by",
    ):
        data.pop(key, None)
    await edit(query, "مقصد ارسال سیگنال را انتخاب کنید:", _signal_target_rows())
    return SIG_TARGET


async def signal_chart_change(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_CHART_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if not isinstance(context.user_data.get("signal"), dict):
        await query.answer("اطلاعات سیگنال منقضی شده است.", show_alert=True)
        return ConversationHandler.END
    await edit(
        query,
        "🖼 عکس چارت جدید را ارسال کنید. عکس جدید جایگزین عکس قبلی می‌شود.\n"
        "برای حذف عکس فعلی و ادامه بدون آن، دکمه زیر را بزنید.",
        _signal_chart_rows(),
    )
    return SIG_CHART_IMAGE


async def signal_wizard_back(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Move one step backward without discarding the signal draft."""
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    data = context.user_data.get("signal")
    if not isinstance(data, dict):
        await edit(query, "❌ اطلاعات سیگنال منقضی شده است؛ دوباره شروع کنید.", back("a_signal"))
        return ConversationHandler.END
    stage = str(query.data or "").split(":", 1)[1]
    if stage == "market":
        # Return to the market chooser without deleting the draft. The next
        # market selection will reset only incompatible downstream fields.
        db = await async_snapshot()
        cycle = current_signal_cycle(db)
        next_numbers = cycle.get("next_numbers", {}) if isinstance(cycle.get("next_numbers"), dict) else {}
        rows = [
            [InlineKeyboardButton(f"💱 سیگنال فارکس — شماره بعد #{int(next_numbers.get('forex', 1) or 1)}", callback_data="sig_market:forex")],
            [InlineKeyboardButton(f"🪙 سیگنال کریپتو — شماره بعد #{int(next_numbers.get('crypto', 1) or 1)}", callback_data="sig_market:crypto")],
            [InlineKeyboardButton("❌ لغو ساخت سیگنال", callback_data="admin_home")],
        ]
        await edit(query, "📡 بازار سیگنال را انتخاب کنید:", rows)
        return SIG_MARKET
    if stage == "symbol":
        category = normalize_market_category(data.get("market_category") or MARKET_FOREX)
        await edit(
            query,
            f"📌 نماد سیگنال {market_label(category)} را انتخاب یا دقیقاً وارد کنید:",
            _signal_symbol_rows(category),
        )
        return SIG_SYMBOL
    if stage == "type":
        await edit(query, "نوع سیگنال را انتخاب کنید:", _signal_side_rows())
        return SIG_TYPE
    if stage == "entry":
        await edit(query, "📍 نقاط ورود را دوباره وارد کنید؛ مقادیر قبلی جایگزین می‌شوند:", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:type")]])
        return SIG_ENTRY
    if stage == "targets":
        await edit(query, "🎯 اهداف را دوباره با کاما جدا کنید:", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:entry")]])
        return SIG_TP
    if stage == "stop":
        await edit(query, "🛑 حد ضرر را دوباره وارد کنید:", [[InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:targets")]])
        return SIG_SL
    if stage == "risk":
        rows = [
            [InlineKeyboardButton(f"{value:g}٪", callback_data=f"sig_risk:{value:g}") for value in (0.5, 1.0, 2.0)],
            [InlineKeyboardButton("✏️ دستی", callback_data="sig_risk:manual")],
            [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:stop")],
        ]
        await edit(query, "⚡ درصد ریسک را انتخاب کنید یا هر مقدار مثبت را دستی وارد کنید؛ سقف ریسک غیرفعال است:", rows)
        return SIG_RISK
    if stage == "chart":
        controls = control_module_state(await async_snapshot(), "signals")
        await edit(query, _signal_chart_prompt(bool(controls.get("send_template_image", True))), _signal_chart_rows())
        return SIG_CHART_IMAGE
    if stage == "target":
        await edit(query, "مقصد ارسال سیگنال را انتخاب کنید:", _signal_target_rows())
        return SIG_TARGET
    if stage == "preview":
        target = str(context.user_data.get("signal_target") or "")
        if target not in {"public", "private", "both"}:
            await edit(query, "مقصد ارسال سیگنال را انتخاب کنید:", _signal_target_rows())
            return SIG_TARGET
        snapshot = await async_snapshot()
        report = evaluate_signal_safety(snapshot, data)
        send_template_image = bool(control_module_state(snapshot, "signals").get("send_template_image", True))
        await edit(
            query,
            _signal_preview_text(data, target, report, send_template_image=send_template_image),
            _signal_preview_rows(allow_publish=report.ok),
        )
        return SIG_TARGET
    await edit(query, "مرحله قبلی پیدا نشد؛ ساخت سیگنال را از نو شروع کنید.", back("a_signal"))
    return ConversationHandler.END


def _signal_target_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("📢 عمومی", callback_data="sig_target:public"),
            InlineKeyboardButton("🔒 خصوصی", callback_data="sig_target:private"),
            InlineKeyboardButton("🔁 هر دو", callback_data="sig_target:both"),
        ],
        [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:chart")],
    ]


def _signal_preview_text(
    data: dict[str, Any],
    target: str,
    safety_report: Any | None = None,
    *,
    send_template_image: bool = True,
) -> str:
    data = enrich_signal_payload(data)
    destination = {
        "public": "📢 کانال عمومی",
        "private": "🔒 کانال VIP",
        "both": "🔁 هر دو کانال",
    }.get(target, target)
    targets = "\n".join(
        f"🎯 تارگت {index}: <code>{esc(value)}</code>"
        for index, value in enumerate(data.get("targets", []), start=1)
    )
    entries = list(data.get("entries") or [data.get("entry")])
    entry_text = "، ".join(str(item) for item in entries)
    side = str(data.get("side") or "").upper()
    safety = ""
    if safety_report is not None:
        safety = "\n\n" + format_safety_report(safety_report)
    footer_channel_id = str(data.get("message_channel_id") or "").strip()
    return (
        "👁 <b>پیش‌نمایش نهایی سیگنال</b>\n\n"
        f"مقصد: <b>{destination}</b>\n"
        f"نوع: <b>{esc(side)}</b>\n"
        f"نماد: <b>{esc(data.get('symbol'))}</b>\n"
        f"📍 ورود: <code>{esc(entry_text)}</code>\n"
        f"{targets}\n"
        f"🛑 حد ضرر: <code>{esc(data.get('stop'))}</code>\n"
        f"⚡ ریسک: <b>{esc(data.get('risk'))}%</b>\n"
        f"🖼 ارسال تصویر قالب ربات: <b>{'روشن' if send_template_image else 'خاموش'}</b>\n"
        f"📊 عکس چارت ادمین: <b>{'پیوست شده' if data.get('chart_photo_file_id') else 'ندارد'}</b>\n"
        f"🆔 آیدی انتهای پیام: <code>{esc(footer_channel_id or 'تنظیم نشده')}</code>"
        f"{safety}\n\n"
        + (
            "قالب BUY یا SELL ارسال می‌شود و در صورت وجود عکس چارت، هر دو تصویر به‌صورت یک آلبوم خواهند بود."
            if send_template_image
            else (
                "قالب ربات ارسال نمی‌شود؛ عکس چارت با کپشن سیگنال منتشر خواهد شد."
                if data.get("chart_photo_file_id")
                else "قالب ربات ارسال نمی‌شود و چون عکس چارت وجود ندارد، سیگنال فقط به‌صورت متن منتشر خواهد شد."
            )
        )
    )


def _signal_preview_rows(*, allow_publish: bool = True) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = []
    if allow_publish:
        rows.append(
            [
                InlineKeyboardButton("✅ انتشار الآن", callback_data="sig_publish_now"),
                InlineKeyboardButton("🕒 زمان‌بندی", callback_data="sig_schedule_start"),
            ]
        )
    rows.extend(
        [
            [InlineKeyboardButton("🖼 افزودن / تغییر عکس چارت", callback_data="sig_chart_change")],
            [
                InlineKeyboardButton("🎯 تغییر مقصد", callback_data="sig_preview_target"),
                InlineKeyboardButton("⬅️ مرحله قبل", callback_data="sig_back:target"),
            ],
            [InlineKeyboardButton("❌ لغو", callback_data="a_signal")],
        ]
    )
    return rows


async def _project_signal_to_miniapp(row: dict[str, Any], event_type: str = "signal.updated") -> dict[str, Any] | None:
    """Keep the normalized Mini App projection in lockstep with Telegram state."""
    try:
        from services.signal_projection_service import project_signal_update

        return await run_blocking(project_signal_update, dict(row), event_type)
    except Exception:
        logger.exception("Signal could not be projected to Mini App signal_id=%s", row.get("id"))
        return None


async def _publish_signal_payload(
    bot,
    data: dict[str, Any],
    target: str,
    admin_id: int | str,
    *,
    scheduled_id: int | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Publish once and project the same canonical signal everywhere.

    Network delivery is checkpointed before the canonical record is finalized.
    A worker restart after Telegram accepted the post therefore resumes from the
    checkpoint instead of sending duplicate channel messages.
    """
    from modules.signal import create_signal_async, send_signal_with_receipts

    data = enrich_signal_payload(data)

    async def finalize_record(record_payload: dict[str, Any], errors: list[str]) -> dict[str, Any]:
        def store(db: dict[str, Any]) -> dict[str, Any]:
            existing = next(
                (
                    row for row in db.get("signals", [])
                    if isinstance(row, dict)
                    and scheduled_id is not None
                    and str(row.get("scheduled_id") or "") == str(scheduled_id)
                    and row.get("delivered_channels")
                ),
                None,
            )
            if existing:
                return existing
            record = register_signal_record(db, dict(record_payload))
            audit(db, admin_id, "send_signal", f"{record['id']}:{record.get('symbol')}:{target}")
            if errors:
                record_incident(
                    db,
                    source="signal_delivery",
                    kind="partial_delivery_failure",
                    detail=" | ".join(str(item) for item in errors),
                    severity="warning",
                    metadata={"signal_id": record.get("id"), "symbol": record.get("symbol"), "target": target},
                )
            refresh_trust_center(db)
            for name in record.get("requested_channels", []):
                delivered = name in set(record.get("delivered_channels") or [])
                delivery = next((item for item in record.get("deliveries", []) if item.get("channel") == name), {})
                record_channel_event(
                    db,
                    name,
                    "signal_sent",
                    success=delivered,
                    message_id=int(delivery.get("message_id", 0) or 0) or None,
                    detail=f"signal:{record['id']}",
                    metadata={"symbol": record.get("symbol"), "target": target},
                )
            if scheduled_id is not None:
                checkpoint = db.setdefault("signal_delivery_checkpoints", {}).get(str(scheduled_id))
                if isinstance(checkpoint, dict):
                    checkpoint["status"] = "committed"
                    checkpoint["signal_id"] = record.get("id")
                    checkpoint["committed_at"] = utc_iso()
            return record

        return await async_with_db(store)

    if scheduled_id is not None:
        recovery = await async_snapshot()
        existing = next(
            (
                row for row in recovery.get("signals", [])
                if isinstance(row, dict)
                and str(row.get("scheduled_id") or "") == str(scheduled_id)
                and row.get("delivered_channels")
            ),
            None,
        )
        if existing:
            stored = dict(existing)
            await _project_signal_to_miniapp(stored, "signal.created")
            return stored, list(stored.get("errors") or [])
        checkpoint = (recovery.get("signal_delivery_checkpoints") or {}).get(str(scheduled_id))
        if isinstance(checkpoint, dict) and checkpoint.get("delivered_channels") and isinstance(checkpoint.get("record_payload"), dict):
            stored = await finalize_record(dict(checkpoint["record_payload"]), list(checkpoint.get("errors") or []))
            await _project_signal_to_miniapp(stored, "signal.created")
            await _sync_signal_live_status(bot, stored, create_if_missing=True)
            await _sync_smart_pin(bot)
            return stored, list(checkpoint.get("errors") or [])

    safety_db = await async_snapshot()
    if "message_channel_id" in data:
        data["message_channel_id"] = normalize_signal_message_channel_id(data.get("message_channel_id"))
    else:
        data["message_channel_id"] = signal_message_channel_id(safety_db)
    allowed, blocked_reason = publication_allowed(safety_db)
    if not allowed:
        raise ValueError(f"انتشار متوقف است: {blocked_reason}")
    safety_controls = control_module_state(safety_db, "signals")
    send_template_image = bool(safety_controls.get("send_template_image", True))
    calendar_events = None
    if bool(safety_controls.get("news_guard", True)):
        try:
            calendar_events = await fetch_economic_calendar(force=False)
        except Exception:
            logger.exception("News Guard calendar fetch failed; admin publication remains allowed")
            calendar_events = None
    safety_report = evaluate_signal_safety(safety_db, data, calendar_events=calendar_events)
    if not safety_report.ok:
        raise ValueError(" | ".join(safety_report.errors))

    identity = await async_with_db(lambda db: reserve_signal_identity(db, data.get("market_category")))
    signal_id = int(identity["id"])
    display_number = int(identity["display_number"])
    cycle_id = int(identity["cycle_id"])
    try:
        signal = await create_signal_async(
            data["symbol"], data["entry"], list(data["targets"]), data["stop"], data["side"], data["risk"],
            brand_handle=SETTINGS.signal_brand_handle, entries=list(data.get("entries") or [data["entry"]]),
            signal_id=display_number,
            message_channel_id=str(data.get("message_channel_id") or ""),
        )
        signal["chart_photo_file_id"] = str(data.get("chart_photo_file_id") or "").strip()
        extra_chart_ids = data.get("chart_photo_file_ids")
        if isinstance(extra_chart_ids, list):
            signal["chart_photo_file_ids"] = [str(item or "").strip() for item in extra_chart_ids if str(item or "").strip()]
        elif signal["chart_photo_file_id"]:
            signal["chart_photo_file_ids"] = [signal["chart_photo_file_id"]]
        signal["send_template_image"] = send_template_image
    except Exception:
        await async_with_db(lambda db: release_reserved_signal_number(db, identity))
        raise

    try:
        runtime = runtime_safety(safety_db)
        if runtime.get("mode") == "staging":
            public_channel_id = SETTINGS.staging_public_channel_id
            private_channel_id = SETTINGS.staging_private_channel_id
            if not public_channel_id and not private_channel_id:
                raise ValueError("حالت Staging فعال است اما کانال آزمایشی تنظیم نشده")
        else:
            public_channel_id = SETTINGS.public_channel_id
            private_channel_id = SETTINGS.private_channel_id
        errors, deliveries = await send_signal_with_receipts(
            bot, signal, target, public_channel_id, private_channel_id,
        )
    except Exception:
        await async_with_db(lambda db: release_reserved_signal_number(db, identity))
        raise

    requested_channels = [name for name in ("public", "private") if target in {name, "both"}]
    delivered_channels = sorted({str(item.get("channel")) for item in deliveries if int(item.get("message_id", 0) or 0) > 0})
    if not delivered_channels:
        await async_with_db(lambda db: release_reserved_signal_number(db, identity))
        detail = " | ".join(str(item) for item in errors) or "هیچ مقصدی پیام را دریافت نکرد"
        await async_with_db(
            lambda db: record_incident(
                db, source="signal_delivery", kind="delivery_failure", detail=detail, severity="critical",
                metadata={"scheduled_id": scheduled_id, "symbol": data.get("symbol"), "target": target},
            )
        )
        raise RuntimeError(detail)

    record_payload = {
        **data,
        "id": signal_id,
        "display_number": display_number,
        "cycle_id": cycle_id,
        "target": target,
        "requested_channels": requested_channels,
        "delivered_channels": delivered_channels,
        "created_at": utc_iso(),
        "admin_id": int(admin_id) if str(admin_id).isdigit() else str(admin_id),
        "errors": list(errors),
        "deliveries": list(deliveries),
        "lifecycle_history": [],
        "highest_target_hit": 0,
        "scheduled_id": scheduled_id,
        "expires_at": safety_report.expires_at,
        "safety_report": safety_report.as_dict(),
        "send_template_image": send_template_image,
    }
    if scheduled_id is not None:
        await async_with_db(
            lambda db: db.setdefault("signal_delivery_checkpoints", {}).__setitem__(
                str(scheduled_id),
                {
                    "scheduled_id": scheduled_id,
                    "status": "delivered",
                    "record_payload": dict(record_payload),
                    "delivered_channels": list(delivered_channels),
                    "deliveries": list(deliveries),
                    "errors": list(errors),
                    "created_at": utc_iso(),
                },
            )
        )

    stored = await finalize_record(record_payload, list(errors))
    await _project_signal_to_miniapp(stored, "signal.created")
    await _sync_signal_live_status(bot, stored, create_if_missing=True)
    await _sync_smart_pin(bot)
    return stored, list(errors)


async def signal_target(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    target = query.data.split(":", 1)[1]
    data = context.user_data.get("signal")
    if not data:
        await query.answer("اطلاعات سیگنال منقضی شده است.", show_alert=True)
        return ConversationHandler.END
    snapshot = await async_snapshot()
    data["message_channel_id"] = signal_message_channel_id(snapshot)
    report = evaluate_signal_safety(snapshot, data)
    send_template_image = bool(
        control_module_state(snapshot, "signals").get("send_template_image", True)
    )
    context.user_data["signal_target"] = target
    context.user_data["signal_safety_preview"] = report.as_dict()
    await edit(
        query,
        _signal_preview_text(
            data,
            target,
            report,
            send_template_image=send_template_image,
        ),
        _signal_preview_rows(allow_publish=report.ok),
    )
    return SIG_TARGET


async def signal_preview_target(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(query, "مقصد ارسال را انتخاب کنید:", _signal_target_rows())
    return SIG_TARGET


async def _queue_signal_for_approval(
    context: ContextTypes.DEFAULT_TYPE,
    *,
    data: dict[str, Any],
    target: str,
    requested_by: int | str,
    run_at: str | None = None,
) -> dict[str, Any]:
    if not SETTINGS.admin_ids:
        raise ValueError("مالک اصلی در ADMIN_IDS تنظیم نشده است")
    approver_ids = [int(SETTINGS.admin_ids[0])]
    row = await async_with_db(
        lambda db: create_signal_approval(
            db,
            payload=enrich_signal_payload(data),
            target=target,
            requested_by=requested_by,
            run_at=run_at,
        )
    )
    destination = {"public": "عمومی", "private": "خصوصی", "both": "هر دو"}.get(target, target)
    mode = f"زمان‌بندی برای {display_dt(run_at)}" if run_at else "انتشار فوری"
    keyboard = InlineKeyboardMarkup(
        [[
            InlineKeyboardButton("✅ تأیید و اجرا", callback_data=f"sig_approval:{row['id']}:approve"),
            InlineKeyboardButton("❌ رد", callback_data=f"sig_approval:{row['id']}:reject"),
        ]]
    )
    message = (
        "🛡 <b>درخواست تأیید مالک اصلی سیگنال</b>\n\n"
        f"شناسه: <code>SA-{row['id']}</code>\n"
        f"نماد: <b>{esc(data.get('symbol'))}</b> | "
        f"نوع: <b>{esc(str(data.get('side') or '').upper())}</b>\n"
        f"Entry: <code>{esc(data.get('entry') or '—')}</code>\n"
        f"SL: <code>{esc(data.get('stop') or '—')}</code>\n"
        f"TP: <code>{esc(' / '.join(str(x) for x in (data.get('targets') or [])) or '—')}</code>\n"
        f"عکس چارت: <b>{'دارد' if data.get('chart_photo_file_id') else 'ندارد'}</b>\n"
        f"آیدی انتهای پیام: <code>{esc(data.get('message_channel_id') or 'تنظیم نشده')}</code>\n"
        f"مقصد: <b>{esc(destination)}</b> | حالت: <b>{esc(mode)}</b>\n"
        f"درخواست‌کننده: <code>{esc(requested_by)}</code>\n\n"
        "با تأیید، Entry، SL و TP فوق به‌صورت انسانی ثبت می‌شوند."
    )
    for admin_id in approver_ids:
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                admin_id,
                message,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except TelegramError:
            logger.warning("Could not notify signal approver %s", admin_id)
    return row


async def signal_approval_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("این صف فقط در اختیار مالک اصلی است.", show_alert=True)
        return
    await query.answer()
    rows_data = await async_with_db(pending_signal_approvals)
    lines = ["🛡 <b>تأییدهای در انتظار سیگنال</b>", ""]
    buttons: list[list[InlineKeyboardButton]] = []
    for row in rows_data[:30]:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        lines.append(
            f"• <code>SA-{row.get('id')}</code> | <b>{esc(payload.get('symbol') or '—')}</b> | "
            f"{esc(str(payload.get('side') or '').upper())} | "
            f"E <code>{esc(payload.get('entry') or '—')}</code> | "
            f"SL <code>{esc(payload.get('stop') or '—')}</code> | "
            f"TP <code>{esc('/'.join(str(x) for x in (payload.get('targets') or [])) or '—')}</code> | "
            f"چارت <b>{'✓' if payload.get('chart_photo_file_id') else '—'}</b> | "
            f"سازنده <code>{esc(row.get('requested_by'))}</code>"
        )
        buttons.append(
            [
                InlineKeyboardButton("✅ تأیید", callback_data=f"sig_approval:{row['id']}:approve"),
                InlineKeyboardButton("❌ رد", callback_data=f"sig_approval:{row['id']}:reject"),
            ]
        )
    if not rows_data:
        lines.append("درخواستی در انتظار نیست.")
    buttons.append(back("a_signal")[0])
    await edit(query, "\n".join(lines), buttons)


async def signal_approval_decision(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("فقط مالک اصلی می‌تواند سیگنال را تأیید یا رد کند.", show_alert=True)
        return
    await query.answer()
    _, approval_id_text, action = query.data.split(":", 2)
    approve = action == "approve"
    try:
        row = await async_with_db(
            lambda db: resolve_signal_approval(db, int(approval_id_text), query.from_user.id, approve=approve)
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    if not approve:
        await mark_callback_message(query, f"❌ درخواست SA-{row['id']} رد شد")
        return
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    target = str(row.get("target") or "")
    try:
        if row.get("run_at"):
            scheduled = await async_with_db(
                lambda db: schedule_signal(
                    db,
                    payload=payload,
                    target=target,
                    run_at=parse_dt(row.get("run_at")) or utc_now(),
                    admin_id=row.get("requested_by"),
                )
            )
            result = f"سیگنال تأیید و برای {display_dt(scheduled['run_at'])} زمان‌بندی شد"
        else:
            record, errors = await _publish_signal_payload(
                context.bot,
                payload,
                target,
                row.get("requested_by") or query.from_user.id,
            )
            result = f"سیگنال #{signal_display_number(record)} منتشر شد"
            if errors:
                result += "؛ بخشی از ارسال ناموفق بود"
        await async_with_db(
            lambda db: mark_signal_approval_execution(db, row["id"], status="completed", result=result)
        )
    except Exception as exc:
        logger.exception("Approved signal execution failed")
        await async_with_db(
            lambda db, error=str(exc): mark_signal_approval_execution(db, row["id"], status="failed", result=error)
        )
        await query.answer(f"اجرای سیگنال ناموفق بود: {str(exc)[:160]}", show_alert=True)
        return
    await mark_callback_message(query, "✅ " + result)
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            int(row["requested_by"]),
            f"🛡 نتیجه تأیید سیگنال SA-{row['id']}: {result}",
        )
    except (TelegramError, ValueError):
        pass


async def signal_publish_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_PUBLISH_NOW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer("در حال ساخت و انتشار…")
    data = context.user_data.get("signal")
    target = context.user_data.get("signal_target")
    if not data or target not in {"public", "private", "both"}:
        await edit(query, "❌ اطلاعات پیش‌نمایش منقضی شده است؛ سیگنال را دوباره بسازید.", back("a_signal"))
        return ConversationHandler.END
    # Human admins with signal-publish permission are not rate-limited or
    # routed through owner approval. Telegram/network idempotency is handled
    # by the delivery checkpoint layer instead of an admin publication ceiling.
    try:
        record, errors = await _publish_signal_payload(context.bot, data, target, query.from_user.id)
    except ValueError as exc:
        await edit(query, f"⛔️ انتشار توسط گیت ایمنی متوقف شد:\n{esc(exc)}", back("a_signal"))
        return ConversationHandler.END
    except Exception:
        logger.exception("Signal generation failed")
        await edit(query, "❌ ساخت یا ارسال سیگنال انجام نشد. جزئیات در لاگ ثبت شد.", back("admin_home"))
        return ConversationHandler.END
    context.user_data.pop("signal", None)
    context.user_data.pop("signal_target", None)
    context.user_data.pop("signal_safety_preview", None)
    if errors:
        text = (
            f"⚠️ سیگنال <code>{signal_reference(signal_display_number(record))}</code> ثبت شد اما بخشی از ارسال ناموفق بود:\n"
            + "\n".join(esc(item) for item in errors)
        )
    else:
        text = (
            "✅ سیگنال با موفقیت منتشر شد.\n"
            f"شناسه پیگیری: <code>{signal_reference(signal_display_number(record))}</code>\n\n"
            "پیام وضعیت زنده زیر سیگنال ساخته شد و از این پس همان پیام بروزرسانی می‌شود."
        )
    await edit(
        query,
        text,
        [[InlineKeyboardButton("📡 مدیریت سیگنال", callback_data=f"sig_result_view:{record['id']}")], *back("a_channel_center")],
    )
    return ConversationHandler.END


async def signal_schedule_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if not context.user_data.get("signal") or not context.user_data.get("signal_target"):
        await edit(query, "❌ اطلاعات سیگنال منقضی شده است.", back("a_signal"))
        return ConversationHandler.END
    await edit(
        query,
        "🕒 <b>زمان انتشار را وارد کنید</b>\n\n"
        "قالب کامل: <code>2026-06-27 18:30</code>\n"
        "یا فقط ساعت: <code>18:30</code>؛ اگر ساعت گذشته باشد برای فردا تنظیم می‌شود.\n"
        f"منطقه زمانی: <b>{esc(SETTINGS.timezone)}</b>",
        [[InlineKeyboardButton("⬅️ مرحله قبل — پیش‌نمایش نهایی", callback_data="sig_back:preview")]],
    )
    return SIG_SCHEDULE_TIME


async def signal_schedule_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return ConversationHandler.END
    data = context.user_data.get("signal")
    target = context.user_data.get("signal_target")
    if not data or target not in {"public", "private", "both"}:
        await reply(update, "❌ اطلاعات سیگنال منقضی شده است.", back("a_signal"))
        return ConversationHandler.END
    try:
        run_at = parse_schedule_time(update.effective_message.text or "", timezone=SETTINGS.timezone)
        report = await async_with_db(lambda db: evaluate_signal_safety(db, data))
        if not report.ok:
            raise ValueError(" | ".join(report.errors))
        # Scheduling by a human admin is direct and never requires owner approval.
        row = await async_with_db(
            lambda db: schedule_signal(
                db,
                payload=data,
                target=target,
                run_at=run_at,
                admin_id=update.effective_user.id,
            )
        )
        await async_with_db(
            lambda db: audit(db, update.effective_user.id, "schedule_signal", f"{row['id']}:{row['run_at']}")
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIG_SCHEDULE_TIME
    context.user_data.pop("signal", None)
    context.user_data.pop("signal_target", None)
    context.user_data.pop("signal_safety_preview", None)
    await reply(
        update,
        f"✅ سیگنال زمان‌بندی شد.\n"
        f"شناسه زمان‌بندی: <code>Q-{row['id']}</code>\n"
        f"زمان اجرا: <b>{display_dt(row['run_at'])}</b>",
        [[InlineKeyboardButton("🕒 صف زمان‌بندی", callback_data="channel_schedules")], *back("a_channel_center")],
    )
    return ConversationHandler.END


async def a_signal_results(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    all_signals = [row for row in reversed(db.get("signals", [])) if isinstance(row, dict) and str(row.get("id", "")).isdigit()]
    parts = str(query.data or "").split(":")
    if len(parts) < 2:
        forex_count = sum(1 for row in all_signals if signal_market_category(row) == MARKET_FOREX)
        crypto_count = sum(1 for row in all_signals if signal_market_category(row) == MARKET_CRYPTO)
        cycle = current_signal_cycle(db)
        next_numbers = cycle.get("next_numbers", {}) if isinstance(cycle.get("next_numbers"), dict) else {}
        action_rows: list[list[InlineKeyboardButton]] = [
            [InlineKeyboardButton(f"💱 فارکس ({forex_count}) • بعدی #{int(next_numbers.get('forex', 1) or 1)}", callback_data="a_signal_results:forex")],
            [InlineKeyboardButton(f"🪙 کریپتو ({crypto_count}) • بعدی #{int(next_numbers.get('crypto', 1) or 1)}", callback_data="a_signal_results:crypto")],
            [InlineKeyboardButton("📊 آمار کانال عمومی", callback_data="sig_stats:public"), InlineKeyboardButton("🔒 آمار کانال خصوصی", callback_data="sig_stats:private")],
        ]
        if _has_admin_permission(query.from_user.id, PERMISSION_RISK_BOARDS):
            action_rows.append([InlineKeyboardButton("🛡 پنج تابلو تجمیع ریسک", callback_data="sig_exposure")])
        action_rows.append([InlineKeyboardButton("🕒 عملکرد سشن‌ها", callback_data="sig_sessions")])
        if _has_admin_permission(query.from_user.id, PERMISSION_ANALYST_DASHBOARD):
            action_rows.append([InlineKeyboardButton("👥 داشبورد تحلیلگران", callback_data="sig_analysts")])
        action_rows.append(back("admin_home")[0])
        await edit(
            query,
            "📈 <b>مدیریت نتایج سیگنال‌ها</b>\n\nبازار را انتخاب کنید؛ فهرست، شماره‌گذاری و شمارش هر بازار مستقل نمایش داده می‌شود:",
            action_rows,
        )
        return
    category = normalize_market_category(parts[1])
    signals = [row for row in all_signals if signal_market_category(row) == category]
    open_rows = [row for row in signals if str(row.get("status", "open")) not in FINAL_SIGNAL_STATUSES][:20]
    closed_rows = [row for row in signals if str(row.get("status", "open")) in FINAL_SIGNAL_STATUSES][:10]
    rows: list[list[InlineKeyboardButton]] = []
    for row in open_rows:
        rows.append([InlineKeyboardButton(f"#{signal_display_number(row)} | {row.get('symbol')} | {signal_status_label(str(row.get('status', 'open')))}", callback_data=f"sig_result_view:{row.get('id')}")])
    if closed_rows:
        rows.append([InlineKeyboardButton("— آخرین برآیندهای ثبت‌شده —", callback_data="sig_results_noop")])
    for row in closed_rows:
        rows.append([InlineKeyboardButton(f"#{signal_display_number(row)} | {row.get('symbol')} | {signal_status_label(str(row.get('status')))}", callback_data=f"sig_result_view:{row.get('id')}")])
    rows.extend([
        [InlineKeyboardButton("🏅 فضای تحلیل‌گران", callback_data="sig_analysts"), InlineKeyboardButton("🤖 ردیابی خودکار", callback_data="sig_tracking")],
        [InlineKeyboardButton("🛡 تابلو ریسک", callback_data="sig_exposure"), InlineKeyboardButton("🕒 عملکرد سشن‌ها", callback_data="sig_sessions")],
        [InlineKeyboardButton("🔀 تغییر بازار", callback_data="a_signal_results"), InlineKeyboardButton("🔙 مدیریت", callback_data="admin_home")],
    ])
    text_value = f"📈 <b>نتایج سیگنال‌های {market_label(category)}</b>\nکل این دسته: <b>{len(signals)}</b> | باز: <b>{len(open_rows)}</b>\nسیگنال را انتخاب و نتیجه نهایی را ثبت کنید."
    if not open_rows:
        text_value += "\n\nسیگنال بازی وجود ندارد."
    await edit(query, text_value, rows)


async def a_signal_edit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_EDIT):
        return
    query = update.callback_query
    await query.answer()
    rows_data = [
        row for row in reversed((await async_snapshot()).get("signals", [])) if isinstance(row, dict) and str(row.get("id", "")).isdigit()
    ][:40]
    rows = [
        [
            InlineKeyboardButton(
                f"✏️ #{signal_display_number(row)} | {row.get('symbol')} | {signal_status_label(str(row.get('status', 'open')))}",
                callback_data=f"sig_edit_menu:{row.get('id')}",
            )
        ]
        for row in rows_data
    ]
    if not rows:
        rows.append([InlineKeyboardButton("سیگنالی برای ویرایش وجود ندارد", callback_data="sig_results_noop")])
    rows.append(back("admin_cat:trading")[0])
    await edit(
        query,
        "✏️ <b>ویرایش سیگنال‌های ارسال‌شده</b>\n\nورود، استاپ، تارگت یا توضیح بروزرسانی را تغییر دهید.",
        rows,
    )


async def a_signal_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_DELETE):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    combined: dict[int, tuple[dict[str, Any], bool]] = {}
    for archived, source in ((False, db.get("signals", [])), (True, db.get("signal_archive", []))):
        for row in source:
            if not isinstance(row, dict) or not str(row.get("id", "")).isdigit():
                continue
            combined[int(row["id"])] = (row, archived)
    items = sorted(combined.values(), key=lambda item: int(item[0].get("id", 0) or 0), reverse=True)[:50]
    rows: list[list[InlineKeyboardButton]] = []
    for row, archived in items:
        suffix = " | آرشیو" if archived else ""
        rows.append(
            [
                InlineKeyboardButton(
                    f"🗑 #{signal_display_number(row)} | {row.get('symbol')}{suffix}",
                    callback_data=f"sig_delete_confirm:{row.get('id')}",
                )
            ]
        )
    if not rows:
        rows.append([InlineKeyboardButton("تاریخچه سیگنال خالی است", callback_data="sig_results_noop")])
    rows.append(back("admin_cat:trading")[0])
    await edit(
        query,
        "🗑 <b>حذف کامل سیگنال</b>\n\nسیگنال از دوره فعلی، آرشیو و انتخاب‌های کاربران حذف می‌شود. پیام کانال نیز در صورت امکان پاک خواهد شد.",
        rows,
    )


async def signal_results_noop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or not _has_any_admin_permission(user.id, PERMISSION_SIGNAL_RESULTS, PERMISSION_SIGNAL_EDIT, PERMISSION_SIGNAL_DELETE):
        return
    query = update.callback_query
    await query.answer()


def _signal_management_rows(row: dict[str, Any], user_id: int | str | None = None) -> list[list[InlineKeyboardButton]]:
    signal_id = int(row.get("id", 0) or 0)
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("📍 ورود انجام شد", callback_data=f"sig_lifecycle:{signal_id}:entry_hit"),
            InlineKeyboardButton("🟦 ریسک‌فری", callback_data=f"sig_lifecycle:{signal_id}:breakeven"),
        ]
    ]
    targets = list(row.get("targets", []))[:10]
    target_buttons = [
        InlineKeyboardButton(f"🎯 TP{index}", callback_data=f"sig_lifecycle:{signal_id}:tp{index}")
        for index, _ in enumerate(targets, start=1)
    ]
    rows.extend([target_buttons[index : index + 3] for index in range(0, len(target_buttons), 3)])
    rows.extend(
        [
            [
                InlineKeyboardButton("✂️ بستن بخشی", callback_data=f"sig_partial_menu:{signal_id}"),
                InlineKeyboardButton("✋ بستن دستی", callback_data=f"sig_lifecycle:{signal_id}:manual_close"),
            ],
            [
                InlineKeyboardButton("🛑 استاپ", callback_data=f"sig_lifecycle:{signal_id}:stop"),
                InlineKeyboardButton("🚫 ورود نداد", callback_data=f"sig_lifecycle:{signal_id}:no_entry"),
                InlineKeyboardButton("❌ لغو", callback_data=f"sig_lifecycle:{signal_id}:cancelled"),
            ],
        ]
    )
    privileged: list[InlineKeyboardButton] = []
    if user_id is not None and _has_admin_permission(user_id, PERMISSION_SIGNAL_EDIT):
        privileged.append(InlineKeyboardButton("✏️ ویرایش سیگنال", callback_data=f"sig_edit_menu:{signal_id}"))
    privileged.append(InlineKeyboardButton("📐 ثبت درصد و R/R", callback_data=f"sig_metrics:{signal_id}"))
    rows.append(privileged)
    rows.append([InlineKeyboardButton("🧾 تاریخچه نسخه‌ها", callback_data=f"sig_versions:{signal_id}")])
    if user_id is not None and _has_admin_permission(user_id, PERMISSION_SIGNAL_DELETE):
        rows.append([InlineKeyboardButton("🗑 حذف کامل از تاریخچه", callback_data=f"sig_delete_confirm:{signal_id}")])
    if str(row.get("status") or "open") != "open":
        rows.append([InlineKeyboardButton("🖼 افزودن / تغییر عکس نتیجه", callback_data=f"sig_result_media:{signal_id}")])
        rows.append([InlineKeyboardButton("🔄 ری‌استارت کامل نتیجه", callback_data=f"sig_result_reset:{signal_id}")])
    rows.append(back("a_signal_results")[0])
    return rows


def _signal_current_text(row: dict[str, Any]) -> str:
    side = str(row.get("side", "")).upper()
    label = "🟢 BUY" if side == "BUY" else "🔴 SELL"
    field_times = row.get("field_edit_times", {}) if isinstance(row.get("field_edit_times"), dict) else {}

    def edit_clock(field: str) -> str:
        stamp = parse_dt(field_times.get(field))
        if not stamp:
            return ""
        try:
            stamp = stamp.astimezone(ZoneInfo(SETTINGS.timezone))
        except (ValueError, ZoneInfoNotFoundError):
            stamp = stamp.astimezone(UTC)
        return f" · <i>ویرایش {stamp.strftime('%H:%M')}</i>"

    def status_clock() -> str:
        history = [item for item in row.get("lifecycle_history", []) if isinstance(item, dict)]
        raw = (history[-1].get("at") or history[-1].get("created_at")) if history else row.get("updated_at")
        stamp = parse_dt(raw)
        if not stamp:
            return ""
        try:
            stamp = stamp.astimezone(ZoneInfo(SETTINGS.timezone))
        except (ValueError, ZoneInfoNotFoundError):
            stamp = stamp.astimezone(UTC)
        return f" · <i>{stamp.strftime('%H:%M')}</i>"

    targets = "\n".join(
        f"🎯 TP{index}: <code>{esc(value)}</code>{edit_clock(f'target_{index}')}"
        for index, value in enumerate(row.get("targets", []), start=1)
    )
    update_note = f"\n\n📝 بروزرسانی: {esc(row.get('update_note'))}" if row.get("update_note") else ""
    status = str(row.get("status") or "open")
    status_label = signal_status_label(status)

    r_line = ""
    highest = int(row.get("highest_target_hit", 0) or 0)
    if highest > 0 or status in {"stop", "target_complete", "manual_close", "breakeven"}:
        from modules.outcome_engine import calculate_signal_outcome

        net_r = float(calculate_signal_outcome(row).net_r)
        r_line = f"\n📐 برآیند: <b>{net_r:+.2f}R</b>"

    footer_channel_id = str(row.get("message_channel_id") or "").strip()
    return (
        f"<b>{label} SIGNAL</b>\n"
        f"🆔 شناسه سیگنال: <code>{signal_reference(signal_display_number(row))}</code>\n\n"
        f"📌 <b>{esc(row.get('symbol'))}</b>\n"
        f"📍 Entry: <code>{esc(row.get('entry'))}</code>{edit_clock('entry')}\n"
        f"{targets}\n"
        f"🛑 SL: <code>{esc(row.get('stop'))}</code>{edit_clock('stop')}\n"
        f"⚡ Risk: <b>{esc(row.get('risk'))}%</b>\n"
        f"🕒 سشن: <b>{esc(row.get('market_session_label') or SESSION_LABELS.get(str(row.get('market_session') or 'off_hours'), 'نامشخص'))}</b>\n"
        f"🧾 نسخه: <b>{int(row.get('revision', 1) or 1)}</b>\n"
        f"📌 وضعیت: <b>{esc(status_label)}</b>{status_clock()}{r_line}{update_note}\n\n"
        "<i>مدیریت سرمایه را رعایت کنید.</i>"
        + (f"\n\n{esc(footer_channel_id)}" if footer_channel_id else "")
    )


def _signal_destination_chat_ids(row: dict[str, Any]) -> list[int]:
    chats = {
        int(item["chat_id"])
        for item in row.get("deliveries", [])
        if isinstance(item, dict) and str(item.get("chat_id", "")).lstrip("-").isdigit()
    }
    if chats:
        return sorted(chats)
    channels = row.get("delivered_channels")
    selected = (
        set(channels) if isinstance(channels, list) else {name for name in ("public", "private") if row.get("target") in {name, "both"}}
    )
    if "public" in selected and SETTINGS.public_channel_id:
        chats.add(int(SETTINGS.public_channel_id))
    if "private" in selected and SETTINGS.private_channel_id:
        chats.add(int(SETTINGS.private_channel_id))
    return sorted(chats)


async def _refresh_signal_channel_messages(bot, row: dict[str, Any], *, rebuild_media: bool = False) -> int:
    errors = 0
    text = _signal_current_text(row)
    image_path: str | None = None
    if rebuild_media and any(
        isinstance(item, dict) and item.get("message_type") in {"photo", "media_group"}
        for item in row.get("deliveries", [])
    ):
        try:
            from modules.signal import create_signal_async

            rendered = await create_signal_async(
                str(row.get("symbol") or ""),
                str(row.get("entry") or ""),
                [str(value) for value in row.get("targets", [])],
                str(row.get("stop") or ""),
                str(row.get("side") or ""),
                str(row.get("risk") or "1"),
                brand_handle=SETTINGS.signal_brand_handle,
                timeframe=str(row.get("timeframe") or "1H"),
                analysis=str(row.get("analysis") or "TECHNICAL"),
                volatility=str(row.get("volatility") or "MEDIUM"),
                strategy=str(row.get("strategy") or "TREND FOLLOWING"),
                confidence=str(row.get("confidence") or "HIGH"),
                notes=list(row.get("notes") or []),
                signal_id=signal_display_number(row),
                message_channel_id=str(row.get("message_channel_id") or ""),
            )
            image_path = str(rendered.get("image_path") or "")
        except Exception:
            logger.exception("Could not rebuild signal image #%s", row.get("id"))
            errors += 1

    try:
        for delivery in row.get("deliveries", []):
            if not isinstance(delivery, dict):
                continue
            try:
                if delivery.get("message_type") in {"photo", "media_group", "chart_photo"}:
                    if image_path and os.path.exists(image_path):
                        with open(image_path, "rb") as photo:
                            await bot.edit_message_media(
                                chat_id=int(delivery["chat_id"]),
                                message_id=int(delivery["message_id"]),
                                media=InputMediaPhoto(media=photo, caption=text, parse_mode=ParseMode.HTML),
                            )
                    else:
                        await bot.edit_message_caption(
                            chat_id=int(delivery["chat_id"]),
                            message_id=int(delivery["message_id"]),
                            caption=text,
                            parse_mode=ParseMode.HTML,
                        )
                else:
                    await bot.edit_message_text(
                        chat_id=int(delivery["chat_id"]),
                        message_id=int(delivery["message_id"]),
                        text=text,
                        parse_mode=ParseMode.HTML,
                    )
            except BadRequest as exc:
                if "Message is not modified" not in str(exc):
                    errors += 1
            except (TelegramError, KeyError, TypeError, ValueError):
                errors += 1
    finally:
        if image_path and os.path.exists(image_path):
            try:
                os.remove(image_path)
            except OSError:
                logger.warning("Could not delete rebuilt signal image %s", image_path)
    return errors


def _store_live_status_message(signal_id: int, chat_id: int, original_message_id: int, status_message_id: int) -> None:
    def mutate(db: dict[str, Any]) -> None:
        for signal in db.get("signals", []):
            if not isinstance(signal, dict) or int(signal.get("id", 0) or 0) != int(signal_id):
                continue
            for delivery in signal.get("deliveries", []):
                if not isinstance(delivery, dict):
                    continue
                if int(delivery.get("chat_id", 0) or 0) == int(chat_id) and int(delivery.get("message_id", 0) or 0) == int(
                    original_message_id
                ):
                    delivery["status_message_id"] = int(status_message_id)
                    delivery["status_message_updated_at"] = utc_iso()
                    return

    with_db(mutate)


async def _sync_signal_live_status(bot, row: dict[str, Any], *, create_if_missing: bool = True) -> int:
    """Remove legacy reply-status messages; the original signal post is authoritative."""
    errors = 0
    cleared: list[tuple[int, int, int]] = []
    for delivery in [item for item in row.get("deliveries", []) if isinstance(item, dict)]:
        chat_id = int(delivery.get("chat_id", 0) or 0)
        original_message_id = int(delivery.get("message_id", 0) or 0)
        status_message_id = int(delivery.get("status_message_id", 0) or 0)
        if not chat_id or not status_message_id:
            continue
        try:
            await bot.delete_message(chat_id=chat_id, message_id=status_message_id)
        except BadRequest as exc:
            message = str(exc).lower()
            if "message to delete not found" not in message and "message can't be deleted" not in message:
                errors += 1
        except TelegramError:
            logger.exception("Could not remove legacy live-status reply for signal #%s", row.get("id"))
            errors += 1
        cleared.append((chat_id, original_message_id, status_message_id))

    if cleared and int(row.get("id", 0) or 0) > 0:
        signal_id = int(row.get("id", 0) or 0)

        def mutate(db: dict[str, Any]) -> None:
            for signal in db.get("signals", []):
                if not isinstance(signal, dict) or int(signal.get("id", 0) or 0) != signal_id:
                    continue
                for delivery in signal.get("deliveries", []):
                    if not isinstance(delivery, dict):
                        continue
                    key = (
                        int(delivery.get("chat_id", 0) or 0),
                        int(delivery.get("message_id", 0) or 0),
                        int(delivery.get("status_message_id", 0) or 0),
                    )
                    if key in cleared:
                        delivery.pop("status_message_id", None)
                        delivery.pop("status_message_updated_at", None)
                return

        await run_blocking(with_db, mutate, timeout=20)
    return errors


async def _sync_smart_pin(bot) -> int:
    db = await async_snapshot()
    settings = get_channel_management(
        db,
        public_channel_id=SETTINGS.public_channel_id,
        private_channel_id=SETTINGS.private_channel_id,
    )
    pin = settings.get("smart_pin", {})
    if not pin.get("enabled", True):
        return 0
    errors = 0
    for channel, chat_id in (("public", SETTINGS.public_channel_id), ("private", SETTINGS.private_channel_id)):
        if not chat_id:
            continue
        key = f"{channel}_message_id"
        message_id = int(pin.get(key, 0) or 0)
        text = smart_pin_text(db, channel)
        if message_id:
            existing_ok = False
            try:
                await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, parse_mode=ParseMode.HTML)
                existing_ok = True
            except BadRequest as exc:
                if "Message is not modified" in str(exc):
                    existing_ok = True
            except TelegramError:
                logger.exception("Could not edit smart pin for %s", channel)
            if existing_ok:
                try:
                    await bot.pin_chat_message(chat_id=chat_id, message_id=message_id, disable_notification=True)
                    await async_with_db(
                        lambda database, c=channel, mid=message_id: record_channel_event(database, c, "smart_pin_updated", message_id=mid)
                    )
                    continue
                except TelegramError:
                    logger.exception("Could not repin smart board for %s", channel)
        try:
            message = await _telegram_request_with_button_fallback(
                bot.send_message, chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_notification=True
            )
            await bot.pin_chat_message(chat_id=chat_id, message_id=message.message_id, disable_notification=True)
            await async_with_db(
                lambda database, c=channel, mid=int(message.message_id): record_channel_event(
                    database, c, "smart_pin_updated", message_id=mid
                )
            )
            await async_with_db(
                lambda database, c=channel, mid=int(message.message_id): set_channel_option(
                    database,
                    "smart_pin",
                    f"{c}_message_id",
                    mid,
                    public_channel_id=SETTINGS.public_channel_id,
                    private_channel_id=SETTINGS.private_channel_id,
                )
            )
        except TelegramError:
            logger.exception("Could not create smart pin for %s", channel)
            await async_with_db(lambda database, c=channel: record_channel_event(database, c, "smart_pin_updated", success=False))
            errors += 1
    return errors


async def signal_result_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    row = next((item for item in (await async_snapshot()).get("signals", []) if int(item.get("id", 0) or 0) == signal_id), None)
    if not row:
        await query.answer("سیگنال پیدا نشد", show_alert=True)
        return
    history = row.get("lifecycle_history", [])
    lines = [
        f"📡 <b>مدیریت سیگنال #{signal_display_number(row)}</b>",
        f"نماد: <b>{esc(row.get('symbol'))}</b>",
        f"نوع: <b>{esc(str(row.get('side', '')).upper())}</b>",
        f"ورودها: <code>{esc('، '.join(str(item) for item in (row.get('entries') or [row.get('entry')])))}</code>",
        f"میانگین ورود: <code>{esc(row.get('entry'))}</code>",
        f"هدف‌ها: <code>{esc(', '.join(row.get('targets', [])))}</code>",
        f"حد ضرر: <code>{esc(row.get('stop'))}</code>",
        f"وضعیت: <b>{esc(signal_status_label(str(row.get('status', 'open'))))}</b>",
        f"بالاترین تارگت: <b>TP{int(row.get('highest_target_hit', 0) or 0)}</b>"
        if row.get("highest_target_hit")
        else "بالاترین تارگت: <b>هنوز هیچ‌کدام</b>",
        f"سود/زیان ثبت‌شده: <b>{float(row.get('profit_percent', 0) or 0):.2f}%</b>",
        f"R/R نهایی: <b>{float(row.get('rr', 0) or 0):.2f}</b>",
        f"R/R اهداف: <code>{esc('، '.join(f'{float(v):.2f}' for v in row.get('rr_targets', [])) or '—')}</code>",
        f"پرشدن ورودها: <b>{float((row.get('execution') or {}).get('filled_percent', 0) or 0):.0f}%</b>",
        f"حجم بسته‌شده: <b>{float((row.get('execution') or {}).get('closed_percent', 0) or 0):.0f}%</b>",
        f"تعداد بروزرسانی‌ها: <b>{len(history)}</b>",
    ]
    if row.get("result_note"):
        lines.append(f"یادداشت نتیجه: {esc(row.get('result_note'))}")
    if row.get("result_chart_photo_file_id"):
        lines.append("عکس نتیجه: <b>✅ ثبت شده و در مینی‌اپ قابل مشاهده است</b>")
        if row.get("result_chart_caption"):
            lines.append(f"توضیح عکس نتیجه: {esc(row.get('result_chart_caption'))}")
    await edit(query, "\n".join(lines), _signal_management_rows(row, query.from_user.id))


def _signal_result_message(row: dict[str, Any]) -> str:
    status = str(row.get("status") or "open")
    icon = {
        "entry_hit": "📍",
        "breakeven": "🟦",
        "partial_close": "✂️",
        "manual_close": "✋",
        "no_entry": "🚫",
        "stop": "🛑",
        "cancelled": "❌",
        "expired": "⌛️",
    }.get(status, "🎯" if status.startswith("tp") else "📌")
    metrics = ""
    if row.get("profit_percent") is not None or row.get("rr") is not None:
        metrics = f"\nسود/زیان: <b>{float(row.get('profit_percent', 0) or 0):.2f}%</b> | R/R: <b>{float(row.get('rr', 0) or 0):.2f}</b>"
    return (
        f"{icon} <b>بروزرسانی سیگنال #{signal_display_number(row)}</b>\n"
        f"نماد: <b>{esc(row.get('symbol'))}</b>\n"
        f"نوع: <b>{esc(str(row.get('side', '')).upper())}</b>\n"
        f"وضعیت: <b>{esc(signal_status_label(status))}</b>{metrics}"
    )


def _signal_result_chart_caption(row: dict[str, Any]) -> str:
    custom = str(row.get("result_chart_caption") or "").strip()
    detail = f"\n\n📝 {esc(custom[:700])}" if custom else ""
    return (
        f"📊 <b>چارت نتیجه سیگنال #{signal_display_number(row)}</b>\n"
        f"نماد: <b>{esc(row.get('symbol'))}</b> | وضعیت: <b>{esc(signal_status_label(str(row.get('status') or 'open')))}</b>"
        f"{detail}"
    )


async def _publish_signal_result_chart(bot, row: dict[str, Any]) -> tuple[int, list[dict[str, Any]]]:
    """Publish or replace the final evidence chart in every signal channel."""
    file_id = str(row.get("result_chart_photo_file_id") or "").strip()
    if not file_id:
        return 0, []
    existing = {
        str(item.get("chat_id")): dict(item)
        for item in row.get("result_chart_deliveries", [])
        if isinstance(item, dict) and item.get("chat_id") and item.get("message_id")
    }
    deliveries: list[dict[str, Any]] = []
    errors = 0
    caption = _signal_result_chart_caption(row)
    for chat_id in _signal_destination_chat_ids(row):
        previous = existing.get(str(chat_id))
        if previous:
            try:
                await bot.edit_message_media(
                    chat_id=chat_id,
                    message_id=int(previous["message_id"]),
                    media=InputMediaPhoto(media=file_id, caption=caption, parse_mode=ParseMode.HTML),
                )
                deliveries.append(previous)
                continue
            except TelegramError:
                logger.warning("Could not replace result chart signal_id=%s chat_id=%s", row.get("id"), chat_id)
        try:
            sent = await bot.send_photo(chat_id=chat_id, photo=file_id, caption=caption, parse_mode=ParseMode.HTML)
            deliveries.append({
                "chat_id": str(chat_id),
                "message_id": int(sent.message_id),
                "message_type": "result_chart_photo",
                "sent_at": utc_iso(),
            })
        except TelegramError:
            logger.exception("Could not publish result chart signal_id=%s chat_id=%s", row.get("id"), chat_id)
            errors += 1
    return errors, deliveries


async def _delete_signal_result_chart_messages(bot, row: dict[str, Any]) -> int:
    errors = 0
    for item in row.get("result_chart_deliveries", []):
        if not isinstance(item, dict):
            continue
        try:
            await bot.delete_message(chat_id=int(item["chat_id"]), message_id=int(item["message_id"]))
        except BadRequest as exc:
            if "message to delete not found" not in str(exc).lower():
                errors += 1
        except (TelegramError, KeyError, TypeError, ValueError):
            errors += 1
    return errors


async def signal_result_media_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Require a chart before committing terminal results; also replaces old evidence."""
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    parts = str(query.data or "").split(":")
    signal_id = int(parts[1])
    requested_status = ""
    if parts[0] == "sig_lifecycle":
        requested_status = parts[2]
    elif parts[0] == "sig_result_set":
        requested_status = "tp1" if parts[2] == "target" else parts[2]
    snapshot = await async_snapshot()
    row = next(
        (item for item in snapshot.get("signals", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id),
        None,
    )
    if not row:
        await query.answer("سیگنال پیدا نشد", show_alert=True)
        return ConversationHandler.END
    target_index = int(requested_status[2:]) if requested_status.startswith("tp") and requested_status[2:].isdigit() else 0
    terminal = requested_status in {"manual_close", "stop"} or bool(
        target_index and target_index >= len(row.get("targets", [])) > 0
    )
    if requested_status and not terminal:
        try:
            updated = await async_with_db(
                lambda db: set_signal_lifecycle(db, signal_id, requested_status, query.from_user.id)
            )
            await async_with_db(
                lambda db: audit(db, query.from_user.id, "signal_lifecycle", f"{signal_id}:{requested_status}")
            )
        except ValueError as exc:
            await query.answer(str(exc), show_alert=True)
            return ConversationHandler.END
        await _project_signal_to_miniapp(updated, "signal.lifecycle_updated")
        message = _signal_result_message(updated)
        errors = await _refresh_signal_channel_messages(context.bot, updated)
        errors += await _publish_signal_update(context.bot, updated, message)
        suffix = f"\n⚠️ {errors} عملیات کانال ناموفق بود." if errors else "\n✅ کانال‌ها بروزرسانی شدند."
        await edit(query, message + suffix, _signal_management_rows(updated, query.from_user.id))
        return ConversationHandler.END
    if not requested_status and str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES:
        await query.answer("ابتدا نتیجه نهایی سیگنال را ثبت کنید.", show_alert=True)
        return ConversationHandler.END
    context.user_data["signal_result_media"] = {
        "signal_id": signal_id,
        "status": requested_status,
    }
    status_text = signal_status_label(requested_status) if requested_status else signal_status_label(str(row.get("status") or ""))
    await edit(
        query,
        f"🖼 <b>عکس نتیجه سیگنال #{signal_display_number(row)}</b>\n\n"
        f"نتیجه انتخابی: <b>{esc(status_text)}</b>\n"
        "عکس چارت نهایی را به‌صورت <b>Photo</b> ارسال کنید. در Caption عکس، توضیح نتیجه مثل «فول TP شد» یا «استاپ خورد» را بنویسید.\n\n"
        "تا قبل از دریافت عکس، نتیجه نهایی ثبت و در کانال منتشر نمی‌شود.",
        [[InlineKeyboardButton("انصراف", callback_data=f"sig_result_media_cancel:{signal_id}")]],
    )
    return SIGNAL_RESULT_MEDIA_INPUT


async def signal_result_media_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return ConversationHandler.END
    pending = context.user_data.get("signal_result_media")
    if not isinstance(pending, dict):
        await reply(update, "❌ درخواست عکس نتیجه منقضی شده است؛ دوباره از مدیریت سیگنال شروع کنید.")
        return ConversationHandler.END
    photos = list(getattr(update.effective_message, "photo", None) or [])
    if not photos:
        await reply(update, "❌ عکس را به‌صورت Photo بفرستید؛ فایل Document پذیرفته نمی‌شود.")
        return SIGNAL_RESULT_MEDIA_INPUT
    photo = photos[-1]
    signal_id = int(pending["signal_id"])
    status = str(pending.get("status") or "")
    snapshot = await async_snapshot()
    current = next(
        (item for item in snapshot.get("signals", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id),
        None,
    )
    if not current:
        await reply(update, "❌ سیگنال پیدا نشد.")
        return ConversationHandler.END
    caption = str(update.effective_message.caption or "").strip()
    if not caption:
        caption = f"نتیجه نهایی سیگنال #{signal_display_number(current)}؛ {signal_status_label(status or str(current.get('status') or ''))}"
    try:
        row = await async_with_db(
            lambda db: set_signal_result_media(
                db,
                signal_id,
                update.effective_user.id,
                photo_file_id=str(photo.file_id),
                photo_unique_id=str(getattr(photo, "file_unique_id", "") or ""),
                width=int(getattr(photo, "width", 0) or 0),
                height=int(getattr(photo, "height", 0) or 0),
                caption=caption,
                lifecycle_status=status,
            )
        )
        await async_with_db(
            lambda db: audit(db, update.effective_user.id, "signal_result_media", f"{signal_id}:{status or 'replace'}")
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIGNAL_RESULT_MEDIA_INPUT
    channel_errors, deliveries = await _publish_signal_result_chart(context.bot, row)
    if deliveries:
        row = await async_with_db(lambda db: set_signal_result_media_deliveries(db, signal_id, deliveries))
    await _project_signal_to_miniapp(row, "signal.result_media_updated")
    channel_errors += await _refresh_signal_channel_messages(context.bot, row)
    channel_errors += await _publish_signal_update(context.bot, row, _signal_result_message(row))
    context.user_data.pop("signal_result_media", None)
    suffix = f"\n⚠️ {channel_errors} عملیات کانال ناموفق بود." if channel_errors else "\n✅ عکس و نتیجه در کانال‌ها و مینی‌اپ بروزرسانی شد."
    await reply(
        update,
        f"✅ عکس نتیجه سیگنال #{signal_display_number(row)} ثبت شد.\n{_signal_result_message(row)}{suffix}",
        [[InlineKeyboardButton("🔙 مدیریت سیگنال", callback_data=f"sig_result_view:{signal_id}")]],
    )
    return ConversationHandler.END


async def signal_result_media_invalid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await reply(update, "❌ لطفاً عکس نتیجه را به‌صورت Photo ارسال کنید و توضیح را در Caption همان عکس بنویسید.")
    return SIGNAL_RESULT_MEDIA_INPUT


async def signal_result_media_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer("ثبت نتیجه لغو شد")
    signal_id = int(query.data.rsplit(":", 1)[1])
    context.user_data.pop("signal_result_media", None)
    await edit(
        query,
        "ثبت نتیجه لغو شد؛ وضعیت نهایی بدون عکس ثبت نشده است.",
        [[InlineKeyboardButton("🔙 مدیریت سیگنال", callback_data=f"sig_result_view:{signal_id}")]],
    )
    return ConversationHandler.END


async def _publish_signal_update(bot, row: dict[str, Any], message: str) -> int:
    """Keep the original signal post authoritative and avoid separate status replies."""
    errors = await _sync_signal_live_status(bot, row, create_if_missing=False)
    errors += await _sync_smart_pin(bot)
    return errors


async def signal_reply_status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Allow a channel admin to reply to the original signal with a short status."""
    message = update.effective_message
    chat = update.effective_chat
    if not message or not chat or not message.reply_to_message:
        return

    configured_channels = {int(chat_id) for chat_id in (SETTINGS.public_channel_id, SETTINGS.private_channel_id) if chat_id}
    if int(chat.id) not in configured_channels:
        return

    db_snapshot = await async_snapshot()
    linked = find_signal_by_delivery(db_snapshot, chat.id, message.reply_to_message.message_id)
    if not linked:
        return

    raw_text = message.text or message.caption or ""
    status = parse_signal_reply_status(raw_text, target_count=len(linked.get("targets", [])))
    if not status:
        return

    actor_id: int | str = update.effective_user.id if update.effective_user else f"channel:{chat.id}"

    def apply_status(db: dict[str, Any]) -> dict[str, Any]:
        current = find_signal_by_delivery(db, chat.id, message.reply_to_message.message_id)
        if not current:
            raise ValueError("سیگنال مرتبط پیدا نشد")
        row = set_signal_lifecycle(
            db,
            int(current["id"]),
            status,
            actor_id,
            source="channel_reply",
        )
        audit(db, actor_id, "signal_channel_reply", f"{row['id']}:{status}:{chat.id}")
        return row

    try:
        row = await async_with_db(apply_status)
    except ValueError:
        logger.exception("Could not apply signal status from channel reply")
        return

    await _project_signal_to_miniapp(row, "signal.lifecycle_updated")
    errors = await _refresh_signal_channel_messages(context.bot, row)
    errors += await _publish_signal_update(context.bot, row, _signal_result_message(row))
    if errors:
        logger.warning("Signal reply status #%s completed with %s Telegram errors", row.get("id"), errors)


async def signal_lifecycle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    _, signal_id_text, status = query.data.split(":", 2)
    try:
        row = await async_with_db(lambda db: set_signal_lifecycle(db, int(signal_id_text), status, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "signal_lifecycle", f"{signal_id_text}:{status}"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _project_signal_to_miniapp(row, "signal.lifecycle_updated")
    message = _signal_result_message(row)
    errors = await _refresh_signal_channel_messages(context.bot, row)
    errors += await _publish_signal_update(context.bot, row, message)
    suffix = f"\n⚠️ {errors} عملیات کانال ناموفق بود." if errors else "\n✅ کانال‌ها بروزرسانی شدند."
    await edit(query, message + suffix, _signal_management_rows(row, query.from_user.id))


async def signal_partial_close_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    row = next(
        (
            item
            for item in (await async_snapshot()).get("signals", [])
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    if not row:
        await query.answer("سیگنال پیدا نشد", show_alert=True)
        return
    closed = float((row.get("execution") or {}).get("closed_percent", 0) or 0)
    remaining = max(0.0, 100.0 - closed)
    buttons = [value for value in (25, 50, 75, 100) if value <= remaining + 1e-9]
    rows = [
        [InlineKeyboardButton(f"{value}%", callback_data=f"sig_partial_apply:{signal_id}:{value}") for value in buttons[:2]],
        [InlineKeyboardButton(f"{value}%", callback_data=f"sig_partial_apply:{signal_id}:{value}") for value in buttons[2:]],
        [InlineKeyboardButton("↩️ بازگشت", callback_data=f"sig_result_view:{signal_id}")],
    ]
    rows = [row_buttons for row_buttons in rows if row_buttons]
    await edit(
        query,
        f"✂️ <b>ثبت خروج جزئی سیگنال #{signal_display_number(row)}</b>\n\n"
        f"حجم بسته‌شده فعلی: <b>{closed:.0f}%</b>\n"
        f"حجم باقی‌مانده: <b>{remaining:.0f}%</b>\n\n"
        "درصدی که اکنون بسته شده را انتخاب کنید:",
        rows,
    )


async def signal_partial_close_apply(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    _, signal_id_text, percent_text = query.data.split(":", 2)
    try:
        percent = float(percent_text)
        row = await async_with_db(
            lambda db: set_signal_lifecycle(
                db,
                int(signal_id_text),
                "partial_close",
                query.from_user.id,
                close_percent=percent,
                source="admin_partial_close",
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _project_signal_to_miniapp(row, "signal.partial_closed")
    message = _signal_result_message(row)
    errors = await _refresh_signal_channel_messages(context.bot, row)
    errors += await _publish_signal_update(context.bot, row, message)
    suffix = f"\n⚠️ {errors} عملیات کانال ناموفق بود." if errors else "\n✅ خروج جزئی ثبت و کانال‌ها بروزرسانی شدند."
    await edit(query, message + suffix, _signal_management_rows(row, query.from_user.id))


async def signal_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_DELETE):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    db = await async_snapshot()
    row = next(
        (
            item
            for item in [*db.get("signals", []), *db.get("signal_archive", [])]
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    if not row:
        await query.answer("سیگنال پیدا نشد", show_alert=True)
        return
    rows = [
        [InlineKeyboardButton("🗑 بله، حذف کامل شود", callback_data=f"sig_delete_execute:{signal_id}")],
        [InlineKeyboardButton("انصراف", callback_data="a_signal_delete")],
    ]
    await edit(
        query,
        f"⚠️ <b>حذف غیرقابل بازگشت سیگنال #{signal_display_number(row)}</b>\n\n"
        f"نماد: <b>{esc(row.get('symbol'))}</b>\n"
        "این عملیات رکورد دوره فعلی، آرشیو، انتخاب کاربران و پیام‌های کانال را تا حد امکان حذف می‌کند. ",
        rows,
    )


async def signal_delete_execute(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_DELETE):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    db = await async_snapshot()
    row = next(
        (
            item
            for item in [*db.get("signals", []), *db.get("signal_archive", [])]
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    if not row:
        await query.answer("سیگنال پیدا نشد", show_alert=True)
        return

    telegram_errors = 0
    deleted_message_keys: set[tuple[int, int]] = set()
    for delivery in [*row.get("deliveries", []), *row.get("result_chart_deliveries", [])]:
        if not isinstance(delivery, dict):
            continue
        try:
            chat_id = int(delivery.get("chat_id", 0) or 0)
        except (TypeError, ValueError):
            continue
        candidate_ids: list[int] = []
        for key in ("status_message_id", "message_id", "chart_message_id"):
            try:
                value = int(delivery.get(key, 0) or 0)
            except (TypeError, ValueError):
                value = 0
            if value:
                candidate_ids.append(value)
        for value in delivery.get("message_ids", []) if isinstance(delivery.get("message_ids"), list) else []:
            try:
                candidate_ids.append(int(value))
            except (TypeError, ValueError):
                continue
        for message_id in candidate_ids:
            pair = (chat_id, message_id)
            if not chat_id or not message_id or pair in deleted_message_keys:
                continue
            deleted_message_keys.add(pair)
            try:
                await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            except BadRequest as exc:
                if "message to delete not found" not in str(exc).lower():
                    telegram_errors += 1
            except TelegramError:
                telegram_errors += 1

    try:
        result = await async_with_db(lambda database: delete_signal_permanently(database, signal_id, query.from_user.id))
        await async_with_db(lambda database: audit(database, query.from_user.id, "signal_delete_permanent", str(signal_id)))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    telegram_errors += await _sync_smart_pin(context.bot)
    try:
        from repositories.v2.signals import SignalRepository
        await run_blocking(SignalRepository().delete, signal_id)
    except Exception:
        logger.exception("Deleted Telegram signal could not be removed from Mini App signal_id=%s", signal_id)
    removed = result["signal"]
    suffix = f"\n⚠️ {telegram_errors} پیام کانال حذف یا بروزرسانی نشد." if telegram_errors else "\n✅ پیام‌های قابل‌دسترسی کانال نیز حذف شدند."
    await edit(
        query,
        f"✅ سیگنال <b>#{signal_display_number(removed)}</b> از تاریخچه حذف شد.\n"
        f"انتخاب حذف‌شده کاربران: <b>{result['removed_choices']}</b>{suffix}",
        [[InlineKeyboardButton("🗑 بازگشت به حذف سیگنال", callback_data="a_signal_delete")], back("admin_cat:trading")[0]],
    )


async def signal_edit_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_EDIT):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    row = next(
        (
            item
            for item in (await async_snapshot()).get("signals", [])
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    if not row:
        await query.answer("سیگنال در دوره فعلی پیدا نشد", show_alert=True)
        return
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("📍 تغییر نقطه ورود", callback_data=f"sig_edit:{signal_id}:entry"),
            InlineKeyboardButton("🛑 تغییر حد ضرر", callback_data=f"sig_edit:{signal_id}:stop"),
        ]
    ]
    target_buttons = [
        InlineKeyboardButton(
            f"🎯 تغییر TP{index} ({value})",
            callback_data=f"sig_edit:{signal_id}:target_{index}",
        )
        for index, value in enumerate(row.get("targets", [])[:10], start=1)
    ]
    rows.extend([target_buttons[index : index + 2] for index in range(0, len(target_buttons), 2)])
    rows.extend(
        [
            [
                InlineKeyboardButton("➕ افزودن تارگت", callback_data=f"sig_edit:{signal_id}:add_target"),
                InlineKeyboardButton("📝 توضیح بروزرسانی", callback_data=f"sig_edit:{signal_id}:note"),
            ],
            [InlineKeyboardButton("🔙 فهرست ویرایش", callback_data="a_signal_edit")],
        ]
    )
    await edit(
        query,
        f"✏️ <b>ویرایش سیگنال #{signal_display_number(row)}</b>\n\n"
        f"ورود: <code>{esc(row.get('entry'))}</code>\n"
        f"استاپ: <code>{esc(row.get('stop'))}</code>\n"
        f"تارگت‌ها: <code>{esc(', '.join(str(x) for x in row.get('targets', [])))}</code>\n\n"
        "موردی را که می‌خواهید تغییر دهید انتخاب کنید:",
        rows,
    )


async def signal_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    _, signal_id, field = query.data.split(":", 2)
    context.user_data["signal_edit_id"] = int(signal_id)
    context.user_data["signal_edit_field"] = field
    prompts = {
        "stop": "حد ضرر جدید را وارد کنید:",
        "entry": "قیمت ورود جدید را وارد کنید:",
        "add_target": "تارگت جدید را وارد کنید:",
        "note": "متن بروزرسانی برای کاربران را وارد کنید:",
    }
    prompt = prompts.get(field)
    if field.startswith("target_") and field.split("_", 1)[1].isdigit():
        prompt = f"قیمت جدید TP{int(field.split('_', 1)[1])} را وارد کنید:"
    await edit(query, prompt or "مقدار جدید را وارد کنید:", back(f"sig_edit_menu:{signal_id}"))
    return SIGNAL_EDIT_INPUT


async def signal_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_EDIT):
        return ConversationHandler.END
    signal_id = context.user_data.get("signal_edit_id")
    field = context.user_data.get("signal_edit_field")
    value = (update.effective_message.text or "").strip()
    try:
        if field in {"stop", "entry", "add_target"} or str(field).startswith("target_"):
            from modules.signal import normalize_signal_price

            value = normalize_signal_price(value, "قیمت")
        row = await async_with_db(lambda db: edit_signal(db, signal_id, update.effective_user.id, field, value))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "signal_edit", f"{signal_id}:{field}"))
        await _project_signal_to_miniapp(row, "signal.edited")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIGNAL_EDIT_INPUT
    errors = await _refresh_signal_channel_messages(
        context.bot, row, rebuild_media=field in {"stop", "entry", "add_target"} or str(field).startswith("target_")
    )
    update_message = f"✏️ <b>سیگنال #{signal_display_number(row)} بروزرسانی شد</b>\n{esc(str(row.get('update_note') or field))}"
    errors += await _publish_signal_update(context.bot, row, update_message)
    context.user_data.pop("signal_edit_id", None)
    context.user_data.pop("signal_edit_field", None)
    await reply(
        update,
        f"✅ سیگنال ویرایش شد.{' تعداد خطای کانال: ' + str(errors) if errors else ''}",
        [[InlineKeyboardButton("🔙 فهرست ویرایش", callback_data="a_signal_edit")]],
    )
    return ConversationHandler.END


async def signal_metrics_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_METRICS_EDIT):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    context.user_data["signal_metrics_id"] = signal_id
    await edit(
        query,
        "اطلاعات را با قالب زیر بفرستید:\n"
        "<code>سود/زیان درصد | R/R | بیشترین سود شناور | بیشترین ضرر شناور | توضیح</code>\n\n"
        "مثال: <code>2.5 | 1.8 | 3.2 | -0.6 | خروج کامل در TP2</code>",
        back(f"sig_result_view:{signal_id}"),
    )
    return SIGNAL_METRICS_INPUT


async def signal_metrics_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_METRICS_EDIT):
        return ConversationHandler.END
    parts = [part.strip() for part in (update.effective_message.text or "").split("|", 4)]
    if len(parts) != 5:
        await reply(update, "❌ قالب صحیح نیست.")
        return SIGNAL_METRICS_INPUT
    try:
        profit, rr, favorable, adverse = [float(value.replace(",", "")) for value in parts[:4]]
        signal_id = int(context.user_data["signal_metrics_id"])
        row = await async_with_db(
            lambda db: set_signal_metrics(
                db,
                signal_id,
                update.effective_user.id,
                profit_percent=profit,
                rr=rr,
                max_favorable=favorable,
                max_adverse=adverse,
                note=parts[4],
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "signal_metrics", str(signal_id)))
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return SIGNAL_METRICS_INPUT
    await _project_signal_to_miniapp(row, "signal.metrics_updated")
    context.user_data.pop("signal_metrics_id", None)
    await reply(
        update,
        f"✅ جزئیات نتیجه سیگنال #{signal_display_number(row)} ثبت شد.\n{_signal_result_message(row)}",
        [[InlineKeyboardButton("🔙 سیگنال", callback_data=f"sig_result_view:{signal_id}")]],
    )
    return ConversationHandler.END


async def signal_result_set_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    _, signal_id_text, result = query.data.split(":", 2)
    status = "tp1" if result == "target" else result
    try:
        row = await async_with_db(lambda db: set_signal_lifecycle(db, int(signal_id_text), status, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "signal_result", f"{signal_id_text}:{status}"))
        await _project_signal_to_miniapp(row, "signal.result_updated")
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    message = _signal_result_message(row)
    errors = await _refresh_signal_channel_messages(context.bot, row)
    errors += await _publish_signal_update(context.bot, row, message)
    await _sync_smart_pin(context.bot)
    suffix = (
        f"\n⚠️ بروزرسانی نتیجه در {errors} عملیات کانال ناموفق بود." if errors else "\n✅ پیام اصلی و تابلوی کانال بروزرسانی شدند."
    )
    rows = [
        [InlineKeyboardButton("🔄 ری‌استارت و ثبت مجدد برآیند", callback_data=f"sig_result_reset:{row.get('id')}")],
        back("a_signal_results")[0],
    ]
    await edit(query, message + suffix, rows)


async def signal_result_reset_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_STATUS_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    before_reset = next(
        (
            item for item in (await async_snapshot()).get("signals", [])
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    result_chart_errors = await _delete_signal_result_chart_messages(context.bot, before_reset or {})
    try:
        row = await async_with_db(lambda db: reset_signal_result(db, signal_id, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "signal_result_reset", str(signal_id)))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await _project_signal_to_miniapp(row, "signal.result_reset")
    errors = result_chart_errors + await _refresh_signal_channel_messages(context.bot, row)
    errors += await _sync_signal_live_status(context.bot, row)
    await _sync_smart_pin(context.bot)
    rows = _signal_management_rows(row, query.from_user.id)
    warning = f"\n⚠️ {errors} عملیات بروزرسانی کانال ناموفق بود." if errors else "\n✅ پیام اصلی و تابلوی کانال نیز پاک‌سازی شدند."
    await edit(
        query,
        f"🔄 برآیند سیگنال <code>#{signal_display_number(row)}</code> ری‌استارت شد.\nنتیجه جدید را انتخاب کنید:\n\n"
        f"نماد: <b>{esc(row.get('symbol'))}</b>{warning}",
        rows,
    )


def _signal_stats_text(db: dict[str, Any], channel: str, days: int | None = None) -> str:
    stats = signal_channel_stats(db, channel, days=days)
    ops = channel_analytics(db, channel, days=days or 30)
    title = "کانال عمومی" if channel == "public" else "کانال خصوصی"
    period_title = "کل دوره" if days is None else f"{days} روز اخیر"
    reset_at = signal_channel_stats_reset_at(db, channel)
    reset_line = f"\nشروع برآیند فعلی: <b>{display_dt(reset_at)}</b>" if reset_at else ""
    member_line = "نامشخص" if ops.get("current_members") is None else f"{int(ops['current_members']):,}"
    growth = ops.get("member_growth")
    growth_line = "نامشخص" if growth is None else f"{int(growth):+d}"
    best_hour = ops.get("best_send_hour_utc")
    best_hour_line = "داده کافی نیست" if best_hour is None else f"{int(best_hour):02d}:00 UTC"
    return (
        f"📊 <b>آمار جامع {title}</b>\n"
        f"بازه: <b>{period_title}</b>{reset_line}\n\n"
        f"👥 اعضای فعلی: <b>{member_line}</b> | رشد: <b>{growth_line}</b>\n"
        f"📨 نرخ موفقیت عملیات: <b>{ops['delivery_rate']:.1f}%</b> | خطا: <b>{ops['failures']}</b>\n"
        f"🕒 ساعت پرتکرار ارسال: <b>{best_hour_line}</b>\n\n"
        f"کل سیگنال‌ها: <b>{stats['total']}</b>\n"
        f"⏳ در انتظار ورود: <b>{stats['waiting_entry']}</b>\n"
        f"📍 معامله فعال: <b>{stats['active_trade']}</b>\n\n"
        f"🏆 برد کامل: <b>{stats['full_win']}</b>\n"
        f"✅ برد جزئی: <b>{stats['partial_win']}</b>\n"
        f"🟦 سربه‌سر: <b>{stats['breakeven']}</b>\n"
        f"🛑 زیان: <b>{stats['loss']}</b>\n"
        f"🚫 بدون ورود: <b>{stats['no_entry']}</b>\n"
        f"❌ لغوشده: <b>{stats['cancelled']}</b>\n\n"
        f"📈 نرخ برد معاملات تعیین‌تکلیف‌شده: <b>{stats['win_rate']:.1f}%</b>\n"
        f"💹 مجموع سود/زیان ثبت‌شده: <b>{stats['profit_percent_sum']:+.2f}%</b>\n"
        f"📐 میانگین R/R ثبت‌شده: <b>{stats['average_rr']:.2f}</b>"
    )


async def signal_stats_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    channel = query.data.split(":", 1)[1]
    text = _signal_stats_text((await async_snapshot()), channel)
    rows = [
        [InlineKeyboardButton("📤 ارسال برآیند کل دوره", callback_data=f"sig_stats_send:{channel}:all")],
        [
            InlineKeyboardButton("📤 ارسال برآیند ۷ روزه", callback_data=f"sig_stats_send:{channel}:7"),
            InlineKeyboardButton("📤 ارسال برآیند ۳۰ روزه", callback_data=f"sig_stats_send:{channel}:30"),
        ],
        [InlineKeyboardButton("🔄 شروع مجدد برآیند این کانال", callback_data=f"sig_stats_reset:{channel}")],
        back("a_signal_results")[0],
    ]
    await edit(query, text, rows)


async def signal_stats_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_METRICS_EDIT):
        return
    query = update.callback_query
    await query.answer()
    channel = query.data.split(":", 1)[1]
    reset_at = await async_with_db(lambda db: reset_signal_channel_stats(db, channel, query.from_user.id))
    await async_with_db(lambda db: audit(db, query.from_user.id, "signal_stats_reset", f"{channel}:{reset_at}"))
    text = _signal_stats_text((await async_snapshot()), channel)
    rows = [
        [InlineKeyboardButton("📤 ارسال برآیند کل دوره", callback_data=f"sig_stats_send:{channel}:all")],
        [
            InlineKeyboardButton("📤 ارسال برآیند ۷ روزه", callback_data=f"sig_stats_send:{channel}:7"),
            InlineKeyboardButton("📤 ارسال برآیند ۳۰ روزه", callback_data=f"sig_stats_send:{channel}:30"),
        ],
        [InlineKeyboardButton("🔄 شروع مجدد برآیند این کانال", callback_data=f"sig_stats_reset:{channel}")],
        back("a_signal_results")[0],
    ]
    await edit(query, "✅ مبنای برآیند از همین لحظه شروع شد.\n\n" + text, rows)


async def signal_stats_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    _, channel, period = query.data.split(":", 2)
    days = None if period == "all" else int(period)
    text = _signal_stats_text((await async_snapshot()), channel, days=days)
    chat_id = SETTINGS.public_channel_id if channel == "public" else SETTINGS.private_channel_id
    try:
        await _telegram_request_with_button_fallback(context.bot.send_message, chat_id, text, parse_mode=ParseMode.HTML)
    except TelegramError:
        await query.answer("ارسال گزارش ناموفق بود", show_alert=True)
        return
    await query.answer("گزارش ارسال شد", show_alert=True)


async def _channel_runtime_snapshot(bot, channel: str, chat_id: int) -> dict[str, Any]:
    result: dict[str, Any] = {
        "channel": channel,
        "chat_id": chat_id,
        "healthy": False,
        "members": None,
        "title": "—",
        "error": "",
    }
    if not int(chat_id or 0):
        result["error"] = "شناسه کانال تنظیم نشده است"
        return result
    try:
        chat = await bot.get_chat(chat_id)
        result["title"] = str(chat.title or chat.username or chat_id)
        result["members"] = await bot.get_chat_member_count(chat_id)
        me = await bot.get_me()
        membership = await bot.get_chat_member(chat_id, me.id)
        status = str(membership.status)
        result["healthy"] = status in {"creator", "administrator"}
        result["admin_status"] = status
        result["can_post"] = bool(getattr(membership, "can_post_messages", True))
        result["can_edit"] = bool(getattr(membership, "can_edit_messages", True))
        result["can_pin"] = bool(getattr(membership, "can_pin_messages", True))
    except TelegramError as exc:
        result["error"] = str(exc)[:180]
    if isinstance(result.get("members"), int):
        await async_with_db(lambda db: record_member_snapshot(db, channel, int(result["members"])))
    return result


async def channel_snapshot_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Snapshot every managed channel, including additional force-join channels."""
    db = await async_snapshot()
    configured: dict[int, str] = {}
    if int(SETTINGS.public_channel_id or 0):
        configured[int(SETTINGS.public_channel_id)] = "public"
    if int(SETTINGS.private_channel_id or 0):
        configured[int(SETTINGS.private_channel_id)] = "private"
    for item in required_join_channels(
        db,
        public_channel_id=SETTINGS.public_channel_id,
        private_channel_id=SETTINGS.private_channel_id,
    ):
        channel_id = int(item.get("channel_id", 0) or 0)
        if channel_id and channel_id not in configured:
            configured[channel_id] = str(channel_id)
    tasks = [_channel_runtime_snapshot(context.bot, channel_key, chat_id) for chat_id, channel_key in configured.items()]
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


def _channel_db_metrics(db: dict[str, Any], channel: str) -> dict[str, Any]:
    rows = [row for row in db.get("signals", []) if isinstance(row, dict)]
    selected: list[dict[str, Any]] = []
    for row in rows:
        delivered = row.get("delivered_channels")
        if isinstance(delivered, list):
            if channel in delivered:
                selected.append(row)
        elif row.get("target") in {channel, "both"}:
            selected.append(row)
    active = sum(1 for row in selected if str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES)
    failures = 0
    for row in rows:
        requested = row.get("requested_channels")
        delivered = row.get("delivered_channels")
        if isinstance(requested, list) and channel in requested and (not isinstance(delivered, list) or channel not in delivered):
            failures += 1
    latest = max((parse_dt(row.get("created_at")) for row in selected), default=None)
    return {"active": active, "failures": failures, "latest": latest, "total": len(selected)}


async def a_channel_center(update: Update, context: ContextTypes.DEFAULT_TYPE, *, answer_query: bool = True) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    if answer_query:
        await query.answer("در حال بررسی کانال‌ها…")
    await async_with_db(
        lambda db: ensure_channel_management(
            db,
            public_channel_id=SETTINGS.public_channel_id,
            private_channel_id=SETTINGS.private_channel_id,
        )
    )
    db = await async_snapshot()
    forced_channels = required_join_channels(
        db,
        public_channel_id=SETTINGS.public_channel_id,
        private_channel_id=SETTINGS.private_channel_id,
    )
    runtime_ids: list[tuple[str, int]] = [
        ("public", int(SETTINGS.public_channel_id or 0)),
        ("private", int(SETTINGS.private_channel_id or 0)),
    ]
    known_ids = {chat_id for _, chat_id in runtime_ids if chat_id}
    for item in forced_channels:
        channel_id = int(item.get("channel_id", 0) or 0)
        if channel_id and channel_id not in known_ids:
            runtime_ids.append((str(channel_id), channel_id))
            known_ids.add(channel_id)
    runtime_rows = await asyncio.gather(
        *(_channel_runtime_snapshot(context.bot, key, chat_id) for key, chat_id in runtime_ids),
        return_exceptions=True,
    )
    runtime_map: dict[str, dict[str, Any]] = {}
    for (key, chat_id), result in zip(runtime_ids, runtime_rows, strict=True):
        if isinstance(result, Exception):
            runtime_map[key] = {
                "channel": key,
                "chat_id": chat_id,
                "healthy": False,
                "members": None,
                "title": "—",
                "error": str(result)[:180],
            }
        else:
            runtime_map[key] = result

    public = runtime_map.get("public", {})
    private = runtime_map.get("private", {})
    public_metrics = _channel_db_metrics(db, "public")
    private_metrics = _channel_db_metrics(db, "private")
    public_ops = channel_analytics(db, "public", days=30)
    private_ops = channel_analytics(db, "private", days=30)
    public_membership_ops = channel_analytics(db, str(SETTINGS.public_channel_id), days=30)
    private_membership_ops = channel_analytics(db, str(SETTINGS.private_channel_id), days=30)
    settings = get_channel_management(
        db,
        public_channel_id=SETTINGS.public_channel_id,
        private_channel_id=SETTINGS.private_channel_id,
    )
    schedules = scheduled_signal_rows(db)
    force = settings.get("force_join", {})
    smart = settings.get("smart_pin", {})
    live = settings.get("live_status", {})

    def channel_block(
        icon: str,
        title: str,
        runtime: dict[str, Any],
        metrics: dict[str, Any],
        ops: dict[str, Any],
        membership_ops: dict[str, Any] | None = None,
    ) -> str:
        health = "🟢 سالم" if runtime.get("healthy") and runtime.get("can_post", True) else "🔴 نیازمند بررسی"
        members = f"{int(runtime['members']):,}" if isinstance(runtime.get("members"), int) else "نامشخص"
        growth = ops.get("member_growth")
        growth_text = "نامشخص" if growth is None else f"{int(growth):+d} در ۳۰ روز"
        last_send = display_dt(metrics["latest"]) if metrics.get("latest") else "هنوز ارسالی ثبت نشده"
        membership = membership_ops or ops
        passed = int(membership.get("membership_passed", 0) or 0)
        failed = int(membership.get("membership_failed", 0) or 0)
        unknown = int(membership.get("membership_unknown", 0) or 0)
        return (
            f"{icon} <b>{title}</b>\n"
            f"وضعیت اتصال: <b>{health}</b>\n"
            f"اعضا: <b>{members}</b> | رشد: <b>{growth_text}</b>\n"
            f"آخرین ارسال: <b>{last_send}</b>\n"
            f"سیگنال فعال: <b>{metrics['active']}</b> | ارسال ناموفق: <b>{metrics['failures']}</b>\n"
            f"تحویل پیام: <b>{float(ops.get('delivery_rate', 0)):.1f}%</b> | "
            f"پین: <b>{float(ops.get('pin_success_rate', 0)):.1f}%</b>\n"
            f"عضویت قبول/رد/نامشخص: <b>{passed}/{failed}/{unknown}</b>"
        )

    extra_blocks: list[str] = []
    primary_ids = {int(SETTINGS.public_channel_id or 0), int(SETTINGS.private_channel_id or 0)}
    for item in forced_channels:
        channel_id = int(item.get("channel_id", 0) or 0)
        key = str(channel_id)
        if channel_id in primary_ids:
            continue
        runtime = runtime_map.get(key, {})
        ops = channel_analytics(db, key, days=30)
        health = "🟢" if runtime.get("healthy") else "🔴"
        members = f"{int(runtime['members']):,}" if isinstance(runtime.get("members"), int) else "نامشخص"
        growth = ops.get("member_growth")
        growth_text = "؟" if growth is None else f"{int(growth):+d}"
        extra_blocks.append(
            f"{health} <b>{esc(item.get('title') or key)}</b> — اعضا <b>{members}</b> | "
            f"رشد <b>{growth_text}</b> | عبور عضویت <b>{float(ops.get('membership_pass_rate', 0)):.1f}%</b>"
        )
    extra_text = ""
    if extra_blocks:
        visible = extra_blocks[:8]
        extra_text = "\n\n🔗 <b>کانال‌های اجباری اضافی</b>\n" + "\n".join(visible)
        if len(extra_blocks) > len(visible):
            extra_text += f"\n… و {len(extra_blocks) - len(visible)} کانال دیگر"

    text = (
        "📺 <b>مرکز مدیریت کانال</b>\n\n"
        + channel_block("📢", "کانال عمومی", public, public_metrics, public_ops, public_membership_ops)
        + "\n\n"
        + channel_block("🔒", "کانال VIP", private, private_metrics, private_ops, private_membership_ops)
        + extra_text
        + "\n\n"
        f"🕒 صف زمان‌بندی: <b>{len(schedules)}</b>\n"
        f"📌 پین هوشمند: <b>{'فعال' if smart.get('enabled', True) else 'خاموش'}</b>\n"
        f"📊 پیام وضعیت زنده: <b>{'فعال' if live.get('enabled', True) else 'خاموش'}</b>\n"
        f"🔐 عضویت اجباری: <b>{'فعال' if force.get('enabled') else 'خاموش'}</b>"
    )
    rows = [
        [
            InlineKeyboardButton("📋 برد سیگنال‌ها", callback_data="sig_board:all:0"),
            InlineKeyboardButton("🕒 زمان‌بندی‌ها", callback_data="channel_schedules"),
        ],
        [
            InlineKeyboardButton("📌 بروزرسانی پین", callback_data="channel_pin_refresh", style="primary"),
            state_button("پین هوشمند", bool(smart.get("enabled", True)), callback_data="channel_pin_toggle"),
        ],
        [
            state_button("پیام وضعیت زنده", bool(live.get("enabled", True)), callback_data="channel_live_toggle"),
            state_button("عضویت اجباری", bool(force.get("enabled")), callback_data="force_join_panel"),
        ],
        [
            InlineKeyboardButton("📈 آمار عمومی", callback_data="sig_stats:public"),
            InlineKeyboardButton("📈 آمار VIP", callback_data="sig_stats:private"),
        ],
        [InlineKeyboardButton("🔄 بروزرسانی مرکز", callback_data="a_channel_center")],
        back("admin_home")[0],
    ]
    await edit(query, text, rows)


async def signal_board(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    _, channel, page_text = query.data.split(":", 2)
    rows_data, page, total_pages = signal_board_page((await async_snapshot()), channel=channel, page=int(page_text), page_size=8)
    label = {"all": "همه کانال‌ها", "public": "عمومی", "private": "VIP"}[channel]
    text = f"📋 <b>تابلو سیگنال‌ها</b>\nفیلتر: <b>{label}</b> | صفحه {page + 1} از {total_pages}\n\n"
    if rows_data:
        text += "سیگنال‌های فعال و بسته‌شده برای بررسی شفاف نتیجه نگهداری می‌شوند."
    else:
        text += "سیگنالی در این بخش وجود ندارد."
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("همه", callback_data="sig_board:all:0"),
            InlineKeyboardButton("عمومی", callback_data="sig_board:public:0"),
            InlineKeyboardButton("VIP", callback_data="sig_board:private:0"),
        ]
    ]
    for item in rows_data:
        from modules.outcome_engine import calculate_signal_outcome

        highest = int(item.get("highest_target_hit", 0) or 0)
        status = str(item.get("status") or "open")
        from modules.signal_status import signal_is_final

        if signal_is_final(item):
            outcome_item = dict(item)
            if status in {"stopped", "sl", "loss"}:
                outcome_item["status"] = "stop"
            elif status == "win":
                outcome_item["status"] = "target_complete"
            net_r = float(calculate_signal_outcome(outcome_item).net_r)
            if status in {"stop", "stopped", "sl", "loss"}:
                state = f"بسته · استاپ · {net_r:+.2f}R"
            elif status in {"target_complete", "win"} or (status.startswith("tp") and highest >= len(item.get("targets", [])) > 0):
                state = f"بسته · فول TP · {net_r:+.2f}R"
            elif status == "manual_close" and highest:
                state = f"بسته روی TP{highest} · {net_r:+.2f}R"
            else:
                state = f"بسته · {signal_status_label(status)} · {net_r:+.2f}R"
        elif highest:
            state = f"TP{highest} · {float(calculate_signal_outcome(item).net_r):+.2f}R"
        else:
            state = signal_status_label(status)
        age = signal_age_minutes(item)
        rows.append(
            [
                InlineKeyboardButton(
                    f"#{item.get('id')} | {item.get('symbol')} | {state} | {age}دقیقه",
                    callback_data=f"sig_result_view:{item.get('id')}",
                )
            ]
        )
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ قبلی", callback_data=f"sig_board:{channel}:{page - 1}"))
    if page + 1 < total_pages:
        nav.append(InlineKeyboardButton("بعدی ➡️", callback_data=f"sig_board:{channel}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"sig_board:{channel}:{page}")])
    rows.append(back("a_channel_center")[0])
    await edit(query, text, rows)


async def channel_schedules(update: Update, context: ContextTypes.DEFAULT_TYPE, *, answer_query: bool = True) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    if answer_query:
        await query.answer()
    schedules = scheduled_signal_rows(await async_snapshot())[:20]
    rows: list[list[InlineKeyboardButton]] = []
    lines = ["🕒 <b>صف انتشار زمان‌بندی‌شده</b>", ""]
    if not schedules:
        lines.append("موردی در صف وجود ندارد.")
    for item in schedules:
        payload = item.get("payload", {}) if isinstance(item.get("payload"), dict) else {}
        status = {"pending": "⏳", "processing": "🔄", "failed": "⚠️"}.get(str(item.get("status")), "•")
        lines.append(
            f"{status} <code>Q-{item.get('id')}</code> | <b>{esc(payload.get('symbol') or '-')}</b> | "
            f"{display_dt(item.get('run_at'))} | تلاش {int(item.get('attempts', 0) or 0)}"
        )
        if item.get("status") in {"pending", "failed"}:
            rows.append([InlineKeyboardButton(f"❌ لغو Q-{item.get('id')}", callback_data=f"channel_schedule_cancel:{item.get('id')}")])
    rows.append([InlineKeyboardButton("➕ ساخت سیگنال زمان‌بندی‌شده", callback_data="a_signal")])
    rows.append(back("a_channel_center")[0])
    await edit(query, "\n".join(lines), rows)


async def channel_schedule_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_SCHEDULE):
        return
    query = update.callback_query
    schedule_id = int(query.data.split(":", 1)[1])
    try:
        await async_with_db(lambda db: update_scheduled_signal(db, schedule_id, status="cancelled"))
        await async_with_db(lambda db: audit(db, query.from_user.id, "cancel_scheduled_signal", str(schedule_id)))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("ارسال زمان‌بندی‌شده لغو شد", show_alert=True)
    await channel_schedules(update, context, answer_query=False)


async def channel_pin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_PIN_MANAGE):
        return
    query = update.callback_query
    current = (
        get_channel_management(
            (await async_snapshot()), public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id
        )
        .get("smart_pin", {})
        .get("enabled", True)
    )
    enabled = not bool(current)
    await async_with_db(
        lambda db: set_channel_option(
            db,
            "smart_pin",
            "enabled",
            enabled,
            public_channel_id=SETTINGS.public_channel_id,
            private_channel_id=SETTINGS.private_channel_id,
        )
    )
    if enabled:
        await _sync_smart_pin(context.bot)
    else:
        settings = get_channel_management(
            (await async_snapshot()), public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id
        ).get("smart_pin", {})
        for channel, chat_id in (("public", SETTINGS.public_channel_id), ("private", SETTINGS.private_channel_id)):
            message_id = int(settings.get(f"{channel}_message_id", 0) or 0)
            if message_id:
                try:
                    await context.bot.unpin_chat_message(chat_id=chat_id, message_id=message_id)
                except TelegramError:
                    logger.warning("Could not unpin smart board in %s", channel)
    await query.answer("پین هوشمند فعال شد" if enabled else "پین هوشمند خاموش شد", show_alert=True)
    await a_channel_center(update, context, answer_query=False)


async def channel_pin_refresh(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CHANNEL_PIN_MANAGE):
        return
    query = update.callback_query
    errors = await _sync_smart_pin(context.bot)
    await query.answer("پین‌ها بروزرسانی شدند" if not errors else f"{errors} خطا در بروزرسانی پین", show_alert=True)
    await a_channel_center(update, context, answer_query=False)


async def channel_live_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    current = (
        get_channel_management(
            (await async_snapshot()), public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id
        )
        .get("live_status", {})
        .get("enabled", True)
    )
    enabled = not bool(current)
    await async_with_db(
        lambda db: set_channel_option(
            db,
            "live_status",
            "enabled",
            enabled,
            public_channel_id=SETTINGS.public_channel_id,
            private_channel_id=SETTINGS.private_channel_id,
        )
    )
    if enabled:
        for row in signal_board_page((await async_snapshot()), channel="all", page=0, page_size=20)[0]:
            await _sync_signal_live_status(context.bot, row, create_if_missing=True)
    await query.answer("پیام وضعیت زنده فعال شد" if enabled else "پیام وضعیت زنده خاموش شد", show_alert=True)
    await a_channel_center(update, context, answer_query=False)


async def force_join_panel(update: Update, context: ContextTypes.DEFAULT_TYPE, *, answer_query: bool = True) -> None:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return
    query = update.callback_query
    if answer_query:
        await query.answer()
    db = await async_snapshot()
    row = get_channel_management(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id).get(
        "force_join", {}
    )
    channels = required_join_channels(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
    channel_lines = [
        f"• <code>{item['channel_id']}</code> — <b>{esc(item['title'])}</b>\n  <code>{esc(item['invite_link'])}</code>" for item in channels
    ]
    text = (
        "🔐 <b>مدیریت عضویت اجباری چندکاناله</b>\n\n"
        f"وضعیت: <b>{'فعال' if row.get('enabled') else 'خاموش'}</b>\n"
        f"حالت بررسی: <b>{'عضویت در همه' if row.get('require_all', True) else 'عضویت در حداقل یکی'}</b>\n"
        f"تعداد کانال‌ها: <b>{len(channels)}</b>\n\n"
        + ("\n".join(channel_lines) if channel_lines else "هنوز کانالی تنظیم نشده است.")
        + "\n\nربات باید در تمام کانال‌ها ادمین باشد."
    )
    rows = [
        [
            state_button("عضویت اجباری", bool(row.get("enabled")), callback_data="force_join_toggle"),
            InlineKeyboardButton("🔁 همه/یکی", callback_data="force_join_mode_toggle"),
        ],
        [InlineKeyboardButton("📝 تنظیم فهرست کانال‌ها", callback_data="force_join_link_start")],
        [InlineKeyboardButton("🧪 بررسی دسترسی همه کانال‌ها", callback_data="force_join_test")],
        back("a_channel_center")[0],
    ]
    await edit(query, text, rows)


async def force_join_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return
    query = update.callback_query
    current = get_channel_management(
        (await async_snapshot()), public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id
    ).get("force_join", {})
    enabled = not bool(current.get("enabled"))
    if enabled and not str(current.get("invite_link") or "").strip():
        await query.answer("ابتدا لینک عضویت کانال را تنظیم کنید", show_alert=True)
        return
    await async_with_db(
        lambda db: set_force_join(
            db,
            enabled=enabled,
            channel_id=SETTINGS.public_channel_id,
            public_channel_id=SETTINGS.public_channel_id,
            private_channel_id=SETTINGS.private_channel_id,
        )
    )
    context.application.bot_data.pop("force_join_cache", None)
    await async_with_db(lambda db: audit(db, query.from_user.id, "force_join_toggle", str(enabled)))
    await query.answer("عضویت اجباری فعال شد" if enabled else "عضویت اجباری خاموش شد", show_alert=True)
    await force_join_panel(update, context, answer_query=False)


async def force_join_link_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "📝 هر کانال را در یک خط با قالب زیر بفرستید:\n"
        "<code>-1001234567890 | کانال اصلی | https://t.me/ChannelName</code>\n"
        "<code>-1009876543210 | کانال اخبار | https://t.me/+InviteHash</code>\n\n"
        "حداکثر ۲۰ کانال قابل ثبت است.",
        back("force_join_panel"),
    )
    return FORCE_JOIN_LINK_INPUT


async def force_join_link_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return ConversationHandler.END
    try:
        channels = parse_force_join_channels(update.effective_message.text or "")
        row = await async_with_db(
            lambda db: set_force_join_channels(
                db,
                channels,
                require_all=bool(
                    get_channel_management(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
                    .get("force_join", {})
                    .get("require_all", True)
                ),
                public_channel_id=SETTINGS.public_channel_id,
                private_channel_id=SETTINGS.private_channel_id,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "force_join_channels", str(len(channels))))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return FORCE_JOIN_LINK_INPUT
    context.application.bot_data.pop("force_join_cache", None)
    await reply(update, f"✅ فهرست {len(row.get('channels', []))} کانال ذخیره شد.", back("force_join_panel"))
    return ConversationHandler.END


async def force_join_mode_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return
    query = update.callback_query
    db = await async_snapshot()
    row = get_channel_management(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id).get(
        "force_join", {}
    )
    channels = required_join_channels(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
    await async_with_db(
        lambda current: set_force_join_channels(
            current,
            channels,
            require_all=not bool(row.get("require_all", True)),
            public_channel_id=SETTINGS.public_channel_id,
            private_channel_id=SETTINGS.private_channel_id,
        )
    )
    context.application.bot_data.pop("force_join_cache", None)
    await query.answer("حالت بررسی تغییر کرد", show_alert=True)
    await force_join_panel(update, context, answer_query=False)


async def force_join_test(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FORCED_JOIN_MANAGE):
        return
    query = update.callback_query
    db = await async_snapshot()
    channels = required_join_channels(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
    if not channels:
        await query.answer("کانالی تنظیم نشده است", show_alert=True)
        return
    results = []
    for item in channels:
        snapshot = await _channel_runtime_snapshot(context.bot, str(item["channel_id"]), int(item["channel_id"]))
        results.append((item, snapshot))
    failed = [item["title"] for item, snapshot in results if not snapshot.get("healthy") or not snapshot.get("can_post")]
    if failed:
        await query.answer(f"دسترسی ناقص: {', '.join(failed[:5])}", show_alert=True)
    else:
        await query.answer("دسترسی ربات به همه کانال‌ها صحیح است ✅", show_alert=True)


async def scheduled_signal_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    due = due_scheduled_signals(await async_snapshot(), limit=5)
    for item in due:
        schedule_id = int(item.get("id", 0) or 0)
        claimed = await async_with_db(lambda db, sid=schedule_id: claim_scheduled_signal(db, sid, lease_seconds=300))
        if not claimed:
            continue
        lease_token = str(claimed.get("lease_token") or "")

        async def renew_loop(sid: int = schedule_id, token: str = lease_token) -> None:
            while True:
                await asyncio.sleep(60)
                renewed = await async_with_db(lambda db: renew_scheduled_signal_lease(db, sid, token, lease_seconds=300))
                if not renewed:
                    logger.error("Lost scheduled signal lease Q-%s", sid)
                    return

        renew_task = asyncio.create_task(renew_loop(), name=f"scheduled-signal-lease:{schedule_id}")
        try:
            record, errors = await _publish_signal_payload(
                context.bot,
                dict(claimed.get("payload") or {}),
                str(claimed.get("target") or "public"),
                str(claimed.get("admin_id") or "scheduled"),
                scheduled_id=schedule_id,
            )
            if not record.get("delivered_channels"):
                raise RuntimeError("ارسال زمان‌بندی‌شده به هیچ کانالی تحویل نشد")
            sent_signal_id = int(record["id"])

            def finish(
                db: dict[str, Any],
                sid: int = schedule_id,
                token: str = lease_token,
                final_signal_id: int = sent_signal_id,
            ) -> dict[str, Any] | None:
                current = next(
                    (row for row in db.get("scheduled_signals", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == sid),
                    None,
                )
                if not current or str(current.get("lease_token") or "") != token:
                    return None
                return update_scheduled_signal(db, sid, status="sent", signal_id=final_signal_id)

            finished = await async_with_db(finish)
            if finished is None:
                logger.error("Scheduled signal Q-%s completed after its lease was lost", schedule_id)
                continue
            admin_id = str(claimed.get("admin_id") or "")
            if admin_id.isdigit():
                try:
                    suffix = f"\n⚠️ خطاها: {', '.join(errors)}" if errors else ""
                    await _telegram_request_with_button_fallback(
                        context.bot.send_message,
                        int(admin_id),
                        f"✅ سیگنال زمان‌بندی‌شده Q-{schedule_id} با شماره #{record['id']} منتشر شد.{suffix}",
                    )
                except TelegramError:
                    logger.info("Could not notify scheduling admin %s", admin_id)
        except Exception as error:
            logger.exception("Scheduled signal Q-%s failed", schedule_id)
            error_text = str(error)

            def fail(
                db: dict[str, Any],
                sid: int = schedule_id,
                token: str = lease_token,
                detail: str = error_text,
            ) -> dict[str, Any] | None:
                current = next(
                    (row for row in db.get("scheduled_signals", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == sid),
                    None,
                )
                if not current or str(current.get("lease_token") or "") != token:
                    return None
                maximum = int(current.get("max_attempts", 3) or 3)
                terminal = int(current.get("attempts", 0) or 0) >= maximum
                row = update_scheduled_signal(db, sid, status="dead" if terminal else "retrying", error=detail)
                row.pop("lease_token", None)
                row.pop("lease_until", None)
                row.pop("processing_started_at", None)
                if not terminal:
                    delay_minutes = min(5 * (2 ** max(int(row.get("attempts", 1) or 1) - 1, 0)), 60)
                    row["run_at"] = utc_iso(utc_now() + timedelta(minutes=delay_minutes))
                    row["retry_at"] = row["run_at"]
                return row

            failed = await async_with_db(fail)
            if failed and str(failed.get("status") or "") == "dead":
                admin_id = str(failed.get("admin_id") or "")
                if admin_id.isdigit():
                    try:
                        await _telegram_request_with_button_fallback(
                            context.bot.send_message,
                            int(admin_id),
                            f"❌ انتشار زمان‌بندی Q-{schedule_id} پس از ۳ تلاش ناموفق ماند.",
                        )
                    except TelegramError:
                        pass
        finally:
            renew_task.cancel()
            try:
                await renew_task
            except asyncio.CancelledError:
                pass


def _crm_view_payload(uid: str) -> tuple[str, list[list[InlineKeyboardButton]]]:
    db = load_db()
    user = db.get("users", {}).get(str(uid), {})
    summary = with_db(lambda database: crm_summary(database, uid))
    profile = summary["profile"]
    behavior = build_user_profile(db, uid)
    persona_labels = {
        "explorer": "کاوشگر تازه‌وارد",
        "engaged": "کاربر درگیر",
        "vip_prospect": "مستعد خرید VIP",
        "paying": "مشتری پرداخت‌کننده",
        "advocate": "حامی و معرف برند",
        "at_risk": "در معرض ریزش",
        "dormant": "کاربر خوابیده",
        "support_sensitive": "نیازمند توجه پشتیبانی",
    }
    tags = "، ".join(profile.get("tags", [])) or "بدون برچسب"
    notes = profile.get("notes", [])
    last_notes = (
        "\n".join(f"• {esc(item.get('text'))} — <code>{esc(item.get('admin_id'))}</code>" for item in notes[-5:] if isinstance(item, dict))
        or "یادداشتی ثبت نشده است."
    )
    custom_fields = profile.get("custom_fields", {}) if isinstance(profile.get("custom_fields"), dict) else {}
    custom_lines = (
        f"☎️ تماس: <code>{esc(custom_fields.get('phone') or '-')}</code>\n"
        f"📣 منبع جذب: <b>{esc(custom_fields.get('source') or '-')}</b>\n"
        f"🏢 شرکت/مجموعه: <b>{esc(custom_fields.get('company') or '-')}</b>\n"
        f"📈 بازار موردعلاقه: <b>{esc(custom_fields.get('preferred_market') or '-')}</b>\n"
        f"💬 روش تماس: <b>{esc(custom_fields.get('contact_method') or '-')}</b>\n"
    )
    text = (
        _admin_user_profile_text(db, uid, user)
        + "\n\n🗂 <b>CRM کامل</b>\n"
        + f"🏷 برچسب‌ها: {esc(tags)}\n"
        + f"📌 وضعیت: <b>{esc(profile.get('status', 'normal'))}</b>\n"
        + f"🎯 امتیاز سرنخ: <b>{int(summary.get('lead_score', 0) or 0)}/100</b>\n"
        + f"🪜 مرحله فروش: <b>{esc(summary.get('stage_label') or CRM_STAGES.get(str(summary.get('stage')), 'سرنخ'))}</b>\n"
        + f"🧩 گروه اصلی: <b>{esc(summary.get('primary_category_label') or 'دسته‌بندی‌نشده')}</b>\n"
        + f"🏷 گروه‌های خودکار: {esc('، '.join(summary.get('segment_labels', [])) or 'ندارد')}\n"
        + f"🧠 رفتار غالب: <b>{esc(persona_labels.get(str(behavior.get('behavior_persona')), 'نامشخص'))}</b>\n"
        + f"📊 تعامل: <b>{int(behavior.get('engagement_score', 0))}/100</b> | قصد خرید: <b>{int(behavior.get('purchase_intent_score', 0))}/100</b> | ریسک ریزش: <b>{int(behavior.get('churn_risk_score', 0))}/100</b>\n"
        + f"👮 مسئول پیگیری: <code>{esc(profile.get('assigned_admin') or '-')}</code>\n"
        + custom_lines
        + f"⏰ زمان پیگیری: {display_dt(profile.get('follow_up_at')) if profile.get('follow_up_at') else '-'}\n"
        + f"💰 خرید VIP: <b>{summary['vip_approved']}</b> تأیید | <b>{summary['vip_spend']:,}</b> تومان\n"
        + f"🎓 آموزش پولی: <b>{summary['education_orders']}</b> سفارش | <b>{summary['education_spend']:,}</b> تومان\n"
        + f"🎫 تیکت: <b>{summary['tickets']}</b> | باز: <b>{summary['open_tickets']}</b>\n"
        + f"👥 معرفی موفق: <b>{summary['referrals']}</b>\n"
        + f"🎁 جوایز: <b>{summary['rewards']}</b>\n\n"
        + f"📝 <b>آخرین یادداشت‌ها</b>\n{last_notes}"
    )
    rows = [
        [
            InlineKeyboardButton("📝 یادداشت", callback_data="crm_note"),
            InlineKeyboardButton("🏷 برچسب", callback_data="crm_tag"),
        ],
        [
            InlineKeyboardButton("⏰ تعیین پیگیری", callback_data="crm_followup"),
            InlineKeyboardButton("✅ بستن پیگیری", callback_data="crm_followup_clear"),
        ],
        [
            InlineKeyboardButton("🪜 تغییر مرحله فروش", callback_data=f"crm_stage_menu:{uid}"),
            InlineKeyboardButton("👮 مسئول پرونده", callback_data=f"crm_assign_menu:{uid}"),
        ],
        [
            InlineKeyboardButton("☎️ اطلاعات تکمیلی", callback_data=f"crm_field_menu:{uid}"),
            InlineKeyboardButton("🕘 Timeline", callback_data=f"crm_timeline:{uid}"),
        ],
        [InlineKeyboardButton("📊 خط فروش", callback_data="crm_pipeline")],
        [
            InlineKeyboardButton("📦 سفارش‌های VIP", callback_data=f"crm_orders:{uid}"),
            InlineKeyboardButton("🎓 خرید آموزش", callback_data=f"crm_edu:{uid}"),
        ],
        [
            InlineKeyboardButton("🧩 تقسیم مشتریان", callback_data="a_crm_segments"),
            InlineKeyboardButton("🔎 کاربر دیگر", callback_data="a_crm"),
        ],
        [InlineKeyboardButton("↩️ کاربران و CRM", callback_data="admin_cat:users")],
    ]
    return text, rows



__feature_exports__ = ('chart_contest_end', 'chart_contest_final', 'candle_contest_start', 'candle_contest_question', 'candle_contest_duration', 'candle_contest_end', 'candle_contest_final', 'news_contest_start', 'news_contest_name', 'news_contest_end', 'news_contest_final', '_announcement_destination_rows', '_announcement_topic_rows', 'a_announcement', 'announcement_start', 'announcement_destination', 'announcement_topic', 'announcement_custom_title', '_announcement_content_type', 'announcement_content', 'announcement_publish', 'announcement_history_view', '_signal_template_side_label', '_signal_template_home_rows', '_render_signal_template_home', 'signal_template_home', 'signal_template_delivery_toggle', '_signal_template_side_rows', 'signal_template_side_menu', 'SIGNAL_TEMPLATE_UPLOAD_INPUT', 'signal_template_upload_start', 'signal_template_upload_input', 'signal_template_upload_cancel', 'signal_template_background_reset', '_signal_template_field_rows', '_render_signal_template_field', 'signal_template_field_menu', 'signal_template_move', 'signal_template_font', 'signal_template_reset', 'signal_template_preview', 'a_signal', 'signal_owner_approval_toggle', 'signal_channel_id_start', 'signal_channel_id_input', 'signal_market_handler', '_signal_side_rows', 'signal_symbol', 'signal_symbol_text', 'signal_side', 'signal_entry', 'signal_targets', 'signal_stop', '_signal_chart_prompt', 'signal_risk_button', 'signal_risk_text', '_signal_chart_rows', 'signal_chart_image', 'signal_chart_skip', 'signal_chart_change', 'signal_wizard_back', '_signal_target_rows', '_signal_preview_text', '_signal_preview_rows', '_publish_signal_payload', 'signal_target', 'signal_preview_target', '_queue_signal_for_approval', 'signal_approval_list', 'signal_approval_decision', 'signal_publish_now', 'signal_schedule_start', 'signal_schedule_input', 'a_signal_results', 'a_signal_edit', 'a_signal_delete', 'signal_results_noop', '_signal_management_rows', '_signal_current_text', '_signal_destination_chat_ids', '_refresh_signal_channel_messages', '_store_live_status_message', '_sync_signal_live_status', '_sync_smart_pin', 'signal_result_view', '_signal_result_message', '_signal_result_chart_caption', '_publish_signal_result_chart', '_delete_signal_result_chart_messages', 'signal_result_media_start', 'signal_result_media_input', 'signal_result_media_invalid', 'signal_result_media_cancel', '_publish_signal_update', 'signal_reply_status_handler', 'signal_lifecycle_handler', 'signal_partial_close_menu', 'signal_partial_close_apply', 'signal_delete_confirm', 'signal_delete_execute', 'signal_edit_menu', 'signal_edit_start', 'signal_edit_input', 'signal_metrics_start', 'signal_metrics_input', 'signal_result_set_handler', 'signal_result_reset_handler', '_signal_stats_text', 'signal_stats_view', 'signal_stats_reset', 'signal_stats_send', '_channel_runtime_snapshot', 'channel_snapshot_job', '_channel_db_metrics', 'a_channel_center', 'signal_board', 'channel_schedules', 'channel_schedule_cancel', 'channel_pin_toggle', 'channel_pin_refresh', 'channel_live_toggle', 'force_join_panel', 'force_join_toggle', 'force_join_link_start', 'force_join_link_input', 'force_join_mode_toggle', 'force_join_test', 'scheduled_signal_job', '_crm_view_payload')
