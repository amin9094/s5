"""Feature-owned Telegram handlers extracted from the v7 runtime: navigation."""

import json

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

def _remember_runtime_bot_username(value: str | None) -> str:
    """Store the authenticated Telegram username for links and Mini App routing."""
    global _RUNTIME_BOT_USERNAME
    candidate = str(value or "").strip().lstrip("@")
    if re.fullmatch(r"[A-Za-z0-9_]{5,32}", candidate):
        if SETTINGS.bot_username and SETTINGS.bot_username.lower() != candidate.lower():
            logger.warning(
                "Configured BOT_USERNAME @%s differs from authenticated bot @%s; using authenticated value",
                SETTINGS.bot_username,
                candidate,
            )
        _RUNTIME_BOT_USERNAME = candidate
    return _RUNTIME_BOT_USERNAME


def effective_bot_username() -> str:
    return _RUNTIME_BOT_USERNAME or SETTINGS.bot_username


def back(callback: str, *, language: str | None = None) -> list[list[InlineKeyboardButton]]:
    """Localized deterministic one-step Back button.

    The visible label is always canonical, while the requested parent callback
    is retained inside a short ``nb:`` navigation envelope.  Back therefore
    opens the actual parent menu and never replays old snapshots of committed
    changes.
    """
    lang = normalize_language(language or "fa")
    label = "⬅️ Back" if lang == "en" else "⬅️ برگشت"
    return [[InlineKeyboardButton(label, callback_data=callback)]]


def standard_user_nav(
    *,
    previous_callback: str | None = None,
    previous_label: str = "⬅️ برگشت",
    section_callback: str | None = None,
    section_label: str = "🧭 مرکز بخش",
    include_home: bool = True,
) -> list[list[InlineKeyboardButton]]:
    """Consistent navigation footer for all user-facing screens."""
    rows: list[list[InlineKeyboardButton]] = []
    first: list[InlineKeyboardButton] = []
    if previous_callback:
        first.append(InlineKeyboardButton(previous_label, callback_data=previous_callback))
    if section_callback and section_callback != previous_callback:
        first.append(InlineKeyboardButton(section_label, callback_data=section_callback))
    if first:
        rows.append(first)
    if include_home:
        rows.append([InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")])
    return rows


def webapp_row() -> list[InlineKeyboardButton] | None:
    from modules.miniapp_runtime import miniapp_enabled

    if not SETTINGS.has_webapp or not miniapp_enabled(load_db()):
        return None
    url = telegram_webapp_launch_url(effective_bot_username())
    # Keep this entry bilingual without needing user context in every caller.
    return [InlineKeyboardButton("🛡 SENTINEL Mini App", web_app=WebAppInfo(url=url), style="primary")]


def with_webapp(rows: list[list[InlineKeyboardButton]]) -> list[list[InlineKeyboardButton]]:
    """Append the Mini App entry without displacing the owner's primary CTA."""
    row = webapp_row()
    return rows + ([row] if row else [])


def _user_callback_enabled(db: dict[str, Any], callback: str) -> bool:
    module_key = feature_for_callback(callback)
    return not module_key or is_module_enabled(db, module_key)


def _visible_user_items(
    db: dict[str, Any], items: list[tuple[str, str]]
) -> list[tuple[str, str]]:
    return [item for item in items if _user_callback_enabled(db, item[1])]


def _is_any_admin(user_id: int | str) -> bool:
    return db_is_any_admin(load_db(), user_id)


def _is_owner_admin(user_id: int | str) -> bool:
    if not SETTINGS.admin_ids:
        return False
    try:
        return int(user_id) == int(SETTINGS.admin_ids[0])
    except (TypeError, ValueError):
        return False


def _has_admin_permission(user_id: int | str, permission: str) -> bool:
    db = load_db()
    return delegated_has_permission(db, user_id, permission) and is_admin_on_shift(db, user_id)


def _has_any_admin_permission(user_id: int | str, *permissions: str) -> bool:
    if is_admin(user_id):
        return True
    return any(_has_admin_permission(user_id, permission) for permission in permissions)


def _admin_ids_for_permission(permission: str) -> list[int]:
    db = load_db()
    ids = {int(admin_id) for admin_id in SETTINGS.admin_ids if is_admin_on_shift(db, admin_id)}
    for uid, row in delegated_admins(db).items():
        if row.get("active", True) and delegated_has_permission(db, uid, permission) and is_admin_on_shift(db, uid):
            ids.add(int(uid))
    return sorted(ids)


def _language_for_user(user_id: int | str) -> str:
    return user_language(load_db(), user_id) or "fa"


QUICK_MENU_BUTTON_FA = "🧭 منوی ربات"
QUICK_MENU_BUTTON_EN = "🧭 Bot Menu"
HOME_BUTTON_FA = "🏠 منوی اصلی"
HOME_BUTTON_EN = "🏠 Main menu"
VIP_BUTTON_FA = "⚪ خرید اشتراک"
VIP_BUTTON_EN = "⚪ Buy subscription"
SIGNALS_BUTTON_FA = "🔵 سیگنال‌ها"
SIGNALS_BUTTON_EN = "🔵 Signals"
PRICES_BUTTON_FA = "🔵 قیمت بازار"
PRICES_BUTTON_EN = "🔵 Market prices"
RISK_BUTTON_FA = "🔵 محاسبه ریسک"
RISK_BUTTON_EN = "🔵 Risk calculator"
SUPPORT_BUTTON_FA = "🔵 پشتیبانی"
SUPPORT_BUTTON_EN = "🔵 Support"
JOURNAL_BUTTON_FA = "⚫ ژورنال من"
JOURNAL_BUTTON_EN = "⚫ My journal"
ACCOUNT_BUTTON_FA = "⚫ حساب من"
ACCOUNT_BUTTON_EN = "⚫ My account"
EDUCATION_BUTTON_FA = "⚪ آموزش"
EDUCATION_BUTTON_EN = "⚪ Education"
CLUB_BUTTON_FA = "⚪ باشگاه و جوایز"
CLUB_BUTTON_EN = "⚪ Club & rewards"
TOOLS_BUTTON_FA = "🔵 ابزارها و ریسک"
TOOLS_BUTTON_EN = "🔵 Tools & risk"
MARKETS_BUTTON_FA = "🔵 مرکز بازار"
MARKETS_BUTTON_EN = "🔵 Market desk"
LANGUAGE_BUTTON_FA = "⚪ تغییر زبان"
LANGUAGE_BUTTON_EN = "⚪ Language"
MINIAPP_BUTTON_FA = "🔵 مینی‌اپ"
MINIAPP_BUTTON_EN = "🔵 Mini App"
ADMIN_HOME_BUTTON_FA = "🔵 مرکز مدیریت"
ADMIN_HOME_BUTTON_EN = "🔵 Admin center"
ADMIN_TRADING_BUTTON_FA = "🔵 مدیریت معاملات"
ADMIN_TRADING_BUTTON_EN = "🔵 Trading admin"
ADMIN_SALES_BUTTON_FA = "⚪ فروش و اشتراک"
ADMIN_SALES_BUTTON_EN = "⚪ Sales & subscriptions"
ADMIN_USERS_BUTTON_FA = "⚫ کاربران و CRM"
ADMIN_USERS_BUTTON_EN = "⚫ Users & CRM"
ADMIN_ANALYTICS_BUTTON_FA = "🔵 تحلیل و گزارش"
ADMIN_ANALYTICS_BUTTON_EN = "🔵 Analytics & reports"
ADMIN_SYSTEM_BUTTON_FA = "⚫ سیستم و امنیت"
ADMIN_SYSTEM_BUTTON_EN = "⚫ System & security"
ADMIN_TICKETS_BUTTON_FA = "🔵 تیکت‌های ادمین"
ADMIN_TICKETS_BUTTON_EN = "🔵 Admin tickets"
CANCEL_OPERATION_BUTTON_FA = "✖️ لغو عملیات جاری"
CANCEL_OPERATION_BUTTON_EN = "✖️ Cancel current action"
RESTART_BOT_BUTTON_FA = "🔄 شروع مجدد ربات"
RESTART_BOT_BUTTON_EN = "🔄 Restart bot"
_COMMAND_MENU_STATE_KEY = "sentinel_command_menu_v1"
_NAVIGATION_STACK_KEY = "sentinel_navigation_stack_v2"
_NAVIGATION_STACK_LIMIT = 24
_NAVIGATION_CALLBACK = "nav_back"
_NAVIGATION_TARGET_PREFIX = "nb:"


def _is_back_or_cancel_label(text: str) -> bool:
    clean = re.sub(r"\s+", " ", str(text or "")).strip().casefold()
    stripped = clean.lstrip("↩️🔙⬅️◀️←❌✖️ ").strip()
    if clean.startswith(("↩", "🔙", "⬅", "◀", "←")):
        return True
    if stripped in {"بازگشت", "برگشت", "back", "انصراف", "لغو", "cancel", "cancel action"}:
        return True
    return stripped.startswith(("بازگشت به ", "برگشت به ", "back to "))


def _normalize_navigation_rows(
    rows: list[list[InlineKeyboardButton]] | None,
) -> list[list[InlineKeyboardButton]] | None:
    """Route every real Back/Cancel UI control through one canonical callback."""
    if not rows:
        return rows
    normalized: list[list[InlineKeyboardButton]] = []
    for row in rows:
        normalized_row: list[InlineKeyboardButton] = []
        for button in row:
            callback = str(getattr(button, "callback_data", "") or "")
            canonical = canonical_navigation_text(getattr(button, "text", ""), callback) if callback else None
            if canonical:
                label, target = canonical
                normalized_row.append(clone_button_with_text_and_callback(button, label, target))
            else:
                normalized_row.append(button)
        normalized.append(normalized_row)
    return normalized


def _callback_screen_snapshot(query) -> dict[str, Any] | None:
    message = getattr(query, "message", None)
    if message is None:
        return None
    if getattr(message, "text", None) is not None:
        kind = "text"
        body = str(getattr(message, "text_html", None) or esc(message.text or ""))
    elif getattr(message, "caption", None) is not None:
        kind = "caption"
        body = str(getattr(message, "caption_html", None) or esc(message.caption or ""))
    else:
        return None
    markup = getattr(message, "reply_markup", None)
    markup_data = markup.to_dict() if markup is not None else None
    snapshot = {
        "kind": kind,
        "body": body,
        "reply_markup": markup_data,
        "chat_id": getattr(message, "chat_id", None),
        "message_id": getattr(message, "message_id", None),
    }
    snapshot["fingerprint"] = json.dumps(
        {"kind": kind, "body": body, "reply_markup": markup_data},
        ensure_ascii=False, sort_keys=True, default=str,
    )
    return snapshot


def _navigation_stack(context: ContextTypes.DEFAULT_TYPE) -> list[dict[str, Any]]:
    value = context.user_data.get(_NAVIGATION_STACK_KEY)
    if not isinstance(value, list):
        value = []
        context.user_data[_NAVIGATION_STACK_KEY] = value
    return value


def _is_state_mutation_callback(callback: str) -> bool:
    """Return True for callbacks that change state without opening a new menu.

    These callbacks must never be pushed onto Back history. Otherwise each
    permission toggle, status change or approval becomes a fake navigation
    step and Back appears to undo the changes one by one.
    """
    value = str(callback or "").strip().casefold()
    if not value:
        return False
    if value.startswith(_NAVIGATION_TARGET_PREFIX):
        return True
    mutation_tokens = (
        "toggle", "perm", "set", "save", "update", "delete", "remove",
        "approve", "reject", "confirm", "apply", "retry", "reset",
        "run", "send", "dispatch", "archive", "restore", "prune",
        "ban", "unban", "assign", "unassign", "refund", "expire",
        "status", "action", "cycle", "move", "pin", "clear", "claim",
        "complete", "ack", "pause", "resume", "submit", "upload",
    )
    parts = tuple(part for part in re.split(r"[:_]", value) if part)
    return any(token in parts for token in mutation_tokens)


async def capture_navigation_screen(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Remember menu transitions only; never record in-place mutations."""
    query = update.callback_query
    if query is None:
        return
    callback = str(query.data or "")
    if (
        callback in {_NAVIGATION_CALLBACK, "cancel_current", "restart_bot", "home"}
        or callback.startswith(_NAVIGATION_TARGET_PREFIX)
        or _is_state_mutation_callback(callback)
    ):
        return
    snapshot = _callback_screen_snapshot(query)
    if snapshot is None:
        return
    stack = _navigation_stack(context)
    if not stack or stack[-1].get("fingerprint") != snapshot.get("fingerprint"):
        stack.append(snapshot)
        del stack[:-_NAVIGATION_STACK_LIMIT]


async def _dispatch_back_target(
    update: Update, context: ContextTypes.DEFAULT_TYPE, target: str
) -> int:
    """Dispatch a Back target through the same callback registry as Telegram."""
    class _CallbackQueryProxy:
        def __init__(self, query, data: str):
            self._query = query
            self.data = data

        def __getattr__(self, name: str):
            return getattr(self._query, name)

    class _UpdateProxy:
        def __init__(self, original, query):
            self._original = original
            self.callback_query = query

        def __getattr__(self, name: str):
            return getattr(self._original, name)

    handler = signal_wizard_back if target.startswith("sig_back:") else None
    for pattern, candidate in callback_routes(globals()):
        if candidate is navigation_back:
            continue
        if re.match(pattern, target):
            handler = candidate
            break
    if handler is None:
        raise LookupError(f"Back target has no callback route: {target}")

    proxied_query = _CallbackQueryProxy(update.callback_query, target)
    proxied_update = _UpdateProxy(update, proxied_query)
    result = await handler(proxied_update, context)
    return ConversationHandler.END if result is None else result


async def navigation_back(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Open exactly one parent menu without undoing committed work.

    New buttons carry their parent callback in an ``nb:`` envelope. The
    current unfinished wizard data is discarded so later messages are not
    swallowed, but database writes that already succeeded are never reversed.
    A snapshot fallback remains only for old Telegram messages created by
    releases before deterministic parent routing.
    """
    query = update.callback_query
    callback = str(query.data or "")
    target = (
        callback[len(_NAVIGATION_TARGET_PREFIX):]
        if callback.startswith(_NAVIGATION_TARGET_PREFIX)
        else ""
    )

    if target == "admin_menu":
        target = "admin_home"
    if target:
        if not target.startswith("sig_back:"):
            _clear_current_operation(context)
        try:
            return await _dispatch_back_target(update, context, target)
        except LookupError:
            logger.warning("Could not resolve deterministic Back target: %s", target)
            return await home_callback(update, context)

    # Compatibility fallback for old messages whose button callback is only
    # ``nav_back``. Mutation callbacks are no longer captured, so this history
    # cannot replay permission/status changes one by one.
    await query.answer()
    current = _callback_screen_snapshot(query)
    current_fingerprint = (current or {}).get("fingerprint")
    stack = _navigation_stack(context)
    snapshot = None
    while stack:
        candidate = stack.pop()
        if candidate.get("fingerprint") != current_fingerprint:
            snapshot = candidate
            break
    _clear_current_operation(context, preserve_navigation=True)
    if snapshot is None:
        return await home_callback(update, context)
    markup_data = snapshot.get("reply_markup")
    markup = InlineKeyboardMarkup.de_json(markup_data, query.get_bot()) if isinstance(markup_data, dict) else None
    if markup is not None:
        normalized_rows = _normalize_navigation_rows([list(row) for row in markup.inline_keyboard])
        markup = InlineKeyboardMarkup(normalized_rows or [])
    try:
        if snapshot.get("kind") == "caption" and getattr(query.message, "caption", None) is not None:
            await _telegram_request_with_button_fallback(
                query.edit_message_caption,
                caption=str(snapshot.get("body") or ""),
                reply_markup=markup,
                parse_mode=ParseMode.HTML,
            )
        else:
            await _telegram_request_with_button_fallback(
                query.edit_message_text,
                text=str(snapshot.get("body") or ""),
                reply_markup=markup,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
            )
    except BadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            logger.warning("Could not restore previous navigation screen: %s", exc)
            restored = await _replace_callback_screen(query, str(snapshot.get("body") or ""), normalized_rows if markup is not None else [])
            if not restored:
                raise
    return ConversationHandler.END

def _keyboard_labels() -> set[str]:
    return {
        QUICK_MENU_BUTTON_FA,
        QUICK_MENU_BUTTON_EN,
        CANCEL_OPERATION_BUTTON_FA,
        CANCEL_OPERATION_BUTTON_EN,
    }


KEYBOARD_SHORTCUT_PATTERN = rf"^(?:{'|'.join(re.escape(label) for label in sorted(_keyboard_labels(), key=len, reverse=True))})$"
QUICK_MENU_BUTTON_PATTERN = rf"^(?:{re.escape(QUICK_MENU_BUTTON_FA)}|{re.escape(QUICK_MENU_BUTTON_EN)})$"
QUICK_MENU_FILTER = (
    filters.ChatType.PRIVATE
    & filters.TEXT
    & ~filters.COMMAND
    & filters.Regex(QUICK_MENU_BUTTON_PATTERN)
)
KEYBOARD_SHORTCUT_FILTER = (
    filters.ChatType.PRIVATE
    & filters.TEXT
    & ~filters.COMMAND
    & filters.Regex(KEYBOARD_SHORTCUT_PATTERN)
)
CANCEL_OPERATION_BUTTON_PATTERN = rf"^(?:{re.escape(CANCEL_OPERATION_BUTTON_FA)}|{re.escape(CANCEL_OPERATION_BUTTON_EN)})$"
RESTART_BOT_BUTTON_PATTERN = rf"^(?:{re.escape(RESTART_BOT_BUTTON_FA)}|{re.escape(RESTART_BOT_BUTTON_EN)})$"
CANCEL_OPERATION_FILTER = filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND & filters.Regex(CANCEL_OPERATION_BUTTON_PATTERN)
RESTART_BOT_FILTER = filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND & filters.Regex(RESTART_BOT_BUTTON_PATTERN)


def quick_access_keyboard(user_id: int | str) -> ReplyKeyboardRemove:
    """Compatibility helper that removes every legacy Reply Keyboard.

    SENTINEL now uses Telegram's native command menu (the button on the left
    side of the message field).  Returning ``ReplyKeyboardRemove`` guarantees
    that keyboards cached by older deployments are dismissed on the client.
    """
    del user_id
    return ReplyKeyboardRemove(selective=True)


async def _send_keyboard_shortcut_entry(
    update: Update,
    *,
    text: str,
    callback: str,
    button_label: str,
    include_home: bool = True,
) -> int:
    rows = [[InlineKeyboardButton(button_label, callback_data=callback)]]
    if include_home:
        language = _language_for_user(update.effective_user.id)
        rows.append([InlineKeyboardButton("Main menu" if language == "en" else "منوی اصلی", callback_data="home")])
    await reply(update, text, rows)
    return ConversationHandler.END


async def keyboard_shortcut_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user or not update.effective_message:
        return ConversationHandler.END
    label = str(update.effective_message.text or "").strip()
    language = _language_for_user(user.id)
    if label in {CANCEL_OPERATION_BUTTON_FA, CANCEL_OPERATION_BUTTON_EN}:
        return await cancel_command(update, context)
    if label in {RESTART_BOT_BUTTON_FA, RESTART_BOT_BUTTON_EN}:
        return await restart_command(update, context)
    if label in {QUICK_MENU_BUTTON_FA, QUICK_MENU_BUTTON_EN, HOME_BUTTON_FA, HOME_BUTTON_EN}:
        return await menu_command(update, context)
    if label in {VIP_BUTTON_FA, VIP_BUTTON_EN}:
        return await _send_keyboard_shortcut_entry(
            update,
            text=("Open your VIP plans and subscription status:" if language == "en" else "پلن‌های VIP و وضعیت اشتراک خود را باز کنید:"),
            callback="u_vip",
            button_label=("💎 Open VIP" if language == "en" else "💎 ورود به VIP"),
        )
    if label in {SIGNALS_BUTTON_FA, SIGNALS_BUTTON_EN}:
        return await signals_command(update, context) or ConversationHandler.END
    if label in {PRICES_BUTTON_FA, PRICES_BUTTON_EN}:
        return await prices_command(update, context) or ConversationHandler.END
    if label in {RISK_BUTTON_FA, RISK_BUTTON_EN}:
        return await _send_keyboard_shortcut_entry(
            update,
            text=("Open the professional risk calculator:" if language == "en" else "ماشین‌حساب حرفه‌ای ریسک را باز کنید:"),
            callback="u_calc",
            button_label=("🧮 Open calculator" if language == "en" else "🧮 ورود به ماشین‌حساب"),
        )
    if label in {SUPPORT_BUTTON_FA, SUPPORT_BUTTON_EN}:
        return await support_command(update, context) or ConversationHandler.END
    if label in {JOURNAL_BUTTON_FA, JOURNAL_BUTTON_EN}:
        return await _send_keyboard_shortcut_entry(
            update,
            text=("Choose the journal you want to manage:" if language == "en" else "ژورنال موردنظر خود را انتخاب کنید:"),
            callback="user_journal",
            button_label=("📔 Open my journal" if language == "en" else "📔 ورود به ژورنال من"),
        )
    if label in {ACCOUNT_BUTTON_FA, ACCOUNT_BUTTON_EN}:
        return await account_command(update, context) or ConversationHandler.END
    if label in {EDUCATION_BUTTON_FA, EDUCATION_BUTTON_EN}:
        return await _send_keyboard_shortcut_entry(
            update,
            text=("Open Sentinel academy and bot guides:" if language == "en" else "آکادمی Sentinel و راهنمای ربات را باز کنید:"),
            callback="nav_user:learning",
            button_label=("🎓 Open academy" if language == "en" else "🎓 ورود به آکادمی"),
        )
    if label in {CLUB_BUTTON_FA, CLUB_BUTTON_EN}:
        await reply(update, user_category_text("club", user.id), user_category_menu("club", user.id))
        return ConversationHandler.END
    if label in {TOOLS_BUTTON_FA, TOOLS_BUTTON_EN}:
        await reply(update, user_category_text("tools", user.id), user_category_menu("tools", user.id))
        return ConversationHandler.END
    if label in {MARKETS_BUTTON_FA, MARKETS_BUTTON_EN}:
        await reply(update, user_category_text("markets", user.id), user_category_menu("markets", user.id))
        return ConversationHandler.END
    if label in {LANGUAGE_BUTTON_FA, LANGUAGE_BUTTON_EN}:
        await _send_language_prompt(update)
        return ConversationHandler.END
    if label in {MINIAPP_BUTTON_FA, MINIAPP_BUTTON_EN}:
        row = webapp_row()
        if row:
            await reply(
                update,
                ("Open the Mini App from the button below:" if language == "en" else "مینی‌اپ را از دکمه زیر باز کنید:"),
                [row, [InlineKeyboardButton("Main menu" if language == "en" else "منوی اصلی", callback_data="home")]],
            )
        else:
            await reply(
                update,
                ("The Mini App is currently disabled." if language == "en" else "مینی‌اپ در حال حاضر غیرفعال است."),
                main_menu(user.id),
            )
        return ConversationHandler.END
    if label in {ADMIN_HOME_BUTTON_FA, ADMIN_HOME_BUTTON_EN}:
        if not _is_any_admin(user.id):
            return ConversationHandler.END
        await reply(update, admin_home_text(user.id), admin_menu(user.id))
        return ConversationHandler.END
    admin_categories = {
        ADMIN_TRADING_BUTTON_FA: "trading",
        ADMIN_TRADING_BUTTON_EN: "trading",
        ADMIN_SALES_BUTTON_FA: "sales",
        ADMIN_SALES_BUTTON_EN: "sales",
        ADMIN_USERS_BUTTON_FA: "users",
        ADMIN_USERS_BUTTON_EN: "users",
        ADMIN_ANALYTICS_BUTTON_FA: "analytics",
        ADMIN_ANALYTICS_BUTTON_EN: "analytics",
        ADMIN_SYSTEM_BUTTON_FA: "system",
        ADMIN_SYSTEM_BUTTON_EN: "system",
    }
    if label in admin_categories and _is_any_admin(user.id):
        category = admin_categories[label]
        granted = _admin_granted_permissions(user.id)
        if not _admin_category_available(category, granted):
            await reply(update, "⛔️ دسترسی ندارید." if language != "en" else "⛔️ You do not have access.", admin_menu(user.id))
            return ConversationHandler.END
        await reply(update, admin_category_text(category, user.id), admin_category_menu(category, user.id))
        return ConversationHandler.END
    if label in {ADMIN_TICKETS_BUTTON_FA, ADMIN_TICKETS_BUTTON_EN} and _is_any_admin(user.id):
        return await _send_keyboard_shortcut_entry(
            update,
            text=("Open the admin ticket queue:" if language == "en" else "صف تیکت‌های ادمین را باز کنید:"),
            callback="a_tickets",
            button_label=("🎫 Open admin tickets" if language == "en" else "🎫 ورود به تیکت‌های ادمین"),
        )
    return ConversationHandler.END


async def ensure_quick_access_keyboard(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    *,
    force: bool = False,
) -> bool:
    """Silently remove a cached legacy Reply Keyboard.

    Telegram requires a message carrying ``ReplyKeyboardRemove`` to dismiss a
    keyboard left behind by an older deployment.  The migration message is an
    invisible marker and is deleted immediately, so starting SENTINEL no
    longer adds a separate command-menu notice to the chat.
    """
    user = update.effective_user
    chat = update.effective_chat
    if not user or not chat or str(getattr(chat, "type", "")) != "private":
        return False
    language = _language_for_user(user.id)
    state_token = f"commands-v1:{language}:{'admin' if _is_any_admin(user.id) else 'user'}"
    if not force and str(context.user_data.get(_COMMAND_MENU_STATE_KEY) or "") == state_token:
        return False
    try:
        marker = await context.bot.send_message(
            chat_id=chat.id,
            text="⁣",
            reply_markup=quick_access_keyboard(user.id),
            disable_notification=True,
        )
    except TelegramError:
        logger.exception("Could not remove legacy reply keyboard for user %s", user.id)
        return False
    try:
        await context.bot.delete_message(chat_id=chat.id, message_id=marker.message_id)
    except TelegramError:
        # Keyboard removal has already been delivered.  A failed cleanup can
        # leave only an invisible marker, never the old explanatory notice.
        logger.debug("Could not delete reply-keyboard migration marker for user %s", user.id, exc_info=True)
    context.user_data[_COMMAND_MENU_STATE_KEY] = state_token
    return True


async def command_menu_keyboard_guard(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Dismiss a cached legacy keyboard on the user's first private message."""
    await ensure_quick_access_keyboard(update, context)


async def quick_menu_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Open the canonical inline menu and end any active input conversation."""
    user = update.effective_user
    if user:
        language = _language_for_user(user.id)
        context.user_data[_COMMAND_MENU_STATE_KEY] = f"commands-v1:{language}:{'admin' if _is_any_admin(user.id) else 'user'}"
    await menu_command(update, context)
    return ConversationHandler.END


def _canonical_user_category(category: str) -> str:
    """Map old deep links to the current luxury navigation hierarchy."""
    value = str(category or "").strip().lower()
    return {
        "growth": "support",
        "more": "support",
        "market": "markets",
        "education": "learning",
    }.get(value, value or "support")


def _user_navigation_items(language: str = "fa") -> dict[str, dict[str, Any]]:
    """Every user-facing module, grouped into a predictable step-by-step path."""
    language = normalize_language(language)
    if language == "en":
        return {
            "trade": {
                "title": "Trading command center",
                "subtitle": "Signals, performance, watchlists, journal and personal risk intelligence",
                "icon": "🛰",
                "items": [
                    ("📡 Active & archived signals", "u_signal_portal"),
                    ("📊 My signal performance", "user_signal_stats"),
                    ("⭐ My watchlist", "user_watchlist"),
                    ("📔 My trading journal", "user_journal"),
                    ("🧭 Trading coach", "u_trading_coach"),
                ],
            },
            "markets": {
                "title": "Live market desk",
                "subtitle": "Iran market, forex, crypto, metals, energy, stocks and economic events",
                "icon": "💹",
                "items": [
                    ("💹 Live market prices", "u_price"),
                    ("🗓 Economic calendar", "u_calendar"),
                    ("📈 Verified signal performance", "u_public_performance"),
                ],
            },
            "tools": {
                "title": "Risk & practice lab",
                "subtitle": "Position sizing, paper trading, prop-account protection and practical tools",
                "icon": "🧮",
                "items": [
                    ("🧮 Professional risk calculator", "u_calc"),
                    ("🧭 Trading tools hub", "u_bot_tools"),
                    ("📝 Paper trading arena", "u_paper_arena"),
                    ("🛡 Prop guardian", "u_prop_guardian"),
                ],
            },
            "learning": {
                "title": "Sentinel academy",
                "subtitle": "Published education and operating rules",
                "icon": "🎓",
                "items": [
                    ("🎓 Education library", "u_edu"),
                    ("📜 Rules & terms", "learning_rules"),
                ],
            },
            "account": {
                "title": "My account",
                "subtitle": "One consolidated account dashboard",
                "icon": "👤",
                "items": [("👤 Open my account", "u_account")],
            },
            "club": {
                "title": "Club & rewards",
                "subtitle": "Points, rankings, rewards and referrals",
                "icon": "🏆",
                "items": [
                    ("🏅 Points & league", "u_score"),
                    ("🏆 Leaderboard", "u_leaderboard"),
                    ("🎁 Rewards store", "u_rewards"),
                    ("📦 My rewards", "u_my_rewards"),
                    ("🤝 Refer friends", "u_referral"),
                ],
            },
            "support": {
                "title": "Support & services",
                "subtitle": "Tickets, FAQs, internal search, language and direct help",
                "icon": "🎧",
                "items": [
                    ("🎫 Support tickets", "u_support"),
                    ("❓ Frequently asked questions", "u_faq"),
                    ("🔎 Search Sentinel", "u_search"),
                    ("🌐 Language", "language_menu"),
                ],
            },
        }
    return {
        "trade": {
            "title": "مرکز فرمان معامله‌گری",
            "subtitle": "سیگنال، عملکرد، واچ‌لیست، ژورنال و کنترل شخصی ریسک",
            "icon": "🛰",
            "items": [
                ("📡 سیگنال‌های فعال و آرشیو", "u_signal_portal"),
                ("📊 عملکرد سیگنال‌های من", "user_signal_stats"),
                ("⭐ واچ‌لیست من", "user_watchlist"),
                ("📔 ژورنال معاملاتی من", "user_journal"),
                ("🧭 مربی معاملاتی", "u_trading_coach"),
            ],
        },
        "markets": {
            "title": "میز بازار زنده",
            "subtitle": "بازار ایران، فارکس، کریپتو، فلزات، انرژی، سهام و خبرهای اقتصادی",
            "icon": "💹",
            "items": [
                ("💹 قیمت لحظه‌ای بازارها", "u_price"),
                ("🗓 تقویم و خبرهای اقتصادی", "u_calendar"),
                ("📈 عملکرد قابل راستی‌آزمایی", "u_public_performance"),
            ],
        },
        "tools": {
            "title": "آزمایشگاه ریسک و تمرین",
            "subtitle": "محاسبه حجم، تمرین معامله، محافظ حساب پراپ و ابزارهای کاربردی",
            "icon": "🧮",
            "items": [
                ("🧮 ماشین‌حساب حرفه‌ای ریسک", "u_calc"),
                ("🧭 مرکز ابزارهای معامله", "u_bot_tools"),
                ("📝 حساب و معامله آزمایشی", "u_paper_arena"),
                ("🛡 محافظ حساب پراپ", "u_prop_guardian"),
            ],
        },
        "learning": {
            "title": "آکادمی Sentinel",
            "subtitle": "آموزش‌های منتشرشده و قوانین استفاده",
            "icon": "🎓",
            "items": [
                ("🎓 کتابخانه آموزش", "u_edu"),
                ("📜 قوانین و شرایط استفاده", "learning_rules"),
            ],
        },
        "account": {
            "title": "حساب من",
            "subtitle": "داشبورد یکپارچه حساب بدون زیرمنوی تکراری",
            "icon": "👤",
            "items": [("👤 ورود به حساب من", "u_account")],
        },
        "club": {
            "title": "باشگاه و جوایز",
            "subtitle": "امتیاز، رتبه‌بندی، جایزه و معرفی دوستان",
            "icon": "🏆",
            "items": [
                ("🏅 امتیاز و لیگ", "u_score"),
                ("🏆 جدول برترین‌ها", "u_leaderboard"),
                ("🎁 فروشگاه جوایز", "u_rewards"),
                ("📦 جایزه‌های من", "u_my_rewards"),
                ("🤝 معرفی دوستان", "u_referral"),
            ],
        },
        "support": {
            "title": "پشتیبانی و خدمات",
            "subtitle": "تیکت‌ها، سوالات متداول، جست‌وجوی داخلی، زبان و راهنمای مستقیم",
            "icon": "🎧",
            "items": [
                ("🎫 پشتیبانی و تیکت‌ها", "u_support"),
                ("❓ سوالات متداول", "u_faq"),
                ("🔎 جست‌وجو در Sentinel", "u_search"),
                ("🌐 تغییر زبان", "language_menu"),
            ],
        },
    }


def _user_home_snapshot(user_id: int | str) -> dict[str, Any]:
    db = load_db()
    try:
        account = user_account_snapshot(db, user_id)
    except Exception:
        logger.exception("Could not build user home snapshot")
        account = {}
    try:
        stats = signal_portal_stats(db, user_id, vip=is_vip(db, user_id))
    except Exception:
        logger.exception("Could not build signal home snapshot")
        stats = {}
    return {"account": account, "signals": stats}


def user_home_text(user_id: int | str) -> str:
    snapshot = _user_home_snapshot(user_id)
    account = snapshot["account"]
    signals = snapshot["signals"]
    language = _language_for_user(user_id)
    name = _account_display_name(account) if account else ("Trader" if language == "en" else "معامله‌گر")
    vip_active = bool(account.get("vip_active"))
    vip_label = ("ACTIVE" if vip_active else "STANDARD") if language == "en" else ("فعال" if vip_active else "عادی")
    active_signals = int(signals.get("open", 0) or 0)
    points = int(account.get("points", 0) or 0)
    if language == "en":
        return (
            "🛡 <b>SENTINEL</b>  |  <b>PRIVATE COMMAND DECK</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>{esc(name)}</b>\n"
            f"💎 Access: <b>{vip_label}</b>\n"
            f"📡 Open signals: <b>{active_signals}</b>\n"
            f"🏅 Club points: <b>{points:,}</b>\n\n"
            "⌨️ <b>Quick navigation</b>\n"
            "Use Telegram's command button on the left side of the message field, or choose a button below.\n\n"
            "<i>Protect • Analyze • Execute</i>"
        )
    return (
        "🛡 <b>SENTINEL</b>  |  <b>عرشه فرمان خصوصی</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>{esc(name)}</b>\n"
        f"💎 دسترسی: <b>{vip_label}</b>\n"
        f"📡 سیگنال باز: <b>{active_signals}</b>\n"
        f"🏅 امتیاز باشگاه: <b>{points:,}</b>\n\n"
        "⌨️ <b>دسترسی سریع</b>\n"
        "از دکمه فرمان‌ها در سمت چپ کادر پیام یا دکمه‌های زیر استفاده کنید.\n\n"
        "<i>Protect • Analyze • Execute</i>"
    )


def _main_menu_activity_badges(db: dict[str, Any]) -> dict[str, str]:
    """Return compact live labels for education, missions and contests."""
    from datetime import UTC, datetime
    now = datetime.now(UTC)
    lessons = [row for row in db.get("lessons", []) if isinstance(row, dict) and str(row.get("status") or "") == "published"]
    missions = [row for row in db.get("missions", []) if isinstance(row, dict) and bool(row.get("active", True)) and str(row.get("status") or "active") not in {"archived", "closed"}]
    contests: list[dict[str, Any]] = []
    for key in ("chart_contest", "candle_contest", "news_direction_contest"):
        row = db.get(key)
        if isinstance(row, dict) and str(row.get("status") or "") in {"active", "awaiting_result"}:
            contests.append(row)
    current = db.get("current_contest")
    if isinstance(current, dict) and str(current.get("status") or "") in {"active", "awaiting_result"}:
        contests.append(current)
    remaining = ""
    active = [row for row in contests if str(row.get("status") or "") == "active"]
    if active:
        end_values = []
        for row in active:
            end = parse_dt(row.get("ends_at") or row.get("expires_at"))
            if end:
                end_values.append(end)
        if end_values:
            seconds = max(0, int((min(end_values) - now).total_seconds()))
            remaining = f" · {seconds // 3600}h" if seconds >= 3600 else f" · {max(1, seconds // 60)}m"
        else:
            remaining = ""
    return {
        "education": f" · {len(lessons)}" if lessons else "",
        "missions": f" · {len(missions)}" if missions else "",
        "contests": (" · شروع شده" + remaining) if active else (f" · {len(contests)}" if contests else ""),
    }


def main_menu(user_id: int | str) -> list[list[InlineKeyboardButton]]:
    """Owner-approved flat user menu with one canonical entry per feature."""
    db = load_db()
    language = _language_for_user(user_id)
    vip_active = is_vip(db, user_id)
    badges = _main_menu_activity_badges(db)

    if language == "en":
        vip_label = "💎 Manage subscription" if vip_active else "💎 Buy subscription"
        education_label = "🎓 Education"
        market_label = "📈 Market prices"
        calculator_label = "🧮 Calculator"
        contest_label = "🎯 Contests"
        mission_label = "🧭 Missions"
        account_label = "👤 My account"
        trading_label = "📡 Trading center"
        news_label = "📰 News & calendar"
        support_label = "🎧 Support"
        refresh_label = "🔄 Refresh"
        language_label = "🌐 Language"
    else:
        vip_label = "💎 مدیریت اشتراک" if vip_active else "💎 خرید اشتراک"
        education_label = "🎓 آموزش"
        market_label = "📈 قیمت بازار"
        calculator_label = "🧮 ماشین حساب"
        contest_label = "🎯 مسابقه"
        mission_label = "🧭 مأموریت"
        account_label = "👤 حساب من"
        trading_label = "📡 مرکز معاملاتی"
        news_label = "📰 اخبار و تقویم"
        support_label = "🎧 پشتیبانی"
        refresh_label = "🔄 تازه‌سازی"
        language_label = "🌐 زبان"

    education_label += badges["education"]
    contest_label += badges["contests"]
    mission_label += badges["missions"]

    # Priority is task-based; all former entries remain available.
    def button(fa, en, callback, style=None):
        return InlineKeyboardButton(en if language == "en" else fa, callback_data=callback, style=style)
    rows: list[list[InlineKeyboardButton]] = [
        [button("📡 سیگنال‌ها", "📡 Signals", "u_signal_portal", "primary"),
         InlineKeyboardButton(trading_label, callback_data="nav_user:trade", style="primary")],
        [button("📅 امروز من", "📅 My today", "u_today"),
         InlineKeyboardButton(calculator_label, callback_data="u_calc")],
        [InlineKeyboardButton(vip_label, callback_data="u_vip", style="success"),
         InlineKeyboardButton(account_label, callback_data="u_account")],
        [InlineKeyboardButton("🎁 Rewards" if language=="en" else "🎁 پاداش‌ها",callback_data="u_rewards"),
         InlineKeyboardButton("👥 My referral link" if language=="en" else "👥 لینک دعوت من",callback_data="u_referral")],
        [InlineKeyboardButton(education_label, callback_data="u_edu"),
         InlineKeyboardButton(mission_label, callback_data="u_missions")],
        [InlineKeyboardButton(contest_label, callback_data="u_contests"),
         button("🏆 رتبه‌بندی", "🏆 Leaderboard", "u_leaderboard")],
        [InlineKeyboardButton(market_label, callback_data="u_price"),
         InlineKeyboardButton(news_label, callback_data="u_calendar:today")],
        [button("🧰 تمام ابزارهای معامله", "🧰 All trading tools", "nav_user:tools"),
         button("🏅 باشگاه و امتیاز", "🏅 Club & points", "nav_user:club")],
        [button("⚙️ تنظیمات", "⚙️ Settings", "u_settings"),
         InlineKeyboardButton(support_label, callback_data="u_support")],
        [button("🔎 جست‌وجو و خدمات", "🔎 Search & services", "nav_user:support"),
         button("📜 قوانین", "📜 Rules", "learning_rules")],
        [InlineKeyboardButton(language_label, callback_data="language_menu")],
    ]

    if _has_any_admin_permission(user_id, PERMISSION_KPI_TRADER_VIEW, PERMISSION_KPI_TRADER_MANAGE):
        rows.append([
            InlineKeyboardButton(
                "🎯 KPI Trader workspace" if language == "en" else "🎯 فضای کاری KPI Trader",
                callback_data="kpi_trader_home",
            )
        ])
    if _is_any_admin(user_id):
        rows.append([
            InlineKeyboardButton(
                "🛠 Admin center" if language == "en" else "🛠 مرکز مدیریت",
                callback_data="admin_home",
            )
        ])

    rows.append([InlineKeyboardButton(refresh_label, callback_data="home")])
    return with_webapp(rows)


def user_category_menu(category: str, user_id: int | str | None = None) -> list[list[InlineKeyboardButton]]:
    language = _language_for_user(user_id) if user_id is not None else "fa"
    navigation = _user_navigation_items(language)
    canonical = _canonical_user_category(category)
    section = navigation.get(canonical) or navigation["support"]
    raw_items = list(section["items"])
    if user_id is None or not _is_any_admin(user_id):
        raw_items = _visible_user_items(load_db(), raw_items)
    items = [InlineKeyboardButton(label, callback_data=callback) for label, callback in raw_items]
    rows = [items[index:index + 2] for index in range(0, len(items), 2)]
    rows.append([
        InlineKeyboardButton(
            "↩️ Command deck" if language == "en" else "↩️ عرشه فرمان",
            callback_data="home",
        )
    ])
    return rows


def user_category_text(category: str, user_id: int | str) -> str:
    language = _language_for_user(user_id)
    navigation = _user_navigation_items(language)
    canonical = _canonical_user_category(category)
    section = navigation.get(canonical) or navigation["support"]
    db = load_db()
    snapshot = user_account_snapshot(db, user_id)
    if canonical == "trade":
        stats = signal_portal_stats(db, user_id, vip=is_vip(db, user_id))
        watch_count = len(watchlist_for_user(db, user_id))
        journal_count = int(journal_stats(db, user_id).get("total", 0) or 0)
        summary = (
            f"Open signals <b>{int(stats.get('open', 0) or 0)}</b>  •  Watchlist <b>{watch_count}</b>  •  Journal <b>{journal_count}</b>"
            if language == "en"
            else f"سیگنال باز <b>{int(stats.get('open', 0) or 0)}</b>  •  واچ‌لیست <b>{watch_count}</b>  •  ژورنال <b>{journal_count}</b>"
        )
    elif canonical == "account":
        vip_text = ("Active" if bool(snapshot.get("vip_active")) else "Inactive") if language == "en" else ("فعال" if bool(snapshot.get("vip_active")) else "غیرفعال")
        summary = (
            f"VIP <b>{vip_text}</b>  •  Points <b>{int(snapshot.get('points', 0) or 0):,}</b>"
            if language == "en"
            else f"VIP <b>{vip_text}</b>  •  امتیاز <b>{int(snapshot.get('points', 0) or 0):,}</b>"
        )
    elif canonical == "club":
        summary = (
            f"Club points <b>{int(snapshot.get('points', 0) or 0):,}</b>"
            if language == "en"
            else f"امتیاز باشگاه <b>{int(snapshot.get('points', 0) or 0):,}</b>"
        )
    elif canonical == "markets":
        summary = "Iran and global markets in one live desk." if language == "en" else "بازار ایران و بازارهای جهانی در یک مسیر زنده."
    elif canonical == "tools":
        summary = "Calculate first, then execute with controlled risk." if language == "en" else "اول محاسبه کن، بعد با ریسک کنترل‌شده وارد معامله شو."
    elif canonical == "learning":
        summary = "Learn the workflow before using advanced tools." if language == "en" else "قبل از ابزارهای پیشرفته، مسیر استفاده را یاد بگیر."
    else:
        summary = "Create, follow and reply to support requests without slash commands." if language == "en" else "تیکت را بدون فرمان اسلشی ثبت، پیگیری و پاسخ‌ها را مشاهده کن."
    return (
        f"{section.get('icon', '✦')} <b>{section['title']}</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"{section['subtitle']}\n\n"
        f"{summary}\n\n"
        f"{tr('choose_option', language)}"
    )


def _admin_menu_items() -> list[tuple[str, str, str]]:
    return [
        ("🛰 مرکز عملیات", "a_mission_control", PERMISSION_MISSION_CONTROL),
        ("🧠 مرکز فرماندهی Gemini", "a_ai_command_center", "ai_command_center"),
        ("🔎 جست‌وجوی سراسری", "a_admin_search", "ai_command_center"),
        ("📡 ارسال سیگنال", "a_signal", PERMISSION_SIGNAL_SCHEDULE),
        ("📥 پرداخت‌های معلق", "a_pending", PERMISSION_PAYMENT_DASHBOARD_VIEW),
        ("🧾 تطبیق پرداخت", "a_reconciliation", PERMISSION_PAYMENT_RECONCILIATION),
        ("💳 تنظیمات مالی VIP", "a_vip_settings", PERMISSION_VIP_SETTINGS),
        ("🧩 مدیریت پلن‌های VIP", "a_vip_plans", PERMISSION_VIP_PLAN_VIEW),
        ("🎟 مدیریت تخفیف", "a_disc", PERMISSION_DISCOUNTS),
        ("📚 مدیریت آموزش", "a_edu", PERMISSION_EDUCATION_VIEW),
        ("🎯 مسابقه‌ها", "a_contest", PERMISSION_CONTEST_VIEW),
        ("✅ مأموریت‌ها", "a_missions", PERMISSION_MISSION_VIEW),
        ("👑 تمدید VIP", "a_vip_ext", PERMISSION_VIP_EXTENSION),
        ("🎁 درخواست جوایز", "a_reward_requests", PERMISSION_REWARD_REQUESTS),
        ("📊 داشبورد", "a_dashboard", PERMISSION_DASHBOARD),
        ("🔌 سلامت منابع قیمت", "a_provider_health", PERMISSION_INTEGRATION_HEALTH_VIEW),
        ("📜 لاگ ادمین", "a_logs", PERMISSION_AUDIT_LOGS),
        ("🧯 خطاهای Runtime", "a_runtime_logs", PERMISSION_RUNTIME_LOGS_VIEW),
        ("🏆 لیدربورد", "a_leaderboard", PERMISSION_LEADERBOARD),
        ("🎫 مدیریت تیکت‌ها", "a_tickets", PERMISSION_TICKETS_VIEW),
        ("❓ مدیریت سوالات", "a_faq", PERMISSION_FAQ),
        ("📊 آمار مسابقه‌ها", "a_contest_stats", PERMISSION_CONTEST_STATS),
        ("📈 نتایج سیگنال", "a_signal_results", PERMISSION_SIGNALS_VIEW),
        ("🎨 قالب‌های سیگنال", "sig_tpl_home", PERMISSION_SIGNAL_TEMPLATES),
        ("🛡 تابلوهای ریسک", "sig_exposure", PERMISSION_RISK_BOARDS),
        ("👥 داشبورد تحلیلگران", "sig_analysts", PERMISSION_ANALYST_DASHBOARD),
        ("🎯 مدیریت KPI Trader", "a_kpi_trader", PERMISSION_KPI_TRADER_MANAGE),
        ("✏️ ویرایش سیگنال", "a_signal_edit", PERMISSION_SIGNAL_EDIT),
        ("🗑 حذف سیگنال", "a_signal_delete", PERMISSION_SIGNAL_DELETE),
        ("📺 مدیریت کانال", "a_channel_center", PERMISSION_SIGNAL_BOARD_MANAGE),
        ("📰 اخبار و اقتصاد", "a_market_intel", PERMISSION_MARKET_INTELLIGENCE),
        ("👥 مدیریت کاربران", "a_users", PERMISSION_USERS_VIEW),
        ("📣 ارسال همگانی", "a_broadcast", PERMISSION_BROADCAST),
        ("📢 مرکز اعلان کانال", "a_announcement", PERMISSION_ANNOUNCEMENT_PREVIEW),
        ("🎁 جوایز کاربران", "a_user_rewards", PERMISSION_USER_REWARDS),
        ("⚙️ امتیاز جوایز", "a_reward_points", PERMISSION_REWARD_POINTS),
        ("🗂 CRM کاربران", "a_crm", PERMISSION_CRM_VIEW),
        ("📔 ژورنال و واچ‌لیست", "a_portfolio", PERMISSION_PORTFOLIO),
        ("🧭 کنترل کامل ربات", "a_control_center", PERMISSION_SYSTEM_CONTROL),
        ("🎛 مدیریت امکانات", "a_features", PERMISSION_FEATURE_TOGGLE_MANAGE),
        ("📜 قوانین استفاده", "a_rules", PERMISSION_RULES),
        ("📱 روشن/خاموش مینی‌اپ", "a_miniapp_runtime", PERMISSION_MAINTENANCE_MODE_MANAGE),
        ("🛟 حالت اجرا و اضطرار", "a_runtime_safety", PERMISSION_RUNTIME_SAFETY),
        ("🚨 مرکز رخدادها", "a_incidents", PERMISSION_INCIDENTS),
        ("🧩 ماتریس قابلیت‌ها", "a_capabilities", PERMISSION_CAPABILITIES),
        ("🚀 توسعه پلتفرم بدون هزینه", "a_platform_expansion", PERMISSION_SYSTEM_CONTROL),
        ("🧠 حاکمیت عملیات", "a_ops_governance", PERMISSION_OPERATIONS_GOVERNANCE),
        ("🔎 مرکز شفافیت", "a_trust_center", PERMISSION_TRUST_CENTER),
        ("🎯 نگهداشت مشتری", "a_retention", PERMISSION_RETENTION),
        ("🚀 استودیو کمپین", "a_campaigns", PERMISSION_CAMPAIGNS),
        ("🔗 لینک‌های جذب کانال", "a_channel_attribution", PERMISSION_CHANNEL_ATTRIBUTION),
        ("🤖 اتوماسیون مدیریتی", "a_automations", PERMISSION_AUTOMATIONS),
        ("♻️ تمدید هوشمند", "a_renewals", PERMISSION_RENEWALS),
        ("🕒 شیفت ادمین‌ها", "a_shifts", PERMISSION_ADMIN_SHIFTS),
        ("💾 بکاپ و بازیابی", "a_backups", PERMISSION_BACKUP_CREATE),
        ("🎓 پرداخت آموزش", "a_edu_orders", PERMISSION_PAID_EDUCATION),
        ("👮 مدیریت ادمین‌ها", "a_admins", PERMISSION_ADMIN_MANAGEMENT),
        ("📦 خروجی اطلاعات", "a_export_csv", PERMISSION_CRM_EXPORT),
    ]


def _admin_navigation_categories() -> dict[str, dict[str, Any]]:
    """Unified taxonomy: every legacy module remains reachable under one clear domain."""
    return {
        "command": {
            "title": "🛰 فرماندهی و هوش مصنوعی",
            "subtitle": "مرکز اقدام، Gemini اجرایی، فرمان صوتی، جست‌وجو و تأییدها",
            "callbacks": ["a_mission_control", "a_ai_command_center", "a_admin_search", "a_ops_governance", "a_incidents"],
        },
        "trading": {
            "title": "📡 سیگنال و عملیات معاملاتی",
            "subtitle": "ساخت، بررسی، انتشار، نتیجه، قالب و مدیریت چرخه سیگنال",
            "callbacks": ["a_signal", "sig_tpl_home", "a_signal_results", "sig_exposure", "sig_sessions", "sig_analysts", "a_kpi_trader", "a_signal_edit", "a_signal_delete", "a_channel_center"],
        },
        "market": {
            "title": "📈 بازار، ریسک و حساب‌ها",
            "subtitle": "اخبار، منابع قیمت، ریسک، ژورنال، واچ‌لیست و اتصال‌های معاملاتی",
            "callbacks": ["a_market_intel", "a_provider_health", "a_portfolio", "sig_exposure", "a_platform_expansion"],
        },
        "users": {
            "title": "👥 کاربران، CRM و پشتیبانی",
            "subtitle": "پرونده کاربر، رفتار، تیکت، سؤال، پیام مستقیم و قوانین",
            "callbacks": ["a_users", "a_crm", "a_tickets", "a_faq", "a_rules", "a_retention"],
        },
        "sales": {
            "title": "💳 VIP، فروش و پرداخت",
            "subtitle": "رسید، تطبیق، پلن، تمدید، تخفیف، درآمد و سفارش",
            "callbacks": ["a_pending", "a_reconciliation", "a_vip_settings", "a_vip_plans", "a_disc", "a_vip_ext", "a_renewals", "a_retention", "a_edu_orders"],
        },
        "content": {
            "title": "📺 کانال، محتوا و تبلیغات",
            "subtitle": "کانال، اعلان، ارسال همگانی، تبلیغ Gemini و لینک جذب",
            "callbacks": ["a_channel_center", "a_announcement", "a_broadcast", "a_campaigns", "a_channel_attribution", "a_market_intel"],
        },
        "education": {
            "title": "📚 آموزش و محتوای کاربر",
            "subtitle": "دوره، درس، رسانه، نمونه رایگان، محتوای پولی و سفارش",
            "callbacks": ["a_edu", "a_edu_orders", "a_faq"],
        },
        "engagement": {
            "title": "🎯 مسابقه، مأموریت و وفاداری",
            "subtitle": "مسابقه، مأموریت، امتیاز، جایزه، لیدربورد و بازگشت",
            "callbacks": ["a_contest", "a_missions", "a_reward_requests", "a_user_rewards", "a_reward_points", "a_leaderboard", "a_contest_stats", "a_retention"],
        },
        "automation": {
            "title": "🤖 اتوماسیون و زمان‌بندی",
            "subtitle": "قانون‌ها، Trigger، Action، کمپین، شیفت، Retry و تقویم",
            "callbacks": ["a_automations", "a_campaigns", "a_renewals", "a_shifts", "a_announcement", "a_broadcast"],
        },
        "analytics": {
            "title": "📊 گزارش، تحلیل و داده",
            "subtitle": "داشبوردها، عملکرد، شفافیت، لاگ و خروجی داده",
            "callbacks": ["a_dashboard", "a_mission_control", "a_trust_center", "a_logs", "a_runtime_logs", "a_export_csv", "a_signal_results", "a_contest_stats", "sig_analysts"],
        },
        "system": {
            "title": "⚙️ ادمین، امنیت و سیستم",
            "subtitle": "کنترل ربات، مجوز، سلامت، بکاپ، مینی‌اپ و حالت اضطراری",
            "callbacks": ["a_control_center", "a_features", "a_miniapp_runtime", "a_runtime_safety", "a_incidents", "a_capabilities", "a_platform_expansion", "a_ops_governance", "a_trust_center", "a_backups", "a_admins", "a_provider_health", "a_logs", "a_runtime_logs"],
        },
    }

def _admin_granted_permissions(user_id: int | str) -> set[str]:
    if is_admin(user_id):
        return set(ALL_PERMISSIONS)
    row = get_delegated_admin(load_db(), user_id) or {}
    granted = set(row.get("permissions", [])) if row.get("active", True) else set()
    # Preserve legacy umbrella roles while allowing newly delegated granular
    # read permissions to surface the corresponding Telegram menus.
    if PERMISSION_PAYMENTS in granted:
        granted.add(PERMISSION_PAYMENT_DASHBOARD_VIEW)
    if PERMISSION_VIP_SETTINGS in granted:
        granted.add(PERMISSION_VIP_PLAN_VIEW)
    return granted


def _admin_items_by_callback() -> dict[str, tuple[str, str, str]]:
    return {callback: (label, callback, permission) for label, callback, permission in _admin_menu_items()}


def _admin_category_available(category: str, granted: set[str]) -> bool:
    section = _admin_navigation_categories().get(category, {})
    item_map = _admin_items_by_callback()
    return any(item_map[callback][2] in granted for callback in section.get("callbacks", []) if callback in item_map)


def _admin_counts() -> dict[str, int]:
    db = load_db()
    current_cycle = int(current_signal_cycle(db).get("current_id", 1) or 1)
    active_signals = sum(
        1
        for row in db.get("signals", [])
        if isinstance(row, dict)
        and int(row.get("cycle_id", current_cycle) or current_cycle) == current_cycle
        and str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES
    )
    pending_payments = sum(1 for row in db.get("vip_orders", []) if isinstance(row, dict) and row.get("status") in {"pending", "approving"})
    pending_education = sum(
        1 for row in db.get("education_orders", []) if isinstance(row, dict) and row.get("status") in {"pending", "approving"}
    )
    open_tickets = sum(1 for row in db.get("tickets", []) if isinstance(row, dict) and row.get("status") == "open")
    pending_rewards = sum(
        1 for row in db.get("reward_requests", []) if isinstance(row, dict) and row.get("status") in {"pending", "requested"}
    )
    active_campaigns = sum(
        1
        for row in db.get("marketing_campaigns", {}).values()
        if isinstance(row, dict) and row.get("status") in {"active", "paused"}
    )
    scheduled = sum(1 for row in db.get("scheduled_signals", []) if isinstance(row, dict) and row.get("status") in {"pending", "retry"})
    return {
        "trading": active_signals + scheduled,
        "content": 0,
        "sales": pending_payments + pending_education + active_campaigns,
        "users": open_tickets + pending_rewards,
        "analytics": 0,
        "system": 0,
        "active_signals": active_signals,
        "scheduled": scheduled,
        "pending_payments": pending_payments,
        "open_tickets": open_tickets,
        "active_campaigns": active_campaigns,
        "users_total": len(db.get("users", {})),
    }


def admin_home_text(user_id: int | str) -> str:
    counts = _admin_counts()
    role = "مدیر اصلی" if is_admin(user_id) else "مدیر محدود"
    mode = admin_ui_mode(load_db(), user_id)
    mode_label = "ساده" if mode == "basic" else "حرفه‌ای"
    return (
        "🛠 <b>SENTINEL</b>  |  <b>مرکز مدیریت</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👑 نقش: <b>{role}</b>\n"
        f"🧭 نمای پنل: <b>{mode_label}</b>\n\n"
        "📌 <b>خلاصه زنده</b>\n"
        f"📡 سیگنال باز: <b>{counts['active_signals']}</b>  •  🕒 زمان‌بندی: <b>{counts['scheduled']}</b>\n"
        f"💳 پرداخت معلق: <b>{counts['pending_payments']}</b>  •  🎫 تیکت باز: <b>{counts['open_tickets']}</b>\n"
        f"🚀 کمپین فعال/متوقف: <b>{counts['active_campaigns']}</b>\n"
        f"👥 کاربران: <b>{counts['users_total']:,}</b>\n\n"
        "⌨️ ماژول‌ها را از کیبورد مدیریت انتخاب کنید.\n"
        "روشن/فعال: سبز  •  خاموش/غیرفعال: قرمز  •  عملیات اجرایی: قرمز"
    )


def admin_menu(user_id: int | str) -> list[list[InlineKeyboardButton]]:
    """Categorized admin menu with permissions preserved and state colors visible."""
    granted = _admin_granted_permissions(user_id)
    counts = _admin_counts()
    mode = admin_ui_mode(load_db(), user_id)
    rows: list[list[InlineKeyboardButton]] = []
    if _is_owner_admin(user_id):
        rows.append([
            InlineKeyboardButton(
                "🧠 فرمان مستقیم Gemini",
                callback_data="a_ai_chat_start",
                style="primary",
            )
        ])
        rows.append([InlineKeyboardButton("☀️ ادمین امروز", callback_data="a_admin_today", style="primary")])
        rows.append([
            InlineKeyboardButton(
                "👑 تسک و امتیاز ادمین‌ها",
                callback_data="owner_kpi_center",
                style="primary",
            )
        ])
    if PERMISSION_MAINTENANCE_MODE_MANAGE in granted or PERMISSION_RUNTIME_SAFETY in granted:
        from modules.miniapp_runtime import miniapp_enabled
        mini_enabled = miniapp_enabled(load_db())
        rows.append([
            state_button(
                "مینی‌اپ کاربران",
                mini_enabled,
                callback_data="a_miniapp_runtime",
                enabled_label="روشن",
                disabled_label="خاموش",
            )
        ])
    quick: list[InlineKeyboardButton] = [InlineKeyboardButton("➕ ساخت آسان", callback_data="a_create")]
    if PERMISSION_MISSION_CONTROL in granted:
        quick.append(InlineKeyboardButton("🛰 عملیات اجرایی", callback_data="a_mission_control", style="danger"))
    if PERMISSION_SIGNAL_SCHEDULE in granted or PERMISSION_SIGNALS in granted:
        quick.append(InlineKeyboardButton("📡 ارسال سیگنال", callback_data="a_signal", style="primary"))
    if quick:
        rows.append(quick)

    category_buttons: list[InlineKeyboardButton] = []
    for key, section in _admin_navigation_categories().items():
        if not _admin_category_available(key, granted):
            continue
        count = int(counts.get(key, 0) or 0)
        suffix = f" · {count}" if count else ""
        category_buttons.append(
            InlineKeyboardButton(
                f"{section['title']}{suffix}",
                callback_data=f"admin_cat:{key}",
                style="primary",
            )
        )
    rows.extend(category_buttons[index:index + 2] for index in range(0, len(category_buttons), 2))
    rows.append([InlineKeyboardButton("📥 کارهای منتظر اقدام", callback_data="work_queue"), InlineKeyboardButton("⚡ دسترسی سریع", callback_data="palette_start")])
    if PERMISSION_REWARD_POINTS in granted or _is_owner_admin(user_id):
        rows.append([InlineKeyboardButton("🎯 مراحل معرفی", callback_data="a_milestones")])
    if PERMISSION_TWO_STEP_APPROVALS in granted or _is_owner_admin(user_id):
        rows.append([InlineKeyboardButton("🔐 تأییدهای دومرحله‌ای", callback_data="a_approvals")])
    rows.append([
        InlineKeyboardButton(
            "🧩 نمایش حرفه‌ای" if mode == "basic" else "🧭 نمایش ساده",
            callback_data=f"admin_ui_mode:{'advanced' if mode == 'basic' else 'basic'}",
        )
    ])
    rows.append([
        InlineKeyboardButton("🔄 تازه‌سازی", callback_data="admin_home", style="primary"),
        InlineKeyboardButton("🏠 منوی کاربر", callback_data="home"),
    ])
    return rows


def admin_category_menu(category: str, user_id: int | str) -> list[list[InlineKeyboardButton]]:
    granted = _admin_granted_permissions(user_id)
    mode = admin_ui_mode(load_db(), user_id)
    section = _admin_navigation_categories().get(category)
    if not section:
        return [[InlineKeyboardButton("↩️ مرکز مدیریت", callback_data="admin_home")]]
    item_map = _admin_items_by_callback()
    buttons: list[InlineKeyboardButton] = []
    for callback in section["callbacks"]:
        if not callback_visible_in_mode(category, callback, mode):
            continue
        item = item_map.get(callback)
        if not item or item[2] not in granted:
            continue
        buttons.append(InlineKeyboardButton(item[0], callback_data=item[1]))
    if category == "trading" and (PERMISSION_SIGNAL_BOARD_MANAGE in granted or PERMISSION_SIGNALS in granted):
        buttons.append(InlineKeyboardButton("🗂 مدیریت دوره‌های سیگنال", callback_data="a_signal_cycle"))
    rows = [buttons[index : index + 2] for index in range(0, len(buttons), 2)]
    rows.append(
        [
            InlineKeyboardButton("🔄 تازه‌سازی", callback_data=f"admin_cat:{category}"),
            InlineKeyboardButton("↩️ مرکز مدیریت", callback_data="admin_home"),
        ]
    )
    return rows


def admin_category_text(category: str, user_id: int | str | None = None) -> str:
    section = _admin_navigation_categories().get(category)
    if not section:
        return "🛠 <b>مرکز مدیریت</b>"
    counts = _admin_counts()
    extra = ""
    if category == "trading":
        extra = f"\n\n📡 باز: <b>{counts['active_signals']}</b>  •  زمان‌بندی: <b>{counts['scheduled']}</b>"
    elif category == "sales":
        extra = f"\n\n💳 پرداخت معلق: <b>{counts['pending_payments']}</b>"
    elif category == "users":
        extra = f"\n\n🎫 تیکت باز: <b>{counts['open_tickets']}</b>"
    elif category == "system":
        summary = control_summary(load_db())
        extra = f"\n\n🧭 ماژول فعال: <b>{summary['enabled_modules']}/{summary['modules']}</b>"
    mode = admin_ui_mode(load_db(), user_id) if user_id is not None else "basic"
    mode_text = (
        "حالت ساده فعال است؛ ابزارهای کم‌کاربرد پنهان‌اند."
        if mode == "basic"
        else "حالت حرفه‌ای فعال است؛ همه ابزارهای مجاز نمایش داده می‌شوند."
    )
    return (
        f"🛠 مرکز مدیریت  ›  <b>{section['title']}</b>\n\n"
        f"{section['subtitle']}{extra}\n\n"
        f"<i>{mode_text}</i>\n\n"
        "عملیات موردنظر را انتخاب کنید:"
    )


def _control_value_text(value: Any) -> str:
    if isinstance(value, bool):
        return "روشن ✅" if value else "خاموش ⛔️"
    if isinstance(value, float):
        return f"{value:g}"
    return str(value)


def _control_center_rows(
    db: dict[str, Any], user_id: int | str | None = None
) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = []
    rows.append([InlineKeyboardButton("🩺 System Center", callback_data="a_system_center", style="primary")])
    mode = admin_ui_mode(db, user_id) if user_id is not None else "basic"
    owner = user_id is not None and _is_owner_admin(user_id)
    if mode == "basic":
        rows.extend(
            [
                [
                    InlineKeyboardButton("📊 داشبورد", callback_data="a_dashboard"),
                    InlineKeyboardButton("🩺 عیب‌یابی", callback_data="ecc_diag"),
                ],
                [
                    InlineKeyboardButton("🚨 رخدادها", callback_data="a_incidents"),
                    InlineKeyboardButton("🧩 قابلیت‌ها", callback_data="a_capabilities"),
                ],
            ]
        )
        if owner:
            rows.extend(
                [
                    [
                        InlineKeyboardButton("🗓 عملیات تیم", callback_data="owner_team_calendar"),
                        InlineKeyboardButton("🏆 عملکرد تیم", callback_data="owner_team_performance"),
                    ],
                    [
                        InlineKeyboardButton("💎 رشد اشتراک", callback_data="owner_subscription_growth"),
                        InlineKeyboardButton("🔔 اعلان هوشمند", callback_data="owner_notification_intelligence"),
                    ],
                    [
                        InlineKeyboardButton(
                            "👑 تسک و امتیاز ادمین‌ها",
                            callback_data="owner_kpi_center",
                            style="primary",
                        )
                    ],
                ]
            )
        rows.append(
            [
                InlineKeyboardButton(
                    "⚙️ نمایش حرفه‌ای همه تنظیمات",
                    callback_data="admin_ui_mode:advanced",
                )
            ]
        )
        rows.append([InlineKeyboardButton("↩️ مرکز مدیریت", callback_data="admin_home")])
        return rows
    buttons: list[InlineKeyboardButton] = []
    for key, (title, _) in CONTROL_CATEGORIES.items():
        modules = control_category_modules(key)
        enabled = sum(1 for item in modules if is_module_enabled(db, item.key))
        total = len(modules)
        if total and enabled == total:
            style, icon = "success", "🟢"
        elif enabled == 0:
            style, icon = "danger", "🔴"
        else:
            style, icon = "primary", "🔵"
        buttons.append(
            InlineKeyboardButton(
                f"{icon} {title} ({enabled}/{total})",
                callback_data=f"ecc_cat:{key}",
                style=style,
            )
        )
    rows.extend(buttons[index : index + 2] for index in range(0, len(buttons), 2))
    rows.extend(
        [
            [
                InlineKeyboardButton("✅ فعال‌سازی کامل", callback_data="ecc_preset:full"),
                InlineKeyboardButton("🛡 حالت امن", callback_data="ecc_preset:safe"),
            ],
            [
                InlineKeyboardButton("♻️ تنظیمات پیش‌فرض", callback_data="ecc_preset:default"),
                InlineKeyboardButton("🩺 عیب‌یابی زنده", callback_data="ecc_diag"),
            ],
            [
                InlineKeyboardButton("🧹 نگهداری سیستم", callback_data="ecc_maintenance"),
                InlineKeyboardButton("📦 خروجی تنظیمات", callback_data="ecc_export"),
            ],
            [
                InlineKeyboardButton("🚨 رخدادها", callback_data="a_incidents"),
                InlineKeyboardButton("🧩 وضعیت قابلیت‌ها", callback_data="a_capabilities"),
            ],
        ]
    )
    if owner:
        rows.append(
            [
                InlineKeyboardButton(
                    "👑 تسک، دسترسی و امتیاز ادمین‌ها",
                    callback_data="owner_kpi_center",
                    style="primary",
                )
            ]
        )
        rows.append(
            [
                InlineKeyboardButton("🗓 عملیات تیم", callback_data="owner_team_calendar"),
                InlineKeyboardButton("🏆 عملکرد تیم", callback_data="owner_team_performance"),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton("💎 رشد اشتراک", callback_data="owner_subscription_growth"),
                InlineKeyboardButton("🔔 اعلان هوشمند", callback_data="owner_notification_intelligence"),
            ]
        )
    rows.append(
        [InlineKeyboardButton("✨ نمایش ساده", callback_data="admin_ui_mode:basic")]
    )
    rows.append([InlineKeyboardButton("↩️ مرکز مدیریت", callback_data="admin_home")])
    return rows


async def a_control_center(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    summary = control_summary(db)
    root = ensure_control_center(db)
    mode = admin_ui_mode(db, query.from_user.id)
    recent_changes = [
        row for row in db.get("admin_logs", []) if isinstance(row, dict)
    ][-3:]
    recent_text = "\n".join(
        f"• {esc(row.get('action') or row.get('event') or 'تغییر')} · {display_dt(row.get('created_at'))}"
        for row in reversed(recent_changes)
    ) or "• هنوز تغییری ثبت نشده است"
    text = (
        "🧭 <b>مرکز کنترل جامع SENTINEL</b>\n\n"
        f"نمای فعال: <b>{'ساده' if mode == 'basic' else 'حرفه‌ای'}</b>\n"
        "در نمای ساده ابزارهای روزمره و در نمای حرفه‌ای همه تنظیمات نمایش داده می‌شوند.\n\n"
        f"ماژول‌ها: <b>{summary['modules']}</b>\n"
        f"فعال: <b>{summary['enabled_modules']}</b> | غیرفعال: <b>{summary['disabled_modules']}</b>\n"
        f"کنترل‌های روشن/خاموش: <b>{summary['active_controls']}/{summary['boolean_controls']}</b>\n"
        f"آخرین تغییر: <code>{esc(root.get('last_updated_at') or '-')}</code>\n\n"
        f"<b>سه تغییر اخیر</b>\n{recent_text}"
    )
    await edit(query, text, _control_center_rows(db, query.from_user.id))


async def control_category_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    category = str(query.data or "").split(":", 1)[1]
    if category not in CONTROL_CATEGORIES:
        await query.answer("دسته پیدا نشد", show_alert=True)
        return
    db = await async_snapshot()
    title, subtitle = CONTROL_CATEGORIES[category]
    rows: list[list[InlineKeyboardButton]] = []
    lines = [f"🧭 مرکز کنترل  ›  <b>{title}</b>", "", subtitle, ""]
    for module in control_category_modules(category):
        enabled = is_module_enabled(db, module.key)
        icon = "✅" if enabled else "⛔️"
        lines.append(f"{icon} <b>{module.label}</b> — {esc(module.description)}")
        rows.append([
            state_button(
                module.label,
                enabled,
                callback_data=f"ecc_mod:{module.key}",
                enabled_label="فعال",
                disabled_label="غیرفعال",
            )
        ])
    rows.append([InlineKeyboardButton("↩️ مرکز کنترل", callback_data="a_control_center")])
    await edit(query, "\n".join(lines), rows)


def _control_module_rows(
    module_key: str,
    db: dict[str, Any],
    *,
    show_planned: bool = False,
) -> list[list[InlineKeyboardButton]]:
    module = CONTROL_MODULES[module_key]
    state = control_module_state(db, module_key)
    rows: list[list[InlineKeyboardButton]] = []
    status_icons = {"connected": "🟢", "experimental": "🟡", "configuration_required": "🟠", "planned": "⚪️"}
    for field in module.fields:
        value = state.get(field.key, field.default)
        status = capability_status(module_key, field.key)
        if status == "planned" and not show_planned:
            continue
        badge = status_icons.get(status, "⚪️")
        if field.kind == "bool":
            rows.append([
                state_button(
                    f"{badge} {field.label}",
                    bool(value),
                    callback_data=f"ecc_bool:{module_key}:{field.key}",
                )
            ])
        else:
            rows.append(
                [
                    InlineKeyboardButton(
                        f"{badge} ✏️ {field.label}: {_control_value_text(value)[:20]}", callback_data=f"ecc_edit:{module_key}:{field.key}"
                    )
                ]
            )
    if module_key == "league":
        rows.append(
            [
                InlineKeyboardButton("▶️ شروع فصل", callback_data="ecc_league:start"),
                InlineKeyboardButton("⏹ پایان فصل", callback_data="ecc_league:close"),
            ]
        )
    operation = CONTROL_OPERATION_LINKS.get(module_key)
    if operation:
        rows.append([InlineKeyboardButton(operation[0], callback_data=operation[1])])
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    "🧩 حالت ساده" if show_planned else "🧩 نمایش تنظیمات در حال توسعه",
                    callback_data=f"ecc_mode:{module_key}:{'basic' if show_planned else 'advanced'}",
                )
            ],
            [InlineKeyboardButton("♻️ بازنشانی این ماژول", callback_data=f"ecc_reset:{module_key}")],
            [InlineKeyboardButton("↩️ بازگشت دسته", callback_data=f"ecc_cat:{module.category}")],
        ]
    )
    return rows


def _control_module_text(
    module_key: str,
    db: dict[str, Any],
    *,
    show_planned: bool = False,
) -> str:
    module = CONTROL_MODULES[module_key]
    state = control_module_state(db, module_key)
    lines = [f"🧭 <b>{module.label}</b>", "", esc(module.description), ""]
    for field in module.fields:
        value = state.get(field.key, field.default)
        status = capability_status(module_key, field.key)
        if status == "planned" and not show_planned:
            continue
        status_label = CAPABILITY_LABELS.get(status, status)
        lines.append(f"• {esc(field.label)}: <b>{esc(_control_value_text(value))}</b> <i>({esc(status_label)})</i>")
    hidden_planned = sum(
        1 for field in module.fields if capability_status(module_key, field.key) == "planned"
    )
    if hidden_planned and not show_planned:
        lines.extend(
            [
                "",
                f"🧩 <i>{hidden_planned} تنظیم در حال توسعه برای جلوگیری از شلوغی مخفی شده است.</i>",
            ]
        )
    if module_key == "league":
        seasons = db.get("league_seasons", [])
        active = next((row for row in reversed(seasons) if row.get("status") == "active"), None)
        lines.extend(["", f"فصل فعال: <b>{esc(active.get('title')) if active else 'ندارد'}</b>"])
        if active:
            lines.append(f"پایان فصل: <code>{esc(active.get('ends_at'))}</code>")
    lines.extend(["", "برای تغییر، یکی از گزینه‌ها را انتخاب کنید."])
    return "\n".join(lines)[:3900]


async def control_module_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    module_key = str(query.data or "").split(":", 1)[1]
    if module_key not in CONTROL_MODULES:
        await query.answer("ماژول پیدا نشد", show_alert=True)
        return
    db = await async_snapshot()
    advanced_modules = set(context.user_data.get("control_advanced_modules", []))
    advanced_modules.discard(module_key)
    context.user_data["control_advanced_modules"] = sorted(advanced_modules)
    await edit(
        query,
        _control_module_text(module_key, db),
        _control_module_rows(module_key, db),
    )


async def control_module_mode_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    _, module_key, mode = str(query.data or "").split(":", 2)
    if module_key not in CONTROL_MODULES or mode not in {"basic", "advanced"}:
        await query.answer("حالت نمایش نامعتبر است.", show_alert=True)
        return
    advanced = set(context.user_data.get("control_advanced_modules", []))
    if mode == "advanced":
        advanced.add(module_key)
    else:
        advanced.discard(module_key)
    context.user_data["control_advanced_modules"] = sorted(advanced)
    await query.answer("حالت حرفه‌ای" if mode == "advanced" else "حالت ساده")
    db = await async_snapshot()
    await edit(
        query,
        _control_module_text(module_key, db, show_planned=mode == "advanced"),
        _control_module_rows(module_key, db, show_planned=mode == "advanced"),
    )


async def control_boolean_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    _, module_key, field_key = str(query.data or "").split(":", 2)
    if module_key == "signals" and field_key == "owner_approval" and not _is_owner_admin(query.from_user.id):
        await query.answer("تأیید مالک فقط توسط مالک اصلی قابل تغییر است.", show_alert=True)
        return
    if (
        field_key == "enabled"
        and module_key in USER_FEATURE_MODULE_KEYS
        and not _has_admin_permission(query.from_user.id, PERMISSION_FEATURE_MANAGEMENT)
    ):
        await query.answer("برای تغییر وضعیت امکانات، مجوز «مدیریت امکانات» لازم است.", show_alert=True)
        return
    status = capability_status(module_key, field_key)
    if status == "planned":
        await query.answer("این قابلیت هنوز عملیاتی نشده و قابل فعال‌سازی نیست.", show_alert=True)
        return
    try:
        snapshot = await async_snapshot()
        field = CONTROL_FIELDS.get(module_key, {}).get(field_key)
        if not field or field.kind != "bool":
            raise ValueError("این گزینه قابل روشن/خاموش کردن نیست")
        old_value = bool(control_module_state(snapshot, module_key).get(field_key, field.default))
        new_value = normalize_control_value(module_key, field_key, not old_value)
        review_risk = governance_control_risk(module_key, field_key, old_value, new_value)
        if review_risk:
            request = await async_with_db(
                lambda db: create_governance_request(
                    db,
                    action="control_change",
                    payload={"module": module_key, "field": field_key, "value": new_value},
                    requested_by=query.from_user.id,
                    risk_level=review_risk,
                    title=f"تغییر حساس: {CONTROL_MODULES[module_key].label} / {field.label}",
                    description=f"درخواست تغییر {module_key}.{field_key} از {old_value} به {new_value}",
                    target_type="control_field",
                    target_id=f"{module_key}.{field_key}",
                    dedupe_key=f"control-change:{module_key}:{field_key}:{new_value}",
                )
            )
            await async_with_db(
                lambda db: audit(
                    db,
                    query.from_user.id,
                    "system_control_review_requested",
                    f"{module_key}.{field_key}:{old_value}->{new_value};request={request['id']}",
                )
            )
            await query.answer("این تغییر حساس است و برای تأیید به صف حاکمیت رفت.", show_alert=True)
            await edit(
                query,
                f"🧠 <b>تغییر مستقیم انجام نشد</b>\n\nدرخواست <b>#{request['id']}</b> با سطح ریسک <code>{esc(review_risk)}</code> ساخته شد. پس از تأیید لازم، مقدار اعمال می‌شود.",
                [
                    [InlineKeyboardButton("بازکردن درخواست", callback_data=f"gov_view:{request['id']}")],
                    [InlineKeyboardButton("بازگشت به ماژول", callback_data=f"ecc_mod:{module_key}")],
                ],
            )
            return
        value = await async_with_db(lambda db: toggle_control_value(db, module_key, field_key, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "system_control_toggle", f"{module_key}.{field_key}={value}"))
    await query.answer("روشن شد ✅" if value else "خاموش شد ⛔️", show_alert=False)
    db = await async_snapshot()
    show_planned = module_key in context.user_data.get("control_advanced_modules", [])
    await edit(
        query,
        _control_module_text(module_key, db, show_planned=show_planned),
        _control_module_rows(module_key, db, show_planned=show_planned),
    )


async def control_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return ConversationHandler.END
    query = update.callback_query
    _, module_key, field_key = str(query.data or "").split(":", 2)
    field = CONTROL_FIELDS.get(module_key, {}).get(field_key)
    status = capability_status(module_key, field_key)
    if status == "planned":
        await query.answer("این قابلیت هنوز عملیاتی نشده و قابل تنظیم نیست.", show_alert=True)
        return ConversationHandler.END
    if not field or field.kind == "bool":
        await query.answer("تنظیم نامعتبر است", show_alert=True)
        return ConversationHandler.END
    await query.answer()
    context.user_data["enterprise_control_edit"] = (module_key, field_key)
    details = []
    if field.minimum is not None:
        details.append(f"حداقل: {field.minimum:g}")
    if field.maximum is not None:
        details.append(f"حداکثر: {field.maximum:g}")
    if field.choices:
        details.append("گزینه‌ها: " + "، ".join(field.choices))
    hint = " | ".join(details)
    await edit(
        query,
        f"✏️ <b>{esc(field.label)}</b>\n\nمقدار جدید را ارسال کنید.\n{esc(hint)}",
        back(f"ecc_mod:{module_key}"),
    )
    return ENTERPRISE_CONTROL_INPUT


async def control_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return ConversationHandler.END
    target = context.user_data.pop("enterprise_control_edit", None)
    if not target:
        await reply(update, "❌ فرایند تغییر تنظیم منقضی شده است.", back("a_control_center"))
        return ConversationHandler.END
    module_key, field_key = target
    raw = update.effective_message.text or ""
    try:
        snapshot = await async_snapshot()
        field = CONTROL_FIELDS[module_key][field_key]
        old = control_module_state(snapshot, module_key).get(field_key, field.default)
        normalized = normalize_control_value(module_key, field_key, raw)
        review_risk = governance_control_risk(module_key, field_key, old, normalized)
        if review_risk:
            request = await async_with_db(
                lambda db: create_governance_request(
                    db,
                    action="control_change",
                    payload={"module": module_key, "field": field_key, "value": normalized},
                    requested_by=update.effective_user.id,
                    risk_level=review_risk,
                    title=f"تغییر حساس: {CONTROL_MODULES[module_key].label} / {field.label}",
                    description=f"درخواست تغییر {module_key}.{field_key} از {old} به {normalized}",
                    target_type="control_field",
                    target_id=f"{module_key}.{field_key}",
                    dedupe_key=f"control-change:{module_key}:{field_key}:{normalized}",
                )
            )
            await async_with_db(
                lambda db: audit(
                    db,
                    update.effective_user.id,
                    "system_control_review_requested",
                    f"{module_key}.{field_key}:{old}->{normalized};request={request['id']}",
                )
            )
            await reply(
                update,
                f"🧠 <b>درخواست #{request['id']} ساخته شد.</b>\nاین تغییر حساس مستقیم اعمال نشد و پس از تأیید لازم اجرا می‌شود.",
                [
                    [InlineKeyboardButton("بازکردن درخواست", callback_data=f"gov_view:{request['id']}")],
                    [InlineKeyboardButton("بازگشت به ماژول", callback_data=f"ecc_mod:{module_key}")],
                ],
            )
            return ConversationHandler.END
        old, new = await async_with_db(
            lambda db: set_control_value(db, module_key, field_key, normalized, update.effective_user.id)
        )
    except ValueError as exc:
        context.user_data["enterprise_control_edit"] = target
        await reply(update, f"❌ {esc(exc)}\nمقدار صحیح را دوباره ارسال کنید.", back(f"ecc_mod:{module_key}"))
        return ENTERPRISE_CONTROL_INPUT
    await async_with_db(
        lambda db: audit(db, update.effective_user.id, "system_control_value", f"{module_key}.{field_key}:{old}->{new}")
    )
    field = CONTROL_FIELDS[module_key][field_key]
    await reply(
        update,
        f"✅ <b>{esc(field.label)}</b> تغییر کرد.\nمقدار جدید: <code>{esc(_control_value_text(new))}</code>",
        [[InlineKeyboardButton("بازگشت به ماژول", callback_data=f"ecc_mod:{module_key}")]],
    )
    return ConversationHandler.END


async def control_reset_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    module_key = str(query.data or "").split(":", 1)[1]
    if module_key == "signals" and not _is_owner_admin(query.from_user.id):
        await query.answer("بازنشانی تنظیمات سیگنال فقط توسط مالک اصلی انجام می‌شود.", show_alert=True)
        return
    if (
        module_key in USER_FEATURE_MODULE_KEYS
        and not _has_admin_permission(query.from_user.id, PERMISSION_FEATURE_MANAGEMENT)
    ):
        await query.answer("برای بازنشانی این ماژول، مجوز «مدیریت امکانات» لازم است.", show_alert=True)
        return
    review_risk = governance_reset_risk(module_key)
    if review_risk:
        request = await async_with_db(
            lambda db: create_governance_request(
                db,
                action="control_reset",
                payload={"module": module_key},
                requested_by=query.from_user.id,
                risk_level=review_risk,
                title=f"بازنشانی ماژول حساس: {CONTROL_MODULES[module_key].label}",
                description="بازنشانی کامل این ماژول به مقادیر پیش‌فرض نیازمند بررسی است.",
                target_type="control_module",
                target_id=module_key,
                dedupe_key=f"control-reset:{module_key}",
            )
        )
        await async_with_db(
            lambda db: audit(db, query.from_user.id, "system_control_reset_requested", f"{module_key};request={request['id']}")
        )
        await query.answer("بازنشانی حساس برای تأیید به صف حاکمیت رفت.", show_alert=True)
        await edit(
            query,
            f"🧠 <b>درخواست بازنشانی #{request['id']}</b>\n\nماژول هنوز تغییر نکرده است و پس از تأیید لازم بازنشانی می‌شود.",
            [
                [InlineKeyboardButton("بازکردن درخواست", callback_data=f"gov_view:{request['id']}")],
                [InlineKeyboardButton("بازگشت به ماژول", callback_data=f"ecc_mod:{module_key}")],
            ],
        )
        return
    try:
        await async_with_db(lambda db: reset_control_module(db, module_key, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "system_control_reset", module_key))
    await query.answer("ماژول به پیش‌فرض بازگشت", show_alert=True)
    db = await async_snapshot()
    show_planned = module_key in context.user_data.get("control_advanced_modules", [])
    await edit(
        query,
        _control_module_text(module_key, db, show_planned=show_planned),
        _control_module_rows(module_key, db, show_planned=show_planned),
    )


async def control_preset_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("Preset سراسری فقط توسط مالک اصلی قابل درخواست است.", show_alert=True)
        return
    preset = str(query.data or "").split(":", 1)[1]
    if preset not in {"full", "safe", "default"}:
        await query.answer("Preset نامعتبر است", show_alert=True)
        return
    request = await async_with_db(
        lambda db: create_governance_request(
            db,
            action="control_preset",
            payload={"preset": preset},
            requested_by=query.from_user.id,
            risk_level="critical",
            title=f"اجرای Preset سراسری: {preset}",
            description="این عملیات تنظیمات تمام ماژول‌ها را تغییر می‌دهد و نیازمند تأیید دومرحله‌ای است.",
            target_type="control_center",
            target_id="all",
            dedupe_key=f"control-preset:{preset}",
        )
    )
    await async_with_db(
        lambda db: audit(db, query.from_user.id, "system_control_preset_requested", f"{preset};request={request['id']}")
    )
    await query.answer("Preset مستقیم اجرا نشد و برای تأیید به صف حاکمیت رفت.", show_alert=True)
    await edit(
        query,
        f"🧠 <b>درخواست Preset #{request['id']}</b>\n\nتا قبل از تأیید دومرحله‌ای، هیچ تنظیمی تغییر نمی‌کند.",
        [
            [InlineKeyboardButton("بازکردن درخواست", callback_data=f"gov_view:{request['id']}")],
            [InlineKeyboardButton("بازگشت به مرکز کنترل", callback_data="a_control_center")],
        ],
    )


async def control_export_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer("در حال ساخت خروجی…")
    payload = export_control_payload(await async_snapshot())
    file_obj = io.BytesIO(payload)
    file_obj.name = "sentinel-enterprise-control.json"
    await query.message.reply_document(file_obj, caption="📦 خروجی کامل مرکز کنترل ربات")
    await async_with_db(lambda db: audit(db, query.from_user.id, "system_control_export", str(len(payload))))


async def control_diagnostics_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer("در حال بررسی سرویس‌ها…")
    checks: list[tuple[str, bool, str]] = []
    try:
        me = await context.bot.get_me()
        checks.append(("Telegram API", bool(me.id), f"@{me.username or '-'}"))
    except TelegramError as exc:
        checks.append(("Telegram API", False, str(exc)[:80]))
    try:
        probe = utc_iso()
        await async_with_db(
            lambda db: (
                db.setdefault("operations", {}).setdefault("health_probe", {}).update({"at": probe, "admin": str(query.from_user.id)})
            )
        )
        db = await async_snapshot()
        checks.append(("دیتابیس خواندن/نوشتن", db.get("operations", {}).get("health_probe", {}).get("at") == probe, SETTINGS.db_file.name))
    except Exception as exc:
        checks.append(("دیتابیس خواندن/نوشتن", False, str(exc)[:80]))
    for label, channel_id in (("کانال عمومی", SETTINGS.public_channel_id), ("کانال خصوصی", SETTINGS.private_channel_id)):
        if not channel_id:
            checks.append((label, False, "تنظیم نشده"))
            continue
        try:
            chat = await context.bot.get_chat(channel_id)
            checks.append((label, True, str(chat.title or channel_id)[:50]))
        except TelegramError as exc:
            checks.append((label, False, str(exc)[:80]))
    try:
        usage = shutil.disk_usage(SETTINGS.db_file.parent)
        used_pct = round((usage.used / max(1, usage.total)) * 100, 1)
        threshold = int(control_module_state((await async_snapshot()), "health").get("disk_warn_pct", 85) or 85)
        checks.append(("فضای دیسک", used_pct < threshold, f"{used_pct}% مصرف"))
    except OSError as exc:
        checks.append(("فضای دیسک", False, str(exc)[:80]))
    backups = [p for p in SETTINGS.backup_dir.glob("*") if p.is_file() and not p.name.endswith(".meta.json")]
    checks.append(("بکاپ", bool(backups), f"{len(backups)} فایل"))
    db = await async_snapshot()
    jobs = db.get("operations", {}).get("job_status", {})
    failed_jobs = sum(1 for item in jobs.values() if isinstance(item, dict) and item.get("status") == "error")
    checks.append(("Job Queue", failed_jobs == 0, f"{failed_jobs} خطادار"))
    ok_count = sum(1 for _, ok, _ in checks if ok)
    lines = ["🩺 <b>عیب‌یابی زنده ربات</b>", "", f"موفق: <b>{ok_count}/{len(checks)}</b>", ""]
    for label, ok, detail in checks:
        lines.append(f"{'✅' if ok else '❌'} <b>{esc(label)}</b> — {esc(detail)}")
    await async_with_db(
        lambda database: record_maintenance(database, query.from_user.id, "diagnostics", {"ok": ok_count, "total": len(checks)})
    )
    await edit(
        query,
        "\n".join(lines),
        [
            [InlineKeyboardButton("🔄 بررسی مجدد", callback_data="ecc_diag")],
            [InlineKeyboardButton("↩️ مرکز کنترل", callback_data="a_control_center")],
        ],
    )


async def control_maintenance_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    text = (
        "🧹 <b>نگهداری سیستم</b>\n\n"
        f"کاربران: <b>{len(db.get('users', {})):,}</b>\n"
        f"فعالیت‌ها: <b>{len(db.get('user_activity', [])):,}</b>\n"
        f"لاگ مدیران: <b>{len(db.get('admin_logs', [])):,}</b>\n"
        f"آرشیو سیگنال: <b>{len(db.get('signal_archive', [])):,}</b>\n\n"
        "عملیات نگهداری فقط داده‌های موقت و قابل بازسازی را محدود می‌کند و رکورد مالی را حذف نمی‌کند."
    )
    rows = [
        [InlineKeyboardButton("🧹 پاک‌سازی داده موقت", callback_data="ecc_maint:trim")],
        [InlineKeyboardButton("👥 بازسازی پروفایل کاربران", callback_data="ecc_maint:profiles")],
        [InlineKeyboardButton("💾 حذف بکاپ‌های اضافی", callback_data="ecc_maint:backups")],
        [InlineKeyboardButton("↩️ مرکز کنترل", callback_data="a_control_center")],
    ]
    await edit(query, text, rows)


async def control_maintenance_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    action = str(query.data or "").split(":", 1)[1]
    await query.answer("در حال اجرا…")
    if action == "trim":
        result = await async_with_db(trim_runtime_data)
        detail = "، ".join(f"{key}: {value}" for key, value in result.items())
    elif action == "profiles":
        profiles = await async_with_db(rebuild_all_user_profiles)
        result = {"profiles": len(profiles)}
        detail = f"{len(profiles):,} پروفایل بازسازی شد"
    elif action == "backups":
        keep = int(control_module_state((await async_snapshot()), "backup").get("keep_daily", 14) or 14)
        removed = await run_blocking(prune_operational_backups, SETTINGS.backup_dir, keep=max(1, keep), timeout=30)
        result = {"removed": removed, "keep": keep}
        detail = f"{removed} بکاپ اضافی حذف شد"
    else:
        await query.answer("عملیات نامعتبر است", show_alert=True)
        return
    await async_with_db(
        lambda db: (
            record_maintenance(db, query.from_user.id, action, result),
            audit(db, query.from_user.id, "system_maintenance", f"{action}:{result}"),
        )
    )
    await edit(query, f"✅ عملیات انجام شد.\n\n{esc(detail)}", [[InlineKeyboardButton("↩️ نگهداری", callback_data="ecc_maintenance")]])


async def control_league_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    action = str(query.data or "").split(":", 1)[1]
    try:
        if action == "start":
            season = await async_with_db(lambda db: start_league_season(db, query.from_user.id))
            message = f"فصل «{season['title']}» شروع شد"
        elif action == "close":
            season = await async_with_db(lambda db: close_league_season(db, query.from_user.id))
            message = f"فصل «{season['title']}» بسته شد"
        else:
            raise ValueError("عملیات نامعتبر است")
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "league_season", f"{action}:{season['id']}"))
    await query.answer(message, show_alert=True)
    db = await async_snapshot()
    await edit(query, _control_module_text("league", db), _control_module_rows("league", db))


async def require_admin(
    update: Update,
    permission: str | tuple[str, ...] | list[str] | set[str] | None = None,
    *,
    allow_limited: bool = False,
) -> bool:
    user = update.effective_user
    allowed = False
    if user:
        if is_admin(user.id):
            allowed = True
        elif permission:
            requested = (permission,) if isinstance(permission, str) else tuple(permission)
            allowed = await run_blocking(lambda: any(_has_admin_permission(user.id, item) for item in requested))
        elif allow_limited:
            allowed = await run_blocking(_is_any_admin, user.id)
    if allowed:
        return True
    if update.callback_query:
        await update.callback_query.answer("❌ شما به این بخش دسترسی ندارید.", show_alert=True)
    elif update.effective_message:
        await update.effective_message.reply_text("❌ شما به این بخش دسترسی ندارید.")
    return False


async def require_admin_all(
    update: Update,
    permissions: tuple[str, ...] | list[str] | set[str],
) -> bool:
    """Require every delegated permission for a sensitive operation.

    Primary owners still pass through ``is_admin``. Delegated administrators
    must hold each listed capability; broad legacy permissions are not treated
    as substitutes for receipt approval, VIP activation, refunds, or plan
    lifecycle actions.
    """
    user = update.effective_user
    requested = tuple(str(item) for item in permissions if str(item))
    allowed = bool(user and await run_blocking(
        lambda: is_admin(user.id) or (requested and all(_has_admin_permission(user.id, item) for item in requested))
    ))
    if allowed:
        return True
    if update.callback_query:
        await update.callback_query.answer("❌ مجوز کامل این عملیات را ندارید.", show_alert=True)
    elif update.effective_message:
        await update.effective_message.reply_text("❌ مجوز کامل این عملیات را ندارید.")
    return False



def _callback_button_text(query) -> str:
    data = str(getattr(query, "data", "") or "")
    markup = getattr(getattr(query, "message", None), "reply_markup", None)
    for row in getattr(markup, "inline_keyboard", []) or []:
        for button in row:
            if str(getattr(button, "callback_data", "") or "") == data:
                return str(getattr(button, "text", "") or "")
    return ""


def _is_back_navigation_query(query) -> bool:
    text = _callback_button_text(query).strip().casefold()
    return text.startswith(("⬅", "↩", "🔙", "←", "back", "برگشت", "بازگشت"))


def _should_replace_navigation_message(query) -> bool:
    """Replace messages only inside the subscription purchase journey.

    Every other menu edits the current message in place. Back navigation always
    remains in place so the previous page is still reachable and visually stable.
    """
    callback = str(getattr(query, "data", "") or "").strip()
    if not callback or _is_back_navigation_query(query) or _is_state_mutation_callback(callback):
        return False
    return callback == "u_vip" or callback.startswith((
        "vip_plan:", "vip_payment:", "buy_has_coupon", "buy_no_coupon",
        "buy_coupon", "buy_receipt", "vip_order:",
    ))


async def _replace_callback_screen(query, text: str, rows: list[list[InlineKeyboardButton]]) -> bool:
    message = getattr(query, "message", None)
    if not message:
        return False
    try:
        await _telegram_request_with_button_fallback(
            query.get_bot().send_message,
            chat_id=message.chat_id,
            text=text,
            reply_markup=InlineKeyboardMarkup(rows) if rows else None,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )
        try:
            await message.delete()
        except TelegramError:
            logger.debug("Previous navigation message could not be removed", exc_info=True)
        return True
    except TelegramError:
        logger.exception("Could not send replacement navigation screen")
        return False

async def edit(query, text: str, rows: list[list[InlineKeyboardButton]] | None = None) -> None:
    from modules.ticket_context import context_for_route
    linked = context_for_route(getattr(query, "data", ""), query.from_user.id)
    if linked:
        rows = list(rows or []) + [[InlineKeyboardButton("🎫 مشکل در این بخش", callback_data=f"ticket_from:{linked[0]}:{linked[1]}")]]
    rows = _normalize_navigation_rows(rows)
    if _should_replace_navigation_message(query) and await _replace_callback_screen(query, text, rows):
        return
    try:
        await _telegram_request_with_button_fallback(
            query.edit_message_text,
            text=text,
            reply_markup=InlineKeyboardMarkup(rows) if rows else None,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )
    except BadRequest as exc:
        if "message is not modified" in str(exc).lower():
            return
        logger.warning("Could not edit Telegram message in-place; replacing it: %s", exc)
        # Media messages and old Telegram message types cannot always be changed
        # into a text screen. Replace them so callback navigation still behaves
        # like one clean, changing page instead of filling the chat with screens.
        if not await _replace_callback_screen(query, text, rows):
            raise
    except TelegramError:
        logger.exception("Could not edit Telegram message")
        raise


async def reply(update: Update, text: str, rows: list[list[InlineKeyboardButton]] | None = None) -> None:
    rows = _normalize_navigation_rows(rows)
    await _telegram_request_with_button_fallback(
        update.effective_message.reply_text,
        text=text,
        reply_markup=InlineKeyboardMarkup(rows) if rows else None,
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True,
    )


async def mark_callback_message(query, suffix: str) -> None:
    """Update either a text message or a photo caption after an admin action."""
    try:
        if query.message.photo:
            base = query.message.caption_html or esc(query.message.caption or "")
            await query.edit_message_caption(caption=base + suffix, parse_mode=ParseMode.HTML, reply_markup=None)
        else:
            base = query.message.text_html or esc(query.message.text or "")
            await query.edit_message_text(text=base + suffix, parse_mode=ParseMode.HTML, reply_markup=None)
    except BadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            logger.warning("Could not mark callback message: %s", exc)
    except TelegramError:
        logger.exception("Could not mark callback message")


def register_current_user(update: Update) -> None:
    if not update.effective_user:
        return
    with_db(lambda db: register_user(db, update.effective_user))


def _language_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("🇮🇷 فارسی", callback_data="lang_select:fa", style="primary"),
            InlineKeyboardButton("🇬🇧 English", callback_data="lang_select:en", style="primary"),
        ]
    ]


async def _send_language_prompt(update: Update) -> None:
    text = (
        "🌐 <b>زبان خود را انتخاب کنید | Choose your language</b>\n\n"
        "زبان تمام منوهای کاربری و قوانین بر اساس انتخاب شما نمایش داده می‌شود.\n"
        "Your menus and rules will follow this language preference."
    )
    if update.callback_query:
        await edit(update.callback_query, text, _language_rows())
    else:
        await reply(update, text, _language_rows())


async def language_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await edit(query, tr("choose_language", _language_for_user(query.from_user.id)), _language_rows())


async def language_select_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = normalize_language(str(query.data or "").split(":", 1)[-1])
    await async_with_db(
        lambda db: set_user_language(
            db,
            query.from_user.id,
            language,
            selected_at=utc_iso(),
        )
    )
    await query.answer(tr("language_saved", language), show_alert=True)
    db = await async_snapshot()
    if not _is_any_admin(query.from_user.id) and not user_has_accepted_rules(db, query.from_user.id, language):
        await _send_rules_prompt(update, context, language=language)
        return
    if not _is_any_admin(query.from_user.id) and not await _user_has_required_membership(context, query.from_user.id):
        text, rows = _force_join_prompt()
        await edit(query, text, rows)
        return
    await ensure_quick_access_keyboard(update, context, force=True)
    if context.user_data.get("pending_gift_token"):
        await redeem_gift_for_update(update, context, context.user_data.pop("pending_gift_token"))
        return
    await edit(query, await run_blocking(user_home_text, query.from_user.id), await run_blocking(main_menu, query.from_user.id))


async def _send_rules_prompt(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    *,
    admin_preview: bool = False,
    language: str | None = None,
) -> None:
    language = normalize_language(language or _language_for_user(update.effective_user.id))
    state = current_rules(await async_snapshot(), language)
    text = str(state.get("text") or "").strip()
    if not text:
        if update.callback_query:
            await update.callback_query.answer(tr("rules_missing", language), show_alert=True)
        elif update.effective_message:
            await reply(update, tr("rules_missing", language))
        return
    chunks = chunk_text(text, 3000)[:12]
    chat_id = update.effective_chat.id
    for index, item in enumerate(chunks):
        final = index == len(chunks) - 1
        if language == "en":
            heading = (
                f"📜 <b>SENTINEL Terms of Use — Version {int(state.get('version', 0) or 0)}</b>\n\n"
                if index == 0
                else f"📜 <b>Rules continued ({index + 1}/{len(chunks)})</b>\n\n"
            )
        else:
            heading = (
                f"📜 <b>قوانین استفاده از SENTINEL — نسخه {int(state.get('version', 0) or 0)}</b>\n\n"
                if index == 0
                else f"📜 <b>ادامه قوانین ({index + 1}/{len(chunks)})</b>\n\n"
            )
        rows = None
        if final:
            if admin_preview:
                rows = InlineKeyboardMarkup([[InlineKeyboardButton("↩️ مدیریت قوانین", callback_data="a_rules")]])
            else:
                rows = InlineKeyboardMarkup(
                    [[InlineKeyboardButton(tr("rules_accept", language), callback_data="rules_accept")]]
                )
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            chat_id,
            heading + esc(item),
            parse_mode=ParseMode.HTML,
            reply_markup=rows,
        )


async def rules_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    chat = update.effective_chat
    if not user or not chat or chat.type != "private" or _is_any_admin(user.id):
        return
    callback = str(update.callback_query.data or "") if update.callback_query else ""
    if callback == "rules_accept" or callback.startswith("lang_select:") or callback == "language_menu":
        return
    if update.effective_message and str(update.effective_message.text or "").startswith("/start"):
        return
    db = await async_snapshot()
    language = user_language(db, user.id)
    if not language:
        await run_blocking(register_current_user, update)
        if update.callback_query:
            await update.callback_query.answer()
        await _send_language_prompt(update)
        raise ApplicationHandlerStop
    if user_has_accepted_rules(db, user.id, language):
        return
    await run_blocking(register_current_user, update)
    if update.callback_query:
        await update.callback_query.answer(tr("rules_required", language), show_alert=True)
    await _send_rules_prompt(update, context, language=language)
    raise ApplicationHandlerStop


async def rules_accept_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = _language_for_user(query.from_user.id)
    try:
        await async_with_db(lambda db: accept_current_rules(db, query.from_user.id, language))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Rules accepted ✅" if language == "en" else "پذیرش قوانین ثبت شد ✅", show_alert=True)
    if not await _user_has_required_membership(context, query.from_user.id):
        text, rows = _force_join_prompt()
        prefix = "✅ Rules accepted.\n\n" if language == "en" else "✅ قوانین پذیرفته شد.\n\n"
        await edit(query, prefix + text, rows)
        return
    await ensure_quick_access_keyboard(update, context, force=True)
    if context.user_data.get("pending_gift_token"):
        await redeem_gift_for_update(update, context, context.user_data.pop("pending_gift_token"))
        return
    await edit(
        query,
        tr("rules_accepted", language),
        main_menu(query.from_user.id),
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return

    if context.args and str(context.args[0]).startswith("gift_"):
        context.user_data["pending_gift_token"] = str(context.args[0])[5:]

    def mutate(db: dict) -> tuple[bool, int | None]:
        was_new = str(user.id) not in db.setdefault("users", {})
        register_user(db, user)
        inviter: int | None = None
        start_arg = str(context.args[0] if context.args else "").strip().lower()
        if start_arg.startswith("cmp_"):
            record_campaign_touch(
                db,
                start_arg.removeprefix("cmp_"),
                user.id,
                "bot_start",
                metadata={"was_new_user": was_new},
            )
        elif was_new and start_arg:
            ok, _, inviter = apply_referral(db, user.id, start_arg)
            if not ok:
                inviter = None
        return was_new, inviter

    _, inviter = await async_with_db(mutate)
    if inviter and await async_with_db(lambda db: route_notification(db, inviter, "referral")):
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message, inviter, "🎉 یک کاربر جدید با لینک معرف شما وارد ربات شد."
            )
        except TelegramError:
            logger.info("Could not notify referrer %s", inviter)

    db = await async_snapshot()
    language = user_language(db, user.id)
    if not language:
        await _send_language_prompt(update)
        return
    language = language or "fa"
    if not _is_any_admin(user.id) and not user_has_accepted_rules(db, user.id, language):
        await _send_rules_prompt(update, context, language=language)
        return

    if not _is_any_admin(user.id) and not await _user_has_required_membership(context, user.id):
        text, rows = _force_join_prompt()
        await reply(update, text, rows)
        return

    await ensure_quick_access_keyboard(update, context)

    if context.user_data.get("pending_gift_token"):
        token = context.user_data.pop("pending_gift_token")
        await redeem_gift_for_update(update, context, token)
        return
    destination = context.args[0].lower() if context.args else ""
    web_destinations = {
        "web_calc": ("برای شروع ماشین‌حساب روی دکمه زیر بزنید.", "u_calc", "شروع ماشین‌حساب"),
        "web_vip": ("برای مشاهده وضعیت و گزینه‌های VIP روی دکمه زیر بزنید.", "u_vip", "مشاهده VIP"),
        "web_edu": ("برای ورود به کتابخانه آموزشی روی دکمه زیر بزنید.", "u_edu", "ورود به آموزش"),
        "web_contests": ("برای مشاهده مسابقات روی دکمه زیر بزنید.", "u_contests", "مشاهده مسابقات"),
        "web_signals": ("برای ورود به مرکز سیگنال روی دکمه زیر بزنید.", "u_signal_portal", "انتخاب بازار سیگنال"),
        "web_signals_forex": ("سیگنال‌های فارکس، طلا و CFD در این بخش قرار دارند.", "u_signal_portal:forex:0", "سیگنال‌های فارکس"),
        "web_signals_crypto": ("سیگنال‌های کریپتو در این بخش قرار دارند.", "u_signal_portal:crypto:0", "سیگنال‌های کریپتو"),
        "web_trade": ("سیگنال‌ها، واچ‌لیست و ژورنال فارکس و کریپتو در مرکز معامله‌گری قرار دارند.", "nav_user:trade", "ورود به مرکز معامله‌گری"),
        "web_watchlist": ("برای انتخاب واچ‌لیست بازار روی دکمه زیر بزنید.", "user_watchlist", "انتخاب واچ‌لیست"),
        "web_watchlist_forex": ("واچ‌لیست فارکس و CFD را باز کنید.", "user_watchlist:forex", "واچ‌لیست فارکس"),
        "web_watchlist_crypto": ("واچ‌لیست کریپتو را باز کنید.", "user_watchlist:crypto", "واچ‌لیست کریپتو"),
        "web_journal": ("برای انتخاب ژورنال بازار روی دکمه زیر بزنید.", "user_journal", "انتخاب ژورنال"),
        "web_journal_forex": ("ژورنال فارکس و CFD را باز کنید.", "user_journal:forex", "ژورنال فارکس"),
        "web_journal_crypto": ("ژورنال کریپتو را باز کنید.", "user_journal:crypto", "ژورنال کریپتو"),
        "web_account_hub": ("حساب، امتیاز، مأموریت‌ها و جوایز در این بخش قرار دارند.", "nav_user:account", "ورود به حساب و باشگاه"),
        "web_services": ("اخبار مهم، پشتیبانی و سوالات متداول در این بخش قرار دارند.", "nav_user:growth", "ورود به خدمات و پشتیبانی"),
        "web_prices": ("برای مشاهده بازار زنده روی دکمه زیر بزنید.", "u_price", "مشاهده قیمت‌ها"),
        "web_news": ("برای مشاهده خبرهای مهم امروز روی دکمه زیر بزنید.", "u_calendar", "مشاهده تقویم امروز"),
        "web_account": ("برای ورود به داشبورد حساب روی دکمه زیر بزنید.", "u_account", "مشاهده حساب"),
        "web_support": ("برای ورود به پشتیبانی روی دکمه زیر بزنید.", "u_support", "ورود به پشتیبانی"),
        "web_rewards": ("برای ورود به باشگاه جوایز روی دکمه زیر بزنید.", "u_rewards", "مشاهده جوایز"),
        "web_club": ("برای ورود به باشگاه، مأموریت‌ها و جوایز روی دکمه زیر بزنید.", "nav_user:club", "ورود به باشگاه"),
        "web_faq": ("برای مشاهده پاسخ سوال‌های متداول روی دکمه زیر بزنید.", "u_faq", "مشاهده سوالات متداول"),
        "web_kpi": ("برای ورود به فضای کاری تحلیلگران روی دکمه زیر بزنید.", "kpi_trader_home", "ورود به KPI Trader"),
    }
    if language == "en":
        web_destinations.update(
            {
                "web_calc": ("Open the professional risk calculator.", "u_calc", "Open calculator"),
                "web_vip": ("View your VIP status and available plans.", "u_vip", "View VIP"),
                "web_edu": ("Open the SENTINEL learning center.", "u_edu", "Open education"),
                "web_contests": ("View active contests and challenges.", "u_contests", "View contests"),
                "web_signals": ("Open the signal center.", "u_signal_portal", "Choose signal market"),
                "web_signals_forex": ("View forex, metals and CFD signals.", "u_signal_portal:forex:0", "Forex signals"),
                "web_signals_crypto": ("View crypto spot and futures signals.", "u_signal_portal:crypto:0", "Crypto signals"),
                "web_trade": ("Open signals, watchlists and trading journals.", "nav_user:trade", "Open trading center"),
                "web_watchlist": ("Choose a market watchlist.", "user_watchlist", "Choose watchlist"),
                "web_watchlist_forex": ("Open your forex and CFD watchlist.", "user_watchlist:forex", "Forex watchlist"),
                "web_watchlist_crypto": ("Open your crypto watchlist.", "user_watchlist:crypto", "Crypto watchlist"),
                "web_journal": ("Choose a trading journal.", "user_journal", "Choose journal"),
                "web_journal_forex": ("Open your forex and CFD journal.", "user_journal:forex", "Forex journal"),
                "web_journal_crypto": ("Open your crypto journal.", "user_journal:crypto", "Crypto journal"),
                "web_account_hub": ("Open your account, points, missions and rewards.", "nav_user:account", "Open account & club"),
                "web_services": ("Open market services, support and FAQs.", "nav_user:growth", "Open services"),
                "web_prices": ("Open live market prices.", "u_price", "View prices"),
                "web_news": ("View today's important economic events.", "u_calendar", "View calendar"),
                "web_account": ("Open your account dashboard.", "u_account", "View account"),
                "web_support": ("Open support and your tickets.", "u_support", "Open support"),
                "web_rewards": ("Open rewards and missions.", "u_rewards", "View rewards"),
                "web_club": ("Open your club, missions and rewards.", "nav_user:club", "Open club"),
                "web_faq": ("View answers to frequently asked questions.", "u_faq", "View FAQs"),
                "web_kpi": ("Open your analyst task workspace.", "kpi_trader_home", "Open KPI Trader"),
            }
        )
    web_destinations.update({
        "web_referral": ("لینک اختصاصی دعوت شما", "u_referral", "👥 لینک دعوت من"),
        "web_missions": ("مأموریت‌ها و پیشرفت شما", "u_missions", "🎯 مأموریت‌ها"),
        "web_my_rewards": ("جوایز و کدهای تخفیف شما", "u_my_rewards", "🎁 جوایز من"),
        "web_reward_catalog": ("جوایز قابل دریافت", "u_reward_catalog", "🎁 مشاهده جوایز"),
        "web_tools": ("تمام ابزارهای معامله", "nav_user:tools", "🧰 ابزارها"),
        "web_today": ("برنامه امروز شما", "u_today", "📅 امروز من"),
    })
    if language == "en":
        for key,title,callback,label in [
            ('web_referral','Your personal invitation link','u_referral','👥 My referral link'),
            ('web_missions','Your missions and progress','u_missions','🎯 Missions'),
            ('web_my_rewards','Your rewards and discount codes','u_my_rewards','🎁 My rewards'),
            ('web_reward_catalog','Available rewards','u_reward_catalog','🎁 Available rewards'),
            ('web_tools','Trading tools','nav_user:tools','🧰 Tools'),
            ('web_today','Your daily plan','u_today','📅 My today')]:web_destinations[key]=(title,callback,label)
    if destination in web_destinations:
        text, callback, label = web_destinations[destination]
        module_key = feature_for_callback(callback)
        if module_key and not _is_any_admin(user.id) and not is_module_enabled(await async_snapshot(), module_key):
            module = CONTROL_MODULES.get(module_key)
            await reply(
                update,
                (
                    "⛔️ This section is currently disabled."
                    if language == "en"
                    else f"⛔️ {esc(module.label if module else 'این بخش')} در حال حاضر غیرفعال است."
                ),
                main_menu(user.id),
            )
            return
        await reply(
            update,
            text,
            [
                [InlineKeyboardButton(label, callback_data=callback)],
                [InlineKeyboardButton("Main menu" if language == "en" else "منوی اصلی", callback_data="home")],
            ],
        )
        return

    await reply(update, await run_blocking(user_home_text, user.id), await run_blocking(main_menu, user.id))


async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    await run_blocking(register_current_user, update)
    if not user_language(await async_snapshot(), user.id):
        await _send_language_prompt(update)
        return ConversationHandler.END
    if not _is_any_admin(user.id) and not await _user_has_required_membership(context, user.id):
        text, rows = _force_join_prompt()
        await reply(update, text, rows)
        return ConversationHandler.END
    await ensure_quick_access_keyboard(update, context)
    await reply(update, await run_blocking(user_home_text, user.id), await run_blocking(main_menu, user.id))
    return ConversationHandler.END


async def _require_user_module(update: Update, module_key: str) -> bool:
    if _is_any_admin(update.effective_user.id):
        return True
    db = await async_snapshot()
    if is_module_enabled(db, module_key):
        return True
    module = CONTROL_MODULES.get(module_key)
    label = module.label if module else "این بخش"
    language = _language_for_user(update.effective_user.id)
    await reply(
        update,
        (
            "⛔️ This section is currently disabled by management."
            if language == "en"
            else f"⛔️ {esc(label)} در حال حاضر توسط مدیریت غیرفعال است."
        ),
        main_menu(update.effective_user.id),
    )
    return False


async def signals_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_user_module(update, "portal"):
        return
    language = _language_for_user(update.effective_user.id)
    await reply(
        update,
        (
            "<b>Signal center</b>\nCurrent-cycle signals, live status and your personal performance."
            if language == "en"
            else "<b>مرکز سیگنال‌ها</b>\nسیگنال‌های دوره فعلی، وضعیت زنده و برآیند شخصی شما."
        ),
        [
            [InlineKeyboardButton("View signals" if language == "en" else "مشاهده سیگنال‌ها", callback_data="u_signal_portal")],
            [InlineKeyboardButton("Main menu" if language == "en" else "مرکز فرمان", callback_data="home")],
        ],
    )


async def prices_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_user_module(update, "prices"):
        return
    language = _language_for_user(update.effective_user.id)
    await reply(
        update,
        (
            "💹 <b>Live markets</b>\nForex, crypto, metals, energy, stocks and Iran-market prices."
            if language == "en"
            else "💹 <b>بازار زنده</b>\nقیمت بازار ایران، فارکس، ارز دیجیتال، نفت و سهام."
        ),
        [
            [InlineKeyboardButton("View prices" if language == "en" else "مشاهده قیمت‌ها", callback_data="u_price")],
            [InlineKeyboardButton("Main menu" if language == "en" else "مرکز فرمان", callback_data="home")],
        ],
    )


async def account_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_user_module(update, "account"):
        return
    language = _language_for_user(update.effective_user.id)
    await reply(
        update,
        (
            "👤 <b>My account</b>\nYour VIP status, points, purchases and activity."
            if language == "en"
            else "👤 <b>حساب من</b>\nوضعیت VIP، امتیازها، خریدها و فعالیت‌های شما."
        ),
        [
            [InlineKeyboardButton("Open account" if language == "en" else "ورود به حساب", callback_data="u_account")],
            [InlineKeyboardButton("Main menu" if language == "en" else "مرکز فرمان", callback_data="home")],
        ],
    )


async def support_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _require_user_module(update, "support"):
        return
    language = _language_for_user(update.effective_user.id)
    await reply(
        update,
        (
            "🎫 <b>Support</b>\nCreate a ticket or follow previous replies."
            if language == "en"
            else "🎫 <b>پشتیبانی</b>\nتیکت جدید ثبت کنید یا پاسخ‌های قبلی را پیگیری کنید."
        ),
        [
            [InlineKeyboardButton("Open support" if language == "en" else "ورود به پشتیبانی", callback_data="u_support")],
            [InlineKeyboardButton("❓ FAQs" if language == "en" else "❓ سوالات متداول", callback_data="u_faq")],
            [InlineKeyboardButton("Main menu" if language == "en" else "مرکز فرمان", callback_data="home")],
        ],
    )


async def vip_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    module_key = feature_for_callback("u_vip")
    if module_key and not await _require_user_module(update, module_key):
        return ConversationHandler.END
    language = _language_for_user(user.id)
    return await _send_keyboard_shortcut_entry(
        update,
        text=(
            "Open your VIP plans, purchases and subscription status:"
            if language == "en"
            else "پلن‌ها، خریدها و وضعیت اشتراک VIP خود را باز کنید:"
        ),
        callback="u_vip",
        button_label="💎 Open VIP" if language == "en" else "💎 ورود به اشتراک VIP",
    )


async def calculator_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    module_key = feature_for_callback("u_calc")
    if module_key and not await _require_user_module(update, module_key):
        return ConversationHandler.END
    language = _language_for_user(user.id)
    return await _send_keyboard_shortcut_entry(
        update,
        text=(
            "Open the professional position-size and risk calculator:"
            if language == "en"
            else "ماشین‌حساب حرفه‌ای حجم و ریسک معامله را باز کنید:"
        ),
        callback="u_calc",
        button_label="🧮 Open calculator" if language == "en" else "🧮 ورود به ماشین‌حساب",
    )


async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    module_key = feature_for_callback("u_referral")
    if module_key and not await _require_user_module(update, module_key):
        return ConversationHandler.END
    language = _language_for_user(user.id)
    return await _send_keyboard_shortcut_entry(
        update,
        text=(
            "Open your personal referral link, member count and rewards:"
            if language == "en"
            else "لینک اختصاصی، تعداد اعضای معرفی‌شده و پاداش‌های رفرال را باز کنید:"
        ),
        callback="u_referral",
        button_label="🤝 Open referral center" if language == "en" else "🤝 ورود به مرکز رفرال",
    )


async def trading_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    await reply(update, user_category_text("trade", user.id), user_category_menu("trade", user.id))
    return ConversationHandler.END


async def language_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not update.effective_user:
        return ConversationHandler.END
    await _send_language_prompt(update)
    return ConversationHandler.END


async def miniapp_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    language = _language_for_user(user.id)
    row = webapp_row()
    if not row:
        await reply(
            update,
            "The Mini App is currently disabled." if language == "en" else "مینی‌اپ در حال حاضر غیرفعال است.",
            main_menu(user.id),
        )
        return ConversationHandler.END
    await reply(
        update,
        "Open SENTINEL Mini App:" if language == "en" else "مینی‌اپ SENTINEL را باز کنید:",
        [row, [InlineKeyboardButton("Main menu" if language == "en" else "منوی اصلی", callback_data="home")]],
    )
    return ConversationHandler.END


async def home_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    _clear_current_operation(context)
    await run_blocking(register_current_user, update)
    await edit(query, await run_blocking(user_home_text, query.from_user.id), await run_blocking(main_menu, query.from_user.id))
    return ConversationHandler.END


async def user_navigation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    category = str(query.data or "").split(":", 1)[1] if ":" in str(query.data or "") else ""
    await edit(
        query,
        user_category_text(category, query.from_user.id),
        user_category_menu(category, query.from_user.id),
    )
    return ConversationHandler.END


def _clear_current_operation(
    context: ContextTypes.DEFAULT_TYPE, *, preserve_navigation: bool = False
) -> None:
    """Drop every transient wizard/form value and optionally keep Back history."""
    activity = context.user_data.get("_sentinel_last_activity_at")
    marker = context.user_data.get(_COMMAND_MENU_STATE_KEY)
    navigation = context.user_data.get(_NAVIGATION_STACK_KEY) if preserve_navigation else None
    context.user_data.clear()
    if activity is not None:
        context.user_data["_sentinel_last_activity_at"] = activity
    if marker:
        context.user_data[_COMMAND_MENU_STATE_KEY] = marker
    if preserve_navigation and isinstance(navigation, list):
        context.user_data[_NAVIGATION_STACK_KEY] = navigation


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    if not user:
        return ConversationHandler.END
    _clear_current_operation(context)
    language = _language_for_user(user.id)
    await reply(
        update,
        "✖️ The current action was cancelled. You are back at the main command deck."
        if language == "en"
        else "✖️ عملیات جاری کاملاً لغو شد. به عرشه فرمان اصلی برگشتید.",
        main_menu(user.id),
    )
    return ConversationHandler.END


async def restart_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Reset the current user flow and run the canonical /start bootstrap again."""
    _clear_current_operation(context)
    await start(update, context)
    return ConversationHandler.END


async def cancel_current_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer("Cancelled" if _language_for_user(query.from_user.id) == "en" else "عملیات لغو شد")
    _clear_current_operation(context)
    await edit(
        query,
        "✖️ <b>Current action cancelled</b>\nYou are back at the main command deck."
        if _language_for_user(query.from_user.id) == "en"
        else "✖️ <b>عملیات جاری لغو شد</b>\nبه عرشه فرمان اصلی برگشتید.",
        main_menu(query.from_user.id),
    )
    return ConversationHandler.END


async def restart_bot_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer("Restarting…" if _language_for_user(query.from_user.id) == "en" else "شروع مجدد…")
    _clear_current_operation(context)
    await run_blocking(register_current_user, update)
    await edit(query, await run_blocking(user_home_text, query.from_user.id), await run_blocking(main_menu, query.from_user.id))
    return ConversationHandler.END


def _ascii_digits(value: str) -> str:
    table = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    return str(value).translate(table)



__feature_exports__ = ('_remember_runtime_bot_username', 'effective_bot_username', 'back', 'standard_user_nav', 'webapp_row', 'with_webapp', '_user_callback_enabled', '_visible_user_items', '_is_any_admin', '_is_owner_admin', '_has_admin_permission', '_has_any_admin_permission', '_admin_ids_for_permission', '_language_for_user', '_user_navigation_items', '_user_home_snapshot', 'user_home_text', 'main_menu', 'user_category_menu', 'user_category_text', '_admin_menu_items', '_admin_navigation_categories', '_admin_granted_permissions', '_admin_items_by_callback', '_admin_category_available', '_admin_counts', 'admin_home_text', 'admin_menu', 'admin_category_menu', 'admin_category_text', '_control_value_text', '_control_center_rows', 'a_control_center', 'control_category_handler', '_control_module_rows', '_control_module_text', 'control_module_handler', 'control_module_mode_handler', 'control_boolean_handler', 'control_edit_start', 'control_edit_input', 'control_reset_handler', 'control_preset_handler', 'control_export_handler', 'control_diagnostics_handler', 'control_maintenance_panel', 'control_maintenance_action', 'control_league_action', 'require_admin', 'require_admin_all', 'edit', 'reply', 'mark_callback_message', 'register_current_user', 'QUICK_MENU_BUTTON_FA', 'QUICK_MENU_BUTTON_EN', 'QUICK_MENU_BUTTON_PATTERN', 'QUICK_MENU_FILTER', 'KEYBOARD_SHORTCUT_FILTER', 'keyboard_shortcut_button', 'CANCEL_OPERATION_BUTTON_FA', 'CANCEL_OPERATION_BUTTON_EN', 'RESTART_BOT_BUTTON_FA', 'RESTART_BOT_BUTTON_EN', 'CANCEL_OPERATION_FILTER', 'RESTART_BOT_FILTER', 'quick_access_keyboard', 'ensure_quick_access_keyboard', 'command_menu_keyboard_guard', 'quick_menu_button', '_language_rows', '_send_language_prompt', 'language_menu_handler', 'language_select_handler', '_send_rules_prompt', 'rules_guard', 'rules_accept_handler', 'start', 'menu_command', '_require_user_module', 'signals_command', 'prices_command', 'account_command', 'support_command', 'vip_command', 'calculator_command', 'referral_command', 'trading_command', 'language_command', 'miniapp_command', 'home_callback', 'user_navigation', 'capture_navigation_screen', 'navigation_back', '_dispatch_back_target', '_is_state_mutation_callback', '_normalize_navigation_rows', '_clear_current_operation', 'cancel_command', 'restart_command', 'cancel_current_callback', 'restart_bot_callback', '_ascii_digits')
