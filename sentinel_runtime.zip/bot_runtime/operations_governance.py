"""Admin decision queue and automatic operations watchdog surfaces."""

from __future__ import annotations

from bot_runtime import shared as _shared

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith("__")})

_STATUS_LABELS = {
    "pending": "در انتظار بررسی",
    "pending_second_approval": "در انتظار تأیید دوم",
    "approved": "آماده اجرا",
    "applied": "اجراشده",
    "failed": "ناموفق/در صف Retry",
    "rejected": "ردشده",
    "cancelled": "لغوشده",
    "expired": "منقضی",
}

_RISK_LABELS = {
    "low": "کم",
    "medium": "متوسط",
    "high": "زیاد",
    "critical": "بحرانی",
}


def _health_icon(status: str) -> str:
    return {"healthy": "✅", "warning": "⚠️", "critical": "🔴", "unknown": "ℹ️"}.get(str(status), "•")




_DETAIL_LABELS = {
    "known": "شناخته‌شده",
    "stale": "قدیمی",
    "stale_seconds": "حد تازگی (ثانیه)",
    "stale_ratio": "نسبت قدیمی",
    "mode": "حالت",
    "total": "کل",
    "healthy": "سالم",
    "degraded": "کند/محدود",
    "offline": "آفلاین اختیاری",
    "unhealthy": "ناسالم",
    "redundancy_ok": "افزونگی سالم",
    "latest_age_hours": "سن آخرین بکاپ (ساعت)",
    "enabled": "فعال",
    "failed": "ناموفق",
    "recovering": "در حال بازیابی",
    "process_uptime_minutes": "زمان اجرای فعلی (دقیقه)",
    "symbols_checked": "نماد بررسی‌شده",
    "items": "آیتم",
    "duplicates": "تکراری",
    "past_retention": "قدیمی‌تر از نگهداری",
    "bad": "دسترسی خراب",
    "stale_or_unknown": "نیازمند تازه‌سازی",
    "overdue": "عبور از مهلت",
    "sla_minutes": "مهلت (دقیقه)",
}

_MODE_LABELS = {
    "idle": "آماده؛ هنوز داده‌ای لازم نیست",
    "live": "زنده",
    "redundant_cache": "زنده با کش پشتیبان",
    "all_stale": "همه داده‌ها قدیمی",
    "redundant": "چندمنبعی سالم",
    "single_source": "تک‌منبعی",
    "probe_stale": "نیازمند Probe تازه",
    "unavailable": "در دسترس نیست",
    "disabled": "غیرفعال",
    "ready": "آماده",
    "warming_up": "در حال آماده‌سازی اولیه",
    "due": "زمان بکاپ رسیده",
    "expired": "منقضی",
    "missing": "ثبت نشده",
    "configured": "پیکربندی‌شده",
    "checked": "بررسی‌شده",
}


def _display_health_value(key: str, value: Any) -> str:
    if value is None:
        return "در انتظار اولین اجرا"
    if isinstance(value, bool):
        return "بله" if value else "خیر"
    if key == "mode":
        return _MODE_LABELS.get(str(value), str(value))
    if isinstance(value, float):
        return f"{value:.2f}".rstrip("0").rstrip(".")
    return str(value)


def _compact_health_details(item: dict[str, Any]) -> tuple[str, str]:
    details = item.get("details") if isinstance(item.get("details"), dict) else {}
    scalar_items = [
        (key, value)
        for key, value in details.items()
        if not isinstance(value, (list, dict, tuple, set))
    ]
    compact = "، ".join(
        f"{_DETAIL_LABELS.get(key, key)}: {_display_health_value(key, value)}"
        for key, value in scalar_items[:6]
    )
    names: list[str] = []
    if str(item.get("key") or "") == "job_freshness":
        for key in ("failed_jobs", "stale_jobs"):
            value = details.get(key)
            if isinstance(value, list):
                names.extend(str(name) for name in value if str(name).strip())
    extra = "، ".join(dict.fromkeys(names))
    return compact or "وضعیت سالم است", extra

def _request_icon(status: str) -> str:
    return {
        "pending": "🕓",
        "pending_second_approval": "👥",
        "approved": "✅",
        "applied": "🚀",
        "failed": "❌",
        "rejected": "🚫",
    }.get(str(status), "•")


_ERROR_LABELS = {
    "REQUEST_NOT_FOUND": "درخواست پیدا نشد.",
    "REQUEST_FINALIZED": "این درخواست قبلاً نهایی شده است.",
    "REQUEST_NOT_APPROVED": "درخواست هنوز تأییدهای لازم را ندارد.",
    "REQUEST_NOT_FAILED": "این درخواست در وضعیت خطا نیست.",
    "ALREADY_APPROVED": "تأیید شما قبلاً ثبت شده است.",
    "CRITICAL_REQUEST_REQUIRES_DIFFERENT_APPROVER": "درخواست بحرانی باید توسط ادمین مستقل تأیید شود.",
    "APPROVAL_EXPIRED": "اعتبار تأیید منقضی شده است؛ دوباره تأیید کنید.",
    "TARGET_NOT_FOUND": "رکورد مقصد پیدا نشد یا قبلاً حذف شده است.",
}


def _governance_error(exc: Exception) -> str:
    code = str(exc)
    return _ERROR_LABELS.get(code, code or "عملیات ناموفق بود.")


def _governance_home_content(
    dashboard: dict[str, Any],
) -> tuple[str, list[list[InlineKeyboardButton]]]:
    health = dashboard["health"]
    pending = dashboard["pending"]
    status = dashboard["request_status"]
    silence = parse_dt(dashboard.get("notifications_silenced_until"))
    silence_text = (
        f"تا <code>{esc(dashboard.get('notifications_silenced_until'))}</code>"
        if silence and silence > datetime.now(UTC)
        else "فعال"
    )
    lines = [
        "🧠 <b>مرکز حاکمیت عملیات</b>",
        "",
        "تصمیم‌های انسانی، تأیید دومرحله‌ای و کنترل‌های خودکار در این بخش یکپارچه شده‌اند.",
        "",
        f"در انتظار: <b>{len(pending)}</b> | اجراشده: <b>{int(status.get('applied', 0))}</b> | ناموفق: <b>{int(status.get('failed', 0))}</b>",
        f"سلامت خودکار — ✅ {health['healthy']} | ⚠️ {health['warning']} | 🔴 {health['critical']} | ℹ️ {health['unknown']}",
        f"آخرین بررسی: <code>{esc(dashboard.get('last_watchdog_at') or 'هنوز اجرا نشده')}</code>",
        f"اعلان مدیریتی: <b>{silence_text}</b>",
        "",
        "بررسی خودکار ادامه دارد، اما اعلان تکراری فقط هنگام تغییر مهم یا گزارش روزانه ارسال می‌شود.",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for item in pending[:12]:
        rows.append([
            InlineKeyboardButton(
                f"{_request_icon(item.get('status'))} #{item.get('id')} · {str(item.get('title') or item.get('action'))[:34]}",
                callback_data=f"gov_view:{item.get('id')}",
            )
        ])
    if not pending:
        lines.append("\nدرخواست بازی برای بررسی وجود ندارد.")
    rows.extend([
        [InlineKeyboardButton("🔍 سلامت بررسی‌های خودکار", callback_data="ops_checks"), InlineKeyboardButton("▶️ اجرای بررسی اکنون", callback_data="ops_run")],
        [InlineKeyboardButton("🔕 سکوت ۶ ساعت", callback_data="ops_snooze:360"), InlineKeyboardButton("🌙 سکوت ۲۴ ساعت", callback_data="ops_snooze:1440")],
        [InlineKeyboardButton("🔔 فعال‌کردن اعلان‌ها", callback_data="ops_snooze:0")],
        [InlineKeyboardButton("⚙️ تنظیمات حاکمیت", callback_data="ecc_mod:governance")],
        [InlineKeyboardButton("↩️ سیستم و امنیت", callback_data="admin_cat:system")],
    ])
    return "\n".join(lines), rows


async def _show_governance_home(query: Any) -> None:
    text, rows = _governance_home_content(governance_dashboard(await async_snapshot()))
    await edit(query, text, rows)


async def governance_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return
    text, rows = _governance_home_content(governance_dashboard(await async_snapshot()))
    await reply(update, text, rows)


async def _load_request_with_access(update: Update, request_id: str, *, approval: bool = False) -> dict[str, Any] | None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return None
    db = await async_snapshot()
    row = governance_request(db, request_id)
    if not row:
        query = update.callback_query
        if query:
            await query.answer("درخواست پیدا نشد", show_alert=True)
        return None
    required = str(row.get("required_permission") or PERMISSION_SYSTEM_CONTROL)
    if not await require_admin(update, required):
        return None
    if approval and str(row.get("risk_level")) == "critical":
        if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
            return None
    return row


async def a_ops_governance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return
    query = update.callback_query
    await query.answer()
    await _show_governance_home(query)


async def operations_checks_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return
    query = update.callback_query
    await query.answer()
    dashboard = governance_dashboard(await async_snapshot())
    lines = ["🔍 <b>بررسی‌های خودکار عملیات</b>", ""]
    for item in dashboard["checks"]:
        compact, extra = _compact_health_details(item)
        lines.append(f"{_health_icon(item.get('status'))} <b>{esc(item.get('label') or item.get('key'))}</b>")
        lines.append(f"   <code>{esc(compact)}</code>")
        if extra:
            lines.append(f"   موارد: <code>{esc(extra)}</code>")
    if not dashboard["checks"]:
        lines.append("هنوز بررسی خودکاری اجرا نشده است.")
    await edit(query, "\n".join(lines), [
        [InlineKeyboardButton("▶️ اجرای دوباره", callback_data="ops_run")],
        [InlineKeyboardButton("↩️ مرکز حاکمیت", callback_data="a_ops_governance")],
    ])


async def operations_run_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return
    query = update.callback_query
    await refresh_channel_permission_health(context)
    result = await async_with_db(run_automation_checks)
    summary = result.get("summary", {})
    dashboard = governance_dashboard(await async_snapshot())
    lines = [
        "🔍 <b>بررسی‌های خودکار عملیات</b>",
        "",
        f"نتیجه اجرا: ✅ {summary.get('healthy', 0)} | ⚠️ {summary.get('warning', 0)} | 🔴 {summary.get('critical', 0)} | ℹ️ {summary.get('unknown', 0)}",
        "",
    ]
    for item in dashboard["checks"]:
        compact, extra = _compact_health_details(item)
        lines.append(f"{_health_icon(item.get('status'))} <b>{esc(item.get('label') or item.get('key'))}</b>")
        lines.append(f"   <code>{esc(compact)}</code>")
        if extra:
            lines.append(f"   موارد: <code>{esc(extra)}</code>")
    await query.answer("بررسی خودکار کامل شد ✅")
    await edit(query, "\n".join(lines), [
        [InlineKeyboardButton("▶️ اجرای دوباره", callback_data="ops_run")],
        [InlineKeyboardButton("↩️ مرکز حاکمیت", callback_data="a_ops_governance")],
    ])


async def governance_notification_snooze(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await require_admin(update, PERMISSION_OPERATIONS_GOVERNANCE):
        return
    query = update.callback_query
    try:
        minutes = int(str(query.data or "").split(":", 1)[1])
        result = await async_with_db(
            lambda db: set_governance_notification_snooze(
                db, minutes, query.from_user.id
            )
        )
    except (ValueError, IndexError) as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    if result["silenced"]:
        await query.answer(f"اعلان‌ها برای {result['minutes']} دقیقه متوقف شدند.")
    else:
        await query.answer("اعلان‌های حاکمیت دوباره فعال شدند.")
    await _show_governance_home(query)


def _governance_request_content(
    row: dict[str, Any],
) -> tuple[str, list[list[InlineKeyboardButton]]]:
    approvals = row.get("approvals") if isinstance(row.get("approvals"), list) else []
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    payload_text = "\n".join(
        f"• <code>{esc(key)}</code>: {esc(value)}"
        for key, value in list(payload.items())[:12]
    ) or "• بدون داده"
    lines = [
        f"{_request_icon(row.get('status'))} <b>درخواست #{row.get('id')}</b>",
        "",
        f"عنوان: <b>{esc(row.get('title') or row.get('action'))}</b>",
        f"عملیات: <code>{esc(row.get('action'))}</code>",
        f"وضعیت: <b>{esc(_STATUS_LABELS.get(str(row.get('status')), row.get('status')))}</b>",
        f"ریسک: <b>{esc(_RISK_LABELS.get(str(row.get('risk_level')), row.get('risk_level')))}</b>",
        f"مجوز لازم: <code>{esc(row.get('required_permission'))}</code>",
        f"تأییدها: <b>{len(approvals)}/{int(row.get('required_approvals', 0) or 0)}</b>",
        f"سازنده: <code>{esc(row.get('requested_by'))}</code> | مسئول: <code>{esc(row.get('assigned_to') or 'تخصیص‌نیافته')}</code>",
        f"تلاش اجرا: <b>{int(row.get('attempts', 0) or 0)}</b>",
        "",
        f"<b>شرح</b>\n{esc(row.get('description') or 'ندارد')}",
        "",
        f"<b>داده عملیات</b>\n{payload_text}",
    ]
    if row.get("last_error"):
        lines.extend(["", f"آخرین خطا: <code>{esc(row.get('last_error'))}</code>"])
    rows: list[list[InlineKeyboardButton]] = []
    status = str(row.get("status"))
    if status in {"pending", "pending_second_approval"}:
        rows.append([
            InlineKeyboardButton("✅ تأیید", callback_data=f"gov_approve:{row.get('id')}"),
            InlineKeyboardButton("🚫 رد", callback_data=f"gov_reject:{row.get('id')}"),
        ])
        rows.append([InlineKeyboardButton("👤 تخصیص به من", callback_data=f"gov_assign:{row.get('id')}:self")])
        rows.append([
            InlineKeyboardButton("ریسک کم", callback_data=f"gov_risk:{row.get('id')}:low"),
            InlineKeyboardButton("متوسط", callback_data=f"gov_risk:{row.get('id')}:medium"),
            InlineKeyboardButton("زیاد", callback_data=f"gov_risk:{row.get('id')}:high"),
        ])
    elif status == "failed":
        rows.append([
            InlineKeyboardButton("🔄 تلاش مجدد", callback_data=f"gov_retry:{row.get('id')}"),
            InlineKeyboardButton("🚫 رد", callback_data=f"gov_reject:{row.get('id')}"),
        ])
    if status == "approved":
        rows.append([InlineKeyboardButton("🚀 اجرای عملیات", callback_data=f"gov_apply:{row.get('id')}")])
    if (
        str(row.get("risk_level")) == "critical"
        and status in {"pending", "pending_second_approval", "failed"}
    ):
        rows.append([InlineKeyboardButton("⚠️ تأیید اضطراری مالک", callback_data=f"gov_force:{row.get('id')}")])
    action = str(row.get("action"))
    if action == "control_change" and payload.get("module"):
        rows.append([InlineKeyboardButton("⚙️ ویرایش مستقیم ماژول", callback_data=f"ecc_mod:{payload.get('module')}")])
    rows.append([InlineKeyboardButton("↩️ مرکز حاکمیت", callback_data="a_ops_governance")])
    return "\n".join(lines), rows


async def _render_governance_request(query: Any, row: dict[str, Any]) -> None:
    text, rows = _governance_request_content(row)
    await edit(query, text, rows)


async def governance_request_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    await query.answer()
    await _render_governance_request(query, row)


async def governance_request_approve(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    row = await _load_request_with_access(update, request_id, approval=True)
    if not row:
        return
    try:
        result = await async_with_db(lambda db: approve_governance_request(db, request_id, query.from_user.id))
    except ValueError as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    await query.answer("تأیید ثبت شد ✅", show_alert=True)
    await _render_governance_request(query, result)


async def governance_request_force(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    if not is_admin(query.from_user.id):
        await query.answer("فقط مالک اصلی می‌تواند Override اضطراری انجام دهد.", show_alert=True)
        return
    row = await _load_request_with_access(update, request_id, approval=True)
    if not row:
        return
    try:
        result = await async_with_db(
            lambda db: approve_governance_request(
                db, request_id, query.from_user.id, force=True
            )
        )
    except ValueError as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    await query.answer("Override مالک ثبت شد؛ این اقدام در Audit باقی می‌ماند.", show_alert=True)
    await _render_governance_request(query, result)


async def governance_request_reject(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    try:
        await async_with_db(
            lambda db: reject_governance_request(
                db, request_id, query.from_user.id, "رد از مرکز حاکمیت"
            )
        )
    except ValueError as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    await query.answer("درخواست رد شد", show_alert=True)
    await _show_governance_home(query)


async def governance_request_apply(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    try:
        await async_with_db(lambda db: apply_governance_request(db, request_id, query.from_user.id))
    except (ValueError, KeyError, RuntimeError) as exc:
        await query.answer(f"اجرا نشد: {_governance_error(exc)}", show_alert=True)
        return
    await query.answer("عملیات با موفقیت اجرا شد ✅", show_alert=True)
    await _show_governance_home(query)


async def governance_request_retry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    request_id = str(query.data or "").split(":", 1)[1]
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    try:
        result = await async_with_db(
            lambda db: retry_governance_request(
                db, request_id, query.from_user.id
            )
        )
    except ValueError as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    await query.answer("درخواست برای تلاش مجدد آماده شد ✅")
    await _render_governance_request(query, result)


async def governance_request_assign(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    _, request_id, assignment = str(query.data or "").split(":", 2)
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    assigned = query.from_user.id if assignment == "self" else None
    result = await async_with_db(
        lambda db: edit_governance_request(
            db,
            request_id,
            actor_id=query.from_user.id,
            assigned_to=assigned,
        )
    )
    await query.answer("مسئول بررسی تغییر کرد")
    await _render_governance_request(query, result)


async def governance_request_risk(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    _, request_id, risk = str(query.data or "").split(":", 2)
    row = await _load_request_with_access(update, request_id)
    if not row:
        return
    try:
        result = await async_with_db(
            lambda db: edit_governance_request(
                db,
                request_id,
                actor_id=query.from_user.id,
                risk_level=risk,
            )
        )
    except ValueError as exc:
        await query.answer(_governance_error(exc), show_alert=True)
        return
    await query.answer("سطح ریسک و الزامات تأیید بازتنظیم شد")
    await _render_governance_request(query, result)


__feature_exports__ = (
    "governance_command",
    "a_ops_governance",
    "operations_checks_view",
    "operations_run_now",
    "governance_notification_snooze",
    "governance_request_view",
    "governance_request_approve",
    "governance_request_force",
    "governance_request_reject",
    "governance_request_apply",
    "governance_request_retry",
    "governance_request_assign",
    "governance_request_risk",
)
