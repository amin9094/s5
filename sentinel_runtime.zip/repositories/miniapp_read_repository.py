from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any, TypeVar

from core.db import read_db_sections, with_db_read

T = TypeVar("T")


class MiniAppReadRepository:
    """Explicit read-only boundary for Mini App queries.

    Narrow queries materialize only the logical sections they need. Broad
    compatibility queries remain defensive snapshots and never call a write
    transaction or advance the canonical state version.
    """

    def sections(self, section_keys: Iterable[str]) -> dict[str, Any]:
        return read_db_sections(section_keys)

    def bounded(self, section_keys: Iterable[str], fn: Callable[[dict[str, Any]], T]) -> T:
        return fn(self.sections(section_keys))

    def snapshot(self, fn: Callable[[dict[str, Any]], T]) -> T:
        return with_db_read(fn)


miniapp_reads = MiniAppReadRepository()
