from __future__ import annotations

from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso


class SupportRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def list_all(self, *, cursor=None, limit=100, query='', include_closed=False):
        size = max(1, min(int(limit), 100)); clauses = ['1=1']; params = []
        if not include_closed: clauses.append("status <> 'closed'")
        if query:
            clauses.append('(id LIKE ? OR subject LIKE ? OR user_id LIKE ?)')
            params.extend([f'%{str(query)[:100]}%']*3)
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append('(updated_at < ? OR (updated_at = ? AND id < ?))')
            params.extend([decoded[0], decoded[0], decoded[1]])
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(f"SELECT * FROM v8_tickets WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC,id DESC LIMIT ?", [*params,size+1]).fetchall()  # nosec B608
        more = len(rows)>size; rows=rows[:size]
        return {'items':[self._decode(r) for r in rows], 'next_cursor':encode_cursor(str(rows[-1]['updated_at']),str(rows[-1]['id'])) if more and rows else None}

    def create_ticket(self, user_id: int | str, *, subject: str, body: str, category: str = "general",
                      priority: str = "normal") -> dict[str, Any]:
        now = utc_iso(); ticket_id = new_id("tkt"); message_id = new_id("msg")
        ticket = {
            "id": ticket_id, "user_id": str(user_id), "subject": str(subject).strip()[:120] or "Support",
            "category": str(category)[:40], "priority": str(priority)[:20], "status": "open",
            "created_at": now, "updated_at": now, "messages": [],
        }
        message = {"id":message_id,"ticket_id":ticket_id,"sender_type":"user","sender_id":str(user_id),
                   "body":str(body).strip()[:5000],"created_at":now}
        if not message["body"]:
            raise ValueError("TICKET_TEXT_REQUIRED")
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_tickets(id,user_id,subject,category,priority,status,created_at,updated_at,closed_at,satisfaction,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (ticket_id,str(user_id),ticket["subject"],ticket["category"],ticket["priority"],"open",now,now,None,None,json_dump(ticket)),
            )
            cursor.execute(
                "INSERT INTO v8_ticket_messages(id,ticket_id,sender_type,sender_id,body,created_at,payload) VALUES(?,?,?,?,?,?,?)",
                (message_id,ticket_id,"user",str(user_id),message["body"],now,json_dump(message)),
            )
        return {**ticket,"messages":[message]}

    def get(self, ticket_id: str | int, *, user_id: int | str | None = None) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            if user_id is None:
                row=cursor.execute("SELECT * FROM v8_tickets WHERE id=?",(str(ticket_id),)).fetchone()
            else:
                row=cursor.execute("SELECT * FROM v8_tickets WHERE id=? AND user_id=?",(str(ticket_id),str(user_id))).fetchone()
            if not row: return None
            messages=cursor.execute("SELECT * FROM v8_ticket_messages WHERE ticket_id=? ORDER BY created_at,id",(str(ticket_id),)).fetchall()
        data=self._decode(row); data["messages"]=[self._decode_message(item) for item in messages]; return data

    def append_message(self, ticket_id: str | int, *, sender_type: str, sender_id: str | int, body: str, idempotency_key: str = '') -> dict[str, Any]:
        ticket=self.get(ticket_id)
        if not ticket: raise ValueError("TICKET_NOT_FOUND")
        text=str(body).strip()[:5000]
        if not text: raise ValueError("TICKET_TEXT_REQUIRED")
        import hashlib
        message_id = 'msg_' + hashlib.sha256(f'{ticket_id}:{sender_type}:{sender_id}:{idempotency_key}'.encode()).hexdigest()[:32] if idempotency_key else new_id('msg')
        now=utc_iso(); message={"id":message_id,"ticket_id":str(ticket_id),"sender_type":str(sender_type),
                               "sender_id":str(sender_id),"body":text,"created_at":now}
        with self.engine.transaction() as cursor:
            cursor.execute("INSERT INTO v8_ticket_messages(id,ticket_id,sender_type,sender_id,body,created_at,payload) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
                           (message["id"],str(ticket_id),message["sender_type"],message["sender_id"],text,now,json_dump(message)))
            if cursor.rowcount == 0:
                return self._decode_message(cursor.execute('SELECT * FROM v8_ticket_messages WHERE id=?', (message_id,)).fetchone())
            cursor.execute("UPDATE v8_tickets SET updated_at=?,status=CASE WHEN status='closed' THEN 'open' ELSE status END WHERE id=?",(now,str(ticket_id)))
        return message

    def update_status(self, ticket_id: str | int, *, status: str, satisfaction: int | None = None) -> dict[str, Any]:
        allowed={"open","pending","answered","closed"}; clean=str(status).lower()
        if clean not in allowed: raise ValueError("INVALID_TICKET_STATUS")
        ticket=self.get(ticket_id)
        if not ticket: raise ValueError("TICKET_NOT_FOUND")
        now=utc_iso(); closed_at=now if clean=="closed" else None
        with self.engine.transaction() as cursor:
            cursor.execute("UPDATE v8_tickets SET status=?,updated_at=?,closed_at=?,satisfaction=COALESCE(?,satisfaction) WHERE id=?",
                           (clean,now,closed_at,satisfaction,str(ticket_id)))
        return self.get(ticket_id) or {}

    def list_for_user(self,user_id:int|str,*,cursor:str|None=None,limit:int=30,status:str="")->dict[str,Any]:
        size=max(1,min(int(limit or 30),100)); clauses=["user_id=?"]; params:list[Any]=[str(user_id)]
        if status: clauses.append("status=?"); params.append(str(status))
        decoded=decode_cursor(cursor)
        if decoded: clauses.append("(updated_at < ? OR (updated_at = ? AND id < ?))"); params.extend([decoded[0],decoded[0],decoded[1]])
        params.append(size+1)
        with self.engine.transaction(read_only=True) as db:
            rows=db.execute(f"SELECT * FROM v8_tickets WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC,id DESC LIMIT ?",params).fetchall()  # nosec B608
        more=len(rows)>size; rows=rows[:size]; items=[self._decode(row) for row in rows]
        nxt=encode_cursor(str(rows[-1]["updated_at"]),str(rows[-1]["id"])) if more and rows else None
        return {"items":items,"next_cursor":nxt,"limit":size}

    @staticmethod
    def _decode(row:dict[str,Any])->dict[str,Any]:
        data=json_load(row.get("payload"),{}) or {}; data.update({k:row.get(k) for k in row if k!="payload"}); return data
    @staticmethod
    def _decode_message(row:dict[str,Any])->dict[str,Any]:
        data=json_load(row.get("payload"),{}) or {}; data.update({k:row.get(k) for k in row if k!="payload"}); return data
