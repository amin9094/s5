from __future__ import annotations

from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso


class AdminCommandRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def create(self, actor_id: int | str, command: str, payload: dict[str, Any]) -> dict[str, Any]:
        row = {
            "id": new_id("cmd"),
            "actor_id": str(actor_id),
            "command": str(command),
            "status": "accepted",
            "payload": dict(payload),
            "created_at": utc_iso(),
            "updated_at": utc_iso(),
        }
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_admin_commands(id,actor_id,command,status,created_at,updated_at,payload)
                   VALUES(?,?,?,?,?,?,?)""",
                (row["id"], row["actor_id"], row["command"], row["status"], row["created_at"], row["updated_at"], json_dump(row)),
            )
        return row

    def update(self, command_id: str, *, status: str, result: dict[str, Any] | None = None) -> dict[str, Any]:
        current = self.get(command_id)
        if not current:
            raise ValueError("ADMIN_COMMAND_NOT_FOUND")
        updated = {**current, "status": str(status), "result": dict(result or {}), "updated_at": utc_iso()}
        with self.engine.transaction() as cursor:
            cursor.execute(
                "UPDATE v8_admin_commands SET status=?,updated_at=?,result=?,payload=? WHERE id=?",
                (updated["status"], updated["updated_at"], json_dump(updated.get("result") or {}), json_dump(updated), str(command_id)),
            )
        return updated

    def get(self, command_id: str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_admin_commands WHERE id=?", (str(command_id),)).fetchone()
        if not row:
            return None
        data = json_load(row.get("payload"), {}) or {}
        data.update({key: value for key, value in row.items() if key != "payload"})
        return data

    def list(self, *, cursor: str | None = None, limit: int = 50, command: str = "") -> dict[str, Any]:
        size = max(1, min(int(limit or 50), 100))
        clauses: list[str] = []
        params: list[Any] = []
        if command:
            clauses.append("command=?")
            params.append(str(command))
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(created_at < ? OR (created_at = ? AND id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as cursor_obj:
            rows = cursor_obj.execute(
                f"SELECT * FROM v8_admin_commands{where} ORDER BY created_at DESC,id DESC LIMIT ?",  # nosec B608
                params,
            ).fetchall()
        more = len(rows) > size
        rows = rows[:size]
        items: list[dict[str, Any]] = []
        for row in rows:
            data = json_load(row.get("payload"), {}) or {}
            data.update({key: value for key, value in row.items() if key != "payload"})
            items.append(data)
        next_cursor = encode_cursor(str(rows[-1]["created_at"]), str(rows[-1]["id"])) if more and rows else None
        return {"items": items, "next_cursor": next_cursor, "limit": size}
