from __future__ import annotations

from collections import Counter, defaultdict
from datetime import timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now

_MAX_EVENTS = 50_000
_MAX_SNAPSHOTS = 10_000


def record_channel_event(
    db: dict[str, Any],
    channel: str,
    event: str,
    *,
    success: bool = True,
    user_id: int | str | None = None,
    message_id: int | None = None,
    detail: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    row = {
        "id": next_id(db, "channel_event"),
        "channel": str(channel)[:80],
        "event": str(event)[:80],
        "success": bool(success),
        "user_id": str(user_id or ""),
        "message_id": int(message_id) if message_id else None,
        "detail": str(detail)[:500],
        "metadata": dict(metadata or {}),
        "created_at": utc_iso(),
    }
    rows = db.setdefault("channel_events", [])
    rows.append(row)
    db["channel_events"] = rows[-_MAX_EVENTS:]
    return row


def record_member_snapshot(db: dict[str, Any], channel: str, members: int | None) -> dict[str, Any] | None:
    if members is None or int(members) < 0:
        return None
    rows = db.setdefault("channel_member_snapshots", [])
    now = utc_now()
    latest = next((row for row in reversed(rows) if isinstance(row, dict) and row.get("channel") == channel), None)
    if latest:
        stamp = parse_dt(latest.get("created_at"))
        if stamp and stamp > now - timedelta(minutes=15) and int(latest.get("members", -1)) == int(members):
            return latest
    row = {"channel": channel, "members": int(members), "created_at": utc_iso(now)}
    rows.append(row)
    db["channel_member_snapshots"] = rows[-_MAX_SNAPSHOTS:]
    return row


def channel_analytics(db: dict[str, Any], channel: str, *, days: int = 30) -> dict[str, Any]:
    """Return channel metrics without mixing unrelated operation classes.

    Older releases calculated one success rate across message delivery,
    membership checks and administrative health events.  That made a channel
    with a healthy delivery pipeline look unhealthy merely because Telegram
    temporarily failed a membership lookup.  Metrics are now split into
    delivery, pin and membership families while preserving the legacy keys.
    """
    now = utc_now()
    since = now - timedelta(days=max(1, min(int(days), 365)))
    events = [
        row
        for row in db.get("channel_events", [])
        if isinstance(row, dict) and row.get("channel") == channel and (parse_dt(row.get("created_at")) or now) >= since
    ]
    snapshots = [
        row
        for row in db.get("channel_member_snapshots", [])
        if isinstance(row, dict) and row.get("channel") == channel and (parse_dt(row.get("created_at")) or now) >= since
    ]
    snapshots.sort(key=lambda row: str(row.get("created_at") or ""))
    current_members = int(snapshots[-1].get("members", 0)) if snapshots else None
    first_members = int(snapshots[0].get("members", 0)) if snapshots else None
    growth = current_members - first_members if current_members is not None and first_members is not None else None

    counts = Counter(str(row.get("event") or "unknown") for row in events)
    delivery_names = {"signal_sent", "message_sent"}
    pin_names = {"smart_pin_updated"}
    membership_names = {"membership_check", "membership_passed", "membership_failed"}

    delivery_events = [row for row in events if str(row.get("event") or "") in delivery_names]
    pin_events = [row for row in events if str(row.get("event") or "") in pin_names]
    membership_checks = [row for row in events if str(row.get("event") or "") == "membership_check"]

    delivery_success = sum(1 for row in delivery_events if row.get("success"))
    delivery_failures = len(delivery_events) - delivery_success
    pin_success = sum(1 for row in pin_events if row.get("success"))
    pin_failures = len(pin_events) - pin_success
    membership_passed = counts.get("membership_passed", 0)
    membership_failed = counts.get("membership_failed", 0)
    membership_total = membership_passed + membership_failed
    membership_unknown = sum(
        1 for row in membership_checks if isinstance(row.get("metadata"), dict) and row["metadata"].get("result") is None
    )

    hour_counts: dict[int, int] = defaultdict(int)
    for row in delivery_events + pin_events:
        stamp = parse_dt(row.get("created_at"))
        if stamp and row.get("success"):
            hour_counts[stamp.hour] += 1
    best_hour = max(hour_counts, key=hour_counts.get) if hour_counts else None

    unrelated_events = [row for row in events if str(row.get("event") or "") not in delivery_names | pin_names | membership_names]
    overall_success = sum(1 for row in events if row.get("success"))
    overall_failures = len(events) - overall_success
    return {
        "channel": channel,
        "days": days,
        "events": len(events),
        "success": overall_success,
        "failures": overall_failures,
        # Legacy key now correctly means message-delivery success only.
        "delivery_rate": delivery_success / max(1, len(delivery_events)) * 100,
        "delivery_events": len(delivery_events),
        "delivery_success": delivery_success,
        "delivery_failures": delivery_failures,
        "pin_events": len(pin_events),
        "pin_success": pin_success,
        "pin_failures": pin_failures,
        "pin_success_rate": pin_success / max(1, len(pin_events)) * 100,
        "current_members": current_members,
        "member_growth": growth,
        "member_growth_percent": (growth / first_members * 100) if growth is not None and first_members else None,
        "membership_checks": len(membership_checks),
        "membership_passed": membership_passed,
        "membership_failed": membership_failed,
        "membership_unknown": membership_unknown,
        "membership_pass_rate": membership_passed / max(1, membership_total) * 100,
        "signals_sent": counts.get("signal_sent", 0),
        "smart_pin_updates": counts.get("smart_pin_updated", 0),
        "best_send_hour_utc": best_hour,
        "other_events": len(unrelated_events),
        "event_breakdown": dict(counts),
    }
