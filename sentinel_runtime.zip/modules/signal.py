from __future__ import annotations

import asyncio
import logging
import os
import re
import threading
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from functools import partial
from typing import Any

from telegram import InputMediaPhoto
from telegram.constants import ParseMode
from telegram.error import TelegramError

from config import SETTINGS
from core.async_runtime import run_blocking
from core.db import load_db
from core.utils import esc
from modules.admin_control_center import module_state
from modules.signal_image import DEFAULT_SIGNAL_IMAGE_TEXTS, create_signal_image
from modules.signal_reference import signal_reference
from modules.signal_safety import entry_display
from modules.signal_template_editor import signal_template_background_path, signal_template_layout

logger = logging.getLogger(__name__)

def _signal_chart_photo_ids(signal: dict[str, Any], *, limit: int = 9) -> list[str]:
    """Return a stable, de-duplicated chart-photo list for Telegram albums.

    Telegram media groups allow at most ten items. The generated Sentinel
    template occupies the first slot when enabled, so chart attachments are
    capped at nine. Legacy callers that only provide ``chart_photo_file_id``
    remain fully supported.
    """
    raw_items: list[Any] = []
    multi = signal.get("chart_photo_file_ids")
    if isinstance(multi, (list, tuple)):
        raw_items.extend(multi)
    legacy = signal.get("chart_photo_file_id")
    if legacy:
        raw_items.append(legacy)
    result: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        clean = str(item or "").strip()
        if not clean or clean in seen:
            continue
        seen.add(clean)
        result.append(clean)
        if len(result) >= max(1, min(9, int(limit))):
            break
    return result


_IMAGE_RENDER_LIMITER = threading.BoundedSemaphore(SETTINGS.image_render_concurrency)

_SYMBOL_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9./:_-]{1,23}$")
_PRICE_PATTERN = re.compile(r"^(?:0|[1-9]\d{0,11})(?:\.\d{1,10})?$")
_RISK_PATTERN = re.compile(r"^(?:0|[1-9]\d*)(?:\.\d{1,4})?$")


def signal_image_text_settings() -> dict[str, str]:
    """Return admin-controlled poster strings with safe built-in fallbacks."""
    try:
        state = module_state(load_db(), "signals")
    except Exception:  # pragma: no cover - defensive fallback during bootstrap
        logger.exception("Could not load signal image text settings; using defaults")
        return dict(DEFAULT_SIGNAL_IMAGE_TEXTS)

    resolved = dict(DEFAULT_SIGNAL_IMAGE_TEXTS)
    for key in resolved:
        value = state.get(f"image_{key}")
        if value is None:
            continue
        clean = str(value).strip()
        if clean:
            resolved[key] = clean[:500]
    return resolved


def signal_template_render_settings(side: str) -> tuple[dict[str, Any], str | None]:
    """Load the persistent overlay layout and optional owner-uploaded artwork."""
    try:
        db = load_db()
        return signal_template_layout(db, side), signal_template_background_path(db, side)
    except Exception:  # pragma: no cover - defensive fallback during bootstrap
        logger.exception("Could not load signal template settings; using defaults")
        return signal_template_layout({}, side), None


def signal_template_layout_settings(side: str) -> dict[str, Any]:
    return signal_template_render_settings(side)[0]


def normalize_signal_symbol(symbol: str) -> str:
    """Return a safe broker symbol while preserving the exact instrument identity."""
    value = (symbol or "").strip()
    if not _SYMBOL_PATTERN.fullmatch(value):
        raise ValueError("نماد باید ۲ تا ۲۴ کاراکتر و فقط شامل حروف، عدد، /، -، _، : یا نقطه باشد.")
    return value




def normalize_signal_price(value: str, field: str = "قیمت") -> str:
    """Validate a display-safe positive decimal without scientific notation."""
    text = str(value or "").strip().replace(",", "")
    if not _PRICE_PATTERN.fullmatch(text):
        raise ValueError(f"{field} باید عدد مثبت معمولی با حداکثر ۱۲ رقم صحیح و ۱۰ رقم اعشار باشد.")
    number = _decimal(text, field)
    if number <= 0:
        raise ValueError(f"{field} باید بزرگ‌تر از صفر باشد.")
    return text

def normalize_signal_side(side: str) -> str:
    value = (side or "").strip().lower()
    if value not in {"buy", "sell"}:
        raise ValueError("نوع سیگنال باید BUY یا SELL باشد.")
    return value


def _decimal(value: str, field: str) -> Decimal:
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field} عدد معتبر نیست.") from exc
    if not number.is_finite() or number <= 0:
        raise ValueError(f"{field} باید عددی مثبت و محدود باشد.")
    return number



def normalize_signal_risk(value: str) -> str:
    """Normalize any positive admin-declared risk percentage without a policy ceiling."""
    text = str(value or "").strip().replace("%", "")
    if not _RISK_PATTERN.fullmatch(text):
        raise ValueError("درصد ریسک باید عدد معمولی مثبت با حداکثر ۴ رقم اعشار باشد.")
    number = _decimal(text, "درصد ریسک")
    normalized = format(number.normalize(), "f")
    return normalized.rstrip("0").rstrip(".") if "." in normalized else normalized

def validate_signal_targets(entry: str, targets: list[str], side: str) -> None:
    normalized_side = normalize_signal_side(side)
    entry_value = _decimal(entry, "قیمت ورود")
    target_values = [_decimal(value, f"هدف {index}") for index, value in enumerate(targets, start=1)]
    if not target_values:
        raise ValueError("حداقل یک هدف وارد کنید.")
    if len(set(target_values)) != len(target_values):
        raise ValueError("هدف‌های تکراری مجاز نیستند.")
    if normalized_side == "buy":
        if any(target <= entry_value for target in target_values):
            raise ValueError("در سیگنال BUY، همه اهداف باید بالاتر از قیمت ورود باشند.")
        if any(next_value <= current for current, next_value in zip(target_values, target_values[1:], strict=False)):
            raise ValueError("در سیگنال BUY، هدف‌ها باید به‌ترتیب صعودی وارد شوند.")
    else:
        if any(target >= entry_value for target in target_values):
            raise ValueError("در سیگنال SELL، همه اهداف باید پایین‌تر از قیمت ورود باشند.")
        if any(next_value >= current for current, next_value in zip(target_values, target_values[1:], strict=False)):
            raise ValueError("در سیگنال SELL، هدف‌ها باید به‌ترتیب نزولی وارد شوند.")


def validate_signal_stop(entry: str, stop: str, side: str) -> None:
    normalized_side = normalize_signal_side(side)
    entry_value = _decimal(entry, "قیمت ورود")
    stop_value = _decimal(stop, "حد ضرر")
    if normalized_side == "buy" and stop_value >= entry_value:
        raise ValueError("در سیگنال BUY، حد ضرر باید پایین‌تر از قیمت ورود باشد.")
    if normalized_side == "sell" and stop_value <= entry_value:
        raise ValueError("در سیگنال SELL، حد ضرر باید بالاتر از قیمت ورود باشد.")


def validate_signal_levels(entry: str, targets: list[str], stop: str, side: str) -> None:
    """Validate that SL/TP levels agree with the selected BUY/SELL direction."""
    validate_signal_targets(entry, targets, side)
    validate_signal_stop(entry, stop, side)


def create_signal(
    symbol: str,
    entry: str,
    targets: list[str],
    stop: str,
    side: str,
    risk: str,
    *,
    brand_handle: str | None = None,
    entries: list[str] | None = None,
    timeframe: str = "1H",
    analysis: str = "TECHNICAL",
    volatility: str = "MEDIUM",
    strategy: str = "TREND FOLLOWING",
    confidence: str = "HIGH",
    notes: list[str] | None = None,
    signal_id: int | None = None,
    message_channel_id: str = "",
) -> dict[str, Any]:
    clean_symbol = normalize_signal_symbol(symbol)
    clean_side = normalize_signal_side(side)
    clean_entry = normalize_signal_price(entry, "قیمت ورود")
    clean_entries = [normalize_signal_price(value, f"ورود {index}") for index, value in enumerate(entries or [clean_entry], start=1)]
    clean_targets = [normalize_signal_price(value, f"هدف {index}") for index, value in enumerate(targets, start=1)]
    clean_stop = normalize_signal_price(stop, "حد ضرر")
    clean_risk = normalize_signal_risk(risk)
    for item in clean_entries:
        validate_signal_levels(item, clean_targets, clean_stop, clean_side)
    image_entry = entry_display(clean_entries)

    label = "🟢 BUY" if clean_side == "buy" else "🔴 SELL"
    target_lines = "\n".join(f"🎯 TP{index}: <code>{esc(value)}</code>" for index, value in enumerate(clean_targets, start=1))
    reference_line = f"🆔 شناسه سیگنال: <code>{signal_reference(signal_id)}</code>\n" if signal_id is not None else ""
    if len(clean_entries) == 1:
        entry_lines = f"📍 نقطه ورود: <code>{esc(clean_entries[0])}</code>"
    else:
        entry_lines = (
            f"📍 محدوده ورود: <code>{esc(image_entry)}</code>\n"
            f"🔹 ورودهای ثبت‌شده: <code>{esc(' | '.join(clean_entries))}</code>"
        )
    channel_footer = str(message_channel_id or "").strip()
    text = (
        f"<b>{label} SIGNAL</b>\n"
        f"{reference_line}\n"
        f"📌 نماد: <b>{esc(clean_symbol)}</b>\n"
        f"{entry_lines}\n"
        f"{target_lines}\n"
        f"🛑 حد ضرر: <code>{esc(clean_stop)}</code>\n"
        f"⚡ ریسک: <b>{esc(clean_risk)}%</b>\n\n"
        "<i>مدیریت سرمایه و حد ضرر را رعایت کنید.</i>"
        + (f"\n\n{esc(channel_footer)}" if channel_footer else "")
    )
    template_layout, template_path = signal_template_render_settings(clean_side)
    image_path = create_signal_image(
        symbol=clean_symbol,
        entry=image_entry,
        tp_values=clean_targets,
        sl=clean_stop,
        signal_type=clean_side,
        risk=clean_risk,
        channel_id=brand_handle or SETTINGS.signal_brand_handle,
        brand_name=SETTINGS.signal_brand_name,
        timeframe=timeframe,
        analysis=analysis,
        volatility=volatility,
        strategy=strategy,
        confidence=confidence,
        notes=notes,
        created_at=datetime.now(UTC),
        signal_id=signal_id,
        text_overrides=signal_image_text_settings(),
        layout_overrides=template_layout,
        template_path=template_path,
    )
    return {
        "text": text,
        "image_path": image_path,
        "symbol": clean_symbol,
        "side": clean_side,
        "signal_id": signal_id,
        "meta": {
            "risk": clean_risk,
            "entries": clean_entries,
            "entry_display": image_entry,
            "timeframe": timeframe,
            "analysis": analysis,
            "volatility": volatility,
            "strategy": strategy,
            "confidence": confidence,
            "notes": notes or [],
        },
    }


async def create_signal_async(
    symbol: str,
    entry: str,
    targets: list[str],
    stop: str,
    side: str,
    risk: str,
    *,
    brand_handle: str | None = None,
    entries: list[str] | None = None,
    timeframe: str = "1H",
    analysis: str = "TECHNICAL",
    volatility: str = "MEDIUM",
    strategy: str = "TREND FOLLOWING",
    confidence: str = "HIGH",
    notes: list[str] | None = None,
    signal_id: int | None = None,
    message_channel_id: str = "",
) -> dict[str, Any]:
    """Build a signal in the dedicated image-render thread pool.

    Pillow rendering is CPU-bound and synchronous. Running the complete signal
    build in this bounded executor keeps the Telegram event loop responsive and
    prevents an unbounded number of concurrent image renders.
    """
    job = partial(
        create_signal,
        symbol,
        entry,
        targets,
        stop,
        side,
        risk,
        brand_handle=brand_handle,
        entries=entries,
        timeframe=timeframe,
        analysis=analysis,
        volatility=volatility,
        strategy=strategy,
        confidence=confidence,
        notes=notes,
        signal_id=signal_id,
        message_channel_id=message_channel_id,
    )
    def run_limited() -> dict[str, Any]:
        thread = threading.current_thread()
        original_name = thread.name
        thread.name = f"signal-image-{thread.ident or 0}"
        try:
            with _IMAGE_RENDER_LIMITER:
                return job()
        finally:
            thread.name = original_name

    # ``asyncio.to_thread`` uses the event loop's managed executor. Unlike a
    # process-wide ThreadPoolExecutor, it is shut down with the loop and cannot
    # keep tests or graceful application shutdown hanging indefinitely.
    return await run_blocking(run_limited, timeout=60)


async def send_signal_with_receipts(
    bot,
    signal: dict[str, Any],
    target: str,
    public_channel_id: int,
    private_channel_id: int,
) -> tuple[list[str], list[dict[str, Any]]]:
    requested: list[tuple[str, str, int]] = []
    if target in {"public", "both"}:
        requested.append(("public", "عمومی", int(public_channel_id or 0)))
    if target in {"private", "both"}:
        requested.append(("private", "خصوصی", int(private_channel_id or 0)))

    # A common deployment mistake is assigning the same Telegram channel ID to
    # both PUBLIC_CHANNEL_ID and PRIVATE_CHANNEL_ID. Sending once per logical
    # destination would then create duplicate posts in the same channel. Group
    # logical destinations by chat ID and send only one Telegram message while
    # retaining a delivery receipt for every requested channel.
    grouped: dict[int, list[tuple[str, str]]] = {}
    errors: list[str] = []
    for channel, label, chat_id in requested:
        if not chat_id:
            errors.append(f"{label}: شناسه کانال تنظیم نشده")
            continue
        grouped.setdefault(chat_id, []).append((channel, label))

    deliveries: list[dict[str, Any]] = []
    image_path = signal.get("image_path")
    chart_photo_file_ids = _signal_chart_photo_ids(signal)
    chart_photo_file_id = chart_photo_file_ids[0] if chart_photo_file_ids else ""
    # The global admin switch is copied into the signal payload at publish time.
    # Missing values default to True for backward compatibility with existing
    # scheduled signals and direct module callers.
    send_template_image = bool(signal.get("send_template_image", True))
    template_image_ready = bool(send_template_image and image_path and os.path.exists(image_path))
    try:
        for chat_id, aliases in grouped.items():
            try:
                message_ids: list[int] = []
                chart_message_id: int | None = None
                chart_message_ids: list[int] = []
                media_group_id: str | None = None
                if template_image_ready and chart_photo_file_ids:
                    # Keep the generated branded card first and put the only
                    # caption on that slide. The remaining chart photos are
                    # intentionally captionless so Telegram renders a clean
                    # swipeable album instead of repeating text on every slide.
                    with open(image_path, "rb") as photo:
                        media = [InputMediaPhoto(media=photo, caption=signal["text"], parse_mode=ParseMode.HTML)]
                        media.extend(InputMediaPhoto(media=file_id) for file_id in chart_photo_file_ids[:9])
                        messages = await bot.send_media_group(chat_id=chat_id, media=media[:10])
                    if not messages:
                        raise TelegramError("empty media group response")
                    message = messages[0]
                    message_ids = [int(item.message_id) for item in messages]
                    media_group_ids = {
                        str(getattr(item, "media_group_id", "") or "").strip()
                        for item in messages
                        if str(getattr(item, "media_group_id", "") or "").strip()
                    }
                    if len(media_group_ids) > 1:
                        raise TelegramError("inconsistent media group response")
                    media_group_id = next(iter(media_group_ids), None)
                    chart_message_id = message_ids[1] if len(message_ids) > 1 else None
                    chart_message_ids = message_ids[1:]
                    message_type = "media_group"
                elif (not template_image_ready) and len(chart_photo_file_ids) >= 2:
                    media = [InputMediaPhoto(media=chart_photo_file_ids[0], caption=signal["text"], parse_mode=ParseMode.HTML)]
                    media.extend(InputMediaPhoto(media=file_id) for file_id in chart_photo_file_ids[1:10])
                    messages = await bot.send_media_group(chat_id=chat_id, media=media[:10])
                    if not messages:
                        raise TelegramError("empty media group response")
                    message = messages[0]
                    message_ids = [int(item.message_id) for item in messages]
                    media_group_ids = {
                        str(getattr(item, "media_group_id", "") or "").strip()
                        for item in messages
                        if str(getattr(item, "media_group_id", "") or "").strip()
                    }
                    if len(media_group_ids) > 1:
                        raise TelegramError("inconsistent media group response")
                    media_group_id = next(iter(media_group_ids), None)
                    chart_message_id = message_ids[0]
                    chart_message_ids = list(message_ids)
                    message_type = "media_group"
                elif template_image_ready:
                    with open(image_path, "rb") as photo:
                        message = await bot.send_photo(chat_id, photo, caption=signal["text"], parse_mode=ParseMode.HTML)
                    message_ids = [int(message.message_id)]
                    message_type = "photo"
                elif chart_photo_file_id:
                    # Defensive fallback: a chart is still delivered if image
                    # rendering unexpectedly fails before this function.
                    message = await bot.send_photo(
                        chat_id, chart_photo_file_id, caption=signal["text"], parse_mode=ParseMode.HTML
                    )
                    message_ids = [int(message.message_id)]
                    chart_message_id = int(message.message_id)
                    chart_message_ids = [int(message.message_id)]
                    message_type = "chart_photo"
                else:
                    message = await bot.send_message(chat_id, signal["text"], parse_mode=ParseMode.HTML)
                    message_ids = [int(message.message_id)]
                    message_type = "text"
                for channel, _label in aliases:
                    deliveries.append({
                        "channel": channel,
                        "chat_id": int(chat_id),
                        "message_id": int(message.message_id),
                        "message_ids": list(message_ids),
                        "chart_message_id": chart_message_id,
                        "chart_message_ids": list(chart_message_ids),
                        "media_group_id": media_group_id,
                        "message_type": message_type,
                        "deduplicated_destination": len(aliases) > 1,
                    })
            except TelegramError:
                logger.exception("Signal send failed for chat_id=%s", chat_id)
                errors.extend(f"{label}: ارسال ناموفق" for _channel, label in aliases)
    finally:
        if image_path and os.path.exists(image_path):
            try:
                os.remove(image_path)
            except OSError:
                logger.warning("Could not delete generated signal image %s", image_path)
    return errors, deliveries


async def send_signal(bot, signal: dict[str, Any], target: str, public_channel_id: int, private_channel_id: int) -> list[str]:
    errors, _ = await send_signal_with_receipts(bot, signal, target, public_channel_id, private_channel_id)
    return errors


def shutdown_signal_executor() -> None:
    """Compatibility hook; render workers are owned by the active event loop."""
    return None
