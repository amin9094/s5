from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

from core.http_client import get_json
from modules.market_catalog import ASSET_BY_SYMBOL
from modules.prices import normalize_market_symbol

logger = logging.getLogger(__name__)

CRYPTO_PAIRS = {
    "BTCUSD": "BTCUSDT",
    "BTCUSDT": "BTCUSDT",
    "ETHUSD": "ETHUSDT",
    "ETHUSDT": "ETHUSDT",
    "SOLUSD": "SOLUSDT",
    "SOLUSDT": "SOLUSDT",
    "BNBUSD": "BNBUSDT",
    "BNBUSDT": "BNBUSDT",
}
YAHOO_SYMBOLS = {
    "US100": "^NDX",
    "GER40": "^GDAXI",
    "US500": "^GSPC",
    "US30": "^DJI",
    "UK100": "^FTSE",
    "JP225": "^N225",
    "HK50": "^HSI",
    "VIX": "^VIX",
    "DXY": "DX-Y.NYB",
    "XAUUSD": "GC=F",
    "XAGUSD": "SI=F",
    "WTI": "CL=F",
    "BRENT": "BZ=F",
    "NATGAS": "NG=F",
    "COPPER": "HG=F",
    "PLATINUM": "PL=F",
    "PALLADIUM": "PA=F",
    "WHEAT": "ZW=F",
    "CORN": "ZC=F",
    "COFFEE": "KC=F",
    "SUGAR": "SB=F",
    "COTTON": "CT=F",
}
_FIAT = {
    "USD",
    "EUR",
    "GBP",
    "JPY",
    "CHF",
    "CAD",
    "AUD",
    "NZD",
    "CNY",
    "HKD",
    "SGD",
    "SEK",
    "NOK",
    "DKK",
    "PLN",
    "CZK",
    "HUF",
    "TRY",
    "AED",
    "SAR",
    "ZAR",
    "MXN",
    "BRL",
    "INR",
    "KRW",
    "IDR",
    "THB",
    "MYR",
    "PHP",
    "ILS",
}


@dataclass(frozen=True, slots=True)
class MarketRange:
    symbol: str
    low: float
    high: float
    close: float
    opened_at: str
    closed_at: str
    source: str
    interval: str
    stale: bool = False
    delayed: bool = False
    fallback: bool = False
    confidence: float = 1.0
    fetched_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    @property
    def age_seconds(self) -> float:
        try:
            market_time = datetime.fromisoformat(self.closed_at.replace("Z", "+00:00"))
            if market_time.tzinfo is None:
                market_time = market_time.replace(tzinfo=UTC)
            return max(0.0, (datetime.now(UTC) - market_time.astimezone(UTC)).total_seconds())
        except (TypeError, ValueError):
            return 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "low": self.low,
            "high": self.high,
            "close": self.close,
            "opened_at": self.opened_at,
            "closed_at": self.closed_at,
            "source": self.source,
            "interval": self.interval,
            "stale": self.stale,
            "delayed": self.delayed,
            "fallback": self.fallback,
            "confidence": max(0.0, min(1.0, float(self.confidence))),
            "fetched_at": self.fetched_at,
            "market_timestamp": self.closed_at,
            "age_seconds": round(self.age_seconds, 3),
        }


async def _json(url: str, *, params: dict[str, Any] | None = None) -> Any:
    return await get_json(url, params=params, headers={"User-Agent": "SENTINELBot/5.2"}, retries=2)


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number > 0 else None


async def _binance_range(symbol: str, interval: str, limit: int) -> MarketRange:
    pair = CRYPTO_PAIRS.get(symbol)
    if pair is None:
        pair = symbol if symbol.endswith("USDT") else f"{symbol[:-3]}USDT" if symbol.endswith("USD") else ""
    if not pair:
        raise ValueError("Binance pair is unavailable")
    payload = await _json(
        "https://api.binance.com/api/v3/klines",
        params={"symbol": pair, "interval": interval, "limit": max(1, min(limit, 100))},
    )
    if not isinstance(payload, list) or not payload:
        raise RuntimeError("Binance candle response is empty")
    lows = [_finite(row[3]) for row in payload if isinstance(row, list) and len(row) >= 7]
    highs = [_finite(row[2]) for row in payload if isinstance(row, list) and len(row) >= 7]
    closes = [_finite(row[4]) for row in payload if isinstance(row, list) and len(row) >= 7]
    valid_lows = [value for value in lows if value is not None]
    valid_highs = [value for value in highs if value is not None]
    valid_closes = [value for value in closes if value is not None]
    if not valid_lows or not valid_highs or not valid_closes:
        raise RuntimeError("Binance candle values are invalid")
    first = payload[0]
    last = payload[-1]
    return MarketRange(
        symbol=symbol,
        low=min(valid_lows),
        high=max(valid_highs),
        close=valid_closes[-1],
        opened_at=datetime.fromtimestamp(int(first[0]) / 1000, UTC).isoformat(),
        closed_at=datetime.fromtimestamp(int(last[6]) / 1000, UTC).isoformat(),
        source="binance_klines",
        interval=interval,
    )


async def _yahoo_range(symbol: str, interval: str, lookback: str, *, ticker: str | None = None) -> MarketRange:
    ticker = ticker or YAHOO_SYMBOLS.get(symbol)
    if not ticker:
        raise ValueError("Yahoo mapping is unavailable")
    payload = await _json(
        f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(ticker, safe='')}",
        params={"interval": interval, "range": lookback, "includePrePost": "true"},
    )
    result = (((payload or {}).get("chart") or {}).get("result") or [None])[0]
    if not isinstance(result, dict):
        raise RuntimeError("Yahoo candle response is unavailable")
    timestamps = result.get("timestamp") or []
    quote_rows = ((result.get("indicators") or {}).get("quote") or [None])[0] or {}
    lows = [_finite(value) for value in quote_rows.get("low", [])]
    highs = [_finite(value) for value in quote_rows.get("high", [])]
    closes = [_finite(value) for value in quote_rows.get("close", [])]
    valid_lows = [value for value in lows if value is not None]
    valid_highs = [value for value in highs if value is not None]
    valid_closes = [value for value in closes if value is not None]
    if not valid_lows or not valid_highs or not valid_closes or not timestamps:
        raise RuntimeError("Yahoo candle values are invalid")
    return MarketRange(
        symbol=symbol,
        low=min(valid_lows),
        high=max(valid_highs),
        close=valid_closes[-1],
        opened_at=datetime.fromtimestamp(int(timestamps[0]), UTC).isoformat(),
        closed_at=datetime.fromtimestamp(int(timestamps[-1]), UTC).isoformat(),
        source="yahoo_chart",
        interval=interval,
    )


async def fetch_market_range(
    symbol: str,
    *,
    interval: str = "5m",
    limit: int = 3,
    snapshot_fallback: bool = True,
) -> MarketRange:
    clean = normalize_market_symbol(symbol)
    errors: list[str] = []
    asset = ASSET_BY_SYMBOL.get(clean)
    category = asset.category if asset is not None else ""
    possible_crypto = (
        category == "crypto"
        or clean.endswith("USDT")
        or (clean.endswith("USD") and category not in {"forex", "metals"} and 2 <= len(clean[:-3]) <= 10)
    )
    if possible_crypto:
        try:
            return await _binance_range(clean, interval, limit)
        except Exception as exc:
            errors.append(f"binance:{exc.__class__.__name__}")

    yahoo_ticker = YAHOO_SYMBOLS.get(clean)
    if yahoo_ticker is None and len(clean) == 6 and clean[:3] in _FIAT and clean[3:] in _FIAT:
        yahoo_ticker = f"{clean}=X"
    if yahoo_ticker is None and category == "stocks":
        yahoo_ticker = clean
    if yahoo_ticker is None and category == "" and not clean.endswith(("USD", "USDT")):
        # Arbitrary safe stock/ETF tickers accepted by the public market lookup
        # should also be trackable by the signal engine.
        yahoo_ticker = clean
    if yahoo_ticker:
        try:
            lookback = "1d" if interval in {"1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h"} else "5d"
            yahoo_interval = "5m" if interval not in {"1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h", "1d"} else interval
            return await _yahoo_range(clean, yahoo_interval, lookback, ticker=yahoo_ticker)
        except Exception as exc:
            errors.append(f"yahoo:{exc.__class__.__name__}")
    if snapshot_fallback:
        from modules.prices import fetch_price

        value = await fetch_price(clean)
        now = datetime.now(UTC).isoformat()
        return MarketRange(
            symbol=clean,
            low=value,
            high=value,
            close=value,
            opened_at=now,
            closed_at=now,
            source="snapshot_fallback:" + (",".join(errors) or "unsupported_candle_source"),
            interval="snapshot",
            # A point-in-time quote is useful for a manual proposal, but it is
            # not an OHLC candle and cannot prove the order in which entry, TP
            # or SL levels were crossed. Never auto-publish from this fallback.
            stale=True,
            delayed=True,
            fallback=True,
            confidence=0.35,
        )
    raise RuntimeError("Market candle sources failed: " + ",".join(errors))


async def fetch_ranges(symbols: set[str], *, concurrency: int = 4) -> dict[str, MarketRange]:
    semaphore = asyncio.Semaphore(max(1, min(concurrency, 10)))

    async def one(symbol: str) -> tuple[str, MarketRange | None]:
        async with semaphore:
            try:
                return symbol, await fetch_market_range(symbol)
            except Exception:
                logger.warning("Could not fetch market range for %s", symbol, exc_info=True)
                return symbol, None

    results = await asyncio.gather(*(one(symbol) for symbol in sorted(symbols)))
    return {symbol: value for symbol, value in results if value is not None}
