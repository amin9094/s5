"""Compensating entries in the existing economy; never erase grant evidence.

All mutations run in the canonical transaction. Historical grants with missing
provenance are retained for authorized review instead of guessing ownership.
"""

from __future__ import annotations

from datetime import timedelta

from core.economy_integrity import economic_event
from core.utils import parse_dt, utc_iso, utc_now


def outstanding_point_debt(db, user_id):
    uid = str(user_id)
    owed = sum(
        int(e.get("metadata", {}).get("unrecovered_points", 0))
        for e in db.get("economic_events", {}).values()
        if e.get("kind") == "points_reversal" and str(e.get("user_id")) == uid
    )
    paid = sum(
        int(e.get("value", 0))
        for e in db.get("economic_events", {}).values()
        if e.get("kind") == "points_debt_repayment" and str(e.get("user_id")) == uid
    )
    return max(0, owed - paid)


def reverse_points(db, uid, amount, source, actor):
    from core.domain import add_points

    key = f"points_reversal:{uid}:{source}"
    if key in db.get("economic_events", {}):
        return
    amount = max(0, int(amount))
    available = max(0, int(db.get("user_points", {}).get(str(uid), 0)))
    recovered = min(amount, available)
    economic_event(
        db,
        key,
        uid,
        kind="points_reversal",
        value=amount,
        actor=actor,
        reason="full purchase refund",
        metadata={"original_source": source, "unrecovered_points": amount - recovered},
    )
    if recovered:
        add_points(db, uid, -recovered, "purchase_refund", source_event=f"points:{key}", actor=actor)


def reverse_vip(db, uid, source, actor):
    from core.domain import vip_record

    uid = str(uid)
    key = f"vip_reversal:{uid}:{source}"
    if key in db.get("economic_events", {}):
        return True
    grant = db.get("economic_events", {}).get(f"vip_grant:{uid}:{source}")
    if not grant:
        return False
    meta = grant["metadata"]
    start, end = parse_dt(meta.get("starts_at")), parse_dt(meta.get("expires_at"))
    if not start or not end or end < start:
        return False
    # Earlier refunds shift queued grants forward. Grants created after a refund
    # already use the shortened authoritative expiry and must not shift twice.
    # Explicit comparisons avoid chained-comparison ambiguity and only include
    # reversals that occurred after this grant was created.
    shift = 0.0
    for event in db.get("economic_events", {}).values():
        prior_end = parse_dt(event.get("metadata", {}).get("grant_end"))
        if (
            event.get("kind") == "vip_reversal"
            and str(event.get("user_id")) == uid
            and prior_end
            and prior_end <= start
            and str(event.get("timestamp", "")) >= str(grant.get("timestamp", ""))
        ):
            shift += float(event["value"])
    now = utc_now()
    remaining = max(
        0.0, ((end - timedelta(seconds=shift)) - max(now, start - timedelta(seconds=shift))).total_seconds()
    )
    current = vip_record(db, uid) or {}
    expiry = parse_dt(current.get("expires_at"))
    withdrawn = min(remaining, max(0.0, (expiry - now).total_seconds())) if expiry else 0.0
    adjusted = max(now, expiry - timedelta(seconds=withdrawn)) if expiry else now
    record = dict(db.get("vip_users", {}).get(uid, {}) or current)
    record.update(expires_at=utc_iso(adjusted), status="active" if adjusted > now else "expired", updated_at=utc_iso())
    db.setdefault("vip_users", {})[uid] = record
    economic_event(
        db,
        key,
        uid,
        kind="vip_reversal",
        value=withdrawn,
        actor=actor,
        reason="full purchase refund",
        metadata={
            "original_source": source,
            "grant_start": meta["starts_at"],
            "grant_end": meta["expires_at"],
            "expires_at": record["expires_at"],
            "status": record["status"],
        },
    )
    return True


def resolve_order(db, order_id):
    row = next((r for r in db.get("vip_orders", []) if str(r.get("order_id")) == str(order_id)), None)
    if row is not None:
        return row, False
    from repositories.v2.commerce import CommerceRepository

    row = CommerceRepository().get(str(order_id))
    return ({**row, "order_id": str(row.get("id") or order_id)} if row else None), True


def reverse_purchase_points(db, order_id, uid, actor):
    """Reverse gross grant effect, including points used to repay earlier debt.

    Older releases reversed only the net balance credit. A replay can repair
    that shortfall with a separate immutable compensating source.
    """
    rows = [
        row
        for row in db.get("point_history", [])
        if str(row.get("user_id")) == str(uid)
        and (row.get("source_event") == f"vip_purchase:{order_id}" or row.get("reason") == f"vip_purchase:{order_id}")
        and int(row.get("requested_amount", row.get("amount", 0))) > 0
    ]
    for row in rows:
        source = str(row.get("source_event") or row["id"])
        amount = int(row.get("requested_amount", row["amount"]))
        prior = db.get("economic_events", {}).get(f"points_reversal:{uid}:{source}")
        if not prior:
            reverse_points(db, uid, amount, source, actor)
        elif int(prior["value"]) < amount:
            reverse_points(db, uid, amount - int(prior["value"]), f"refund_adjustment:{source}", actor)
    return rows


def repair_refunded_purchase_points(db, limit=50):
    """Repair only recorded full refunds with immutable gross-grant evidence."""
    repaired = 0
    for event in list(db.get("economic_events", {}).values()):
        source = str(event.get("source", ""))
        if (
            event.get("kind") != "order_refund"
            or not source.startswith("order_refund:")
            or not source.endswith(":full")
        ):
            continue
        oid = source[len("order_refund:") : -len(":full")]
        before = len(db.get("economic_events", {}))
        reverse_purchase_points(db, oid, str(event["user_id"]), "refund_reconciliation")
        if len(db.get("economic_events", {})) > before:
            repaired += 1
        if repaired >= limit:
            break
    return repaired


def notification_order_snapshot(db, order):
    oid = str(order.get("order_id") or order.get("id") or "")
    current, _ = resolve_order(db, oid)
    if current and f"order_refund:{oid}:full" in db.get("economic_events", {}):
        current = {**current, "refund_status": "full"}
    return current


def refund_invite_due(order):
    due = parse_dt(order.get("refund_invite_next_retry_at"))
    return (
        order.get("refund_status") == "full"
        and bool(order.get("invite_link"))
        and order.get("refund_invite_status") != "revoked"
        and int(order.get("refund_invite_attempts", 0)) < 8
        and (not due or due <= utc_now())
    )


def refund_invite_result(order, success, error=""):
    if order.get("refund_status") != "full" or order.get("refund_invite_status") == "revoked":
        return
    attempts = int(order.get("refund_invite_attempts", 0)) + 1
    order.update(
        refund_invite_attempts=attempts,
        refund_invite_status="revoked" if success else ("failed" if attempts >= 8 else "pending"),
        refund_invite_last_error=str(error)[:100],
        refund_invite_next_retry_at=utc_iso(utc_now() + timedelta(seconds=min(3600, 30 * 2 ** min(attempts, 7)))),
    )
    if success:
        order["refund_invite_revoked_at"] = utc_iso()


def record_order_refund(db, order_id, refund_type, actor):
    from core.domain import audit
    from modules.discount_campaigns import settle_discount_for_order
    from modules.incident_center import record_incident

    if refund_type not in {"full", "partial"}:
        raise ValueError("REFUND_TYPE_INVALID")
    order, normalized = resolve_order(db, order_id)
    if not order or order.get("status") != "approved":
        raise ValueError("APPROVED_ORDER_REQUIRED")
    source = f"order_refund:{order_id}:{refund_type}"
    old = db.get("economic_events", {}).get(source)
    if old:
        if refund_type == "full":
            reverse_purchase_points(db, order_id, str(order["user_id"]), actor)
        return dict(old["metadata"]["result"]), bool(old["metadata"]["result"].get("discount_restored_after_refund"))
    if (order.get("refund_status") == "full" and refund_type != "full") or (
        order.get("refund_status") == "partial" and refund_type == "partial"
    ):
        raise ValueError("REFUND_ALREADY_RECORDED")
    item = settle_discount_for_order(db, order, "refunded", refund_type=refund_type, reason=f"admin:{actor}")
    restored = bool(item and str(order_id) in item.get("restored_refund_order_ids", []))
    review = []
    uid = str(order["user_id"])
    if refund_type == "full":
        # Immutable purchase sources, including legacy point rows with a reason.
        rows = reverse_purchase_points(db, order_id, uid, actor)
        if order.get("purchase_points_awarded") and not rows:
            review.append("historical purchase points without ledger")
        if order.get("vip_grant"):
            meta = order["vip_grant"]
            economic_event(
                db,
                f"vip_grant:{uid}:{order_id}",
                uid,
                kind="vip_grant",
                value=meta["seconds"],
                actor=order.get("approved_by", "payment_service"),
                metadata=meta,
            )
        gifts = [
            gift
            for gift in db.get("vip_gifts", {}).values()
            if str(gift.get("order_id")) == str(order_id)
            or (order.get("gift_id") and str(gift.get("gift_id")) == str(order["gift_id"]))
        ]
        if gifts:
            for gift in gifts:
                recipient = str(gift.get("redeemed_by") or "")
                if recipient and not reverse_vip(db, recipient, f"gift:{gift['gift_id']}", actor):
                    review.append("historical redeemed gift without source interval")
                gift.update(status="cancelled", refunded_at=utc_iso(), refunded_by=str(actor))
                economic_event(
                    db,
                    f"gift_refund:{gift['gift_id']}",
                    uid,
                    kind="gift_refund",
                    value=1,
                    actor=actor,
                    metadata={"gift_id": gift["gift_id"], "recipient": recipient, "payment_id": str(order_id)},
                )
                for reward in db.get("user_rewards", []):
                    if reward.get("source") == "gift_vip" and str(reward.get("reference_id")) == str(gift["gift_id"]):
                        reward["status"] = "cancelled"
        elif not reverse_vip(db, uid, str(order_id), actor):
            review.append("historical purchased VIP without source interval")
        ref_event = db.get("economic_events", {}).get(f"referral_purchase:{order_id}")
        if ref_event:
            referrer = ref_event["user_id"]
            economic_event(
                db,
                f"referral_purchase_reversal:{order_id}",
                referrer,
                kind="referral_purchase_reversal",
                value=ref_event["value"],
                actor=actor,
                metadata={"original_source": f"referral_purchase:{order_id}"},
            )
            # Future milestones read only verified, non-refunded purchases.
            from core.economy_integrity import verified_referral_activity

            _, purchases = verified_referral_activity(db, referrer)
            referral = db.get("user_referrals", {}).get(str(referrer), {})
            referral["purchasers"] = sorted({p[0] for p in purchases.values()})
            referral["purchase_count"] = len(referral["purchasers"])
            referral.get("purchase_amounts", {}).pop(str(order_id), None)
            from core.domain import referral_program_settings

            required = max(1, int(referral_program_settings(db)["purchase_required"]))
            eligible_batches = referral["purchase_count"] // required
            for grant in list(db.get("economic_events", {}).values()):
                if grant.get("kind") != "vip_days" or not str(grant.get("source", "")).startswith(
                    f"referral_vip:{referrer}:"
                ):
                    continue
                if int(str(grant["source"]).rsplit(":", 1)[1]) <= eligible_batches:
                    continue
                grant_source = f"referral:{grant.get('metadata', {}).get('payment_id')}"
                if not reverse_vip(db, referrer, grant_source, actor):
                    review.append("historical referral VIP without source interval")
                for reward in db.get("user_rewards", []):
                    if reward.get("reference_id") == grant_source:
                        reward["status"] = "cancelled"
            from modules.referral_milestones import milestone_progress

            eligible = {str(r["id"]): r for r in milestone_progress(db, referrer)}
            for event in list(db.get("economic_events", {}).values()):
                meta = event.get("metadata", {})
                milestone = eligible.get(str(meta.get("milestone")))
                if not str(event.get("source", "")).startswith("referral_milestone:") or event["user_id"] != str(
                    referrer
                ):
                    continue
                if str(order_id) not in meta.get("payment_ids", []):
                    if "payment_ids" not in meta:
                        review.append("historical referral milestone without payment provenance")
                    continue
                if not milestone:
                    review.append("removed referral milestone requires review")
                    continue
                if milestone["trigger_type"] == "referrals_joined":
                    continue
                needed = int(milestone["required_count"]) * int(meta.get("cycle", 1))
                if int(milestone["progress"]) >= needed:
                    continue
                if event["kind"] == "points":
                    reverse_points(db, referrer, event["value"], event["source"], actor)
                elif event["kind"] == "vip_days":
                    if not reverse_vip(db, referrer, event["source"], actor):
                        review.append("milestone VIP missing interval")
                else:
                    reward = next((r for r in db.get("user_rewards", []) if r.get("id") == meta.get("reward_id")), None)
                    coupon = db.get("discount_codes", {}).get(str((reward or {}).get("reference_id")))
                    if coupon and not coupon.get("used_at") and not coupon.get("reserved_order_id"):
                        coupon["status"] = "disabled"
                    else:
                        review.append("consumed coupon or custom prize requires review")
                for reward in db.get("user_rewards", []):
                    if reward.get("id") == meta.get("reward_id"):
                        reward["status"] = "cancelled"
        for reward in db.get("user_rewards", []):
            if reward.get("reference_id") == str(order_id):
                reward["status"] = "cancelled"
    update = {
        "refund_status": refund_type,
        "refunded_at": utc_iso(),
        "refunded_by": str(actor),
        "discount_restored_after_refund": restored,
        "refund_review_required": bool(review),
        "refund_review_reasons": sorted(set(review)),
    }
    if refund_type == "full":
        update.update(
            user_notification_status="cancelled_refund",
            refund_invite_status="pending" if order.get("invite_link") else "not_required",
            refund_invite_attempts=0,
            refund_invite_next_retry_at=None,
        )
    order.update(update)
    economic_event(
        db,
        source,
        uid,
        kind="order_refund",
        value=1,
        actor=actor,
        metadata={
            "normalized": normalized,
            "order_updated_at": order.get("updated_at"),
            "order_id": str(order_id),
            "refund": update,
            "result": dict(order),
        },
    )
    if review:
        record_incident(
            db,
            source="payment_refund",
            kind="economic_reversal_review",
            detail=f"order={order_id}; " + "; ".join(sorted(set(review))),
            severity="critical",
        )
    audit(db, actor, "order_refund_recorded", f"{order_id}:{refund_type}:review={bool(review)}")
    return dict(order), restored
