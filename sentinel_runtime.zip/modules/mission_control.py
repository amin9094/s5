from __future__ import annotations

from typing import Any

from modules.analyst_dashboard import all_analyst_dashboards
from modules.incident_center import incident_summary
from modules.payment_reconciliation import reconciliation_summary
from modules.provider_health import provider_health_summary
from modules.risk_exposure import professional_exposure_boards
from modules.signal_safety import pending_signal_approvals


def mission_control_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    signals = [row for row in db.get("signals", []) if isinstance(row, dict)]
    open_signals = [
        row
        for row in signals
        if str(row.get("status") or "open")
        not in {"target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}
    ]
    orders = [row for row in db.get("vip_orders", []) if isinstance(row, dict)]
    incidents = incident_summary(db)
    risk = professional_exposure_boards(db)
    analysts = all_analyst_dashboards(db)
    return {
        "attention": {
            "pending_signal_approvals": len(pending_signal_approvals(db)),
            "pending_orders": sum(
                1 for row in orders if str(row.get("status") or "") in {"pending", "approving", "awaiting_payment"}
            ),
            "critical_incidents": int(incidents.get("critical", 0) or 0),
            "open_incidents": int(incidents.get("open", 0) or 0),
            "failed_deliveries": sum(
                1 for row in signals[-250:] if row.get("errors") or row.get("delivery_status") == "failed"
            ),
        },
        "trading": {
            "open_signals": len(open_signals),
            "risk": risk["executive"],
            "markets": risk["markets"],
        },
        "commerce": reconciliation_summary(db),
        "providers": provider_health_summary(db),
        "analysts": analysts,
        "latest_incidents": incidents.get("latest", [])[:8],
    }

