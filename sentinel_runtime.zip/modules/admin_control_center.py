from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.utils import utc_iso
from modules.signal_image import DEFAULT_SIGNAL_IMAGE_TEXTS

CONTROL_SCHEMA_VERSION = 7


@dataclass(frozen=True, slots=True)
class ControlField:
    key: str
    label: str
    kind: str
    default: Any
    minimum: float | None = None
    maximum: float | None = None
    choices: tuple[str, ...] = ()
    help_text: str = ""


@dataclass(frozen=True, slots=True)
class ControlModule:
    key: str
    category: str
    label: str
    description: str
    fields: tuple[ControlField, ...]


CATEGORIES: dict[str, tuple[str, str]] = {
    "content": ("📚 محتوا و تعامل", "آموزش، مأموریت، FAQ، پشتیبانی و اعلان‌ها"),
    "trading": ("📡 معامله و سیگنال", "پرتال سیگنال، چرخه معامله، هشدار و ریسک"),
    "market": ("💹 بازار و اطلاعات", "قیمت‌ها، رمزارز، سهام، انرژی، تقویم و خبر"),
    "growth": ("🏆 رشد و باشگاه", "لیگ، مسابقه، جوایز، معرفی دوستان و حساب"),
    "management": ("👥 مدیریت و عملیات", "داشبورد، CRM، ارسال همگانی، مدیران و شیفت"),
    "system": ("⚙️ زیرساخت و امنیت", "بکاپ، سلامت، دیتابیس، مانیتورینگ و امنیت"),
}


def B(key: str, label: str, default: bool = True, help_text: str = "") -> ControlField:
    return ControlField(key, label, "bool", default, help_text=help_text)


def INT(key: str, label: str, default: int, minimum: int, maximum: int, help_text: str = "") -> ControlField:
    return ControlField(key, label, "int", default, minimum, maximum, help_text=help_text)


def F(key: str, label: str, default: float, minimum: float, maximum: float, help_text: str = "") -> ControlField:
    return ControlField(key, label, "float", default, minimum, maximum, help_text=help_text)


def S(key: str, label: str, default: str, help_text: str = "") -> ControlField:
    return ControlField(key, label, "str", default, help_text=help_text)


def C(key: str, label: str, default: str, *choices: str, help_text: str = "") -> ControlField:
    return ControlField(key, label, "choice", default, choices=tuple(choices), help_text=help_text)


MODULES: tuple[ControlModule, ...] = (
    ControlModule("edu", "content", "🎓 آموزش", "دوره‌ها، درس‌ها، پیشرفت و محتوای چندرسانه‌ای", (
        B("enabled", "فعال بودن آموزش"), B("drafts", "پیش‌نویس و انتشار"), B("chapters", "فصل‌بندی دوره"),
        B("progress", "ثبت پیشرفت کاربر"), B("quiz", "آزمون پایان درس"), B("certificate", "گواهی پایان دوره"),
        B("rating", "امتیاز و نظر کاربران"), B("anti_forward", "محافظت از محتوای حساس"),
        B("publish_notice", "اعلان انتشار درس"), INT("max_upload_mb", "حداکثر فایل آموزشی (MB)", 50, 1, 2000),
    )),
    ControlModule("missions", "content", "✅ مأموریت‌ها", "مأموریت روزانه، هفتگی، زنجیره‌ای و پاداش", (
        B("enabled", "فعال بودن مأموریت‌ها"), B("daily", "مأموریت روزانه"), B("weekly", "مأموریت هفتگی"),
        B("monthly", "مأموریت ماهانه"), B("streak", "حضور متوالی"), B("chains", "مأموریت زنجیره‌ای"),
        B("random_reward", "جایزه تصادفی"), INT("max_daily_points", "سقف امتیاز روزانه", 100, 0, 100000),
        INT("reset_hour", "ساعت بازنشانی", 0, 0, 23),
    )),
    ControlModule("faq", "content", "❓ سوالات متداول", "جستجو، دسته‌بندی، بازخورد و پیشنهاد هوشمند", (
        B("enabled", "فعال بودن FAQ"), B("search", "جستجوی سوالات"), B("categories", "دسته‌بندی"),
        B("feedback", "مفید بود/نبود"), B("suggestions", "پیشنهاد خودکار"), B("popular", "نمایش محبوب‌ها"),
        INT("max_items", "حداکثر تعداد سوال", 500, 10, 10000),
    )),
    ControlModule("support", "content", "🎫 پشتیبانی", "تیکت، فایل، SLA، یادداشت داخلی و پاسخ آماده", (
        B("enabled", "فعال بودن پشتیبانی"), B("attachments", "پیوست عکس/فایل/صدا"), B("private_notes", "یادداشت خصوصی ادمین"),
        B("canned_replies", "پاسخ‌های آماده"), B("merge", "ادغام تیکت"), B("escalation", "ارجاع خودکار"),
        INT("max_open", "حداکثر تیکت باز هر کاربر", 3, 1, 50), INT("max_attachment_mb", "حداکثر پیوست (MB)", 20, 1, 200),
        INT("sla_urgent_h", "SLA فوری (ساعت)", 2, 1, 168), INT("sla_normal_h", "SLA عادی (ساعت)", 24, 1, 720),
    )),
    ControlModule("notify", "content", "🔔 مرکز اعلان", "پیش‌فرض اعلان‌ها، ساعات سکوت و خلاصه‌ها", (
        B("enabled", "فعال بودن مرکز اعلان"), B("signals", "اعلان سیگنال"), B("results", "اعلان نتیجه سیگنال"),
        B("news", "اعلان خبر مهم"), B("calendar", "اعلان تقویم اقتصادی"), B("contests", "اعلان مسابقه"),
        B("missions", "اعلان مأموریت"), B("education", "اعلان آموزش"), B("support", "اعلان پشتیبانی"),
        B("alerts", "اعلان هشدار قیمت"), B("retention", "یادآوری اشتراک و سفارش"),
        B("daily_digest", "خلاصه روزانه", False), B("weekly_digest", "خلاصه هفتگی", False),
        S("quiet_start", "شروع سکوت", "23:00"), S("quiet_end", "پایان سکوت", "07:00"),
    )),
    ControlModule("subscriptions", "growth", "💳 خرید و مدیریت اشتراک", "خرید VIP، تمدید و پیگیری سفارش کاربر", (
        B("enabled", "فعال بودن خرید و مدیریت اشتراک"),
    )),
    ControlModule("rules", "content", "📜 قوانین استفاده", "نمایش و پذیرش قوانین پیش از ورود به امکانات ربات", (
        B("enabled", "فعال بودن الزام پذیرش قوانین"),
    )),
    ControlModule("alerts", "trading", "🔔 هشدار قیمت", "هشدار تکراری، درصدی، نزدیکی قیمت و تاریخچه", (
        B("enabled", "فعال بودن هشدار قیمت"), B("recurring", "هشدار تکرارشونده"), B("percent_change", "هشدار درصد تغییر"),
        B("proximity", "هشدار نزدیک‌شدن"), B("quiet_hours", "رعایت ساعات سکوت"), B("history", "نگهداری تاریخچه"),
        INT("max_per_user", "حداکثر هشدار هر کاربر", 25, 1, 500), INT("check_seconds", "فاصله بررسی (ثانیه)", 60, 15, 3600),
    )),
    ControlModule("portal", "trading", "📊 پرتال سیگنال", "فیلترها، واچ‌لیست و ژورنال شخصی", (
        B("enabled", "فعال بودن پرتال"), B("filters", "فیلتر پیشرفته"), B("watchlist", "واچ‌لیست"),
        B("journal", "ژورنال معاملاتی"), B("personal_pnl", "سود و زیان شخصی"), B("equity_chart", "نمودار سرمایه"),
        B("export", "خروجی ژورنال"), INT("history_limit", "تعداد سیگنال قابل نمایش", 100, 10, 5000),
    )),
    ControlModule("watchlists", "trading", "⭐ واچ‌لیست", "نمادهای منتخب، اعلان و محدودیت دارایی", (
        B("enabled", "فعال بودن واچ‌لیست"), B("price_notifications", "اعلان تغییر قیمت"),
        B("admin_visibility", "نمایش برای ادمین"), B("market_groups", "گروه‌بندی بازارها"),
        INT("max_assets", "حداکثر نماد هر کاربر", 30, 1, 500),
    )),
    ControlModule("journal", "trading", "📔 ژورنال معاملاتی", "ثبت معامله، سود و زیان، خروجی و آمار سرمایه", (
        B("enabled", "فعال بودن ژورنال"), B("auto_from_signal", "ثبت خودکار سیگنال گرفته‌شده"),
        B("personal_pnl", "ثبت سود و زیان"), B("equity", "محاسبه شاخص سرمایه"), B("export", "خروجی CSV"),
        B("admin_notes", "یادداشت ادمین"), INT("max_entries", "حداکثر رکورد هر کاربر", 1000, 10, 100000),
    )),
    ControlModule("signals", "trading", "📡 مدیریت سیگنال", "قالب و تمام متن‌های تصویر، Draft، Partial، Trailing و گزارش", (
        B("enabled", "فعال بودن سیگنال"), B("drafts", "پیش‌نویس"), B("templates", "قالب سیگنال"),
        B("send_template_image", "ارسال تصویر قالب همراه سیگنال", True),
        B("partial_close", "بستن مرحله‌ای"), B("trailing_stop", "Trailing Stop"), B("break_even", "قانون Break Even"),
        B("owner_approval", "تأیید سیگنال توسط مالک اصلی", False), B("news_guard", "محافظ خبر مهم"), B("news_guard_fail_closed", "توقف انتشار در خطای تقویم", True),
        B("block_opposite", "جلوگیری از سیگنال متضاد", True),
        INT("max_open", "حداکثر سیگنال باز", 20, 1, 500),
        INT("max_same_symbol_open", "حداکثر سیگنال باز برای هر نماد", 1, 1, 20),
        INT("expiry_hours", "انقضای پیش‌فرض (ساعت)", 48, 1, 720),
        INT("news_guard_minutes", "فاصله امن خبر مهم (دقیقه)", 30, 0, 360),
        INT("approval_expiry_minutes", "مهلت تأیید مالک (دقیقه)", 30, 5, 1440),
        F("max_risk_percent", "حداکثر ریسک هر سیگنال (%)", 2.0, 0.1, 20.0),
        B("exposure_guard", "گیت ریسک تجمیعی", True),
        B("correlation_guard", "کنترل هم‌بستگی دارایی‌ها", True),
        F("max_total_open_risk", "سقف ریسک باز کل (%)", 8.0, 0.5, 100.0),
        F("max_market_open_risk", "سقف ریسک هر بازار (%)", 5.0, 0.5, 100.0),
        F("max_symbol_open_risk", "سقف ریسک هر نماد (%)", 3.0, 0.1, 50.0),
        F("max_correlated_risk", "سقف ریسک هم‌بسته (%)", 6.0, 0.5, 100.0),
        F("max_daily_new_risk", "سقف ریسک سیگنال‌های روز (%)", 10.0, 0.5, 200.0),
        B("signal_versioning", "نسخه‌بندی ویرایش سیگنال", True),
        B("market_sessions", "ثبت سشن بازار", True),
        B("smart_followup", "پیگیری هوشمند مرحله‌ای", True),
        S("image_brand_name", "نام برند روی تصویر", DEFAULT_SIGNAL_IMAGE_TEXTS["brand_name"]),
        S("image_brand_handle", "آیدی برند روی تصویر", DEFAULT_SIGNAL_IMAGE_TEXTS["brand_handle"]),
        S("image_tagline", "شعار بالای تصویر", DEFAULT_SIGNAL_IMAGE_TEXTS["tagline"]),
        S("image_signal_type_label", "عنوان نوع سیگنال", DEFAULT_SIGNAL_IMAGE_TEXTS["signal_type_label"]),
        S("image_signal_number_prefix", "پیشوند شماره سیگنال", DEFAULT_SIGNAL_IMAGE_TEXTS["signal_number_prefix"]),
        S("image_symbol_label", "عنوان نماد", DEFAULT_SIGNAL_IMAGE_TEXTS["symbol_label"]),
        S("image_entry_label", "عنوان ورود", DEFAULT_SIGNAL_IMAGE_TEXTS["entry_label"]),
        S("image_entry_icon", "متن آیکن ورود", DEFAULT_SIGNAL_IMAGE_TEXTS["entry_icon"]),
        S("image_stop_loss_label", "عنوان حد ضرر", DEFAULT_SIGNAL_IMAGE_TEXTS["stop_loss_label"]),
        S("image_stop_loss_icon", "متن آیکن حد ضرر", DEFAULT_SIGNAL_IMAGE_TEXTS["stop_loss_icon"]),
        S("image_take_profit_label", "عنوان تارگت", DEFAULT_SIGNAL_IMAGE_TEXTS["take_profit_label"]),
        S("image_target_singular_label", "عنوان یک تارگت", DEFAULT_SIGNAL_IMAGE_TEXTS["target_singular_label"]),
        S("image_target_plural_label", "عنوان چند تارگت", DEFAULT_SIGNAL_IMAGE_TEXTS["target_plural_label"]),
        S("image_risk_label", "عنوان ریسک", DEFAULT_SIGNAL_IMAGE_TEXTS["risk_label"]),
        S("image_risk_icon", "متن آیکن ریسک", DEFAULT_SIGNAL_IMAGE_TEXTS["risk_icon"]),
        S("image_market_momentum_label", "عنوان مومنتوم بازار", DEFAULT_SIGNAL_IMAGE_TEXTS["market_momentum_label"]),
        S("image_bullish_label", "متن روند صعودی", DEFAULT_SIGNAL_IMAGE_TEXTS["bullish_label"]),
        S("image_bearish_label", "متن روند نزولی", DEFAULT_SIGNAL_IMAGE_TEXTS["bearish_label"]),
        S("image_date_label", "عنوان تاریخ", DEFAULT_SIGNAL_IMAGE_TEXTS["date_label"]),
        S("image_time_label", "عنوان زمان", DEFAULT_SIGNAL_IMAGE_TEXTS["time_label"]),
        S("image_timeframe_label", "عنوان تایم‌فریم", DEFAULT_SIGNAL_IMAGE_TEXTS["timeframe_label"]),
        S("image_trend_label", "عنوان روند", DEFAULT_SIGNAL_IMAGE_TEXTS["trend_label"]),
        S("image_analysis_label", "عنوان تحلیل", DEFAULT_SIGNAL_IMAGE_TEXTS["analysis_label"]),
        S("image_volatility_label", "عنوان نوسان", DEFAULT_SIGNAL_IMAGE_TEXTS["volatility_label"]),
        S("image_strategy_label", "عنوان استراتژی", DEFAULT_SIGNAL_IMAGE_TEXTS["strategy_label"]),
        S("image_confidence_label", "عنوان اطمینان", DEFAULT_SIGNAL_IMAGE_TEXTS["confidence_label"]),
        S("image_notes_label", "عنوان یادداشت‌ها", DEFAULT_SIGNAL_IMAGE_TEXTS["notes_label"]),
        S("image_principle_1_title", "عنوان اصل اول", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_1_title"]),
        S("image_principle_1_subtitle", "زیرعنوان اصل اول", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_1_subtitle"]),
        S("image_principle_2_title", "عنوان اصل دوم", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_2_title"]),
        S("image_principle_2_subtitle", "زیرعنوان اصل دوم", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_2_subtitle"]),
        S("image_principle_3_title", "عنوان اصل سوم", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_3_title"]),
        S("image_principle_3_subtitle", "زیرعنوان اصل سوم", DEFAULT_SIGNAL_IMAGE_TEXTS["principle_3_subtitle"]),
        S("image_footer_slogan", "شعار پایین تصویر", DEFAULT_SIGNAL_IMAGE_TEXTS["footer_slogan"]),
        S("image_default_note_1", "یادداشت پیش‌فرض اول", DEFAULT_SIGNAL_IMAGE_TEXTS["default_note_1"]),
        S("image_default_note_2", "یادداشت پیش‌فرض دوم", DEFAULT_SIGNAL_IMAGE_TEXTS["default_note_2"]),
        S("image_default_note_3", "یادداشت پیش‌فرض سوم", DEFAULT_SIGNAL_IMAGE_TEXTS["default_note_3"]),
    )),
    ControlModule("tracker", "trading", "🛰 ردیاب بازار", "Failover، تشخیص قیمت غیرعادی و کنترل Provider", (
        B("enabled", "فعال بودن ردیاب"), B("multi_provider", "چند Provider"), B("auto_failover", "Failover خودکار"),
        B("outlier_detection", "تشخیص قیمت غیرعادی"), B("spread_guard", "کنترل Spread"), B("market_hours", "کنترل ساعات بازار"),
        B("replay", "ثبت Replay خطا"), INT("interval_seconds", "فاصله ردیابی", 180, 30, 3600),
        INT("max_failures", "حد خطای متوالی", 5, 1, 100),
    )),
    ControlModule("risk", "trading", "🧮 مدیریت ریسک", "Pip، Margin، Drawdown، Compound و Prop Firm", (
        B("enabled", "فعال بودن ماشین‌حساب"), B("pip_value", "محاسبه Pip Value"), B("margin", "محاسبه Margin"),
        B("drawdown", "محاسبه Drawdown"), B("compound", "رشد مرکب"), B("partial", "Partial Close"),
        B("prop_profiles", "پروفایل Prop Firm"), F("max_risk_pct", "حداکثر ریسک مجاز (%)", 5.0, 0.1, 100.0),
    )),
    ControlModule("channels", "trading", "📺 کانال‌ها", "چند کانال، قالب، زمان‌بندی و گزارش ارسال", (
        B("enabled", "فعال بودن مدیریت کانال"), B("multi_channel", "چند کانال"), B("templates", "قالب جداگانه"),
        B("recurring", "ارسال تکرارشونده"), B("best_time", "پیشنهاد زمان انتشار"), B("archive", "آرشیو پیام"),
        B("permission_watch", "پایش دسترسی ربات"), INT("schedule_limit", "حداکثر زمان‌بندی", 500, 10, 10000),
    )),
    ControlModule("prices", "market", "💹 قیمت بازار", "نمودار، تاریخچه، مقایسه و واچ‌لیست", (
        B("enabled", "فعال بودن قیمت بازار"), B("charts", "نمودار قیمت"), B("history", "تاریخچه"),
        B("watchlist", "واچ‌لیست"), B("compare", "مقایسه دارایی"), B("market_status", "وضعیت بازار"),
        B("share_snapshot", "تصویر اشتراک‌گذاری"), INT("cache_seconds", "کش قیمت (ثانیه)", 30, 1, 3600),
    )),
    ControlModule("crypto", "market", "🪙 رمزارز", "چند صرافی، ترندها، Dominance و نوسان", (
        B("enabled", "فعال بودن رمزارز"), B("charts", "نمودار"), B("multi_exchange", "چند صرافی"),
        B("trending", "ارزهای ترند"), B("gainers", "برندگان/بازندگان"), B("dominance", "Dominance"),
        B("fear_greed", "Fear & Greed"), B("volatility_alert", "هشدار نوسان"), INT("top_limit", "تعداد فهرست برتر", 20, 5, 200),
    )),
    ControlModule("stocks", "market", "🏛 سهام جهانی", "Fundamental، Earnings، Dividend و After-hours", (
        B("enabled", "فعال بودن سهام"), B("charts", "نمودار"), B("fundamentals", "اطلاعات بنیادی"),
        B("earnings", "تقویم Earnings"), B("dividends", "سود تقسیمی"), B("extended_hours", "Pre/After Market"),
        B("comparison", "مقایسه سهام"), INT("requests_per_minute", "حد درخواست API در دقیقه", 5, 1, 500),
    )),
    ControlModule("energy", "market", "🛢 انرژی و اقتصاد", "نفت، گاز، DXY، اوراق و گزارش EIA", (
        B("enabled", "فعال بودن انرژی"), B("wti", "WTI"), B("brent", "Brent"), B("natural_gas", "Natural Gas"),
        B("dxy", "شاخص دلار"), B("bonds", "بازده اوراق"), B("eia", "گزارش EIA"), B("charts", "نمودار روند"),
    )),
    ControlModule("calendar", "market", "🗓 تقویم اقتصادی", "فیلتر، Reminder، Actual و محافظ خبر", (
        B("enabled", "فعال بودن تقویم"), B("filters", "فیلتر کشور/ارز/اهمیت"), B("reminders", "یادآوری قبل خبر"),
        B("actual_alert", "اعلان Actual"), B("history", "تاریخچه رویداد"), B("countdown", "شمارش معکوس"),
        B("signal_guard", "توقف سیگنال نزدیک خبر"), INT("reminder_minutes", "دقیقه یادآوری", 30, 1, 1440),
    )),
    ControlModule("news", "market", "📰 خبر و تحلیل", "حذف تکراری، ترجمه، اعتبار منبع و Sentiment", (
        B("enabled", "فعال بودن خبر"), B("deduplicate", "حذف خبر تکراری"), B("translation", "ترجمه فارسی"),
        B("source_score", "امتیاز اعتبار منبع"), B("sentiment", "تحلیل Sentiment"), B("asset_link", "ارتباط خبر با دارایی"),
        B("breaking", "خبر فوری"), B("daily_report", "گزارش روزانه"), INT("retention_days", "نگهداری خبر (روز)", 30, 1, 3650),
    )),
    ControlModule("league", "growth", "🏅 لیگ و فصل", "فصل، صعود/سقوط، تاریخچه و تالار افتخار", (
        B("enabled", "فعال بودن لیگ"), B("seasons", "فصل‌های لیگ"), B("promotion", "صعود و سقوط"),
        B("weekly", "رتبه هفتگی"), B("monthly", "رتبه ماهانه"), B("hall_of_fame", "تالار افتخار"),
        INT("season_days", "طول فصل (روز)", 30, 7, 365), INT("bronze_min", "حد برنز", 0, 0, 10000000),
        INT("silver_min", "حد نقره", 100, 0, 10000000), INT("gold_min", "حد طلا", 200, 0, 10000000),
        INT("diamond_min", "حد الماس", 500, 0, 10000000),
    )),
    ControlModule("contests", "growth", "🎯 مسابقه‌ها", "فصل، Tournament، ضدتقلب و زمان‌بندی", (
        B("enabled", "فعال بودن مسابقه"), B("seasons", "فصل مسابقات"), B("tournament", "Tournament"),
        B("multi_question", "چند سؤال"), B("countdown", "شمارش معکوس"), B("anti_cheat", "ضدتقلب"),
        B("speed_bonus", "امتیاز سرعت"), B("scheduled", "شروع زمان‌بندی‌شده"), INT("max_entries", "حد شرکت‌کنندگان", 10000, 10, 1000000),
    )),
    ControlModule("rewards", "growth", "🎁 امتیاز و جوایز", "موجودی، انقضا، Badge و وضعیت تحویل", (
        B("enabled", "فعال بودن جوایز"), B("expiry", "انقضای امتیاز"), B("pending_points", "امتیاز Pending"),
        B("anti_fraud", "قوانین ضدتقلب"), B("badges", "Badge و Achievement"), B("inventory", "موجودی محدود"),
        B("delivery_tracking", "رهگیری تحویل"), INT("daily_earn_cap", "سقف دریافت روزانه", 500, 0, 1000000),
    )),
    ControlModule("referrals", "growth", "👥 معرفی دوستان", "کمپین، QR، ضدتقلب و Conversion", (
        B("enabled", "فعال بودن معرفی"), B("anti_fraud", "ضدتقلب"), B("campaigns", "لینک کمپینی"),
        B("qr", "QR Code"), B("leaderboard", "رتبه معرف‌ها"), B("multi_stage", "جایزه چندمرحله‌ای"),
        INT("reward_batch_size", "تعداد دعوت هر پاداش", 5, 1, 1000), INT("reward_points", "امتیاز هر مرحله", 2, 0, 100000),
    )),
    ControlModule("account", "growth", "👤 حساب کاربری", "زبان، منطقه زمانی، واچ‌لیست و گزارش ماهانه", (
        B("enabled", "فعال بودن حساب"), B("language", "انتخاب زبان"), B("timezone", "انتخاب منطقه زمانی"),
        B("watchlist", "واچ‌لیست"), B("activity_history", "تاریخچه فعالیت"), B("monthly_report", "گزارش ماهانه"),
        B("device_sessions", "مدیریت دستگاه‌ها"),
    )),
    ControlModule("privacy", "growth", "🔐 حریم خصوصی", "خروجی امن، رضایت، اصلاح و حذف اطلاعات", (
        B("enabled", "فعال بودن حریم خصوصی"), B("encrypted_export", "خروجی رمزگذاری‌شده"), B("consent_log", "ثبت رضایت"),
        B("policy_versions", "نسخه‌بندی سیاست"), B("rectification", "درخواست اصلاح"), B("processing_limit", "محدودسازی پردازش"),
        INT("export_cooldown_h", "فاصله خروجی (ساعت)", 24, 0, 8760), INT("delete_grace_days", "مهلت حذف (روز)", 7, 1, 90),
    )),
    ControlModule("dashboard", "management", "📊 داشبورد ادمین", "KPI، نمودار، سلامت سرویس و خروجی گزارش", (
        B("enabled", "فعال بودن داشبورد"), B("charts", "نمودارهای مدیریتی"), B("date_filters", "فیلتر تاریخ"),
        B("custom_kpi", "KPI قابل تنظیم"), B("online_users", "کاربران آنلاین"), B("service_health", "سلامت سرویس‌ها"),
        B("pdf_report", "خروجی PDF"), INT("refresh_seconds", "فاصله بروزرسانی", 60, 10, 3600),
    )),
    ControlModule("crm", "management", "🗂 CRM", "Pipeline، امتیاز Lead، Segment و Follow-up", (
        B("enabled", "فعال بودن CRM"), B("pipeline", "Pipeline و Kanban"), B("custom_fields", "فیلد سفارشی"),
        B("advanced_segments", "Segment پیشرفته"), B("lead_score", "امتیاز Lead"), B("churn_risk", "ریسک ریزش"),
        B("bulk_edit", "ویرایش گروهی"), INT("followup_reminder_h", "یادآوری Follow-up", 24, 1, 720),
    )),
    ControlModule("broadcast", "management", "📣 ارسال همگانی", "رسانه، زمان‌بندی، A/B و گزارش", (
        B("enabled", "فعال بودن ارسال"), B("media", "عکس/ویدئو/فایل"), B("buttons", "دکمه شیشه‌ای"),
        B("scheduled", "زمان‌بندی"), B("test_send", "ارسال آزمایشی"), B("ab_test", "A/B Test"),
        B("click_tracking", "رهگیری کلیک"), INT("batch_size", "اندازه Batch", 25, 1, 100), INT("rate_per_second", "حد ارسال در ثانیه", 20, 1, 30),
    )),
    ControlModule("admins", "management", "👮 مدیران و مجوزها", "نقش، دسترسی موقت، نشست و گزارش تغییرات", (
        B("enabled", "فعال بودن مدیریت مدیران"), B("roles", "نقش‌های آماده"), B("custom_roles", "نقش سفارشی"),
        B("temporary_access", "دسترسی موقت"), B("session_log", "گزارش نشست"), B("read_only", "مجوز فقط خواندنی"),
        B("channel_scope", "مجوز در سطح کانال"),
    )),
    ControlModule("shifts", "management", "🕒 شیفت مدیران", "تقویم، جانشین، جابه‌جایی و توزیع تیکت", (
        B("enabled", "فعال بودن شیفت"), B("recurring", "شیفت تکرارشونده"), B("holidays", "تعطیلات"),
        B("substitute", "جانشین"), B("swap", "جابه‌جایی شیفت"), B("auto_ticket_assign", "توزیع خودکار تیکت"),
        B("attendance", "ثبت حضور"),
    )),
    ControlModule("automation", "management", "🤖 اتوماسیون", "Rule Engine، شرط ترکیبی، Dry Run و Retry", (
        B("enabled", "فعال بودن اتوماسیون"), B("rule_engine", "Rule Engine"), B("combined_conditions", "شرط ترکیبی"),
        B("multiple_actions", "چند Action"), B("dry_run", "Dry Run"), B("retry", "Retry"),
        B("loop_guard", "جلوگیری از Loop"), INT("max_rules", "حداکثر Rule", 200, 1, 10000),
    )),
    ControlModule("exports", "management", "📦 خروجی اطلاعات", "CSV/XLSX/JSON/PDF، رمزگذاری و لینک موقت", (
        B("enabled", "فعال بودن خروجی"), B("csv", "CSV"), B("xlsx", "XLSX"), B("json", "JSON"), B("pdf", "PDF"),
        B("encrypted", "رمزگذاری"), B("mask_sensitive", "ماسک اطلاعات حساس"), B("scheduled", "خروجی زمان‌بندی‌شده"),
        INT("max_rows", "حداکثر ردیف", 100000, 100, 5000000),
    )),
    ControlModule("audit", "management", "📜 Audit و لاگ", "Diff، Severity، Correlation ID و هشدار مشکوک", (
        B("enabled", "فعال بودن Audit"), B("before_after", "ثبت قبل و بعد"), B("ip_session", "IP و Session"),
        B("severity", "سطح اهمیت"), B("tamper_guard", "محافظت تغییر"), B("suspicious_alert", "هشدار عملیات مشکوک"),
        B("correlation_id", "Correlation ID"), INT("retention_days", "نگهداری لاگ (روز)", 365, 7, 3650),
    )),
    ControlModule("incidents", "system", "🚨 مرکز رخدادها", "ثبت، تجمیع، تأیید و رفع خطاهای عملیاتی", (
        B("enabled", "فعال بودن مرکز رخداد"), B("dedupe", "ادغام خطاهای تکراری"), B("notify_critical", "اعلان رخداد بحرانی"),
        INT("dedupe_minutes", "بازه ادغام رخداد (دقیقه)", 15, 1, 1440), INT("retention_days", "نگهداری رخداد (روز)", 180, 7, 3650),
    )),
    ControlModule("retention", "growth", "🧲 نگهداشت مشترک", "پایان VIP، خرید نیمه‌کاره و کاربر کم‌فعالیت", (
        B("enabled", "فعال بودن موتور نگهداشت"), B("vip_expiring", "پیگیری VIP رو به پایان"),
        B("abandoned_checkout", "پیگیری خرید نیمه‌کاره"), B("inactive_vip", "پیگیری VIP کم‌فعالیت"),
        B("auto_send", "ارسال خودکار", False), INT("daily_limit", "سقف پیام روزانه", 100, 1, 10000),
    )),
    ControlModule("campaigns", "growth", "🚀 استودیو کمپین", "کمپین، بخش‌بندی مخاطب، کد تخفیف و سنجش تبدیل", (
        B("enabled", "فعال بودن استودیو کمپین"),
        B("discount_codes", "ساخت و اتصال کد تخفیف"),
        B("segmentation", "بخش‌بندی دقیق مخاطبان"),
        B("direct_delivery", "ارسال مستقیم به کاربران"),
        B("channel_delivery", "انتشار در کانال‌ها"),
        B("channel_attribution", "ردیابی لینک‌های جذب کانال"),
        B("conversion_reporting", "گزارش تبدیل و درآمد"),
        INT("daily_campaign_limit", "سقف کمپین روزانه", 20, 1, 500),
    )),
    ControlModule("trust", "growth", "🛡 مرکز شفافیت", "نتایج قابل‌راستی‌آزمایی، ریسک و تاریخچه ویرایش", (
        B("enabled", "فعال بودن مرکز شفافیت"), B("public_stats", "نمایش آمار عمومی"),
        B("show_revisions", "نمایش تعداد اصلاحات"), B("show_risk", "نمایش میانگین ریسک"),
        B("show_methodology", "نمایش روش محاسبه"),
    )),
    ControlModule("health", "system", "🩺 سلامت سرویس", "Telegram، دیتابیس، کانال، Provider، Job و منابع", (
        B("enabled", "فعال بودن Healthcheck"), B("telegram", "بررسی Telegram API"), B("database", "بررسی دیتابیس"),
        B("channels", "بررسی کانال‌ها"), B("providers", "بررسی Providerها"), B("jobs", "بررسی Jobها"),
        B("backup", "بررسی بکاپ"), B("disk", "بررسی دیسک"), B("memory", "بررسی RAM"),
        INT("stale_job_minutes", "حد کهنگی Job (دقیقه)", 30, 1, 10080), INT("disk_warn_pct", "هشدار مصرف دیسک (%)", 85, 1, 99),
    )),
    ControlModule("backup", "system", "💾 بکاپ و بازیابی", "رمزگذاری، Metadata، تست Restore و نگهداری", (
        B("enabled", "فعال بودن بکاپ"), B("encrypted", "رمزگذاری اجباری"), B("metadata", "Metadata و SHA-256"),
        B("restore_test", "تست خودکار Restore"), B("external_upload", "انتقال به فضای خارجی"), B("safe_restore", "بکاپ ایمنی قبل Restore"),
        INT("keep_daily", "تعداد روزانه", 14, 1, 365), INT("keep_weekly", "تعداد هفتگی", 8, 0, 104), INT("keep_monthly", "تعداد ماهانه", 12, 0, 120),
    )),
    ControlModule("database", "system", "🗄 دیتابیس", "Migration، Index، Query Log، Cleanup و Repair", (
        B("enabled", "فعال بودن کنترل دیتابیس"), B("migration_guard", "محافظ Migration"), B("query_log", "لاگ Query کند"),
        B("index_monitor", "پایش Index"), B("cleanup", "پاک‌سازی دوره‌ای"), B("repair", "ابزار Repair"),
        INT("slow_query_ms", "حد Query کند (ms)", 500, 10, 60000), INT("cleanup_days", "نگهداری داده موقت", 365, 7, 3650),
    )),
    ControlModule("monitoring", "system", "📈 مانیتورینگ", "Metrics، Trace، خطا، Latency و هشدار منابع", (
        B("enabled", "فعال بودن مانیتورینگ"), B("json_logs", "Structured JSON Logs"), B("metrics", "Metrics"),
        B("tracing", "Tracing"), B("error_tracking", "ردیابی خطا"), B("resource_alerts", "هشدار منابع"),
        B("queue_metrics", "متریک صف"), INT("error_alert_threshold", "آستانه خطا در ۵ دقیقه", 10, 1, 10000),
    )),
    ControlModule("security", "system", "🛡 امنیت", "Secret، Rate Limit، فایل، لاگ و رفتار مشکوک", (
        B("enabled", "فعال بودن کنترل امنیت"), B("secret_rotation", "Rotation کلیدها"), B("encrypt_sensitive", "رمزگذاری داده حساس"),
        B("anti_spam", "Anti-spam"), B("adaptive_rate_limit", "Rate Limit پویا"), B("suspicious_behavior", "تشخیص رفتار مشکوک"),
        B("log_redaction", "حذف داده حساس از Log"), B("file_scan", "کنترل فایل"), INT("max_file_mb", "حد فایل عمومی (MB)", 20, 1, 200),
    )),
    ControlModule("runtime", "system", "🧰 نگهداری سیستم", "پاک‌سازی، بازسازی پروفایل، Diagnostics و محدودیت داده", (
        B("enabled", "فعال بودن ابزار نگهداری"), B("auto_cleanup", "پاک‌سازی خودکار"), B("profile_rebuild", "بازسازی پروفایل"),
        B("diagnostics", "Diagnostics"), B("data_caps", "محدودیت رشد داده"), INT("cleanup_interval_h", "فاصله پاک‌سازی (ساعت)", 24, 1, 720),
    )),
    ControlModule("copilot", "trading", "🧠 Gemini AI Sentinel", "دستیار کاربر و مرکز فرماندهی ادمین با مرز مالی سخت", (
        B("enabled", "فعال بودن هوش مصنوعی"), B("journal_analysis", "تحلیل ژورنال"), B("risk_explanation", "توضیح ریسک"),
        B("daily_plan", "برنامه روزانه"), B("show_evidence", "نمایش شواهد"), B("external_ai", "اتصال Gemini", True),
        B("admin_command_center", "مرکز فرماندهی ادمین", True), B("crm_analysis", "تحلیل CRM", True),
        B("user_behavior", "تحلیل رفتار کاربران", True), B("channel_content", "کنترل محتوای کانال", True),
        B("ticket_assistant", "دستیار تیکت", True), B("signal_analysis", "تحلیل سیگنال", True),
        B("risk_supervision", "نظارت ریسک و پراپ", True), B("system_monitoring", "تحلیل سلامت فنی", True),
        INT("max_questions_daily", "سقف پرسش روزانه", 30, 1, 500),
    )),
    ControlModule("risk_coach", "trading", "🧭 مربی رفتار و ریسک", "تشخیص Overtrading، Revenge Trading و انضباط معاملاتی", (
        B("enabled", "فعال بودن مربی ریسک"), B("revenge_detection", "تشخیص معامله انتقامی"), B("risk_escalation", "تشخیص افزایش ریسک"),
        B("cooldown", "پیشنهاد Cooldown"), B("discipline_score", "امتیاز انضباط"), B("admin_visibility", "نمایش برای ادمین"),
        INT("loss_streak_limit", "حد زیان متوالی", 3, 1, 20), INT("cooldown_minutes", "زمان توقف پیشنهادی", 30, 5, 1440),
    )),
    ControlModule("paper_trading", "growth", "🎮 معامله آزمایشی", "حساب مجازی، لیگ و رتبه‌بندی تعدیل‌شده با ریسک", (
        B("enabled", "فعال بودن معامله آزمایشی"), B("leaderboard", "لیدربورد"), B("private_leagues", "لیگ خصوصی"),
        B("signal_link", "اتصال به سیگنال"), B("risk_adjusted_score", "امتیاز تعدیل‌شده با ریسک"),
        INT("max_accounts", "حداکثر حساب هر کاربر", 5, 1, 20), F("max_trade_risk", "حداکثر ریسک معامله (%)", 5.0, 0.1, 10.0),
        F("max_total_risk", "حداکثر ریسک باز (%)", 10.0, 0.5, 50.0),
    )),
    ControlModule("prop_guardian", "trading", "🛡 نگهبان پراپ", "پایش Drawdown، Daily Loss، هدف سود و شبیه‌سازی نقض", (
        B("enabled", "فعال بودن نگهبان پراپ"), B("daily_loss", "کنترل زیان روزانه"), B("total_drawdown", "کنترل افت کل"),
        B("profit_target", "پایش هدف سود"), B("min_days", "حداقل روزهای معاملاتی"), B("what_if", "شبیه‌سازی معامله بعدی"),
        B("hard_block", "مسدودسازی قانون‌شکن", True),
    )),
    ControlModule("market_v2", "market", "🌐 هوش بازار ۲", "تجمیع Cache، سلامت منابع، تازگی داده و اخبار ذخیره‌شده", (
        B("enabled", "فعال بودن هوش بازار ۲"), B("cached_sources_only", "فقط منابع رایگان/Cache", True),
        B("freshness", "نمایش تازگی داده"), B("provider_health", "سلامت منابع"), B("high_impact", "رویدادهای مهم"),
        B("sentiment_rules", "تحلیل متنی محلی"), INT("stale_seconds", "حد کهنگی داده", 300, 30, 86400),
    )),
    ControlModule("publisher", "management", "📣 ناشر چندکاناله", "صف انتشار، قالب مستقل، تأیید و Retry بدون سرویس پولی", (
        B("enabled", "فعال بودن ناشر"), B("approval", "تأیید قبل انتشار"), B("scheduling", "زمان‌بندی"),
        B("retry", "تلاش مجدد"), B("language_templates", "قالب چندزبانه"), B("dedupe", "جلوگیری از تکرار"),
        INT("max_channels", "حداکثر کانال", 50, 1, 500), INT("daily_limit", "سقف انتشار روزانه", 500, 1, 10000),
    )),
    ControlModule("partners", "growth", "🤝 مرکز همکاران", "انتساب، ضدتقلب و اعتبار داخلی بدون درگاه جدید", (
        B("enabled", "فعال بودن همکاران"), B("attribution", "انتساب جذب"), B("anti_fraud", "تشخیص تکراری"),
        B("internal_credit", "تسویه اعتبار داخلی", True), B("cash_payout", "تسویه نقدی خودکار", False),
        B("coupon_link", "کد اختصاصی"), INT("max_partners", "حداکثر همکار", 500, 1, 10000),
    )),
    ControlModule("performance", "growth", "📊 عملکرد عمومی معتبر", "Track Record عمومی با Evidence Hash و تاریخچه", (
        B("enabled", "فعال بودن عملکرد عمومی"), B("evidence_hash", "Evidence Hash"), B("show_revisions", "نمایش اصلاحات"),
        B("show_drawdown", "نمایش Drawdown"), B("show_methodology", "نمایش روش محاسبه"), B("snapshot_history", "تاریخچه Snapshot"),
    )),
    ControlModule("content_factory", "content", "🏭 کارخانه محتوا", "تولید متن از قالب داخلی و اتصال به ناشر", (
        B("enabled", "فعال بودن کارخانه محتوا"), B("signal_posts", "پست سیگنال"), B("result_posts", "پست نتیجه"),
        B("weekly_reports", "گزارش هفتگی"), B("bilingual", "فارسی/انگلیسی"), B("approval", "تأیید قبل انتشار"),
        INT("max_outputs_daily", "سقف خروجی روزانه", 200, 1, 5000),
    )),
    ControlModule("business_inbox", "management", "💼 صندوق کسب‌وکار", "دسته‌بندی پیام، ساخت Lead و ارجاع به پشتیبانی", (
        B("enabled", "فعال بودن صندوق"), B("sales_classification", "تشخیص فروش"), B("support_classification", "تشخیص پشتیبانی"),
        B("partner_classification", "تشخیص همکاری"), B("urgent_detection", "تشخیص فوری"), B("crm_lead", "ساخت Lead"),
    )),
    ControlModule("miniapp_next", "system", "📱 مینی‌اپ نسل بعد", "Draft آفلاین، همگام‌سازی و تنظیمات امن دستگاه", (
        B("enabled", "فعال بودن قابلیت‌های نسل بعد"), B("offline_drafts", "Draft آفلاین"), B("device_state", "تنظیمات دستگاه"),
        B("compact_mode", "حالت کم‌مصرف"), B("home_shortcut", "میانبر Home"), B("secure_storage", "Secure Storage"),
        INT("max_devices", "حداکثر دستگاه", 5, 1, 20),
    )),
    ControlModule("developer_api", "system", "🔌 پلتفرم توسعه‌دهندگان", "Webhook امن، HMAC و صف تحویل با حالت Held پیش‌فرض", (
        B("enabled", "فعال بودن Developer API"), B("webhooks", "Webhook"), B("hmac", "امضای HMAC"),
        B("delivery_enabled", "ارسال بیرونی", False), B("ip_allowlist", "IP Allowlist"), B("rate_limit", "Rate Limit"),
        INT("max_webhooks", "حداکثر Webhook", 20, 1, 500), INT("max_attempts", "حداکثر تلاش", 5, 1, 20),
    )),
    ControlModule("workspaces", "system", "🏢 فضاهای کاری", "هسته Multi-tenant و White-label با Namespace جدا", (
        B("enabled", "فعال بودن فضای کاری"), B("data_namespace", "Namespace جدا"), B("brand_override", "برند اختصاصی"),
        B("member_roles", "نقش اعضا"), B("channel_scope", "دامنه کانال"), B("billing_external", "صورتحساب خارجی", False),
        INT("max_workspaces", "حداکثر فضای کاری", 20, 1, 1000),
    )),
    ControlModule("governance", "system", "🧠 حاکمیت عملیات", "صف تصمیم‌های ادمین، تأیید دومرحله‌ای، Retry و پایش خودکار بدون سرویس پولی", (
        B("enabled", "فعال بودن مرکز حاکمیت"),
        B("two_step_critical", "تأیید دومرحله‌ای عملیات بحرانی", True),
        B("creator_cannot_approve_critical", "ممنوعیت خودتأییدی عملیات بحرانی", True),
        B("auto_incident", "ساخت خودکار رخداد برای خطای تکراری", True),
        B("auto_retry", "Retry خودکار عملیات ناموفق", True),
        B("auto_pause_on_failure", "توقف خودکار ماژول پس از شکست‌های شدید", False),
        B("notify_admins", "اعلان موارد نیازمند تصمیم به ادمین", True),
        B("daily_digest", "گزارش روزانه وضعیت", True),
        B("notify_on_change_only", "اعلان فقط هنگام تغییر قابل اقدام", True),
        INT("watchdog_interval_minutes", "فاصله بررسی خودکار (دقیقه)", 10, 5, 1440),
        INT("notification_cooldown_minutes", "فاصله حداقل اعلان تکراری (دقیقه)", 360, 30, 10080),
        INT("max_attempts", "حداکثر تلاش مجدد", 5, 1, 20),
        INT("stale_minutes", "حد کهنگی صف و Job (دقیقه)", 30, 5, 1440),
        INT("review_sla_minutes", "مهلت بررسی ادمین (دقیقه)", 120, 5, 10080),
        INT("override_expiry_minutes", "انقضای Override دستی (دقیقه)", 60, 5, 1440),
    )),
)

MODULE_BY_KEY: dict[str, ControlModule] = {item.key: item for item in MODULES}
FIELD_BY_KEY: dict[str, dict[str, ControlField]] = {
    module.key: {field.key: field for field in module.fields} for module in MODULES
}


def _module_defaults(module: ControlModule) -> dict[str, Any]:
    return {field.key: copy.deepcopy(field.default) for field in module.fields}


def default_control_root() -> dict[str, Any]:
    return {
        "schema_version": CONTROL_SCHEMA_VERSION,
        "modules": {module.key: _module_defaults(module) for module in MODULES},
        "change_log": [],
        "maintenance_log": [],
        "last_updated_at": None,
        "last_updated_by": None,
    }


def ensure_control_center(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("enterprise_control", {})
    if not isinstance(root, dict):
        root = {}
        db["enterprise_control"] = root
    # The catalog is additive, but the stored version must reflect the code
    # that completed the migration instead of remaining on a legacy value.
    root["schema_version"] = CONTROL_SCHEMA_VERSION
    modules = root.setdefault("modules", {})
    if not isinstance(modules, dict):
        modules = {}
        root["modules"] = modules
    for module in MODULES:
        state = modules.setdefault(module.key, {})
        if not isinstance(state, dict):
            state = {}
            modules[module.key] = state
        legacy_owner_approval = (
            module.key == "signals"
            and "owner_approval" not in state
            and "second_analyst" in state
            and bool(state.get("second_analyst"))
        )
        for field in module.fields:
            state.setdefault(field.key, copy.deepcopy(field.default))
        if module.key == "signals":
            # Admin signal publication is unrestricted: legacy or stored owner-approval
            # flags must never re-enable a publication gate.
            state["owner_approval"] = False
    root.setdefault("change_log", [])
    root.setdefault("maintenance_log", [])
    root.setdefault("last_updated_at", None)
    root.setdefault("last_updated_by", None)
    db.setdefault("user_notification_preferences", {})
    db.setdefault("league_seasons", [])
    db.setdefault("league_history", [])
    db.setdefault("support_canned_replies", [])
    db.setdefault("support_internal_notes", {})
    db.setdefault("faq_feedback", {})
    db.setdefault("user_watchlists", {})
    return root


CAPABILITY_OVERRIDES: dict[tuple[str, str], str] = {
    ("broadcast", "ab_test"): "experimental",
    ("broadcast", "click_tracking"): "experimental",
    ("security", "secret_rotation"): "manual",
    ("security", "file_scan"): "experimental",
    ("monitoring", "tracing"): "experimental",
    ("backup", "external_upload"): "configuration_required",
    ("exports", "pdf"): "experimental",
    ("security", "encrypt_sensitive"): "configuration_required",
}

# The matrix is deliberately allow-listed. A setting is advertised as
# operational only after a runtime path reads it; unknown/new settings remain
# visible as planned and cannot be toggled from the panel.
CONNECTED_FIELDS: dict[str, set[str]] = {
    "subscriptions": {"enabled"},
    "rules": {"enabled"},
    "edu": {"enabled", "drafts", "progress", "rating", "max_upload_mb"},
    "missions": {"enabled", "max_daily_points", "reset_hour"},
    "faq": {"enabled", "search", "categories", "feedback", "popular", "max_items"},
    "support": {"enabled", "attachments", "private_notes", "canned_replies", "max_open", "max_attachment_mb", "sla_urgent_h", "sla_normal_h"},
    "notify": set(FIELD_BY_KEY["notify"]),
    "alerts": {"enabled", "recurring", "history", "max_per_user", "check_seconds"},
    "portal": {"enabled", "filters", "watchlist", "journal", "export", "history_limit"},
    "watchlists": {"enabled", "admin_visibility", "market_groups", "max_assets"},
    "journal": {"enabled", "auto_from_signal", "personal_pnl", "equity", "export", "admin_notes", "max_entries"},
    "signals": set(FIELD_BY_KEY["signals"]),
    "tracker": {"enabled", "multi_provider", "auto_failover", "interval_seconds", "max_failures"},
    "risk": {"enabled", "pip_value", "margin", "drawdown", "compound", "partial", "max_risk_pct"},
    "prices": {"enabled", "cache_seconds"},
    "calendar": {"enabled", "filters", "reminders", "actual_alert", "history", "countdown", "signal_guard", "reminder_minutes"},
    "dashboard": {"enabled", "date_filters", "online_users", "service_health", "refresh_seconds"},
    "crm": {"enabled", "pipeline", "custom_fields", "advanced_segments", "lead_score", "churn_risk", "followup_reminder_h"},
    "broadcast": {"enabled", "media", "buttons", "scheduled", "test_send", "retry", "batch_size", "rate_per_second"},
    "admins": {"enabled", "roles", "custom_roles", "temporary_access", "session_log", "read_only", "channel_scope"},
    "shifts": {"enabled", "recurring", "holidays", "substitute", "swap", "auto_ticket_assign", "attendance"},
    "automation": {"enabled", "rule_engine", "dry_run", "retry", "loop_guard", "max_rules"},
    "exports": {"enabled", "csv", "json", "mask_sensitive"},
    "audit": {"enabled", "admin_actions", "before_after", "severity", "correlation_id", "retention_days"},
    "incidents": set(FIELD_BY_KEY["incidents"]),
    "retention": set(FIELD_BY_KEY["retention"]),
    "campaigns": set(FIELD_BY_KEY["campaigns"]),
    "trust": set(FIELD_BY_KEY["trust"]),
    "health": {"enabled", "heartbeat", "readiness", "channels", "providers", "jobs", "backup", "disk", "memory", "stale_job_minutes", "disk_warn_pct"},
    "backup": {"enabled", "encrypted", "metadata", "restore_test", "safe_restore", "keep_daily", "keep_weekly", "keep_monthly"},
    "database": {"enabled", "migration_guard", "query_log", "index_monitor", "cleanup", "slow_query_ms", "cleanup_days"},
    "monitoring": {"enabled", "json_logs", "metrics", "error_tracking", "resource_alerts", "queue_metrics", "error_alert_threshold"},
    "security": {"enabled", "anti_spam", "log_redaction", "max_file_mb"},
    "runtime": {"enabled", "auto_cleanup", "profile_rebuild", "diagnostics", "data_caps", "cleanup_interval_h"},
    "copilot": set(FIELD_BY_KEY["copilot"]),
    "risk_coach": set(FIELD_BY_KEY["risk_coach"]),
    "paper_trading": set(FIELD_BY_KEY["paper_trading"]),
    "prop_guardian": set(FIELD_BY_KEY["prop_guardian"]),
    "market_v2": set(FIELD_BY_KEY["market_v2"]),
    "publisher": set(FIELD_BY_KEY["publisher"]),
    "partners": set(FIELD_BY_KEY["partners"]),
    "performance": set(FIELD_BY_KEY["performance"]),
    "content_factory": set(FIELD_BY_KEY["content_factory"]),
    "business_inbox": set(FIELD_BY_KEY["business_inbox"]),
    "miniapp_next": set(FIELD_BY_KEY["miniapp_next"]),
    "developer_api": set(FIELD_BY_KEY["developer_api"]),
    "workspaces": set(FIELD_BY_KEY["workspaces"]),
    "governance": set(FIELD_BY_KEY["governance"]),
}

# Every module's master switch is enforced centrally by Telegram callbacks,
# Mini App actions and background jobs. It is therefore always operational,
# even when some advanced fields in the module remain planned.
for _module in MODULES:
    CONNECTED_FIELDS.setdefault(_module.key, set()).add("enabled")

FREE_MODE_LOCKED_FIELDS: frozenset[tuple[str, str]] = frozenset({
    ("partners", "cash_payout"),
    ("workspaces", "billing_external"),
})


def is_free_mode_locked(module_key: str, field_key: str) -> bool:
    return (str(module_key), str(field_key)) in FREE_MODE_LOCKED_FIELDS


CAPABILITY_LABELS = {
    "connected": "متصل و عملیاتی",
    "experimental": "آزمایشی",
    "manual": "نیازمند اجرای دستی",
    "configuration_required": "نیازمند تنظیمات خارجی",
    "planned": "در حال توسعه",
}


def capability_status(module_key: str, field_key: str) -> str:
    pair = (str(module_key), str(field_key))
    if pair in CAPABILITY_OVERRIDES:
        return CAPABILITY_OVERRIDES[pair]
    return "connected" if pair[1] in CONNECTED_FIELDS.get(pair[0], set()) else "planned"


def capability_summary() -> dict[str, int]:
    result = {key: 0 for key in CAPABILITY_LABELS}
    for module in MODULES:
        for field in module.fields:
            result[capability_status(module.key, field.key)] += 1
    return result


def module_state(db: dict[str, Any], module_key: str) -> dict[str, Any]:
    root = ensure_control_center(db)
    if module_key not in MODULE_BY_KEY:
        raise ValueError("ماژول مدیریت پیدا نشد")
    return root["modules"][module_key]


def is_module_enabled(db: dict[str, Any], module_key: str) -> bool:
    if module_key not in MODULE_BY_KEY:
        return True
    return bool(module_state(db, module_key).get("enabled", True))


def _coerce(field: ControlField, raw: Any) -> Any:
    if field.kind == "bool":
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in {"1", "true", "yes", "on", "enable", "enabled", "بله", "روشن", "فعال"}:
            return True
        if text in {"0", "false", "no", "off", "disable", "disabled", "خیر", "خاموش", "غیرفعال"}:
            return False
        raise ValueError("مقدار باید روشن یا خاموش باشد")
    if field.kind == "int":
        try:
            value = int(str(raw).strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")))
        except (TypeError, ValueError) as exc:
            raise ValueError("مقدار باید عدد صحیح باشد") from exc
        if field.minimum is not None and value < field.minimum:
            raise ValueError(f"حداقل مقدار {int(field.minimum)} است")
        if field.maximum is not None and value > field.maximum:
            raise ValueError(f"حداکثر مقدار {int(field.maximum)} است")
        return value
    if field.kind == "float":
        try:
            value = float(str(raw).strip().replace(",", ".").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")))
        except (TypeError, ValueError) as exc:
            raise ValueError("مقدار باید عدد باشد") from exc
        if field.minimum is not None and value < field.minimum:
            raise ValueError(f"حداقل مقدار {field.minimum:g} است")
        if field.maximum is not None and value > field.maximum:
            raise ValueError(f"حداکثر مقدار {field.maximum:g} است")
        return value
    text = str(raw or "").strip()
    if not text:
        raise ValueError("مقدار نمی‌تواند خالی باشد")
    if field.kind == "choice" and text not in field.choices:
        raise ValueError("گزینه معتبر نیست: " + "، ".join(field.choices))
    if len(text) > 500:
        raise ValueError("مقدار بیش از حد طولانی است")
    return text


def normalize_control_value(module_key: str, field_key: str, value: Any) -> Any:
    """Validate and normalize a control value without mutating persistent state."""
    # Owner approval used to block delegated admins from publishing signals.
    # Keep the legacy field readable for compatibility, but it can no longer
    # be enabled as a publication restriction.
    if str(module_key) == "signals" and str(field_key) == "owner_approval":
        return False
    module = MODULE_BY_KEY.get(module_key)
    field = FIELD_BY_KEY.get(module_key, {}).get(field_key)
    if not module or not field:
        raise ValueError("تنظیم انتخاب‌شده معتبر نیست")
    normalized = _coerce(field, value)
    if is_free_mode_locked(module_key, field_key) and bool(normalized):
        raise ValueError("این گزینه در حالت بدون هزینه قفل است و قابل فعال‌سازی نیست")
    return normalized


def set_control_value(
    db: dict[str, Any], module_key: str, field_key: str, value: Any, actor_id: int | str
) -> tuple[Any, Any]:
    module = MODULE_BY_KEY.get(module_key)
    field = FIELD_BY_KEY.get(module_key, {}).get(field_key)
    if not module or not field:
        raise ValueError("تنظیم انتخاب‌شده معتبر نیست")
    state = module_state(db, module_key)
    old = copy.deepcopy(state.get(field_key, field.default))
    new = normalize_control_value(module_key, field_key, value)
    state[field_key] = new
    _record_change(db, actor_id, module_key, field_key, old, new)
    _sync_runtime_settings(db, module_key, field_key, new)
    return old, new


def toggle_control_value(db: dict[str, Any], module_key: str, field_key: str, actor_id: int | str) -> bool:
    field = FIELD_BY_KEY.get(module_key, {}).get(field_key)
    if not field or field.kind != "bool":
        raise ValueError("این گزینه قابل روشن/خاموش کردن نیست")
    current = bool(module_state(db, module_key).get(field_key, field.default))
    set_control_value(db, module_key, field_key, not current, actor_id)
    return not current


def reset_module(db: dict[str, Any], module_key: str, actor_id: int | str) -> dict[str, Any]:
    module = MODULE_BY_KEY.get(module_key)
    if not module:
        raise ValueError("ماژول پیدا نشد")
    root = ensure_control_center(db)
    old = copy.deepcopy(root["modules"].get(module_key, {}))
    root["modules"][module_key] = _module_defaults(module)
    _record_change(db, actor_id, module_key, "__reset__", old, root["modules"][module_key])
    for key, value in root["modules"][module_key].items():
        _sync_runtime_settings(db, module_key, key, value)
    return root["modules"][module_key]


def apply_preset(db: dict[str, Any], preset: str, actor_id: int | str) -> None:
    root = ensure_control_center(db)
    if preset not in {"default", "full", "safe"}:
        raise ValueError("Preset نامعتبر است")
    for module in MODULES:
        target = _module_defaults(module)
        if preset == "full":
            for field in module.fields:
                if field.kind == "bool":
                    target[field.key] = not is_free_mode_locked(module.key, field.key)
        elif preset == "safe":
            for field in module.fields:
                if field.kind == "bool" and field.key != "enabled":
                    target[field.key] = False
            target["enabled"] = True
            if module.key in {"broadcast", "automation", "tracker"}:
                target["enabled"] = False
        root["modules"][module.key] = target
        for key, value in target.items():
            _sync_runtime_settings(db, module.key, key, value)
    _record_change(db, actor_id, "all", f"preset:{preset}", "mixed", preset)


def _record_change(
    db: dict[str, Any], actor_id: int | str, module_key: str, field_key: str, old: Any, new: Any
) -> None:
    root = ensure_control_center(db)
    now = utc_iso()
    root["last_updated_at"] = now
    root["last_updated_by"] = str(actor_id)
    log = root.setdefault("change_log", [])
    log.append({
        "module": module_key,
        "field": field_key,
        "old": old,
        "new": new,
        "actor_id": str(actor_id),
        "created_at": now,
    })
    root["change_log"] = log[-5000:]


def record_maintenance(db: dict[str, Any], actor_id: int | str, action: str, result: Any) -> None:
    root = ensure_control_center(db)
    rows = root.setdefault("maintenance_log", [])
    rows.append({"action": action, "result": result, "actor_id": str(actor_id), "created_at": utc_iso()})
    root["maintenance_log"] = rows[-1000:]


def _sync_runtime_settings(db: dict[str, Any], module_key: str, field_key: str, value: Any) -> None:
    """Mirror settings used by legacy modules so admin changes take effect immediately."""
    if module_key == "support":
        settings = db.setdefault("support_settings", {})
        settings[field_key] = value
    elif module_key == "notify":
        defaults = db.setdefault("notification_defaults", {})
        defaults[field_key] = value
    elif module_key == "league":
        settings = db.setdefault("league_settings", {})
        settings[field_key] = value
    elif module_key == "broadcast" and field_key == "batch_size":
        db.setdefault("broadcast_settings", {})["batch_size"] = value
    elif module_key == "referrals":
        db.setdefault("referral_settings", {})[field_key] = value
    elif module_key == "privacy":
        db.setdefault("privacy_settings", {})[field_key] = value
    elif module_key == "backup":
        db.setdefault("backup_settings", {})[field_key] = value
    elif module_key == "health":
        db.setdefault("health_settings", {})[field_key] = value
    elif module_key == "security":
        db.setdefault("security_settings", {})[field_key] = value
    elif module_key == "rules" and field_key == "enabled":
        db.setdefault("rules_settings", {})["enabled"] = bool(value)
    elif module_key == "incidents":
        db.setdefault("incident_settings", {})[field_key] = value
    elif module_key == "retention":
        settings = db.setdefault("retention_settings", {})
        mapped = {"daily_limit": "max_messages_per_day"}.get(field_key, field_key)
        settings[mapped] = value
    elif module_key == "trust":
        db.setdefault("trust_settings", {})[field_key] = value
    elif module_key in {"copilot", "risk_coach", "paper_trading", "prop_guardian", "market_v2", "publisher", "partners", "performance", "content_factory", "business_inbox", "miniapp_next", "developer_api", "workspaces"}:
        settings = db.setdefault("platform_settings", {}).setdefault(module_key, {})
        settings[field_key] = value
        if field_key == "enabled":
            from modules.platform_registry import CAPABILITIES, ensure_platform_registry
            root = ensure_platform_registry(db)
            for capability in CAPABILITIES:
                if capability.control_module == module_key:
                    root["capabilities"][capability.key]["enabled"] = bool(value)
                    root["capabilities"][capability.key]["updated_at"] = utc_iso()
    elif module_key == "tracker":
        settings = db.setdefault("settings", {}).setdefault("signalTracking", {})
        mapped = {
            "interval_seconds": "check_interval_seconds",
            "max_failures": "max_provider_failures",
        }.get(field_key, field_key)
        settings[mapped] = value


def category_modules(category: str) -> tuple[ControlModule, ...]:
    return tuple(module for module in MODULES if module.category == category)


def control_summary(db: dict[str, Any]) -> dict[str, Any]:
    ensure_control_center(db)
    enabled = sum(1 for module in MODULES if is_module_enabled(db, module.key))
    booleans = 0
    active_booleans = 0
    for module in MODULES:
        state = module_state(db, module.key)
        for field in module.fields:
            if field.kind == "bool":
                booleans += 1
                active_booleans += int(bool(state.get(field.key, field.default)))
    return {
        "modules": len(MODULES),
        "enabled_modules": enabled,
        "disabled_modules": len(MODULES) - enabled,
        "boolean_controls": booleans,
        "active_controls": active_booleans,
    }


def export_control_payload(db: dict[str, Any]) -> bytes:
    root = ensure_control_center(db)
    payload = {
        "exported_at": utc_iso(),
        "schema_version": CONTROL_SCHEMA_VERSION,
        "catalog": {
            module.key: {
                "label": module.label,
                "category": module.category,
                "description": module.description,
                "fields": [field.key for field in module.fields],
            }
            for module in MODULES
        },
        "state": root,
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")


CALLBACK_FEATURE_MAP: tuple[tuple[tuple[str, ...], str], ...] = (
    (("u_vip", "vip_plan:", "vip_pay_method:", "buy_", "account_vip"), "subscriptions"),
    (("u_edu", "edu_", "lesson:"), "edu"),
    (("u_missions", "mission_"), "missions"),
    (("u_faq", "faq:"), "faq"),
    (("u_support", "ticket_"), "support"),
    (("price_alert", "pa_"), "alerts"),
    (("u_signal_portal", "user_signal_"), "portal"),
    (("user_watchlist", "watchlist_"), "watchlists"),
    (("user_journal", "journal_"), "journal"),
    (("u_calc", "calc:", "risk:", "calc_market:", "calc_symbol:", "calc_leverage:", "calc_fee:"), "risk"),
    (("u_price", "price:", "iran_prices"), "prices"),
    (("crypto_",), "crypto"),
    (("stock_",), "stocks"),
    (("price_energy",), "energy"),
    (("u_calendar",), "calendar"),
    (("u_market_intel", "mi_view:", "mi_latest_brief"), "news"),
    (("u_contests", "contest_", "chart_answer:"), "contests"),
    (("u_score", "u_leaderboard"), "league"),
    (("u_rewards", "u_my_rewards", "redeem:"), "rewards"),
    (("u_referral",), "referrals"),
    (("u_account", "account_", "notification_"), "account"),
    (("privacy_",), "privacy"),
    (("u_copilot",), "copilot"),
    (("u_risk_coach",), "risk_coach"),
    (("u_paper_arena",), "paper_trading"),
    (("u_prop_guardian",), "prop_guardian"),
    (("u_public_performance",), "performance"),
)


def feature_for_callback(data: str) -> str | None:
    text = str(data or "")
    if text.startswith(("admin_", "a_", "ecc_", "backup_", "shift_", "crm_")):
        return None
    for prefixes, module_key in CALLBACK_FEATURE_MAP:
        if any(text == prefix or text.startswith(prefix) for prefix in prefixes):
            return module_key
    return None


CONTEXT_FEATURE_MARKERS: tuple[tuple[tuple[str, ...], str], ...] = (
    (("calc",), "risk"),
    (("buy_plan_id", "buy_payment_method", "buy_coupon"), "subscriptions"),
    (("price_alert_draft",), "alerts"),
    (("portfolio_note_uid", "journal_result_id"), "journal"),
    (("ticket_draft", "ticket_id"), "support"),
    (("market_search", "crypto_search", "stock_search"), "prices"),
)


def feature_for_context(user_data: dict[str, Any] | None) -> str | None:
    if not isinstance(user_data, dict):
        return None
    keys = set(user_data)
    for markers, module_key in CONTEXT_FEATURE_MARKERS:
        if any(marker in keys for marker in markers):
            return module_key
    return None


NOTIFICATION_KEYS: tuple[tuple[str, str], ...] = (
    ("signals", "📡 سیگنال‌های جدید"),
    ("results", "📈 نتیجه سیگنال‌ها"),
    ("news", "📰 خبرهای مهم"),
    ("calendar", "🗓 تقویم اقتصادی"),
    ("contests", "🎯 مسابقه‌ها"),
    ("missions", "✅ مأموریت‌ها"),
    ("education", "🎓 آموزش جدید"),
    ("support", "🎫 پاسخ پشتیبانی"),
    ("alerts", "🔔 هشدار قیمت"),
    ("retention", "💎 یادآوری اشتراک و سفارش"),
    ("daily_digest", "☀️ خلاصه روزانه"),
    ("weekly_digest", "📅 خلاصه هفتگی"),
    ("tp", "🎯 رسیدن به هدف"), ("sl", "🛑 حد ضرر"), ("risk_free", "🛡 ریسک‌فری"),
    ("high_impact", "⚡ خبر پراثر"), ("payment", "💳 پرداخت"), ("vip", "💎 وضعیت اشتراک"),
    ("referral", "👥 معرفی"), ("reward", "🎁 پاداش"), ("general", "📣 عمومی"),
)


def notification_preferences(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    ensure_control_center(db)
    uid = str(int(user_id))
    from modules.shared_preferences import migrate_shared_preference
    migrate_shared_preference(db, uid, "user_notification_preferences")
    defaults = module_state(db, "notify")
    rows = db.setdefault("user_notification_preferences", {})
    pref = rows.setdefault(uid, {})
    for key, _ in NOTIFICATION_KEYS:
        pref.setdefault(key, bool(defaults.get(key, True)))
    pref.setdefault("quiet_enabled", True)
    pref.setdefault("quiet_start", str(defaults.get("quiet_start", "23:00")))
    pref.setdefault("quiet_end", str(defaults.get("quiet_end", "07:00")))
    pref.setdefault("timezone", "Asia/Tehran")
    pref.setdefault("paused_until", None)
    pref.setdefault("markets", [])
    pref.setdefault("symbols", [])
    pref.setdefault("digest_time", "09:00")
    pref.setdefault("weekly_digest_day", 0)
    pref.setdefault("updated_at", utc_iso())
    return pref


def toggle_notification(db: dict[str, Any], user_id: int | str, key: str) -> bool:
    allowed = {item[0] for item in NOTIFICATION_KEYS} | {"quiet_enabled"}
    if key not in allowed:
        raise ValueError("نوع اعلان نامعتبر است")
    pref = notification_preferences(db, user_id)
    pref[key] = not bool(pref.get(key, True))
    pref["updated_at"] = utc_iso()
    return bool(pref[key])


def pause_notifications(db: dict[str, Any], user_id: int | str, hours: int) -> str | None:
    pref = notification_preferences(db, user_id)
    if hours <= 0:
        pref["paused_until"] = None
    else:
        pref["paused_until"] = (datetime.now(UTC) + timedelta(hours=min(hours, 24 * 365))).isoformat()
    pref["updated_at"] = utc_iso()
    return pref["paused_until"]


def set_notification_timezone(db: dict[str, Any], user_id: int | str, timezone_name: str) -> str:
    value = str(timezone_name or "").strip()[:64]
    try:
        ZoneInfo(value)
    except (ZoneInfoNotFoundError, ValueError):
        raise ValueError("منطقه زمانی نامعتبر است") from None
    pref = notification_preferences(db, user_id)
    pref["timezone"] = value
    pref["updated_at"] = utc_iso()
    return value


def set_notification_quiet_hours(
    db: dict[str, Any],
    user_id: int | str,
    start: str,
    end: str,
    *,
    enabled: bool = True,
) -> tuple[str, str]:
    def normalize(value: str) -> str:
        raw = str(value or "").strip()
        try:
            hour_text, minute_text = raw.split(":", 1)
            hour, minute = int(hour_text), int(minute_text)
        except (ValueError, TypeError):
            raise ValueError("ساعت سکوت نامعتبر است") from None
        if not 0 <= hour <= 23 or not 0 <= minute <= 59:
            raise ValueError("ساعت سکوت نامعتبر است")
        return f"{hour:02d}:{minute:02d}"

    quiet_start, quiet_end = normalize(start), normalize(end)
    pref = notification_preferences(db, user_id)
    pref["quiet_start"] = quiet_start
    pref["quiet_end"] = quiet_end
    pref["quiet_enabled"] = bool(enabled)
    pref["updated_at"] = utc_iso()
    return quiet_start, quiet_end


def set_notification_digest_time(db: dict[str, Any], user_id: int | str, value: str) -> str:
    """Persist the user's preferred local delivery time for summary digests."""
    raw = str(value or "").strip()
    try:
        hour_text, minute_text = raw.split(":", 1)
        hour, minute = int(hour_text), int(minute_text)
    except (ValueError, TypeError):
        raise ValueError("زمان خلاصه نامعتبر است") from None
    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ValueError("زمان خلاصه نامعتبر است")
    normalized = f"{hour:02d}:{minute:02d}"
    pref = notification_preferences(db, user_id)
    pref["digest_time"] = normalized
    pref["updated_at"] = utc_iso()
    return normalized


def _minutes_from_clock(value: str, fallback: int) -> int:
    try:
        hour_text, minute_text = str(value).split(":", 1)
        hour, minute = int(hour_text), int(minute_text)
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return hour * 60 + minute
    except (ValueError, TypeError):
        pass
    return fallback


def notification_allowed(db: dict[str, Any], user_id: int | str, key: str, now: datetime | None = None) -> bool:
    if not is_module_enabled(db, "notify"):
        return False
    pref = notification_preferences(db, user_id)
    if not bool(pref.get(key, True)):
        return False
    current = now or datetime.now(UTC)
    if current.tzinfo is None:
        current = current.replace(tzinfo=UTC)
    else:
        current = current.astimezone(UTC)
    paused = pref.get("paused_until")
    if paused:
        try:
            paused_at = datetime.fromisoformat(str(paused).replace("Z", "+00:00"))
            if paused_at.tzinfo is None:
                paused_at = paused_at.replace(tzinfo=UTC)
            if paused_at.astimezone(UTC) > current:
                return False
        except (ValueError, TypeError):
            pass
    if not bool(pref.get("quiet_enabled", True)):
        return True
    try:
        local_now = current.astimezone(ZoneInfo(str(pref.get("timezone") or "Asia/Tehran")))
    except (ZoneInfoNotFoundError, ValueError):
        local_now = current.astimezone(UTC)
    current_minutes = local_now.hour * 60 + local_now.minute
    start = _minutes_from_clock(str(pref.get("quiet_start") or "23:00"), 23 * 60)
    end = _minutes_from_clock(str(pref.get("quiet_end") or "07:00"), 7 * 60)
    if start == end:
        return True
    quiet = start <= current_minutes < end if start < end else current_minutes >= start or current_minutes < end
    return not quiet


def start_league_season(db: dict[str, Any], actor_id: int | str, title: str = "") -> dict[str, Any]:
    ensure_control_center(db)
    settings = module_state(db, "league")
    now = datetime.now(UTC)
    days = int(settings.get("season_days", 30) or 30)
    active = next((row for row in reversed(db["league_seasons"]) if row.get("status") == "active"), None)
    if active:
        raise ValueError("یک فصل فعال وجود دارد")
    season = {
        "id": max((int(row.get("id", 0) or 0) for row in db["league_seasons"]), default=0) + 1,
        "title": str(title or f"فصل {len(db['league_seasons']) + 1}")[:100],
        "status": "active",
        "starts_at": now.isoformat(),
        "ends_at": (now + timedelta(days=days)).isoformat(),
        "created_by": str(actor_id),
        "snapshot": {},
    }
    db["league_seasons"].append(season)
    return season


def close_league_season(db: dict[str, Any], actor_id: int | str) -> dict[str, Any]:
    ensure_control_center(db)
    season = next((row for row in reversed(db["league_seasons"]) if row.get("status") == "active"), None)
    if not season:
        raise ValueError("فصل فعالی وجود ندارد")
    ranking = sorted(
        ((str(uid), int(points or 0)) for uid, points in db.get("user_points", {}).items()),
        key=lambda item: (-item[1], item[0]),
    )
    season["status"] = "closed"
    season["closed_at"] = utc_iso()
    season["closed_by"] = str(actor_id)
    season["snapshot"] = {uid: points for uid, points in ranking[:1000]}
    db["league_history"].append({
        "season_id": season["id"], "title": season["title"], "closed_at": season["closed_at"],
        "top": [{"user_id": uid, "points": points} for uid, points in ranking[:100]],
    })
    db["league_history"] = db["league_history"][-100:]
    return season


def trim_runtime_data(db: dict[str, Any]) -> dict[str, int]:
    """Bound non-financial runtime collections without deleting canonical business records."""
    limits = {
        "admin_logs": 10000,
        "user_activity": 100000,
        "privacy_log": 10000,
        "broadcasts": 5000,
        "contest_history": 1000,
        "signal_archive": 5000,
    }
    removed: dict[str, int] = {}
    for key, limit in limits.items():
        rows = db.get(key)
        if isinstance(rows, list) and len(rows) > limit:
            removed[key] = len(rows) - limit
            db[key] = rows[-limit:]
        else:
            removed[key] = 0
    return removed


def catalog_as_dict() -> dict[str, Any]:
    return {
        module.key: {
            "category": module.category,
            "label": module.label,
            "description": module.description,
            "fields": {
                field.key: {
                    "label": field.label,
                    "kind": field.kind,
                    "default": field.default,
                    "minimum": field.minimum,
                    "maximum": field.maximum,
                    "choices": list(field.choices),
                    "help_text": field.help_text,
                }
                for field in module.fields
            },
        }
        for module in MODULES
    }
