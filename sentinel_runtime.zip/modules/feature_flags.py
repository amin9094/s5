from __future__ import annotations

import hashlib
from typing import Any

from core.utils import utc_iso

DEFAULT_FEATURE_FLAGS: dict[str, bool] = {
    "ops.memory_guardian": True,
    "ops.memory_trend": True,
    "ops.self_healing": True,
    "ops.recovery_budget": True,
    "ops.security_sentinel": True,
    "ops.smart_logging": True,
    "messaging.priority_queue": True,
    "messaging.signal_album": True,
    "providers.intelligence": True,
    "providers.cost_intelligence": True,
    "analytics.business_bi": True,
    "trading.coach": True,
    "miniapp.operations_center": True,
    "admin.operations_center": True,
    "admin.feature_rollout": True,
    "admin.migration_sandbox": True,
}


def _root(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("feature_flags", {})
    if not isinstance(root, dict):
        root = {}
        db["feature_flags"] = root
    return root


def ensure_feature_flags(db: dict[str, Any]) -> dict[str, Any]:
    root = _root(db)
    for key, enabled in DEFAULT_FEATURE_FLAGS.items():
        root.setdefault(key, bool(enabled))
    return root


def _normalize_config(value: Any, default_enabled: bool) -> tuple[bool, int]:
    if isinstance(value, dict):
        enabled = bool(value.get("enabled", default_enabled))
        try:
            rollout = int(value.get("rollout_percent", 100) or 100)
        except (TypeError, ValueError):
            rollout = 100
        return enabled, max(0, min(100, rollout))
    if value is None:
        return bool(default_enabled), 100
    return bool(value), 100


def _rollout_bucket(key: str, subject_id: int | str) -> int:
    digest = hashlib.sha256(f"{key}:{subject_id}".encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") % 100


def feature_enabled(
    db: dict[str, Any],
    key: str,
    *,
    default: bool | None = None,
    subject_id: int | str | None = None,
) -> bool:
    root = ensure_feature_flags(db)
    clean = str(key)
    fallback = DEFAULT_FEATURE_FLAGS.get(clean, bool(default) if default is not None else False)
    enabled, rollout = _normalize_config(root.get(clean), fallback)
    if not enabled:
        return False
    if subject_id is None or rollout >= 100:
        return True
    if rollout <= 0:
        return False
    return _rollout_bucket(clean, subject_id) < rollout


def set_feature_flag(
    db: dict[str, Any],
    key: str,
    enabled: bool,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    clean = str(key or "").strip()
    if clean not in DEFAULT_FEATURE_FLAGS:
        raise ValueError("FEATURE_FLAG_UNKNOWN")
    root = ensure_feature_flags(db)
    current_enabled, rollout = _normalize_config(root.get(clean), DEFAULT_FEATURE_FLAGS[clean])
    _ = current_enabled
    root[clean] = {"enabled": bool(enabled), "rollout_percent": rollout}
    return _append_audit(db, clean, bool(enabled), rollout, actor_id)


def set_feature_rollout(
    db: dict[str, Any],
    key: str,
    rollout_percent: int,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    clean = str(key or "").strip()
    if clean not in DEFAULT_FEATURE_FLAGS:
        raise ValueError("FEATURE_FLAG_UNKNOWN")
    rollout = max(0, min(100, int(rollout_percent)))
    root = ensure_feature_flags(db)
    enabled, _old_rollout = _normalize_config(root.get(clean), DEFAULT_FEATURE_FLAGS[clean])
    root[clean] = {"enabled": enabled, "rollout_percent": rollout}
    return _append_audit(db, clean, enabled, rollout, actor_id)


def _append_audit(
    db: dict[str, Any],
    key: str,
    enabled: bool,
    rollout_percent: int,
    actor_id: int | str,
) -> dict[str, Any]:
    audit = db.setdefault("feature_flag_audit", [])
    if not isinstance(audit, list):
        audit = []
        db["feature_flag_audit"] = audit
    row = {
        "feature": key,
        "enabled": bool(enabled),
        "rollout_percent": int(rollout_percent),
        "actor_id": str(actor_id),
        "updated_at": utc_iso(),
    }
    audit.append(row)
    db["feature_flag_audit"] = audit[-500:]
    return row


def feature_flag_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_feature_flags(db)
    items = []
    for key in sorted(DEFAULT_FEATURE_FLAGS):
        enabled, rollout = _normalize_config(root.get(key), DEFAULT_FEATURE_FLAGS[key])
        items.append({"key": key, "enabled": enabled, "rollout_percent": rollout})
    return {
        "items": items,
        "enabled": sum(1 for item in items if item["enabled"]),
        "total": len(items),
        "updated_at": (db.get("feature_flag_audit") or [{}])[-1].get("updated_at")
        if isinstance(db.get("feature_flag_audit"), list) and db.get("feature_flag_audit")
        else None,
    }
