from __future__ import annotations

import copy
import hashlib
import io
import json
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps, UnidentifiedImageError

from config import SETTINGS
from core.utils import parse_dt, utc_iso
from modules.campaign_studio import campaign_by_id, create_marketing_campaign, record_campaign_event, schedule_campaign
from modules.gemini_ai import gemini_generate_ad_copy, gemini_generate_admin_image

AI_AD_STATUSES = {
    "AI_DRAFT", "AI_IMAGE_GENERATING", "AI_QA", "READY_FOR_REVIEW", "APPROVED",
    "SCHEDULED", "PUBLISHED", "PAUSED", "EXPIRED", "REJECTED", "FAILED",
}
_PROHIBITED_PATTERNS = (
    r"سود\s*تضمینی", r"درآمد\s*تضمینی", r"بدون\s*ریسک", r"صددرصد\s*سود",
    r"۱۰۰\s*٪\s*سود", r"100\s*%\s*profit", r"guaranteed\s+profit",
    r"risk[-\s]?free", r"ضرر\s*نمی(?:\s|‌)?کن", r"تضمین\s*بازده",
)
_MAX_IMAGE_BYTES = max(1_000_000, int(os.getenv("AI_AD_MAX_IMAGE_BYTES", str(15 * 1024 * 1024))))
_MAX_IMAGE_PIXELS = max(4_000_000, int(os.getenv("AI_AD_MAX_IMAGE_PIXELS", str(40_000_000))))
_MIN_IMAGE_SIDE = max(128, int(os.getenv("AI_AD_MIN_IMAGE_SIDE", "512")))
_MAX_IMAGE_SIDE = max(_MIN_IMAGE_SIDE, int(os.getenv("AI_AD_MAX_IMAGE_SIDE", "4096")))
_ALLOWED_FORMATS = {"PNG", "JPEG", "WEBP"}
_IMAGE_MIME = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp"}


def _safe_dir() -> Path:
    root = Path(SETTINGS.gemini_generated_ads_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    if getattr(SETTINGS, "run_mode", "development") == "production" and not os.getenv("ALLOW_EPHEMERAL_STORAGE", "").strip().lower() in {"1", "true", "yes", "on"}:
        mount_raw = os.getenv("PERSISTENT_DATA_DIR") or os.getenv("RAILWAY_VOLUME_MOUNT_PATH") or os.getenv("VOLUME_MOUNT_PATH")
        if mount_raw:
            mount = Path(mount_raw).expanduser().resolve()
            try:
                root.relative_to(mount)
            except ValueError as exc:
                raise RuntimeError("AI_AD_STORAGE_NOT_ON_PERSISTENT_VOLUME") from exc
    try:
        os.chmod(root, 0o700)
    except OSError:
        pass
    return root


def _campaign(db: dict[str, Any], campaign_id: int | str) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if not isinstance(row, dict):
        raise ValueError("AI_AD_CAMPAIGN_NOT_FOUND")
    return row


def _decode_and_sanitize_image(payload: bytes) -> tuple[bytes, dict[str, Any]]:
    if not payload:
        raise ValueError("ASSET_EMPTY")
    if len(payload) > _MAX_IMAGE_BYTES:
        raise ValueError("ASSET_TOO_LARGE")
    Image.MAX_IMAGE_PIXELS = _MAX_IMAGE_PIXELS
    try:
        with Image.open(io.BytesIO(payload)) as source:
            source.verify()
        with Image.open(io.BytesIO(payload)) as source:
            if str(source.format or "").upper() not in _ALLOWED_FORMATS:
                raise ValueError("ASSET_FORMAT_NOT_ALLOWED")
            if int(getattr(source, "n_frames", 1) or 1) != 1:
                raise ValueError("ASSET_ANIMATION_NOT_ALLOWED")
            width, height = source.size
            if width < _MIN_IMAGE_SIDE or height < _MIN_IMAGE_SIDE:
                raise ValueError("ASSET_RESOLUTION_TOO_LOW")
            if width * height > _MAX_IMAGE_PIXELS:
                raise ValueError("ASSET_PIXEL_LIMIT_EXCEEDED")
            image = ImageOps.exif_transpose(source)
            image.load()
            if max(image.size) > _MAX_IMAGE_SIDE:
                image.thumbnail((_MAX_IMAGE_SIDE, _MAX_IMAGE_SIDE), Image.Resampling.LANCZOS)
            if image.mode not in {"RGB", "RGBA"}:
                image = image.convert("RGBA" if "A" in image.getbands() else "RGB")
            output = io.BytesIO()
            # Canonical PNG strips EXIF/metadata and makes the QA hash deterministic.
            image.save(output, format="PNG", optimize=True, compress_level=7)
            canonical = output.getvalue()
            if not canonical or len(canonical) > _MAX_IMAGE_BYTES:
                raise ValueError("ASSET_SANITIZED_SIZE_INVALID")
            metadata = {
                "format": "PNG",
                "mime_type": "image/png",
                "width": int(image.width),
                "height": int(image.height),
                "pixels": int(image.width * image.height),
                "bytes": len(canonical),
            }
            return canonical, metadata
    except Image.DecompressionBombError as exc:
        raise ValueError("ASSET_DECOMPRESSION_BOMB") from exc
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("ASSET_CORRUPT") from exc


def _asset_live_digest(asset: dict[str, Any]) -> str:
    path = Path(str(asset.get("path") or ""))
    if not path.is_file():
        return "missing"
    try:
        if path.stat().st_size > _MAX_IMAGE_BYTES:
            return "oversized"
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return "unreadable"


def _qa_subject_hash(row: dict[str, Any]) -> str:
    assets = row.get("ai_assets") if isinstance(row.get("ai_assets"), list) else []
    payload = {
        "message": str(row.get("message") or row.get("ai_copy_selected") or "").strip(),
        "assets": [
            {
                "id": str(asset.get("id") or ""),
                "path": str(asset.get("path") or ""),
                "stored_sha256": str(asset.get("sha256") or ""),
                "live_sha256": _asset_live_digest(asset),
                "mime_type": str(asset.get("mime_type") or ""),
                "width": int(asset.get("width") or 0),
                "height": int(asset.get("height") or 0),
            }
            for asset in assets if isinstance(asset, dict)
        ],
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _invalidate_qa(row: dict[str, Any], reason: str) -> None:
    row["ai_qa"] = {
        "passed": False,
        "errors": ["QA_INVALIDATED"],
        "warnings": [],
        "invalidated_reason": reason,
        "invalidated_at": utc_iso(),
    }
    if row.get("ai_ad_status") in {"READY_FOR_REVIEW", "APPROVED", "SCHEDULED"}:
        row["ai_ad_status"] = "AI_DRAFT"
    row.pop("confirmed_at", None)
    row.pop("confirmed_by", None)


def create_ai_ad_campaign(
    db: dict[str, Any], *, actor_id: int | str, name: str, product: str, objective: str,
    audience: str = "all", delivery: str = "draft", tone: str = "premium",
    call_to_action: str = "", language: str = "fa", brand_notes: str = "",
) -> dict[str, Any]:
    brief = {
        "name": name, "product": product, "objective": objective, "audience": audience,
        "delivery": delivery, "tone": tone, "call_to_action": call_to_action,
        "language": language, "brand": "SENTINEL", "brand_notes": brand_notes,
    }
    generated = gemini_generate_ad_copy(actor_id, brief)
    row = create_marketing_campaign(
        db, name=name, category="acquisition", audience=audience,
        message=str(generated["selected"]), delivery=delivery, created_by=actor_id,
        objective=objective, tracking={"source": "gemini", "medium": "telegram", "creative": "ai-command-os"},
    )
    row.update({
        "ai_ad_status": "AI_DRAFT", "ai_brief": brief, "ai_copy_variants": list(generated.get("variants") or []),
        "ai_copy_selected": str(generated.get("selected") or ""), "ai_copy_rationale": str(generated.get("rationale") or ""),
        "ai_copy_model": str(generated.get("model") or ""), "ai_assets": [], "ai_qa": {}, "updated_at": utc_iso(),
    })
    record_campaign_event(db, row["id"], "ai_copy_created", actor_id=actor_id, metadata={"model": row["ai_copy_model"]})
    return copy.deepcopy(row)


def run_ai_ad_qa(db: dict[str, Any], campaign_id: int | str, *, actor_id: int | str = "system") -> dict[str, Any]:
    row = _campaign(db, campaign_id)
    row["ai_ad_status"] = "AI_QA"
    copy_text = str(row.get("message") or row.get("ai_copy_selected") or "").strip()
    errors: list[str] = []
    warnings: list[str] = []
    if len(copy_text) < 20:
        errors.append("COPY_TOO_SHORT")
    if len(copy_text) > 3500:
        errors.append("COPY_TOO_LONG")
    assets = row.get("ai_assets") if isinstance(row.get("ai_assets"), list) else []
    if assets and len(copy_text) > 1024:
        errors.append("IMAGE_CAPTION_TOO_LONG")
    if any(re.search(pattern, copy_text, flags=re.IGNORECASE) for pattern in _PROHIBITED_PATTERNS):
        errors.append("PROHIBITED_CLAIM")
    for asset in assets:
        if not isinstance(asset, dict):
            errors.append("ASSET_METADATA_INVALID")
            continue
        path = Path(str(asset.get("path") or ""))
        if not path.is_file():
            errors.append("ASSET_MISSING")
            continue
        try:
            if path.stat().st_size > _MAX_IMAGE_BYTES:
                errors.append("ASSET_TOO_LARGE")
                continue
            raw = path.read_bytes()
        except OSError:
            errors.append("ASSET_UNREADABLE")
            continue
        digest = hashlib.sha256(raw).hexdigest()
        if digest != str(asset.get("sha256") or ""):
            errors.append("ASSET_HASH_MISMATCH")
            continue
        try:
            canonical, metadata = _decode_and_sanitize_image(raw)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if canonical != raw:
            errors.append("ASSET_NOT_CANONICAL")
        if str(asset.get("mime_type") or "") != metadata["mime_type"]:
            errors.append("ASSET_MIME_MISMATCH")
        if int(asset.get("width") or 0) != metadata["width"] or int(asset.get("height") or 0) != metadata["height"]:
            errors.append("ASSET_DIMENSION_MISMATCH")
    if not assets:
        warnings.append("IMAGE_NOT_GENERATED")
    subject_hash = _qa_subject_hash(row)
    result = {
        "passed": not errors,
        "errors": sorted(set(errors)),
        "warnings": sorted(set(warnings)),
        "subject_hash": subject_hash,
        "checked_at": utc_iso(),
        "checked_by": str(actor_id),
    }
    row["ai_qa"] = result
    row["ai_ad_status"] = "READY_FOR_REVIEW" if result["passed"] else "FAILED"
    row["updated_at"] = utc_iso()
    record_campaign_event(db, row["id"], "ai_qa_completed", actor_id=actor_id, metadata=result)
    return copy.deepcopy(result)


def generate_ai_ad_image(db: dict[str, Any], campaign_id: int | str, *, actor_id: int | str, prompt: str = "", aspect_ratio: str = "1:1") -> dict[str, Any]:
    row = _campaign(db, campaign_id)
    row["ai_ad_status"] = "AI_IMAGE_GENERATING"
    row["updated_at"] = utc_iso()
    brief = row.get("ai_brief") if isinstance(row.get("ai_brief"), dict) else {}
    effective_prompt = str(prompt or "").strip() or (
        f"Premium luxury fintech advertisement for SENTINEL. Product: {brief.get('product')}. "
        f"Objective: {brief.get('objective')}. Deep black, graphite, polished silver and restrained metallic gold. "
        "No people, no random logos, no watermark, ample negative space, accurate Persian text only when essential."
    )
    try:
        generated = gemini_generate_admin_image(actor_id, effective_prompt, aspect_ratio=aspect_ratio)
        raw_payload = bytes(generated.get("image_bytes") or b"")
        payload, metadata = _decode_and_sanitize_image(raw_payload)
        root = _safe_dir()
        digest = hashlib.sha256(payload).hexdigest()
        filename = f"{re.sub(r'[^A-Za-z0-9_-]', '_', str(row['id']))}_{digest[:16]}.png"
        destination = (root / filename).resolve()
        destination.relative_to(root)
        fd, tmp = tempfile.mkstemp(prefix=".sentinel-ad-", dir=root)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(tmp, 0o600)
            os.replace(tmp, destination)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        _invalidate_qa(row, "ASSET_CHANGED")
        preview_default = "0" if getattr(SETTINGS, "run_mode", "development") == "production" else "200"
        preview_chars = max(0, min(800, int(os.getenv("AI_AD_PROMPT_PREVIEW_CHARS", preview_default))))
        asset = {
            "id": f"AD-{len(row.setdefault('ai_assets', [])) + 1}",
            "path": str(destination),
            "mime_type": metadata["mime_type"],
            "sha256": digest,
            "bytes": metadata["bytes"],
            "width": metadata["width"],
            "height": metadata["height"],
            "format": metadata["format"],
            "model": str(generated.get("model") or ""),
            "prompt_hash": hashlib.sha256(effective_prompt.encode("utf-8")).hexdigest(),
            "aspect_ratio": aspect_ratio,
            "created_at": utc_iso(),
            "created_by": str(actor_id),
            "storage_state": "available",
        }
        if preview_chars:
            asset["prompt_preview"] = effective_prompt[:preview_chars]
        row["ai_assets"].append(asset)
        row["creative"] = {"type": "photo", "file_path": asset["path"], "caption": row.get("message", "")}
        row["updated_at"] = utc_iso()
        qa = run_ai_ad_qa(db, row["id"], actor_id=actor_id)
        return {"campaign": copy.deepcopy(row), "asset": copy.deepcopy(asset), "qa": qa}
    except Exception as exc:
        row["ai_ad_status"] = "FAILED"
        row["ai_last_error"] = f"{exc.__class__.__name__}:{str(exc)[:300]}"
        row["updated_at"] = utc_iso()
        raise


def approve_ai_ad(db: dict[str, Any], campaign_id: int | str, *, actor_id: int | str) -> dict[str, Any]:
    row = _campaign(db, campaign_id)
    # Approval always re-runs QA against current copy and file bytes. A stale QA record can never authorize publication.
    qa = run_ai_ad_qa(db, row["id"], actor_id=actor_id)
    if not qa.get("passed") or qa.get("subject_hash") != _qa_subject_hash(row):
        raise ValueError("AI_AD_QA_FAILED")
    row.update({"ai_ad_status": "APPROVED", "confirmed_at": utc_iso(), "confirmed_by": str(actor_id), "updated_at": utc_iso()})
    record_campaign_event(db, row["id"], "ai_ad_approved", actor_id=actor_id, metadata={"subject_hash": qa["subject_hash"]})
    return copy.deepcopy(row)


def schedule_ai_ad(db: dict[str, Any], campaign_id: int | str, *, scheduled_for: Any, actor_id: int | str, priority: int = 3) -> dict[str, Any]:
    row = _campaign(db, campaign_id)
    qa = row.get("ai_qa") if isinstance(row.get("ai_qa"), dict) else {}
    if row.get("ai_ad_status") != "APPROVED" or not qa.get("passed") or qa.get("subject_hash") != _qa_subject_hash(row):
        raise ValueError("AI_AD_APPROVAL_REQUIRED")
    scheduled = schedule_campaign(db, row["id"], scheduled_for, actor_id=actor_id, priority=priority)
    scheduled["ai_ad_status"] = "SCHEDULED"
    scheduled["updated_at"] = utc_iso()
    return copy.deepcopy(scheduled)


def cleanup_generated_ad_assets(db: dict[str, Any], *, now: datetime | None = None) -> dict[str, int]:
    root = _safe_dir()
    now = now or datetime.now(timezone.utc)
    retention_days = max(1, int(os.getenv("AI_AD_ASSET_RETENTION_DAYS", "30")))
    max_total_bytes = max(10_000_000, int(os.getenv("AI_AD_ASSET_MAX_TOTAL_BYTES", str(2 * 1024 * 1024 * 1024))))
    cutoff = now - timedelta(days=retention_days)
    protected: set[Path] = set()
    purge_metadata: dict[Path, list[dict[str, Any]]] = {}
    campaigns = (db.get("marketing_campaigns") or {}).values() if isinstance(db.get("marketing_campaigns"), dict) else (db.get("marketing_campaigns") or [])
    for row in campaigns:
        if not isinstance(row, dict):
            continue
        campaign_status = str(row.get("status") or "").lower()
        ai_status = str(row.get("ai_ad_status") or "").upper()
        active = campaign_status in {"scheduled", "queued", "processing"} or ai_status in {"APPROVED", "SCHEDULED"}
        updated = parse_dt(row.get("updated_at") or row.get("created_at"))
        recent = updated is None or updated >= cutoff
        for asset in row.get("ai_assets") or []:
            if not isinstance(asset, dict) or not asset.get("path"):
                continue
            try:
                path = Path(str(asset["path"])).resolve()
                path.relative_to(root)
            except (OSError, ValueError):
                continue
            if active or recent:
                protected.add(path)
            else:
                purge_metadata.setdefault(path, []).append(asset)

    files: list[tuple[Path, float, int]] = []
    for path in root.glob("*.png"):
        try:
            resolved = path.resolve()
            resolved.relative_to(root)
            stat = resolved.stat()
            files.append((resolved, stat.st_mtime, stat.st_size))
        except (OSError, ValueError):
            continue
    removed = 0
    freed = 0

    def remove_file(path: Path, size: int) -> bool:
        nonlocal removed, freed
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            return False
        removed += 1
        freed += size
        for asset in purge_metadata.get(path, []):
            asset["path"] = ""
            asset["storage_state"] = "purged"
            asset["purged_at"] = utc_iso(now)
            asset.pop("prompt_preview", None)
        return True

    retained: list[tuple[Path, float, int]] = []
    for path, mtime, size in files:
        modified = datetime.fromtimestamp(mtime, tz=timezone.utc)
        if path not in protected and modified < cutoff and remove_file(path, size):
            continue
        retained.append((path, mtime, size))

    total = sum(size for _, _, size in retained)
    if total > max_total_bytes:
        for path, _, size in sorted(retained, key=lambda item: item[1]):
            if total <= max_total_bytes:
                break
            if path in protected:
                continue
            if remove_file(path, size):
                total -= size
    return {"removed": removed, "freed_bytes": freed, "remaining_bytes": total}


def ai_ad_summary(db: dict[str, Any], campaign_id: int | str) -> dict[str, Any]:
    row = _campaign(db, campaign_id)
    return {
        "id": row.get("id"), "name": row.get("name"), "status": row.get("status"), "ai_ad_status": row.get("ai_ad_status"),
        "delivery": row.get("delivery"), "scheduled_for": row.get("scheduled_for"), "message": row.get("message"),
        "assets": copy.deepcopy(row.get("ai_assets") or []), "qa": copy.deepcopy(row.get("ai_qa") or {}),
        "tracking": copy.deepcopy(row.get("tracking") or {}), "updated_at": row.get("updated_at"),
    }
