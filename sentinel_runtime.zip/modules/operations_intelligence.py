from __future__ import annotations

import gc
import os
import resource
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.utils import parse_dt, utc_iso
from modules.feature_flags import feature_enabled, feature_flag_snapshot
from modules.provider_health import provider_health_summary
from modules.provider_intelligence import provider_cost_summary
from modules.security_sentinel import security_sentinel_snapshot


def _read_int(path: str) -> int | None:
    try:
        raw = Path(path).read_text(encoding="utf-8").strip()
        if raw == "max":
            return None
        return int(raw)
    except (OSError, ValueError):
        return None


def _rss_bytes() -> int:
    try:
        for line in Path("/proc/self/status").read_text(encoding="utf-8").splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss or 0)
    return value * 1024 if value < 10_000_000 else value


def _memory_limit_bytes() -> int | None:
    values = [
        _read_int("/sys/fs/cgroup/memory.max"),
        _read_int("/sys/fs/cgroup/memory/memory.limit_in_bytes"),
    ]
    env_mb = str(os.getenv("SENTINEL_MEMORY_LIMIT_MB", "")).strip()
    if env_mb:
        try:
            values.append(int(float(env_mb) * 1024 * 1024))
        except ValueError:
            pass
    realistic = [value for value in values if value and value > 16 * 1024 * 1024 and value < (1 << 60)]
    return min(realistic) if realistic else None


def memory_guardian_snapshot() -> dict[str, Any]:
    rss = max(0, _rss_bytes())
    limit = _memory_limit_bytes()
    percent = round(rss / limit * 100, 2) if limit else None
    warning = max(50.0, min(95.0, float(os.getenv("MEMORY_GUARDIAN_WARNING_PERCENT", "75") or 75)))
    critical = max(warning + 1, min(99.0, float(os.getenv("MEMORY_GUARDIAN_CRITICAL_PERCENT", "90") or 90)))
    if percent is None:
        state = "unknown"
    elif percent >= critical:
        state = "critical"
    elif percent >= warning:
        state = "warning"
    else:
        state = "healthy"
    return {
        "state": state,
        "rss_bytes": rss,
        "rss_mb": round(rss / 1024 / 1024, 2),
        "limit_bytes": limit,
        "limit_mb": round(limit / 1024 / 1024, 2) if limit else None,
        "percent": percent,
        "warning_percent": warning,
        "critical_percent": critical,
        "generated_at": utc_iso(),
    }


def _operations(db: dict[str, Any]) -> dict[str, Any]:
    operations = db.setdefault("operations", {})
    if not isinstance(operations, dict):
        operations = {}
        db["operations"] = operations
    return operations


def record_memory_trend_sample(
    db: dict[str, Any],
    snapshot: dict[str, Any] | None = None,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    now = (now or datetime.now(UTC)).astimezone(UTC)
    sample = dict(snapshot or memory_guardian_snapshot())
    row = {
        "created_at": now.isoformat(),
        "rss_bytes": int(sample.get("rss_bytes", 0) or 0),
        "rss_mb": float(sample.get("rss_mb", 0) or 0),
        "percent": sample.get("percent"),
    }
    operations = _operations(db)
    samples = operations.setdefault("memory_trend", [])
    if not isinstance(samples, list):
        samples = []
        operations["memory_trend"] = samples
    samples.append(row)
    cutoff = now - timedelta(hours=max(1, int(os.getenv("MEMORY_TREND_RETENTION_HOURS", "24") or 24)))
    trimmed = []
    for item in samples[-500:]:
        if not isinstance(item, dict):
            continue
        created = parse_dt(item.get("created_at"))
        if created is None or created.astimezone(UTC) >= cutoff:
            trimmed.append(item)
    operations["memory_trend"] = trimmed[-500:]
    return row


def memory_trend_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    operations = _operations(db)
    samples = [dict(item) for item in (operations.get("memory_trend") or []) if isinstance(item, dict)]
    points: list[tuple[datetime, float]] = []
    for item in samples:
        created = parse_dt(item.get("created_at"))
        if created is None:
            continue
        points.append((created.astimezone(UTC), float(item.get("rss_mb", 0) or 0)))
    points.sort(key=lambda item: item[0])
    growth_per_hour = 0.0
    if len(points) >= 2:
        seconds = max(1.0, (points[-1][0] - points[0][0]).total_seconds())
        growth_per_hour = (points[-1][1] - points[0][1]) / seconds * 3600.0
    threshold = max(1.0, float(os.getenv("MEMORY_TREND_WARNING_MB_PER_HOUR", "64") or 64))
    suspected = len(points) >= 3 and growth_per_hour >= threshold
    return {
        "samples": len(points),
        "growth_mb_per_hour": round(growth_per_hour, 2),
        "suspected_leak": bool(suspected),
        "warning_mb_per_hour": threshold,
        "latest_rss_mb": points[-1][1] if points else None,
        "generated_at": utc_iso(),
    }


def _self_heal_state(db: dict[str, Any]) -> dict[str, Any]:
    operations = _operations(db)
    state = operations.setdefault("self_healing", {})
    if not isinstance(state, dict):
        state = {}
        operations["self_healing"] = state
    state.setdefault("history", [])
    state.setdefault("recovery_events", [])
    return state


def _recovery_budget(state: dict[str, Any], now: datetime) -> dict[str, Any]:
    window_minutes = max(5, int(os.getenv("SELF_HEALING_BUDGET_WINDOW_MINUTES", "60") or 60))
    max_actions = max(1, int(os.getenv("SELF_HEALING_MAX_RECOVERIES_PER_WINDOW", "5") or 5))
    cutoff = now - timedelta(minutes=window_minutes)
    recent = []
    for raw in state.get("recovery_events") or []:
        created = parse_dt(raw)
        if created is not None and created.astimezone(UTC) >= cutoff:
            recent.append(created.astimezone(UTC).isoformat())
    state["recovery_events"] = recent[-100:]
    return {
        "used": len(recent),
        "limit": max_actions,
        "remaining": max(0, max_actions - len(recent)),
        "window_minutes": window_minutes,
        "exhausted": len(recent) >= max_actions,
    }


def run_safe_self_healing(db: dict[str, Any], *, force: bool = False, now: datetime | None = None) -> dict[str, Any]:
    now = (now or datetime.now(UTC)).astimezone(UTC)
    if not feature_enabled(db, "ops.self_healing", default=True):
        return {"status": "disabled", "actions": []}
    memory = memory_guardian_snapshot()
    record_memory_trend_sample(db, memory, now=now)
    state = _self_heal_state(db)
    budget = _recovery_budget(state, now)
    if feature_enabled(db, "ops.recovery_budget", default=True) and budget["exhausted"] and not force:
        state["last_status"] = "degraded_budget_exhausted"
        return {"status": state["last_status"], "actions": [], "memory": memory, "recovery_budget": budget}

    cooldown = max(60, int(os.getenv("SELF_HEALING_COOLDOWN_SECONDS", "300") or 300))
    last = parse_dt(state.get("last_run_at"))
    if last and not force and now - last.astimezone(UTC) < timedelta(seconds=cooldown):
        return {
            "status": "cooldown",
            "actions": [],
            "memory": memory,
            "last_run_at": state.get("last_run_at"),
            "recovery_budget": budget,
        }

    actions: list[dict[str, Any]] = []
    should_collect = force or memory.get("state") in {"warning", "critical"}
    if should_collect:
        before = int(memory.get("rss_bytes") or 0)
        collected = gc.collect()
        try:
            from core.shared_cache import trim_local_cache
            cache_result = trim_local_cache(keep_ratio=0.5 if memory.get("state") == "critical" else 0.75)
        except Exception:
            cache_result = {"removed": 0}
        after_snapshot = memory_guardian_snapshot()
        actions.append({
            "action": "memory_cleanup",
            "gc_collected": int(collected),
            "cache_removed": int(cache_result.get("removed", 0) or 0),
            "rss_before": before,
            "rss_after": int(after_snapshot.get("rss_bytes") or 0),
        })
        memory = after_snapshot

    providers = provider_health_summary(db)
    if int(providers.get("offline", 0) or 0) > 0:
        actions.append({"action": "provider_failover_advisory", "offline": int(providers.get("offline", 0) or 0)})

    state["last_run_at"] = now.isoformat()
    state["last_status"] = "acted" if actions else "healthy"
    history = state.setdefault("history", [])
    if not isinstance(history, list):
        history = []
        state["history"] = history
    if actions:
        events = state.setdefault("recovery_events", [])
        if not isinstance(events, list):
            events = []
            state["recovery_events"] = events
        events.append(now.isoformat())
        state["recovery_events"] = events[-100:]
        budget = _recovery_budget(state, now)
    event = {
        "created_at": now.isoformat(),
        "status": state["last_status"],
        "actions": actions,
        "memory": memory,
        "recovery_budget": budget,
    }
    history.append(event)
    state["history"] = history[-100:]
    return {"status": state["last_status"], "actions": actions, "memory": memory, "recovery_budget": budget}


def business_intelligence_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    users = db.get("users") if isinstance(db.get("users"), dict) else {}
    vip = db.get("vip_users") if isinstance(db.get("vip_users"), dict) else {}
    signals = db.get("signals") if isinstance(db.get("signals"), list) else []
    payments = db.get("payments")
    if isinstance(payments, dict):
        payment_count = len(payments)
    elif isinstance(payments, list):
        payment_count = len(payments)
    else:
        payment_count = 0
    active_users = 0
    for row in users.values():
        if isinstance(row, dict) and str(row.get("status") or "active") not in {"blocked", "deleted"}:
            active_users += 1
    return {
        "users": len(users),
        "active_users": active_users,
        "vip_records": len(vip),
        "signals": len(signals),
        "payments": payment_count,
        "generated_at": utc_iso(),
    }


def operations_command_center_snapshot(db: dict[str, Any], *, observability: dict[str, Any] | None = None) -> dict[str, Any]:
    obs = dict(observability or {})
    memory = memory_guardian_snapshot()
    providers = provider_health_summary(db)
    healing = _self_heal_state(db)
    jobs = [row for row in (obs.get("jobs") or {}).values() if isinstance(row, dict)]
    failed_jobs = sum(1 for row in jobs if str(row.get("status")) in {"failed", "degraded"})
    budget = _recovery_budget(healing, datetime.now(UTC))
    return {
        "memory": memory,
        "memory_trend": memory_trend_snapshot(db),
        "self_healing": {
            "enabled": feature_enabled(db, "ops.self_healing", default=True),
            "last_run_at": healing.get("last_run_at"),
            "last_status": healing.get("last_status", "never"),
            "recent": list(healing.get("history") or [])[-5:],
            "recovery_budget": budget,
        },
        "providers": providers,
        "provider_costs": provider_cost_summary(db),
        "security": security_sentinel_snapshot(db),
        "business": business_intelligence_snapshot(db),
        "feature_flags": feature_flag_snapshot(db),
        "jobs": {"total": len(jobs), "failed_or_degraded": failed_jobs},
        "uptime_seconds": int(obs.get("uptime_seconds", 0) or 0),
        "generated_at": utc_iso(),
    }
