from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now
from modules.kpi_trader import task_is_overdue

HANDOFF_STATUSES = {"open", "acknowledged", "completed", "cancelled"}


def ensure_operations_handoff(db: dict[str, Any]) -> None:
    db.setdefault("shift_handoffs", [])
    db.setdefault("operations_daily_briefs", {})


def _next_id(db: dict[str, Any], key: str) -> int:
    next_ids = db.setdefault("next_ids", {})
    value = int(next_ids.get(key, 1) or 1)
    next_ids[key] = value + 1
    return value


def _clean_items(values: Any, *, limit: int = 30) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    if not isinstance(values, list):
        return output
    for item in values[:limit]:
        if isinstance(item, dict):
            title = str(item.get("title") or item.get("text") or "").strip()
            if not title:
                continue
            output.append(
                {
                    "title": title[:240],
                    "owner_id": str(item.get("owner_id") or ""),
                    "due_at": str(item.get("due_at") or ""),
                    "priority": str(item.get("priority") or "normal")[:24],
                    "status": str(item.get("status") or "pending")[:24],
                    "reference": str(item.get("reference") or "")[:160],
                }
            )
        elif str(item).strip():
            output.append(
                {
                    "title": str(item).strip()[:240],
                    "owner_id": "",
                    "due_at": "",
                    "priority": "normal",
                    "status": "pending",
                    "reference": "",
                }
            )
    return output


def create_shift_handoff(
    db: dict[str, Any],
    *,
    from_admin_id: int | str,
    to_admin_id: int | str,
    summary: str,
    pending_items: Any = None,
    risks: Any = None,
    decisions: Any = None,
    next_actions: Any = None,
    due_at: str | None = None,
) -> dict[str, Any]:
    ensure_operations_handoff(db)
    from_uid = str(from_admin_id).strip()
    to_uid = str(to_admin_id).strip()
    if not from_uid or not to_uid:
        raise ValueError("HANDOFF_ADMIN_REQUIRED")
    from modules.admin_access import is_any_admin
    if not is_any_admin(db, to_uid) or from_uid == to_uid:
        raise ValueError("HANDOFF_TARGET_INVALID")
    summary_text = str(summary or "").strip()
    if len(summary_text) < 5:
        raise ValueError("HANDOFF_SUMMARY_REQUIRED")
    due = parse_dt(due_at) if due_at else None
    now = utc_now()
    if due and due < now - timedelta(minutes=1):
        raise ValueError("HANDOFF_DUE_AT_INVALID")
    row = {
        "id": _next_id(db, "shift_handoff"),
        "from_admin_id": from_uid,
        "to_admin_id": to_uid,
        "summary": summary_text[:2000],
        "pending_items": _clean_items(pending_items),
        "risks": _clean_items(risks),
        "decisions": _clean_items(decisions),
        "next_actions": _clean_items(next_actions),
        "status": "open",
        "created_at": utc_iso(now),
        "due_at": utc_iso(due) if due else None,
        "acknowledged_at": None,
        "completed_at": None,
        "updated_at": utc_iso(now),
        "history": [
            {
                "status": "open",
                "admin_id": from_uid,
                "at": utc_iso(now),
                "note": "handoff created",
            }
        ],
    }
    db["shift_handoffs"].append(row)
    return dict(row)


def _find_handoff(db: dict[str, Any], handoff_id: int | str) -> dict[str, Any]:
    target = int(handoff_id)
    for row in db.get("shift_handoffs", []):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target:
            return row
    raise ValueError("HANDOFF_NOT_FOUND")


def update_shift_handoff(
    db: dict[str, Any],
    handoff_id: int | str,
    *,
    admin_id: int | str,
    status: str,
    note: str = "",
) -> dict[str, Any]:
    row = _find_handoff(db, handoff_id)
    next_status = str(status or "").strip().lower()
    if next_status not in HANDOFF_STATUSES:
        raise ValueError("HANDOFF_STATUS_INVALID")
    uid = str(admin_id)
    if uid not in {str(row.get("from_admin_id")), str(row.get("to_admin_id"))}:
        raise ValueError("HANDOFF_ADMIN_MISMATCH")
    current = str(row.get("status") or "open")
    allowed = {
        "open": {"acknowledged", "cancelled"},
        "acknowledged": {"completed", "cancelled"},
        "completed": set(),
        "cancelled": set(),
    }
    if next_status != current and next_status not in allowed.get(current, set()):
        raise ValueError("HANDOFF_TRANSITION_INVALID")
    now = utc_iso()
    row["status"] = next_status
    row["updated_at"] = now
    if next_status == "acknowledged":
        row["acknowledged_at"] = row.get("acknowledged_at") or now
    if next_status == "completed":
        row["completed_at"] = now
    row.setdefault("history", []).append(
        {"status": next_status, "admin_id": uid, "at": now, "note": str(note or "")[:500]}
    )
    return dict(row)


def handoffs_for_admin(
    db: dict[str, Any],
    admin_id: int | str,
    *,
    status: str = "",
    limit: int = 50,
) -> list[dict[str, Any]]:
    ensure_operations_handoff(db)
    uid = str(admin_id)
    rows = [
        dict(row)
        for row in db.get("shift_handoffs", [])
        if isinstance(row, dict)
        and uid in {str(row.get("from_admin_id")), str(row.get("to_admin_id"))}
        and (not status or str(row.get("status")) == status)
    ]
    rows.sort(key=lambda row: str(row.get("updated_at") or row.get("created_at") or ""), reverse=True)
    return rows[: max(1, min(int(limit or 50), 200))]


def _pending_vip_orders(db: dict[str, Any]) -> list[dict[str, Any]]:
    pending = {"pending", "approving", "submitted", "review"}
    return [
        row
        for row in db.get("vip_orders", [])
        if isinstance(row, dict) and str(row.get("status") or "").lower() in pending
    ]


def _open_tickets(db: dict[str, Any]) -> list[dict[str, Any]]:
    closed = {"closed", "resolved", "cancelled"}
    return [
        row
        for row in db.get("tickets", [])
        if isinstance(row, dict) and str(row.get("status") or "open").lower() not in closed
    ]


def _open_incidents(db: dict[str, Any]) -> list[dict[str, Any]]:
    raw = db.get("incidents", [])
    rows = raw.values() if isinstance(raw, dict) else raw if isinstance(raw, list) else []
    closed = {"resolved", "closed", "cancelled"}
    return [
        row
        for row in rows
        if isinstance(row, dict) and str(row.get("status") or "open").lower() not in closed
    ]


def daily_operations_brief(
    db: dict[str, Any],
    *,
    admin_ids: list[int | str] | tuple[int | str, ...] = (),
    now: datetime | None = None,
    persist: bool = True,
) -> dict[str, Any]:
    ensure_operations_handoff(db)
    current = now or utc_now()
    today = current.date().isoformat()
    orders = _pending_vip_orders(db)
    tickets = _open_tickets(db)
    incidents = _open_incidents(db)
    scheduled = [
        row
        for row in db.get("scheduled_signals", [])
        if isinstance(row, dict) and str(row.get("status") or "") in {"pending", "processing", "failed"}
    ]
    overdue_tasks = [
        row
        for row in db.get("kpi_trader_tasks", [])
        if isinstance(row, dict) and row.get("status") == "active" and task_is_overdue(row, now=current)
    ]
    active_handoffs = [
        row
        for row in db.get("shift_handoffs", [])
        if isinstance(row, dict) and row.get("status") in {"open", "acknowledged", "pending", "accepted"}
    ]
    campaigns = db.get("marketing_campaigns", {})
    campaign_rows = campaigns.values() if isinstance(campaigns, dict) else []
    campaign_attention = [
        row
        for row in campaign_rows
        if isinstance(row, dict) and str(row.get("status") or "") in {"failed", "paused", "needs_review"}
    ]
    shift_map = db.get("admin_shifts", {}) if isinstance(db.get("admin_shifts"), dict) else {}
    uncovered = [str(uid) for uid in admin_ids if not isinstance(shift_map.get(str(uid)), dict)]

    priorities: list[dict[str, Any]] = []
    for severity, count, title, route in (
        ("critical", len(incidents), "Unresolved operational incidents", "incidents"),
        ("high", len(orders), "VIP orders awaiting review", "orders"),
        ("high", len(tickets), "Open support tickets", "tickets"),
        ("high", len(overdue_tasks), "Overdue KPI tasks", "kpi"),
        ("normal", len(scheduled), "Scheduled signal jobs requiring attention", "signals"),
        ("normal", len(active_handoffs), "Open shift handoffs", "handoffs"),
        ("normal", len(campaign_attention), "Campaigns requiring review", "campaigns"),
    ):
        if count:
            priorities.append({"severity": severity, "count": count, "title": title, "route": route})
    severity_order = {"critical": 0, "high": 1, "normal": 2, "low": 3}
    priorities.sort(key=lambda row: (severity_order.get(str(row["severity"]), 9), -int(row["count"])))

    ticket_priorities = Counter(str(row.get("priority") or "normal") for row in tickets)
    brief = {
        "date": today,
        "generated_at": utc_iso(current),
        "counts": {
            "pending_vip_orders": len(orders),
            "open_tickets": len(tickets),
            "critical_tickets": int(ticket_priorities.get("critical", 0)) + int(ticket_priorities.get("urgent", 0)),
            "open_incidents": len(incidents),
            "scheduled_signal_jobs": len(scheduled),
            "overdue_tasks": len(overdue_tasks),
            "open_handoffs": len(active_handoffs),
            "campaigns_attention": len(campaign_attention),
        },
        "priorities": priorities[:20],
        "shift_coverage": {
            "configured": len(shift_map),
            "requested_admins": len(admin_ids),
            "unconfigured_admin_ids": uncovered,
        },
        "health": "critical" if incidents else "attention" if priorities else "clear",
    }
    if persist:
        db["operations_daily_briefs"][today] = brief
    return brief
