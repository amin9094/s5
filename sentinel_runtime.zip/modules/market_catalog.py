from __future__ import annotations

import re
from dataclasses import dataclass

_SAFE_SYMBOL = re.compile(r"^[A-Z0-9.^=_-]{2,24}$")


@dataclass(frozen=True, slots=True)
class MarketAsset:
    symbol: str
    title: str
    category: str
    aliases: tuple[str, ...] = ()


_ASSETS = (
    MarketAsset("XAUUSD", "طلای جهانی", "metals", ("GOLD", "XAU")),
    MarketAsset("XAGUSD", "نقره جهانی", "metals", ("SILVER", "XAG")),
    MarketAsset("PL=F", "پلاتین", "metals", ("PLATINUM",)),
    MarketAsset("PA=F", "پالادیوم", "metals", ("PALLADIUM",)),
    MarketAsset("HG=F", "مس", "metals", ("COPPER",)),
    MarketAsset("EURUSD", "یورو/دلار", "forex"),
    MarketAsset("GBPUSD", "پوند/دلار", "forex"),
    MarketAsset("USDJPY", "دلار/ین", "forex"),
    MarketAsset("USDCHF", "دلار/فرانک", "forex"),
    MarketAsset("USDCAD", "دلار/دلار کانادا", "forex"),
    MarketAsset("AUDUSD", "دلار استرالیا/دلار", "forex"),
    MarketAsset("NZDUSD", "دلار نیوزیلند/دلار", "forex"),
    MarketAsset("EURGBP", "یورو/پوند", "forex"),
    MarketAsset("EURJPY", "یورو/ین", "forex"),
    MarketAsset("GBPJPY", "پوند/ین", "forex"),
    MarketAsset("AUDJPY", "دلار استرالیا/ین", "forex"),
    MarketAsset("US100", "نزدک ۱۰۰", "indices", ("NASDAQ", "NAS100", "NDX")),
    MarketAsset("US500", "S&P 500", "indices", ("SP500", "SPX500")),
    MarketAsset("US30", "داوجونز", "indices", ("DOW", "DJI")),
    MarketAsset("GER40", "دکس آلمان", "indices", ("DAX", "DE40")),
    MarketAsset("UK100", "فوتسی ۱۰۰", "indices", ("FTSE",)),
    MarketAsset("JP225", "نیکی ۲۲۵", "indices", ("NIKKEI",)),
    MarketAsset("VIX", "شاخص ترس VIX", "indices"),
    MarketAsset("DXY", "شاخص دلار", "indices", ("DX",)),
    MarketAsset("WTI", "نفت WTI", "energy", ("CL", "CRUDE")),
    MarketAsset("BRENT", "نفت برنت", "energy", ("BZ",)),
    MarketAsset("NATGAS", "گاز طبیعی", "energy", ("NG",)),
    MarketAsset("BTCUSD", "بیت‌کوین", "crypto", ("BTC", "BTCUSDT")),
    MarketAsset("ETHUSD", "اتریوم", "crypto", ("ETH", "ETHUSDT")),
    MarketAsset("BNBUSD", "بایننس کوین", "crypto", ("BNB", "BNBUSDT")),
    MarketAsset("SOLUSD", "سولانا", "crypto", ("SOL", "SOLUSDT")),
    MarketAsset("XRPUSD", "ریپل", "crypto", ("XRP", "XRPUSDT")),
    MarketAsset("ADAUSD", "کاردانو", "crypto", ("ADA", "ADAUSDT")),
    MarketAsset("DOGEUSD", "دوج‌کوین", "crypto", ("DOGE", "DOGEUSDT")),
    MarketAsset("TRXUSD", "ترون", "crypto", ("TRX", "TRXUSDT")),
    MarketAsset("TONUSD", "تون", "crypto", ("TON", "TONUSDT")),
)

ASSET_BY_SYMBOL = {item.symbol: item for item in _ASSETS}
_ALIAS_TO_SYMBOL: dict[str, str] = {}
for item in _ASSETS:
    _ALIAS_TO_SYMBOL[item.symbol] = item.symbol
    for alias in item.aliases:
        _ALIAS_TO_SYMBOL[alias] = item.symbol

LOCAL_ASSETS = {
    "dollar": "دلار آزاد",
    "tether": "تتر",
    "gold18": "طلای ۱۸ عیار",
    "gold24": "طلای ۲۴ عیار",
    "mesghal": "مثقال طلا",
    "coin_emami": "سکه امامی",
    "coin_bahar": "سکه بهار آزادی",
    "half_coin": "نیم‌سکه",
    "quarter_coin": "ربع‌سکه",
    "gerami_coin": "سکه گرمی",
    "euro_iran": "یورو آزاد",
    "aed_iran": "درهم امارات",
    "gbp_iran": "پوند آزاد",
    "try_iran": "لیر ترکیه",
}

CATEGORY_LABELS = {
    "forex": "فارکس",
    "crypto": "ارز دیجیتال",
    "indices": "شاخص‌ها",
    "metals": "فلزات",
    "energy": "انرژی",
    "stocks": "سهام",
}


def normalize_asset_symbol(value: str) -> str:
    raw = str(value or "").strip()
    local_key = raw.casefold().replace(" ", "")
    if local_key in LOCAL_ASSETS:
        return local_key
    clean = raw.upper().replace("/", "").replace(" ", "")
    clean = _ALIAS_TO_SYMBOL.get(clean, clean)
    if not _SAFE_SYMBOL.fullmatch(clean):
        raise ValueError("نماد بازار نامعتبر است")
    return clean


def asset_title(symbol: str) -> str:
    clean = str(symbol or "")
    if clean in LOCAL_ASSETS:
        return LOCAL_ASSETS[clean]
    item = ASSET_BY_SYMBOL.get(clean)
    return item.title if item else clean


def assets_by_category(category: str) -> list[MarketAsset]:
    return [item for item in _ASSETS if item.category == category]


def popular_assets() -> list[MarketAsset]:
    wanted = ("XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "BTCUSD", "ETHUSD", "US100", "US500", "WTI", "DXY")
    return [ASSET_BY_SYMBOL[symbol] for symbol in wanted]
