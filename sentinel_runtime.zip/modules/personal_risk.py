from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from core.utils import utc_iso
from modules.trading_os import (
    account_exposure,
    calculate_position_plan,
    create_or_update_account,
    get_account,
    prop_account_snapshot,
)

DEFAULT_RISK_PROFILE: dict[str, Any] = {
    "balance": 0.0,
    "account_currency": "USD",
    "default_risk_percent": 1.0,
    "max_daily_risk_percent": 3.0,
    "max_open_risk_percent": 5.0,
    "max_open_trades": 5,
    "leverage": 1.0,
    "enabled": False,
    "prop_firm_enabled": False,
    "starting_balance": 0.0,
    "current_equity": 0.0,
    "max_daily_loss_percent": 5.0,
    "max_total_loss_percent": 10.0,
    "profit_target_percent": 8.0,
    "min_trading_days": 5,
    "current_trading_days": 0,
    "timezone": "UTC",
}


def _number(value: Any, fallback: float = 0.0) -> float:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return fallback
    return float(number) if number.is_finite() else fallback


def _profiles(db: dict[str, Any]) -> dict[str, dict[str, Any]]:
    root = db.setdefault("personal_risk_profiles", {})
    if not isinstance(root, dict):
        root = {}
        db["personal_risk_profiles"] = root
    return root


def risk_profile(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    """Backward-compatible profile projected from the default Trading OS account."""
    uid = str(user_id)
    profile = _profiles(db).setdefault(uid, {})
    if not isinstance(profile, dict):
        profile = {}
        _profiles(db)[uid] = profile
    for key, value in DEFAULT_RISK_PROFILE.items():
        profile.setdefault(key, value)
    try:
        account = get_account(db, uid)
    except (ValueError, IndexError):
        return profile
    projected = {
        "balance": account.get("balance", 0.0),
        "account_currency": account.get("currency", "USD"),
        "default_risk_percent": account.get("default_risk_percent", 1.0),
        "max_daily_risk_percent": account.get("max_daily_risk_percent", 3.0),
        "max_open_risk_percent": account.get("max_open_risk_percent", 5.0),
        "max_open_trades": account.get("max_open_trades", 5),
        "leverage": account.get("leverage", 1.0),
        "enabled": account.get("risk_enabled", False),
        "prop_firm_enabled": account.get("type") in {"prop_challenge", "prop_funded"},
        "starting_balance": account.get("starting_balance", 0.0),
        "current_equity": account.get("equity", 0.0),
        "max_daily_loss_percent": account.get("max_daily_loss_percent", 5.0),
        "max_total_loss_percent": account.get("max_total_loss_percent", 10.0),
        "profit_target_percent": account.get("profit_target_percent", 8.0),
        "min_trading_days": account.get("min_trading_days", 5),
        "current_trading_days": account.get("current_trading_days", 0),
        "timezone": account.get("timezone", "UTC"),
        "account_id": account.get("id"),
        "account_name": account.get("name"),
        "updated_at": account.get("updated_at"),
    }
    profile.update(projected)
    return profile


def update_risk_profile(db: dict[str, Any], user_id: int | str, values: dict[str, Any]) -> dict[str, Any]:
    """Update legacy inputs while keeping the multi-account Trading OS canonical."""
    mapping = {
        "account_currency": "currency",
        "current_equity": "equity",
        "enabled": "risk_enabled",
    }
    account_values: dict[str, Any] = {}
    for key, value in values.items():
        account_values[mapping.get(key, key)] = value
    if "prop_firm_enabled" in values:
        enabled = bool(values.get("prop_firm_enabled"))
        account_values["type"] = "prop_challenge" if enabled else "personal"
        account_values["phase"] = "phase_1" if enabled else "personal"
    account = get_account(db, user_id)
    create_or_update_account(db, user_id, account_values, account_id=account["id"])
    profile = _profiles(db).setdefault(str(user_id), {})
    for key, value in values.items():
        if key in DEFAULT_RISK_PROFILE:
            profile[key] = value
    profile["updated_at"] = utc_iso()
    return dict(risk_profile(db, user_id))


def personal_exposure(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    exposure = account_exposure(db, user_id)
    return {
        "account_id": exposure.get("account_id"),
        "trade_day": exposure.get("trade_day"),
        "open_trades": exposure.get("open_trades", 0),
        "open_risk_percent": exposure.get("open_risk_percent", 0.0),
        "daily_risk_percent": exposure.get("daily_risk_percent", 0.0),
        "remaining_open_risk_percent": exposure.get("remaining_open_risk_percent", 0.0),
        "remaining_daily_risk_percent": exposure.get("remaining_daily_risk_percent", 0.0),
        "remaining_open_trades": exposure.get("remaining_trade_slots", 0),
    }


def position_for_signal(
    db: dict[str, Any],
    user_id: int | str,
    signal: dict[str, Any],
    *,
    risk_percent: float | None = None,
) -> dict[str, Any]:
    return calculate_position_plan(
        db,
        user_id,
        signal,
        risk_percent=risk_percent,
    )


def prop_firm_snapshot(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    return prop_account_snapshot(db, user_id)
