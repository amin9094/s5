from __future__ import annotations

import copy
import re
from typing import Any, Callable

from core.utils import utc_iso
from modules.feature_flags import ensure_feature_flags

MigrationFn = Callable[[dict[str, Any]], None]
_CURRENT_OPERATIONS_MIGRATION = "operations-intelligence-foundation"
_RESILIENCE_MIGRATION = "resilience-experience-foundation"
_VERSIONED_OPERATIONS_RE = re.compile(r"^\d+\.\d+\.\d+-operations-intelligence$")


def _migration_operations(db: dict[str, Any]) -> None:
    ensure_feature_flags(db)
    operations = db.setdefault("operations", {})
    if not isinstance(operations, dict):
        operations = {}
        db["operations"] = operations
    operations.setdefault("self_healing", {"history": [], "recovery_events": []})
    operations.setdefault("memory_trend", [])
    operations.setdefault("security_events", [])


def _rollback_operations(db: dict[str, Any]) -> None:
    flags = ensure_feature_flags(db)
    for key in list(flags):
        if str(key).startswith(("ops.", "messaging.", "providers.", "trading.", "miniapp.", "admin.", "analytics.")):
            value = flags.get(key)
            if isinstance(value, dict):
                value["enabled"] = False
            else:
                flags[key] = False


def _migration_resilience(db: dict[str, Any]) -> None:
    _migration_operations(db)
    operations = db["operations"]
    operations.setdefault("restore_drill", {})
    operations.setdefault("security_events", [])


def _rollback_resilience(db: dict[str, Any]) -> None:
    _rollback_operations(db)


MIGRATIONS: dict[str, tuple[MigrationFn, MigrationFn]] = {
    _CURRENT_OPERATIONS_MIGRATION: (_migration_operations, _rollback_operations),
    _RESILIENCE_MIGRATION: (_migration_resilience, _rollback_resilience),
}


def _state(db: dict[str, Any]) -> dict[str, Any]:
    operations = db.setdefault("operations", {})
    state = operations.setdefault("app_migrations", {})
    if not isinstance(state, dict):
        state = {}
        operations["app_migrations"] = state
    applied = [str(item) for item in state.get("applied", [])]
    normalized: list[str] = []
    for item in applied:
        if _VERSIONED_OPERATIONS_RE.fullmatch(item):
            item = _CURRENT_OPERATIONS_MIGRATION
        if item not in normalized:
            normalized.append(item)
    state["applied"] = normalized
    rolled = state.get("rolled_back", [])
    if not isinstance(rolled, list):
        rolled = []
    for row in rolled:
        if isinstance(row, dict) and _VERSIONED_OPERATIONS_RE.fullmatch(str(row.get("migration") or "")):
            row["migration"] = _CURRENT_OPERATIONS_MIGRATION
    state["rolled_back"] = rolled[-50:]
    return state


def migration_status(db: dict[str, Any]) -> dict[str, Any]:
    state = _state(db)
    applied = {str(item) for item in state.get("applied", [])}
    return {
        "available": list(MIGRATIONS),
        "applied": sorted(applied),
        "pending": [name for name in MIGRATIONS if name not in applied],
        "rolled_back": list(state.get("rolled_back", []))[-20:],
    }


def apply_migration(db: dict[str, Any], name: str) -> dict[str, Any]:
    clean = str(name)
    if clean not in MIGRATIONS:
        raise ValueError("MIGRATION_UNKNOWN")
    state = _state(db)
    applied = [str(item) for item in state.get("applied", [])]
    if clean in applied:
        return {"migration": clean, "status": "already_applied"}
    MIGRATIONS[clean][0](db)
    applied.append(clean)
    state["applied"] = applied
    state["last_applied_at"] = utc_iso()
    return {"migration": clean, "status": "applied"}


def rollback_migration(db: dict[str, Any], name: str) -> dict[str, Any]:
    clean = str(name)
    if clean not in MIGRATIONS:
        raise ValueError("MIGRATION_UNKNOWN")
    state = _state(db)
    applied = [str(item) for item in state.get("applied", [])]
    if clean not in applied:
        return {"migration": clean, "status": "not_applied"}
    MIGRATIONS[clean][1](db)
    state["applied"] = [item for item in applied if item != clean]
    rolled = state.setdefault("rolled_back", [])
    rolled.append({"migration": clean, "rolled_back_at": utc_iso()})
    state["rolled_back"] = rolled[-50:]
    return {"migration": clean, "status": "rolled_back"}


def simulate_migration(db: dict[str, Any], name: str) -> dict[str, Any]:
    clean = str(name)
    if clean not in MIGRATIONS:
        raise ValueError("MIGRATION_UNKNOWN")
    clone = copy.deepcopy(db)
    before_keys = set(clone)
    result = apply_migration(clone, clean)
    after_keys = set(clone)
    return {
        "migration": clean,
        "status": result["status"],
        "sandbox": True,
        "added_top_level_keys": sorted(after_keys - before_keys),
        "removed_top_level_keys": sorted(before_keys - after_keys),
        "result_schema_version": clone.get("schema_version"),
    }
