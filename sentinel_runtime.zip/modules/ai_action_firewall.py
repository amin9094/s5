from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from modules.admin_access import ALL_PERMISSIONS

# A primary-owner command may assign any permission that exists in SENTINEL's
# canonical permission registry. Delegated-admin requests are still queued for
# the numeric primary owner and cannot bypass the shared authorization layer.
AI_ASSIGNABLE_PERMISSIONS = frozenset(ALL_PERMISSIONS)

# Approval/rejection is a human attestation, never an AI tool. These actions can
# still be used by authenticated Telegram/Mini App callbacks.
HUMAN_ONLY_ACTIONS = frozenset({
    "delegated_admin_approve", "delegated_admin_reject",
    "admin_ai_command_approve", "admin_ai_command_reject",
    "governance_request_approve", "governance_request_reject", "governance_request_apply",
    "admin_ai_proposal_approve", "admin_ai_proposal_reject",
    "ai_signal_draft_approve", "ai_signal_draft_reject",
    "admin_ai_undo_restore", "ai_signal_lab_candidate_to_review",
})

ACTION_RISK_OVERRIDES = {
    "delegated_admin_upsert": "privilege_change",
    "delegated_admin_permissions_set": "privilege_change",
    "delegated_admin_remove": "privilege_change",
    "admin_user_ban": "destructive",
    "signal_delete": "destructive",
    "ai_lesson_delete": "destructive",
    "ai_mission_delete": "destructive",
    "ai_channel_message_operation": "destructive",
    "runtime_mode_update": "destructive",
    "control_reset": "reversible",
    "control_preset": "reversible",
    "control_change": "reversible",
    "ai_signal_draft_create": "reversible",
    "miniapp_signal_publish": "external_side_effect",
    "payment_approve": "financial_mutation",
    "payment_reject": "financial_mutation",
    "admin_vip_plan_create": "financial_mutation",
    "admin_vip_plan_update": "financial_mutation",
    "admin_vip_plan_toggle": "financial_mutation",
    "admin_vip_plan_delete": "destructive",
    "public_discount_create": "sensitive_human_confirmation",
    "ai_ad_approve": "sensitive_human_confirmation",
    "ai_ad_schedule": "external_side_effect",
}

# Known enum and numeric constraints. Generic properties still receive strict
# primitive type validation and additionalProperties=false.
ENUMS: dict[tuple[str, str], set[Any]] = {
    ("runtime_mode_update", "mode"): {"normal", "safe", "maintenance", "read_only", "production", "staging"},
    ("admin_ai_user_access_toggle", "mode"): {"vip_only", "all"},
    ("ai_signal_draft_create", "side"): {"BUY", "SELL", "buy", "sell"},
    ("ai_signal_draft_create", "target"): {"public", "private", "both"},
    ("miniapp_announcement_publish", "delivery"): {"public", "private"},
    ("ai_channel_message_operation", "operation"): {"edit", "delete", "pin", "unpin"},
    ("admin_vip_plan_toggle", "mode"): {"activate", "deactivate", "toggle", "archive"},
}

REQUIRED: dict[str, set[str]] = {
    "control_change": {"module", "field", "value"},
    "control_reset": {"module"},
    "runtime_mode_update": {"mode"},
    "campaign_create": {"name", "category", "audience", "message", "delivery"},
    "public_discount_create": {"code", "percent", "days"},
    "ai_idea_create": {"title", "description"},
    "payment_approve": {"order_id"},
    "payment_reject": {"order_id", "reason"},
    "admin_vip_plan_create": {"name", "price", "duration_days"},
    "admin_vip_plan_update": {"plan_id", "field", "value"},
    "admin_vip_plan_toggle": {"plan_id", "mode"},
    "admin_vip_plan_delete": {"plan_id"},
    "campaign_schedule": {"campaign_id", "scheduled_for"},
    "miniapp_announcement_publish": {"title", "message"},
    "publication_enqueue": {"channel_ids", "content"},
    "content_render": {"template_key", "values"},
    "workspace_create": {"name", "slug"},
    "delegated_admin_upsert": {"user_id", "permissions"},
    "delegated_admin_permissions_set": {"user_id", "permissions"},
    "delegated_admin_remove": {"user_id"},
    "signal_edit": {"signal_id", "field", "value"},
    "signal_result_set": {"signal_id", "result"},
    "signal_delete": {"signal_id"},
    "ai_signal_draft_create": {"symbol", "side", "targets"},
    "miniapp_signal_publish": {"symbol", "side", "targets"},
    "ticket_admin_reply": {"ticket_id", "text"},
    "ai_signal_lab_strategy_create": {"name", "rules"},
    "ai_signal_lab_scan_queue": {"strategy_id", "symbols"},
    "admin_global_search": {"query"},
    "automation_v2_rule_create": {"name", "trigger", "actions"},
    "automation_v2_rule_update": {"rule_id", "changes"},
    "automation_v2_rule_test": {"rule_id", "trigger", "event"},
    "ai_ad_campaign_create": {"name", "product", "objective"},
    "ai_ad_image_generate": {"campaign_id"},
    "ai_ad_summary": {"campaign_id"},
    "ai_ad_approve": {"campaign_id"},
    "ai_ad_schedule": {"campaign_id", "scheduled_for"},
}

ARRAY_KEYS = {"permissions", "targets", "entries", "channel_ids", "variants", "pending_items", "risks", "symbols", "timeframes", "features", "events", "implementation_steps", "conditions", "actions"}
BOOLEAN_KEYS = {"enabled", "active", "approval_required", "autodetect", "generation_test", "force", "one_per_user", "highlight"}
INTEGER_KEYS = {
    "days", "duration_minutes", "reward", "target", "position", "random_bonus_max",
    "reward_points", "priority", "font_delta", "size", "percent", "max_uses",
    "price", "original_price", "duration_days", "sales_limit", "limit",
}
NUMBER_KEYS = {"x", "y", "dx", "dy", "entry", "stop", "risk", "risk_percent", "final_price"}
OBJECT_KEYS = {"payload", "values", "rules", "quiz", "tracking", "guards", "changes", "event"}

_TARGET_KEYS = {
    "user_id", "admin_id", "to_admin_id", "signal_id", "ticket_id", "message_id",
    "job_id", "campaign_id", "incident_id", "mission_id", "lesson_id", "cycle_id",
    "request_id", "handoff_id", "asset_id", "chat_id",
}

_ACTION_FAMILY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "admin": ("ادمین", "مدیر", "مجوز", "دسترسی", "admin", "permission"),
    "idea": ("ایده", "پیشنهاد", "طرح", "قابلیت", "ویژگی", "idea", "proposal", "feature"),
    "signal": ("سیگنال", "ورود", "استاپ", "حد ضرر", "تارگت", "هدف", "قالب", "signal", "entry", "stop", "target"),
    "channel": ("کانال", "پست", "پیام", "انتشار", "پین", "channel", "post", "publish", "pin"),
    "ticket": ("تیکت", "پشتیبانی", "ticket", "support"),
    "user": ("کاربر", "بن", "مسدود", "user", "ban", "unban"),
    "crm": ("crm", "کمپین", "کارزار", "مشتری", "تخفیف", "کد", "campaign", "discount", "coupon"),
    "runtime": (
        "ران‌تایم", "سیستم", "ماژول", "حالت", "مینی اپ", "مینی‌اپ", "ربات", "روشن", "خاموش",
        "runtime", "module", "maintenance", "miniapp", "mini app", "bot", "enable", "disable",
    ),
    "education": ("آموزش", "درس", "ماموریت", "مأموریت", "مسابقه", "lesson", "mission", "contest"),
    "report": ("گزارش", "سلامت", "بررسی", "report", "health", "status"),
    "commerce": (
        "پرداخت", "رسید", "سفارش", "وی آی پی", "vip", "پلن", "اشتراک", "تخفیف", "بازپرداخت",
        "payment", "receipt", "order", "plan", "subscription", "discount", "refund",
    ),
}


def action_family(action: str) -> str:
    name = str(action or "")
    if name.startswith("ai_idea"):
        return "idea"
    if name.startswith("admin_user") or name.startswith("user_"):
        return "user"
    if name.startswith("delegated_") or name.startswith("admin_ai_command") or name.startswith("admin_ai_execution"):
        return "admin"
    if name.startswith("payment_") or name.startswith("admin_vip_plan_") or "discount" in name or "refund" in name:
        return "commerce"
    if "signal" in name:
        return "signal"
    if "channel" in name or "publication" in name or "announcement" in name or "content_" in name or "publisher" in name:
        return "channel"
    if "ticket" in name or "handoff" in name:
        return "ticket"
    if "campaign" in name or "crm" in name or "experiment" in name or "business_inbox" in name or "discount" in name:
        return "crm"
    if "lesson" in name or "mission" in name or "contest" in name:
        return "education"
    if "health" in name or "report" in name or "snapshot" in name:
        return "report"
    return "runtime"


def backend_risk(action: str) -> str:
    name = str(action or "")
    if name in ACTION_RISK_OVERRIDES:
        return ACTION_RISK_OVERRIDES[name]
    if any(token in name for token in ("delete", "remove", "ban", "reset", "cancel")):
        return "destructive"
    if any(token in name for token in ("publish", "enqueue", "reply", "start", "end", "create", "update", "set", "toggle", "edit", "retry", "approve", "reject", "archive")):
        return "reversible"
    return "read"


def _expected_type(key: str) -> type | tuple[type, ...]:
    if key in ARRAY_KEYS:
        return list
    if key in BOOLEAN_KEYS:
        return bool
    if key in INTEGER_KEYS:
        return int
    if key in NUMBER_KEYS:
        return (int, float, str)
    if key in OBJECT_KEYS:
        return dict
    return (str, int, float, bool, type(None))


def json_schema_for(action: str, keys: list[str]) -> dict[str, Any]:
    properties: dict[str, Any] = {}
    for key in keys:
        expected = _expected_type(key)
        if expected is list:
            definition: dict[str, Any] = {"type": "array"}
        elif expected is bool:
            definition = {"type": "boolean"}
        elif expected is int:
            definition = {"type": "integer"}
        elif expected is dict:
            definition = {"type": "object"}
        elif isinstance(expected, tuple) and (int in expected or float in expected) and str in expected:
            definition = {"type": ["number", "string"]}
        else:
            definition = {"type": ["string", "number", "boolean", "null"]}
        enum = ENUMS.get((action, key))
        if enum:
            definition["enum"] = sorted(enum, key=str)
        properties[key] = definition
    return {
        "type": "object",
        "properties": properties,
        "required": sorted(REQUIRED.get(action, set())),
        "additionalProperties": False,
    }


_PARAM_DESCRIPTIONS: dict[str, str] = {
    "code": "Public code exactly as requested by the administrator.",
    "percent": "Discount percentage as an integer from 1 to 100.",
    "days": "Validity duration in days.",
    "order_id": "Numeric payment/order identifier explicitly present in the administrator command.",
    "ticket_id": "Numeric ticket identifier explicitly present in the administrator command.",
    "signal_id": "Signal identifier explicitly present in the administrator command.",
    "user_id": "Numeric Telegram user identifier explicitly present in the administrator command.",
    "plan_id": "VIP plan identifier explicitly present in the administrator command.",
    "side": "BUY or SELL side.",
    "asset_id": "Stored Sentinel admin asset identifier or the literal latest.",
    "text": "Text content supplied by the administrator.",
    "reason": "Administrator-provided reason for the operation.",
    "enabled": "True to enable and false to disable.",
    "status": "Target status supported by the action.",
    "mode": "Target mode supported by the action.",
}


def gemini_function_schema_for(action: str, keys: list[str]) -> dict[str, Any]:
    """Build a Gemini FunctionDeclaration-compatible parameter schema.

    Gemini custom functions support a subset of OpenAPI. In particular, union
    type arrays used by the internal validator are not portable. This adapter
    keeps one primitive type per field while the existing server validator
    remains the final authority and performs safe coercion.
    """
    properties: dict[str, Any] = {}
    for key in keys:
        expected = _expected_type(key)
        if expected is list:
            definition: dict[str, Any] = {"type": "array", "items": {"type": "string"}}
        elif expected is bool:
            definition = {"type": "boolean"}
        elif expected is int:
            definition = {"type": "integer"}
        elif expected is dict:
            definition = {
                "type": "string",
                "description": _PARAM_DESCRIPTIONS.get(key, "A JSON object serialized as a string."),
            }
        elif key in NUMBER_KEYS:
            definition = {"type": "number"}
        else:
            definition = {"type": "string"}
        enum = ENUMS.get((action, key))
        if enum:
            definition["enum"] = sorted(enum, key=str)
        description = _PARAM_DESCRIPTIONS.get(key)
        if description:
            definition["description"] = description
        properties[key] = definition
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    required = sorted(REQUIRED.get(action, set()))
    if required:
        schema["required"] = required
    return schema


def validate_permissions_for_ai(values: Any) -> list[str]:
    if not isinstance(values, list):
        raise ValueError("AI_PERMISSIONS_LIST_REQUIRED")
    cleaned = list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))
    invalid = [value for value in cleaned if value not in AI_ASSIGNABLE_PERMISSIONS]
    if invalid:
        raise PermissionError("AI_PERMISSION_GRANT_BLOCKED:" + ",".join(invalid[:10]))
    return cleaned


def _coerce_value(action: str, key: str, value: Any) -> Any:
    expected = _expected_type(key)
    if value is None:
        return None
    if expected is list:
        if not isinstance(value, list):
            raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}")
        return value[:100]
    if expected is bool:
        if not isinstance(value, bool):
            raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}")
        return value
    if expected is int:
        if isinstance(value, bool):
            raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}")
        try:
            return int(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}") from exc
    if expected is dict:
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"AI_TOOL_FIELD_TYPE_INVALID:{key}")
        return value
    enum = ENUMS.get((action, key))
    if enum and value not in enum:
        raise ValueError(f"AI_TOOL_FIELD_ENUM_INVALID:{key}")
    return value


def validate_payload(action: str, payload: dict[str, Any], keys: list[str]) -> dict[str, Any]:
    if action in HUMAN_ONLY_ACTIONS:
        raise PermissionError("AI_HUMAN_ONLY_ACTION")
    if not isinstance(payload, dict):
        raise ValueError("AI_TOOL_PAYLOAD_OBJECT_REQUIRED")
    allowed = set(keys)
    extras = sorted(set(map(str, payload)) - allowed)
    if extras:
        raise ValueError("AI_TOOL_ADDITIONAL_PROPERTIES_BLOCKED:" + ",".join(extras[:10]))
    missing = sorted(key for key in REQUIRED.get(action, set()) if key not in payload or payload.get(key) in (None, "", []))
    if missing:
        raise ValueError("AI_TOOL_REQUIRED_FIELDS_MISSING:" + ",".join(missing))
    result = {key: _coerce_value(action, key, value) for key, value in payload.items()}
    if action in {"ai_signal_draft_create", "miniapp_signal_publish"}:
        if not result.get("entry") and not result.get("entries"):
            raise ValueError("AI_TOOL_REQUIRED_FIELDS_MISSING:entry_or_entries")
        if not result.get("stop") and not result.get("stop_loss"):
            raise ValueError("AI_TOOL_REQUIRED_FIELDS_MISSING:stop_or_stop_loss")
    if action in {"delegated_admin_upsert", "delegated_admin_permissions_set"}:
        result["permissions"] = validate_permissions_for_ai(result.get("permissions"))
    return result


def _contains_explicit_target(command: str, value: Any) -> bool:
    text = str(command or "").casefold()
    token = str(value or "").strip().casefold()
    if not token:
        return False
    if token in text:
        return True
    # Numeric IDs must be explicitly present. Pseudonyms are never accepted as
    # implicit targets for an autonomous destructive/privilege operation.
    digits = "".join(ch for ch in token if ch.isdigit())
    numeric_tokens = set(re.findall(r"\d+", text))
    return bool(digits and digits in numeric_tokens)


def bind_to_admin_intent(action: str, payload: dict[str, Any], admin_command: str) -> None:
    command = str(admin_command or "").strip().casefold()
    family = action_family(action)
    if not command or not any(keyword.casefold() in command for keyword in _ACTION_FAMILY_KEYWORDS[family]):
        raise PermissionError("AI_TOOL_NOT_EXPLICITLY_REQUESTED")
    risk = backend_risk(action)
    if risk in {"destructive", "privilege_change"}:
        target_values = [payload[key] for key in _TARGET_KEYS if key in payload and payload[key] not in (None, "")]
        if target_values and not all(_contains_explicit_target(command, value) for value in target_values):
            raise PermissionError("AI_TOOL_TARGET_NOT_BOUND_TO_ADMIN_COMMAND")


def stable_execution_key(*, conversation_id: Any, response_id: Any, index: int, action: str, payload: dict[str, Any]) -> str:
    material = json.dumps(
        {
            "conversation_id": str(conversation_id or ""),
            "response_id": str(response_id or ""),
            "index": int(index),
            "action": str(action),
            "payload": payload,
        },
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=str,
    )
    return "ai:" + hashlib.sha256(material.encode("utf-8")).hexdigest()


def is_human_confirmation(transport: dict[str, Any] | None) -> bool:
    row = transport or {}
    return bool(row.get("human_confirmation")) and str(row.get("source") or "") in {
        "telegram_callback", "miniapp_human_action", "telegram_command",
    }


@dataclass(frozen=True)
class ExecutionPlanItem:
    index: int
    action: str
    risk: str
    reversible: bool
    execution_key: str


def build_execution_plan(calls: list[dict[str, Any]], *, conversation_id: Any, response_id: Any) -> list[ExecutionPlanItem]:
    result: list[ExecutionPlanItem] = []
    for index, call in enumerate(calls):
        risk = backend_risk(call["action"])
        result.append(ExecutionPlanItem(
            index=index,
            action=call["action"],
            risk=risk,
            reversible=risk in {"read", "reversible"},
            execution_key=stable_execution_key(
                conversation_id=conversation_id, response_id=response_id, index=index,
                action=call["action"], payload=call.get("payload") or {},
            ),
        ))
    return result
