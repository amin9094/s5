"""Read models over the existing coupon ownership and reward ledgers."""
from __future__ import annotations
from datetime import UTC, datetime
from typing import Any
from core.utils import parse_dt


def wallet_items(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    uid = str(user_id)
    owned = {str(code): row for code, row in db.get("discount_codes", {}).items()
             if str(row.get("assigned_to")) == uid}
    rows = [dict(row) for row in db.get("user_rewards", [])
            if str(row.get("user_id")) == uid and str(row.get("reference_id")) not in owned]
    now = datetime.now(UTC)
    for code, coupon in owned.items():
        expiry = parse_dt(coupon.get("expires_at"))
        state = str(coupon.get("status") or "active")
        if coupon.get("used_at") or state == "used":
            state = "used"
        elif expiry and expiry <= now:
            state = "expired"
        elif state == "active" and parse_dt(coupon.get("starts_at")) and parse_dt(coupon["starts_at"]) > now:
            state = "scheduled"
        elif state == "active" and coupon.get("reserved_order_id"):
            state = "reserved"
        discount = (f"{int(coupon.get('fixed_amount', 0)):,} تومان" if coupon.get('discount_type') == 'fixed'
                    else f"{coupon.get('percent', 0)}%")
        rows.append({"id": f"coupon:{code}", "title": "کد تخفیف", "type": "discount",
                     "detail": f"{discount} | {code}", "status": state,
                     "source": coupon.get("issued_via") or coupon.get("source"),
                     "created_at": coupon.get("assigned_at") or coupon.get("created_at"),
                     "expires_at": coupon.get("expires_at"), "code": code,
                     "conditions": {"plans": coupon.get("applicable_plan_ids", []),
                         "per_user_limit": coupon.get("max_uses_per_user", 1),
                         "minimum_purchase": coupon.get("minimum_order_amount", 0),
                         "renewal_only": bool(coupon.get("renewal_only")),
                         "starts_at": coupon.get("starts_at")}})
    return sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)


def point_summary(db: dict[str, Any], user_id: int | str, *, cursor: int = 0, limit: int = 10, language: str = 'fa') -> dict[str, Any]:
    uid = str(user_id)
    history = [row for row in db.get("point_history", []) if str(row.get("user_id")) == uid]
    # Old deployments may have pruned ledger rows. Do not invent lifetime totals.
    earned = sum(max(0, int(row.get("amount", 0))) for row in history)
    spent = sum(max(0, -int(row.get("amount", 0))) for row in history)
    ordered = sorted(history, key=lambda row: (str(row.get("created_at") or ""), int(row.get("id", 0) or 0)), reverse=True)
    ordered=[{**row,'reason_label':point_reason_label(row.get('reason'),language)} for row in ordered]
    offset, size = max(0, int(cursor)), max(1, min(50, int(limit)))
    from modules.economic_refunds import outstanding_point_debt
    return {"recovery_due":outstanding_point_debt(db,uid),"total": len(history), "next_cursor": offset + size if offset + size < len(history) else None, "balance": int(db.get("user_points", {}).get(uid, 0)), "earned": earned,
            "spent": spent, "history": ordered[offset:offset + size]}


def reward_source_label(value, language='fa'):
    labels={'mission':('مأموریت','Mission'),'contest':('مسابقه','Contest'),'referral':('دعوت دوستان','Referral'),
            'reward_shop':('فروشگاه جوایز','Rewards store'),'admin_wizard':('پاداش مدیر','Admin reward'),
            'admin':('مدیر','Admin'),'stock':('موجودی جوایز','Reward stock'),'vip_purchase':('خرید VIP','VIP purchase')}
    raw=str(value or '')
    if raw.startswith('auto:'):raw=raw[5:]
    raw=raw.split(':',1)[0]
    return labels.get(raw, ('سایر پاداش‌ها','Other rewards'))[language=='en']


def point_reason_label(value, language='fa'):
    reason=str(value or '')
    labels={'vip_purchase':('خرید اشتراک VIP','VIP purchase'),'mission':('تکمیل مأموریت','Mission completion'),
            'price_contest':('جایزه مسابقه قیمت','Price contest prize'),'chart_contest':('جایزه مسابقه چارت','Chart contest prize'),
            'candle_contest':('جایزه مسابقه کندل','Candle contest prize'),'news_direction_contest':('جایزه مسابقه خبر','News contest prize'),
            'reward':('دریافت جایزه','Reward redemption'),'reward_delivery':('تحویل جایزه','Reward delivery'),
            'purchase_refund':('بازگردانی امتیاز خرید','Purchase refund reversal'),'reward_refund':('بازگشت امتیاز جایزه','Reward point refund'),'referral':('دعوت دوستان','Referral')}
    return labels.get(reason.split(':',1)[0],(reason,reason))[language=='en']
