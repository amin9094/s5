from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from core.domain import is_vip
from core.utils import parse_dt
from modules.analytics import user_account_snapshot
from modules.economic_calendar import cached_calendar_events
from modules.portfolio import journal_stats, watchlist_for_user
from modules.signal_portal import signal_portal_stats, user_visible_signals
from modules.support import user_tickets


def user_today_snapshot(db: dict[str, Any], user_id: int | str, *, now: datetime | None = None) -> dict[str, Any]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    account = user_account_snapshot(db, user_id, now=current)
    vip = is_vip(db, user_id)
    signals = signal_portal_stats(db, user_id, vip=vip)
    visible = user_visible_signals(db, vip=vip)
    open_signals = [row for row in visible if str(row.get('status') or 'open') in {'open', 'partial', 'active'}]
    latest_signal = open_signals[0] if open_signals else (visible[0] if visible else None)
    watchlist = watchlist_for_user(db, user_id)
    journal = journal_stats(db, user_id)
    tickets = user_tickets(db, user_id)
    open_tickets = [row for row in tickets if str(row.get('status') or 'open') not in {'closed', 'resolved'}]
    try:
        events = cached_calendar_events(db, user_id, period='today', local_now=current)
    except Exception:
        events = []
    future_events = []
    for event in events:
        when = parse_dt(event.get('datetime'))
        if when and when.astimezone(UTC) >= current:
            future_events.append((when, event))
    future_events.sort(key=lambda pair: pair[0])
    next_event = future_events[0][1] if future_events else None
    return {
        'account': account,
        'vip_active': bool(account.get('vip_active')),
        'vip_days_left': int(account.get('vip_days_left', 0) or 0),
        'points': int(account.get('points', 0) or 0),
        'signals': signals,
        'latest_signal': dict(latest_signal) if isinstance(latest_signal, dict) else None,
        'watchlist_count': len(watchlist),
        'journal_total': int(journal.get('total', 0) or 0),
        'journal_open': int(journal.get('open', 0) or 0),
        'open_ticket_count': len(open_tickets),
        'active_alert_count': int(account.get('active_alert_count', 0) or 0),
        'next_event': dict(next_event) if isinstance(next_event, dict) else None,
    }
