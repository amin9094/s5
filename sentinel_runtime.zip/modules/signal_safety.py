from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.admin_control_center import module_state as control_module_state
from modules.market_scope import signal_market_category
from modules.risk_exposure import evaluate_pending_exposure
from modules.signal_engine import normalize_entries
from modules.signal_team_rules import evaluate_team_signal_gate

FINAL_SIGNAL_STATUSES = {
    "target_complete",
    "manual_close",
    "no_entry",
    "stop",
    "cancelled",
    "expired",
}


@dataclass(frozen=True, slots=True)
class SignalSafetyReport:
    ok: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    metrics: dict[str, Any]
    expires_at: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "metrics": dict(self.metrics),
            "expires_at": self.expires_at,
        }


def _decimal(value: Any, field: str) -> Decimal:
    try:
        number = Decimal(str(value).strip().replace(",", ""))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field} عدد معتبر نیست") from exc
    if not number.is_finite() or number <= 0:
        raise ValueError(f"{field} باید بزرگ‌تر از صفر باشد")
    return number


def entry_display(entries: str | list[str]) -> str:
    """Create a compact image-safe entry value while preserving the full list in data/caption."""
    values = normalize_entries(entries)
    if len(values) == 1:
        return values[0]
    numbers = [_decimal(item, "قیمت ورود") for item in values]
    low = min(numbers)
    high = max(numbers)
    if len(values) == 2:
        return f"{_format_decimal(low)} – {_format_decimal(high)}"
    # Three to five entries are deliberately shown as a range on the artwork;
    # the full ladder remains in the caption and canonical database record.
    return f"{_format_decimal(low)} – {_format_decimal(high)}"


def _format_decimal(value: Decimal) -> str:
    text = format(value.normalize(), "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def worst_case_entry(entries: str | list[str], side: str) -> Decimal:
    values = [_decimal(item, "قیمت ورود") for item in normalize_entries(entries)]
    normalized = str(side or "").strip().lower()
    if normalized == "buy":
        return max(values)
    if normalized == "sell":
        return min(values)
    raise ValueError("نوع سیگنال باید BUY یا SELL باشد")


def risk_reward_ratio(entries: str | list[str], stop: Any, target: Any, side: str) -> Decimal:
    entry = worst_case_entry(entries, side)
    stop_value = _decimal(stop, "حد ضرر")
    target_value = _decimal(target, "تارگت")
    normalized = str(side or "").strip().lower()
    if normalized == "buy":
        risk = entry - stop_value
        reward = target_value - entry
    elif normalized == "sell":
        risk = stop_value - entry
        reward = entry - target_value
    else:
        raise ValueError("نوع سیگنال باید BUY یا SELL باشد")
    if risk <= 0 or reward <= 0:
        return Decimal("0")
    return reward / risk


def _relevant_currencies(symbol: Any) -> set[str]:
    compact = "".join(ch for ch in str(symbol or "").upper() if ch.isalnum())
    if not compact:
        return set()
    aliases = {
        "XAU": "USD",
        "XAG": "USD",
        "US100": "USD",
        "NAS100": "USD",
        "US500": "USD",
        "SPX500": "USD",
        "US30": "USD",
        "DJ30": "USD",
        "GER40": "EUR",
        "DE40": "EUR",
        "UK100": "GBP",
        "JP225": "JPY",
    }
    currencies: set[str] = set()
    for prefix, currency in aliases.items():
        if compact.startswith(prefix):
            currencies.add(currency)
    if len(compact) >= 6:
        first, last = compact[:3], compact[3:6]
        known = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "CNY"}
        if first in known:
            currencies.add(first)
        if last in known:
            currencies.add(last)
    if compact.endswith(("USDT", "USDC", "FDUSD", "TUSD", "BUSD", "USD")):
        currencies.add("USD")
    return currencies


def high_impact_conflicts(
    events: Iterable[dict[str, Any]],
    symbol: Any,
    *,
    now: datetime | None = None,
    window_minutes: int = 30,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    currencies = _relevant_currencies(symbol)
    if not currencies:
        return []
    window = timedelta(minutes=max(0, int(window_minutes)))
    conflicts: list[dict[str, Any]] = []
    for event in events:
        if not isinstance(event, dict):
            continue
        if str(event.get("impact") or "").lower() != "high":
            continue
        if str(event.get("currency") or "").upper() not in currencies:
            continue
        when = parse_dt(event.get("datetime"))
        if when is None:
            continue
        if abs(when.astimezone(UTC) - current) <= window:
            conflicts.append(dict(event))
    conflicts.sort(key=lambda row: str(row.get("datetime") or ""))
    return conflicts


def _active_signals(db: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        row
        for row in db.get("signals", [])
        if isinstance(row, dict) and str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES
    ]


def evaluate_signal_safety(
    db: dict[str, Any],
    payload: dict[str, Any],
    *,
    calendar_events: Iterable[dict[str, Any]] | None = None,
    now: datetime | None = None,
) -> SignalSafetyReport:
    """Apply runtime signal controls before preview, scheduling and publication."""
    state = control_module_state(db, "signals")
    errors: list[str] = []
    warnings: list[str] = []
    current = (now or datetime.now(UTC)).astimezone(UTC)

    if not bool(state.get("enabled", True)):
        warnings.append("فلگ عمومی ماژول سیگنال غیرفعال است؛ انتشار مستقیم ادمین بدون محدودیت ادامه پیدا می‌کند")

    try:
        entries = normalize_entries(payload.get("entries") or payload.get("entry"))
    except ValueError as exc:
        entries = []
        errors.append(str(exc))
    side = str(payload.get("side") or "").strip().lower()
    if side not in {"buy", "sell"}:
        errors.append("نوع سیگنال باید BUY یا SELL باشد")
    symbol = str(payload.get("symbol") or "").strip().upper()
    if not symbol:
        errors.append("نماد سیگنال لازم است")
    targets = [str(item) for item in payload.get("targets", []) if str(item).strip()]
    if not targets:
        errors.append("حداقل یک تارگت لازم است")

    try:
        risk_value = _decimal(payload.get("risk"), "درصد ریسک")
    except ValueError as exc:
        errors.append(str(exc))
        risk_value = Decimal("0")
    rr_value = Decimal("0")
    if targets and entries and side in {"buy", "sell"}:
        target_selector = str(state.get("rr_target", "first") or "first")
        selected_target = targets[-1] if target_selector == "final" else targets[0]
        try:
            rr_value = risk_reward_ratio(entries, payload.get("stop"), selected_target, side)
        except ValueError as exc:
            errors.append(str(exc))
        # R/R is calculated for reporting only. Publication must not be
        # blocked by a minimum reward-to-risk threshold. Directional level
        # validation (target/stop on the correct side) remains enforced by the
        # signal builder before this gate is reached.

    # Admin publication has no policy ceilings. We still calculate exposure and
    # legacy team metrics for dashboards/audit, but they are informational and
    # never prevent preview, scheduling or publication.
    active = _active_signals(db)
    same_symbol = [row for row in active if str(row.get("symbol") or "").upper() == symbol]
    exposure = evaluate_pending_exposure(db, payload, state)
    team_gate = evaluate_team_signal_gate(
        db, payload, now=current, override=bool(payload.get("owner_override", False)),
    )

    conflicts: list[dict[str, Any]] = []
    if bool(state.get("news_guard", True)):
        if calendar_events is None:
            warnings.append("News Guard در بررسی اولیه بدون داده زنده تقویم ارزیابی شد؛ هنگام انتشار دوباره کنترل می‌شود")
        else:
            conflicts = high_impact_conflicts(
                calendar_events,
                symbol,
                now=current,
                window_minutes=int(state.get("news_guard_minutes", 30) or 30),
            )
            if conflicts:
                names = "، ".join(str(item.get("title_fa") or item.get("title") or "خبر مهم")[:80] for item in conflicts[:3])
                warnings.append(f"News Guard اطلاع‌رسانی: خبر مهم نزدیک زمان انتشار است: {names}")

    expiry_hours = int(state.get("expiry_hours", 48) or 48)
    expires_at = utc_iso(current + timedelta(hours=max(1, expiry_hours)))
    entry_text = entry_display(entries) if entries else "—"
    worst_entry = _format_decimal(worst_case_entry(entries, side)) if entries and side in {"buy", "sell"} else "—"
    metrics = {
        "entry_display": entry_text,
        "entry_count": len(entries),
        "worst_case_entry": worst_entry,
        "rr": round(float(rr_value), 4),
        "rr_enforced": False,
        "rr_policy": "informational_only",
        "risk_percent": float(risk_value),
        "active_signals": len(active),
        "same_symbol_open": len(same_symbol),
        "news_conflicts": len(conflicts),
        "market_category": signal_market_category(payload),
        "exposure": exposure.snapshot,
        "team_gate": team_gate.metrics,
        "publication_limits_enforced": False,
        "publication_policy": "admin_unrestricted",
    }
    return SignalSafetyReport(not errors, tuple(errors), tuple(warnings), metrics, expires_at)


def format_safety_report(report: SignalSafetyReport) -> str:
    icon = "✅" if report.ok else "⛔️"
    lines = [f"{icon} <b>گیت ایمنی سیگنال</b>"]
    rr = float(report.metrics.get("rr", 0) or 0)
    exposure = report.metrics.get("exposure", {}) if isinstance(report.metrics.get("exposure"), dict) else {}
    lines.append(
        f"R/R: <b>{rr:.2f}</b> | ریسک: <b>{float(report.metrics.get('risk_percent', 0) or 0):g}%</b> | "
        f"ورودی: <b>{int(report.metrics.get('entry_count', 0) or 0)}</b>"
    )
    if exposure:
        lines.append(
            f"ریسک باز پس از انتشار: <b>{float(exposure.get('total_open_risk', 0) or 0):.2f}%</b> | "
            f"ریسک امروز: <b>{float(exposure.get('daily_new_risk', 0) or 0):.2f}%</b>"
        )
    for item in report.errors:
        lines.append(f"❌ {item}")
    for item in report.warnings:
        lines.append(f"⚠️ {item}")
    return "\n".join(lines)


def create_signal_approval(
    db: dict[str, Any],
    *,
    payload: dict[str, Any],
    target: str,
    requested_by: int | str,
    run_at: str | None = None,
    source: str = "human_admin",
    review_requirements: list[str] | None = None,
) -> dict[str, Any]:
    state = control_module_state(db, "signals")
    minutes = int(state.get("approval_expiry_minutes", 30) or 30)
    row = {
        "id": next_id(db, "signal_approval"),
        "payload": dict(payload),
        "target": str(target),
        "requested_by": str(requested_by),
        "run_at": run_at,
        "source": str(source or "human_admin")[:80],
        "review_requirements": list(review_requirements or []),
        "status": "pending",
        "created_at": utc_iso(),
        "expires_at": utc_iso(utc_now() + timedelta(minutes=max(5, min(minutes, 1440)))),
        "resolved_by": None,
        "resolved_at": None,
        "execution_status": None,
        "execution_result": None,
    }
    db.setdefault("signal_approvals", []).append(row)
    db["signal_approvals"] = db["signal_approvals"][-1000:]
    return row


def pending_signal_approvals(db: dict[str, Any]) -> list[dict[str, Any]]:
    now = utc_now()
    rows: list[dict[str, Any]] = []
    for row in db.setdefault("signal_approvals", []):
        if not isinstance(row, dict) or row.get("status") != "pending":
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry is not None and expiry <= now:
            row["status"] = "expired"
            row["resolved_at"] = utc_iso()
            row.setdefault("expiry_notification_status", "pending")
            continue
        rows.append(row)
    rows.sort(key=lambda item: int(item.get("id", 0) or 0), reverse=True)
    return rows


def claim_expired_signal_approvals(
    db: dict[str, Any],
    *,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Materialize expiration in the background and claim requester notices."""
    pending_signal_approvals(db)
    claimed: list[dict[str, Any]] = []
    for row in db.setdefault("signal_approvals", []):
        if len(claimed) >= max(1, int(limit)):
            break
        if (
            not isinstance(row, dict)
            or row.get("status") != "expired"
            or row.get("expiry_notification_status") not in {None, "pending", "retry"}
        ):
            continue
        row["expiry_notification_status"] = "sending"
        row["expiry_notification_attempts"] = int(
            row.get("expiry_notification_attempts", 0) or 0
        ) + 1
        claimed.append(dict(row))
    return claimed


def mark_expired_signal_approval_notice(
    db: dict[str, Any],
    approval_id: int | str,
    *,
    success: bool,
    error: str = "",
) -> dict[str, Any]:
    target = str(approval_id)
    for row in db.setdefault("signal_approvals", []):
        if isinstance(row, dict) and str(row.get("id")) == target:
            row["expiry_notification_status"] = "sent" if success else "retry"
            row["expiry_notification_error"] = None if success else str(error)[:300]
            row["expiry_notified_at"] = utc_iso() if success else None
            return row
    raise ValueError("درخواست تأیید سیگنال پیدا نشد")


def resolve_signal_approval(
    db: dict[str, Any],
    approval_id: int | str,
    admin_id: int | str,
    *,
    approve: bool,
) -> dict[str, Any]:
    target = int(approval_id)
    for row in reversed(db.setdefault("signal_approvals", [])):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        if row.get("status") != "pending":
            raise ValueError("این درخواست قبلاً تعیین تکلیف شده است")
        expiry = parse_dt(row.get("expires_at"))
        if expiry is not None and expiry <= utc_now():
            row["status"] = "expired"
            row["resolved_at"] = utc_iso()
            raise ValueError("مهلت تأیید سیگنال تمام شده است")
        row["status"] = "approved" if approve else "rejected"
        row["resolved_by"] = str(admin_id)
        row["resolved_at"] = utc_iso()
        row["human_confirmation"] = True
        row["human_confirmation_source"] = "telegram_callback"
        if approve and str(row.get("source") or "").startswith("gemini"):
            payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
            required = {"entry", "stop", "targets"}
            if not required.issubset(payload) or not payload.get("targets"):
                raise ValueError("نقاط Entry/SL/TP پیش‌نویس هوش مصنوعی کامل نیست")
            row["confirmed_fields"] = ["entry", "stop", "targets"]
        return row
    raise ValueError("درخواست تأیید سیگنال پیدا نشد")


def mark_signal_approval_execution(
    db: dict[str, Any], approval_id: int | str, *, status: str, result: str
) -> dict[str, Any]:
    target = int(approval_id)
    for row in reversed(db.setdefault("signal_approvals", [])):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target:
            row["execution_status"] = str(status)
            row["execution_result"] = str(result)[:1000]
            row["executed_at"] = utc_iso()
            return row
    raise ValueError("درخواست تأیید سیگنال پیدا نشد")


def expire_due_signals(db: dict[str, Any], *, now: datetime | None = None) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    expired: list[dict[str, Any]] = []
    for row in db.get("signals", []):
        if not isinstance(row, dict) or str(row.get("status") or "open") in FINAL_SIGNAL_STATUSES:
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry is None or expiry > current:
            continue
        previous = str(row.get("status") or "open")
        row["status"] = "expired"
        row["expired_at"] = utc_iso(current)
        row["result_at"] = row["expired_at"]
        row["expiration_reason"] = "signal_expiry"
        row.setdefault("lifecycle_history", []).append(
            {
                "from": previous,
                "to": "expired",
                "event": "expired",
                "admin_id": "system",
                "at": row["expired_at"],
                "source": "signal_expiry_job",
            }
        )
        row["lifecycle_history"] = row["lifecycle_history"][-100:]
        expired.append(row)
    return expired
